# NovaTek Platform

NovaTek's public website, lead-generation engine, CRM, sales pipeline, executive portals and internal operations
platform — one Next.js app on Supabase.

> **Brand lock.** The NovaTek logo, app icon, company name and its lettering are served from the original files in
> `public/brand/` and are never changed, recoloured or restyled. `tests/brand/brand-lock.test.ts` fails the build if
> anyone tries. See [docs/ARCHITECTURE.md §1](docs/ARCHITECTURE.md).

## What's inside

| Area | Highlights |
|---|---|
| Public website | Home, Services, Solutions, Industries, Portfolio, Case Studies, About, Contact, campaign landing pages (`/l/<slug>`), client proposal links (`/p/<token>`) |
| Lead generation | Website/landing-page/campaign forms create real leads (server-validated, rate-limited, honeypot), UTM capture, CSV import with preview, manual entry |
| CRM | Configurable statuses, scoring (0–100, Cold → Very Hot), qualification questions, duplicate flagging + safe merge, full activity timeline, follow-ups |
| Sales | Deal board with forecast, proposals with evidence-based statuses, atomic won/lost (lead → client → commission), clients, commission rules with two-person approval |
| Work | Projects with members and progress from tasks, tasks (bugs, design, technical…), meetings with participants and reminders, documents |
| Marketing | Campaigns with attribution and cost per lead, landing pages, website content |
| Executives | CEO, COO, CTO, CMO portals, personalised dashboards, analytics with date ranges, exportable reports |
| Admin | Users, roles & permission matrix, departments, settings, integrations registry, announcements, audit log, exports with re-authentication |
| Platform | RBAC enforced by Postgres RLS + server actions, audit log, notifications + scheduled reminders, global search, PWA, dark/light mode |

## Quick start (local)

```bash
cp .env.example .env.local        # fill in your Supabase project values
npm install
# apply supabase/migrations/*.sql to your project (see docs/SETUP.md)
npm run admin:create -- you@company.com "Your Name"
npm run dev
```

## Commands

| Command | What it does |
|---|---|
| `npm run dev` / `build` / `start` | Next.js |
| `npm run typecheck` | Route types + TypeScript |
| `npm run lint` | ESLint |
| `npm test` | Unit + database security tests (needs a local Postgres, see docs/SETUP.md) |
| `npm run db:reset:local` | Recreate the local test database from migrations |
| `npm run admin:create` | Create the first Super Admin |
| `npm run e2e` | End-to-end browser flow against a running app |

## Documentation

- [docs/SETUP.md](docs/SETUP.md) — environment variables, Supabase setup, migrations, first admin, local testing
- [docs/SECURITY.md](docs/SECURITY.md) — authentication, roles, permissions, RLS, audit, data handling
- [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) — Vercel + Supabase production deployment, cron, backups and recovery
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) — architecture decisions, data model, lead-generation design
