#!/usr/bin/env bash
# Recreate the LOCAL test database: Supabase shim + all migrations, in order.
# Usage: DATABASE_URL=postgres://user:pass@localhost:5432/novatek_test scripts/db-reset-local.sh
set -euo pipefail

: "${DATABASE_URL:?DATABASE_URL is required}"
DB_NAME="${DATABASE_URL##*/}"
ADMIN_URL="${DATABASE_URL%/*}/postgres"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

psql "$ADMIN_URL" -v ON_ERROR_STOP=1 -q -c "drop database if exists \"$DB_NAME\" with (force);" -c "create database \"$DB_NAME\";"
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -q -f "$ROOT/supabase/tests/supabase_shim.sql"
for f in "$ROOT"/supabase/migrations/*.sql; do
  echo "applying $(basename "$f")"
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -q -f "$f"
done
echo "local database ready: $DB_NAME"
