#!/usr/bin/env node
// Creates (or promotes) the first Super Admin. Run once after migrations, from a trusted machine.
// Usage: NEXT_PUBLIC_SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... node scripts/create-super-admin.mjs admin@company.com "Full Name"
// The password is read from the SUPER_ADMIN_PASSWORD env var or prompted (never passed on the command line).
import { createInterface } from "node:readline/promises";
import { createClient } from "@supabase/supabase-js";

const [email, fullName = "Administrator"] = process.argv.slice(2);
const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!email || !url || !key) {
  console.error("Usage: NEXT_PUBLIC_SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... node scripts/create-super-admin.mjs <email> [full name]");
  process.exit(1);
}
let password = process.env.SUPER_ADMIN_PASSWORD;
if (!password) {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  password = await rl.question("Password (min 12 chars, upper, lower, number): ");
  rl.close();
}
if (!password || password.length < 12 || !/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/\d/.test(password)) {
  console.error("Password too weak.");
  process.exit(1);
}

const admin = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
let userId;
const created = await admin.auth.admin.createUser({ email, password, email_confirm: true, user_metadata: { full_name: fullName } });
if (created.error) {
  if (!/already/i.test(created.error.message)) throw created.error;
  const { data } = await admin.auth.admin.listUsers({ perPage: 1000 });
  userId = data.users.find((u) => u.email?.toLowerCase() === email.toLowerCase())?.id;
  if (!userId) throw new Error("User exists but could not be found");
  console.log("User already existed — promoting to Super Admin.");
} else {
  userId = created.data.user.id;
}
await admin.from("profiles").update({ full_name: fullName, status: "active" }).eq("id", userId);
const { data: role } = await admin.from("roles").select("id").eq("key", "super_admin").single();
const { error } = await admin.from("user_roles").upsert({ user_id: userId, role_id: role.id });
if (error) throw error;
await admin.rpc("log_audit_event", { p_actor: userId, p_action: "user.bootstrap_super_admin", p_entity: "user", p_entity_id: userId, p_metadata: { email } });
console.log(`Super Admin ready: ${email}`);
