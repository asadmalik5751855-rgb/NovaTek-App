-- NovaTek platform — Row Level Security. Default deny on every table; access is granted by permission.

create or replace function public.can_view_lead_row(p_assigned uuid, p_created uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select has_permission('leads.view_all')
      or (has_permission('leads.view_own') and auth.uid() is not null
          and (p_assigned = auth.uid() or p_created = auth.uid()))
$$;

create or replace function public.can_edit_lead_row(p_assigned uuid, p_created uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select has_permission('leads.edit') and (
    has_permission('leads.view_all')
    or (auth.uid() is not null and (p_assigned = auth.uid() or p_created = auth.uid()))
  )
$$;

create or replace function public.can_edit_lead(p_lead uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from leads l where l.id = p_lead and can_edit_lead_row(l.assigned_to, l.created_by))
$$;

revoke execute on function public.can_view_lead_row(uuid, uuid), public.can_edit_lead_row(uuid, uuid),
  public.can_edit_lead(uuid) from public, anon;
grant execute on function public.can_view_lead_row(uuid, uuid), public.can_edit_lead_row(uuid, uuid),
  public.can_edit_lead(uuid) to authenticated;

-- Enable RLS everywhere
do $$
declare t text;
begin
  foreach t in array array['departments', 'profiles', 'roles', 'permissions', 'role_permissions', 'user_roles',
    'lead_sources', 'lead_statuses', 'services', 'industries', 'countries', 'scoring_rules', 'settings',
    'leads', 'lead_activities', 'lead_tags', 'lead_tag_relations', 'lead_submissions', 'notifications', 'audit_logs']
  loop
    execute format('alter table public.%I enable row level security', t);
    execute format('alter table public.%I force row level security', t);
  end loop;
end $$;

-- Anonymous visitors: nothing except the public catalogue lists used by the website form.
revoke all on all tables in schema public from anon;
grant select on public.services, public.countries to anon;

-- ---------------------------------------------------------------- profiles
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or has_permission('employees.view') or has_permission('users.manage_roles'));
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid() or has_permission('employees.manage'))
  with check (id = auth.uid() or has_permission('employees.manage'));

-- Colleague directory: names/titles only, for showing assignees. Runs as owner, so it reveals
-- no contact or HR fields; only active users can read it.
create view public.directory with (security_barrier = true) as
  select p.id, p.full_name, p.avatar_url, p.designation, p.department_id, p.status
  from public.profiles p
  where public.is_active_user();
revoke all on public.directory from anon, public;
grant select on public.directory to authenticated;

-- ---------------------------------------------------------------- departments / roles / permissions
create policy departments_select on public.departments for select to authenticated using (is_active_user());
create policy departments_write on public.departments for all to authenticated
  using (has_permission('employees.manage')) with check (has_permission('employees.manage'));

create policy roles_select on public.roles for select to authenticated using (is_active_user());
create policy roles_write on public.roles for all to authenticated
  using (is_superuser()) with check (is_superuser() and not is_system);

create policy permissions_select on public.permissions for select to authenticated using (is_active_user());

create policy role_permissions_select on public.role_permissions for select to authenticated using (is_active_user());
create policy role_permissions_insert on public.role_permissions for insert to authenticated with check (is_superuser());
create policy role_permissions_delete on public.role_permissions for delete to authenticated using (is_superuser());

create policy user_roles_select on public.user_roles for select to authenticated
  using (user_id = auth.uid() or has_permission('employees.view') or has_permission('users.manage_roles'));
create policy user_roles_insert on public.user_roles for insert to authenticated
  with check (has_permission('users.manage_roles'));
create policy user_roles_delete on public.user_roles for delete to authenticated
  using (has_permission('users.manage_roles'));

-- ---------------------------------------------------------------- reference data
do $$
declare t text;
begin
  foreach t in array array['lead_sources', 'lead_statuses', 'industries', 'scoring_rules']
  loop
    execute format('create policy %I on public.%I for select to authenticated using (is_active_user())', t || '_select', t);
    execute format('create policy %I on public.%I for insert to authenticated with check (has_permission(''crm.configure''))', t || '_insert', t);
    execute format('create policy %I on public.%I for update to authenticated using (has_permission(''crm.configure'')) with check (has_permission(''crm.configure''))', t || '_update', t);
  end loop;
end $$;

create policy services_select_public on public.services for select to anon using (active);
create policy services_select on public.services for select to authenticated using (is_active_user());
create policy services_insert on public.services for insert to authenticated with check (has_permission('crm.configure'));
create policy services_update on public.services for update to authenticated
  using (has_permission('crm.configure')) with check (has_permission('crm.configure'));

create policy countries_select_public on public.countries for select to anon using (active);
create policy countries_select on public.countries for select to authenticated using (is_active_user());
create policy countries_update on public.countries for update to authenticated
  using (has_permission('crm.configure')) with check (has_permission('crm.configure'));

create policy settings_select on public.settings for select to authenticated using (is_active_user());
create policy settings_write on public.settings for all to authenticated
  using (has_permission('settings.manage')) with check (has_permission('settings.manage'));

-- ---------------------------------------------------------------- leads
create policy leads_select on public.leads for select to authenticated
  using (can_view_lead_row(assigned_to, created_by));
create policy leads_insert on public.leads for insert to authenticated
  with check (has_permission('leads.create'));
create policy leads_update on public.leads for update to authenticated
  using (can_edit_lead_row(assigned_to, created_by))
  with check (can_edit_lead_row(assigned_to, created_by));
-- Assigning/archiving additionally require leads.assign / leads.delete (enforced in leads_guard).
-- No delete policy: leads are archived (soft delete) to preserve history.

create policy lead_activities_select on public.lead_activities for select to authenticated
  using (exists (select 1 from public.leads l where l.id = lead_id));
create policy lead_activities_insert on public.lead_activities for insert to authenticated
  with check (can_edit_lead(lead_id));

create policy lead_tags_select on public.lead_tags for select to authenticated using (is_active_user());
create policy lead_tags_insert on public.lead_tags for insert to authenticated with check (has_permission('leads.edit'));
create policy lead_tags_manage on public.lead_tags for update to authenticated
  using (has_permission('crm.configure')) with check (has_permission('crm.configure'));

create policy lead_tag_relations_select on public.lead_tag_relations for select to authenticated
  using (exists (select 1 from public.leads l where l.id = lead_id));
create policy lead_tag_relations_insert on public.lead_tag_relations for insert to authenticated
  with check (can_edit_lead(lead_id));
create policy lead_tag_relations_delete on public.lead_tag_relations for delete to authenticated
  using (can_edit_lead(lead_id));

-- lead_submissions: no policies (server-only via submit_public_lead).

-- ---------------------------------------------------------------- notifications / audit
create policy notifications_select on public.notifications for select to authenticated using (user_id = auth.uid());
create policy notifications_update on public.notifications for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke update on public.notifications from authenticated;
grant update (read_at) on public.notifications to authenticated;

create policy audit_logs_select on public.audit_logs for select to authenticated using (has_permission('audit.view'));

-- Append-only tables: clients can never rewrite history.
revoke update, delete, truncate on public.lead_activities, public.audit_logs from authenticated;
revoke insert on public.audit_logs from authenticated;
revoke all on public.lead_submissions from authenticated;
