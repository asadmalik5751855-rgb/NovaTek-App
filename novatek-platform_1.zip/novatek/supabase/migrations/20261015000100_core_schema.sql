-- NovaTek platform — core schema (identity, RBAC, reference data, leads/CRM, notifications, audit)
-- Target: Supabase Postgres 15+.

set check_function_bodies = off;

-- ---------------------------------------------------------------------------
-- Utility
-- ---------------------------------------------------------------------------
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ---------------------------------------------------------------------------
-- Identity & RBAC
-- ---------------------------------------------------------------------------
create table public.departments (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (length(name) between 1 and 80),
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text not null default '' check (length(full_name) <= 120),
  phone text check (length(phone) <= 40),
  avatar_url text check (length(avatar_url) <= 500),
  department_id uuid references public.departments(id) on delete set null,
  designation text check (length(designation) <= 120),
  joining_date date,
  status text not null default 'active' check (status in ('active', 'disabled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index profiles_department_idx on public.profiles(department_id);
create trigger profiles_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

create table public.roles (
  id uuid primary key default gen_random_uuid(),
  key text not null unique check (key ~ '^[a-z][a-z0-9_]{1,40}$'),
  name text not null check (length(name) between 1 and 80),
  description text,
  is_superuser boolean not null default false,
  is_system boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.permissions (
  key text primary key check (key ~ '^[a-z]+\.[a-z_]+$'),
  category text not null,
  description text not null
);

create table public.role_permissions (
  role_id uuid not null references public.roles(id) on delete cascade,
  permission_key text not null references public.permissions(key) on delete cascade,
  primary key (role_id, permission_key)
);

create table public.user_roles (
  user_id uuid not null references public.profiles(id) on delete cascade,
  role_id uuid not null references public.roles(id) on delete restrict,
  assigned_by uuid references public.profiles(id) on delete set null,
  assigned_at timestamptz not null default now(),
  primary key (user_id, role_id)
);
create index user_roles_role_idx on public.user_roles(role_id);

-- ---------------------------------------------------------------------------
-- Reference data (admin-editable; nothing about markets is hardcoded in code)
-- ---------------------------------------------------------------------------
create table public.lead_sources (
  id uuid primary key default gen_random_uuid(),
  key text not null unique check (key ~ '^[a-z][a-z0-9_]{1,40}$'),
  name text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.lead_statuses (
  id uuid primary key default gen_random_uuid(),
  key text not null unique check (key ~ '^[a-z][a-z0-9_]{1,40}$'),
  name text not null,
  position int not null,
  color text not null default 'slate' check (color ~ '^[a-z]{3,12}$'),
  show_in_pipeline boolean not null default false,
  is_closed boolean not null default false,
  is_won boolean not null default false,
  score_signal text check (score_signal is null or score_signal ~ '^[a-z_]{2,40}$'),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.services (
  id uuid primary key default gen_random_uuid(),
  key text not null unique check (key ~ '^[a-z][a-z0-9_]{1,40}$'),
  name text not null,
  description text,
  position int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.industries (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  is_target boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.countries (
  code char(2) primary key check (code ~ '^[A-Z]{2}$'),
  name text not null,
  is_target boolean not null default false,
  active boolean not null default true
);

-- Signals the scoring engine knows how to evaluate from real data.
-- Admins configure points/active/params; they cannot invent new signal logic from the UI.
create table public.scoring_rules (
  signal text primary key check (signal in (
    'target_industry', 'target_country', 'service_selected', 'has_website', 'no_website',
    'budget_known', 'budget_high', 'contact_complete', 'engaged_replied', 'meeting_booked'
  )),
  label text not null,
  points int not null check (points between -100 and 100),
  params jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table public.settings (
  key text primary key check (key ~ '^[a-z][a-z0-9_.]{1,60}$'),
  value jsonb not null,
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Leads / CRM
-- ---------------------------------------------------------------------------
create table public.leads (
  id uuid primary key default gen_random_uuid(),
  company_name text not null check (length(company_name) between 1 and 200),
  company_name_normalized text not null default '',
  website text check (length(website) <= 300),
  website_domain text,
  industry_id uuid references public.industries(id) on delete set null,
  country_code char(2) references public.countries(code) on delete set null,
  city text check (length(city) <= 120),
  business_size text check (business_size in ('solo', '2_10', '11_50', '51_200', '201_1000', '1000_plus')),
  contact_name text check (length(contact_name) <= 120),
  email text check (length(email) <= 254),
  email_normalized text,
  phone text check (length(phone) <= 40),
  phone_key text,
  source_id uuid not null references public.lead_sources(id),
  source_reference text check (length(source_reference) <= 500),
  service_id uuid references public.services(id) on delete set null,
  budget_range text check (budget_range in ('under_1k', '1k_5k', '5k_15k', '15k_plus', 'not_sure')),
  estimated_value numeric(14, 2) check (estimated_value >= 0),
  currency char(3) not null default 'USD' check (currency ~ '^[A-Z]{3}$'),
  message text check (length(message) <= 5000),
  score int not null default 0 check (score between 0 and 100),
  score_breakdown jsonb not null default '[]'::jsonb,
  temperature text not null default 'cold' check (temperature in ('cold', 'warm', 'hot', 'very_hot')),
  status_id uuid not null references public.lead_statuses(id),
  assigned_to uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  last_contacted_at timestamptz,
  next_follow_up_at timestamptz,
  follow_up_type text check (follow_up_type in ('call', 'email', 'message', 'meeting', 'other')),
  follow_up_priority text check (follow_up_priority in ('low', 'medium', 'high')),
  qualification jsonb not null default '{}'::jsonb,
  consent_status text not null default 'unknown' check (consent_status in ('unknown', 'granted', 'withdrawn')),
  possible_duplicate_of uuid references public.leads(id) on delete set null,
  utm_source text check (length(utm_source) <= 200),
  utm_medium text check (length(utm_medium) <= 200),
  utm_campaign text check (length(utm_campaign) <= 200),
  utm_content text check (length(utm_content) <= 200),
  utm_term text check (length(utm_term) <= 200),
  archived_at timestamptz,
  archived_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index leads_status_idx on public.leads(status_id) where archived_at is null;
create index leads_assigned_idx on public.leads(assigned_to) where archived_at is null;
create index leads_created_by_idx on public.leads(created_by);
create index leads_created_at_idx on public.leads(created_at desc);
create index leads_follow_up_idx on public.leads(next_follow_up_at) where archived_at is null;
create index leads_domain_idx on public.leads(website_domain) where website_domain is not null;
create index leads_email_idx on public.leads(email_normalized) where email_normalized is not null;
create index leads_phone_idx on public.leads(phone_key) where phone_key is not null;
create index leads_name_norm_idx on public.leads(company_name_normalized);
create index leads_source_idx on public.leads(source_id);

create table public.lead_activities (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  type text not null check (type in (
    'created', 'assigned', 'unassigned', 'status_change', 'note', 'call', 'email', 'message',
    'meeting', 'follow_up', 'archived', 'restored', 'merged', 'updated'
  )),
  body text check (length(body) <= 5000),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index lead_activities_lead_idx on public.lead_activities(lead_id, created_at desc);

create table public.lead_tags (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (length(name) between 1 and 40),
  color text not null default 'slate' check (color ~ '^[a-z]{3,12}$'),
  created_at timestamptz not null default now()
);

create table public.lead_tag_relations (
  lead_id uuid not null references public.leads(id) on delete cascade,
  tag_id uuid not null references public.lead_tags(id) on delete cascade,
  primary key (lead_id, tag_id)
);

-- Inbound form submissions: abuse control + evidence. Not directly accessible to clients.
create table public.lead_submissions (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid references public.leads(id) on delete set null,
  ip_hash text not null,
  email_normalized text,
  user_agent text,
  page_path text,
  created_at timestamptz not null default now()
);
create index lead_submissions_ip_idx on public.lead_submissions(ip_hash, created_at desc);
create index lead_submissions_email_idx on public.lead_submissions(email_normalized, created_at desc);

-- ---------------------------------------------------------------------------
-- Notifications & Audit
-- ---------------------------------------------------------------------------
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null,
  title text not null,
  body text,
  link text,
  priority text not null default 'normal' check (priority in ('low', 'normal', 'high')),
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications(user_id, created_at desc);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity text not null,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_created_idx on public.audit_logs(created_at desc);
create index audit_logs_entity_idx on public.audit_logs(entity, entity_id);
create index audit_logs_actor_idx on public.audit_logs(actor_id);

create trigger leads_updated_at before update on public.leads
  for each row execute function public.set_updated_at();
