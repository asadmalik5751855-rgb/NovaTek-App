-- NovaTek platform — reference data required for the system to operate.
-- Contains NO business data (no leads, clients, revenue or employees).

insert into public.permissions(key, category, description) values
  ('leads.view_own',     'Leads',      'View leads assigned to or created by me'),
  ('leads.view_all',     'Leads',      'View all leads'),
  ('leads.create',       'Leads',      'Create leads'),
  ('leads.edit',         'Leads',      'Edit leads I can access'),
  ('leads.assign',       'Leads',      'Assign and reassign leads'),
  ('leads.delete',       'Leads',      'Archive and restore leads'),
  ('leads.merge',        'Leads',      'Merge duplicates and dismiss duplicate flags'),
  ('leads.export',       'Leads',      'Export leads'),
  ('crm.configure',      'CRM',        'Configure statuses, sources, services, industries, countries and scoring'),
  ('campaigns.view',     'Marketing',  'View campaigns'),
  ('campaigns.manage',   'Marketing',  'Create and manage campaigns'),
  ('employees.view',     'People',     'View employee profiles'),
  ('employees.manage',   'People',     'Manage employee profiles, departments and account status'),
  ('users.manage_roles', 'People',     'Create users and assign roles'),
  ('sales.view',         'Sales',      'View deals and proposals'),
  ('sales.manage',       'Sales',      'Manage deals and proposals'),
  ('projects.view',      'Projects',   'View projects and tasks'),
  ('projects.manage',    'Projects',   'Manage projects and tasks'),
  ('reports.view',       'Reports',    'View reports and analytics'),
  ('settings.manage',    'Settings',   'Manage system settings and branding'),
  ('audit.view',         'Security',   'View the audit log'),
  ('portal.ceo',         'Portals',    'Access the CEO portal'),
  ('portal.coo',         'Portals',    'Access the COO portal'),
  ('portal.cto',         'Portals',    'Access the CTO portal'),
  ('portal.cmo',         'Portals',    'Access the CMO portal');

insert into public.roles(key, name, description, is_superuser, is_system) values
  ('super_admin',   'Super Admin',          'Full system control',                                   true,  true),
  ('ceo',           'CEO',                  'Executive overview and strategic management',           false, true),
  ('coo',           'COO',                  'Operations, leads, sales operations and performance',   false, true),
  ('cto',           'CTO',                  'Technology, developers and technical projects',         false, true),
  ('cmo',           'CMO',                  'Marketing, campaigns and lead sources',                 false, true),
  ('sales_manager', 'Sales Manager',        'Sales team management',                                 false, true),
  ('sales_rep',     'Sales Representative', 'Lead management and sales activities',                  false, true),
  ('developer',     'Developer',            'Technical and project workspace',                       false, true),
  ('designer',      'UI/UX Designer',       'Design and project workspace',                          false, true),
  ('marketing',     'Marketing Employee',   'Marketing workspace',                                   false, true),
  ('employee',      'Employee',             'Base access; extend with configurable permissions',     false, true);

insert into public.role_permissions(role_id, permission_key)
select r.id, x.perm
from (values
  ('ceo', 'leads.view_all'), ('ceo', 'campaigns.view'), ('ceo', 'employees.view'), ('ceo', 'sales.view'),
  ('ceo', 'projects.view'), ('ceo', 'reports.view'), ('ceo', 'portal.ceo'), ('ceo', 'audit.view'),

  ('coo', 'leads.view_all'), ('coo', 'leads.create'), ('coo', 'leads.edit'), ('coo', 'leads.assign'),
  ('coo', 'leads.merge'), ('coo', 'crm.configure'), ('coo', 'employees.view'), ('coo', 'sales.view'),
  ('coo', 'sales.manage'), ('coo', 'projects.view'), ('coo', 'projects.manage'), ('coo', 'reports.view'),
  ('coo', 'portal.coo'),

  ('cto', 'employees.view'), ('cto', 'projects.view'), ('cto', 'projects.manage'), ('cto', 'reports.view'),
  ('cto', 'portal.cto'),

  ('cmo', 'leads.view_all'), ('cmo', 'leads.create'), ('cmo', 'leads.edit'), ('cmo', 'leads.export'),
  ('cmo', 'crm.configure'), ('cmo', 'campaigns.view'), ('cmo', 'campaigns.manage'), ('cmo', 'reports.view'),
  ('cmo', 'portal.cmo'),

  ('sales_manager', 'leads.view_all'), ('sales_manager', 'leads.create'), ('sales_manager', 'leads.edit'),
  ('sales_manager', 'leads.assign'), ('sales_manager', 'leads.merge'), ('sales_manager', 'leads.export'),
  ('sales_manager', 'employees.view'), ('sales_manager', 'sales.view'), ('sales_manager', 'sales.manage'),
  ('sales_manager', 'reports.view'),

  ('sales_rep', 'leads.view_own'), ('sales_rep', 'leads.create'), ('sales_rep', 'leads.edit'), ('sales_rep', 'sales.view'),

  ('developer', 'projects.view'),
  ('designer', 'projects.view'),

  ('marketing', 'leads.view_own'), ('marketing', 'leads.create'), ('marketing', 'campaigns.view')
) as x(role_key, perm)
join public.roles r on r.key = x.role_key;

insert into public.departments(name) values
  ('Executive'), ('Operations'), ('Technology'), ('Marketing'), ('Sales'), ('Design');

insert into public.lead_sources(key, name) values
  ('website', 'Website'), ('landing_page', 'Landing Page'), ('campaign', 'Campaign'),
  ('referral', 'Referral'), ('manual', 'Manual'), ('import', 'Import'), ('integration', 'Integration');

insert into public.lead_statuses(key, name, position, color, show_in_pipeline, is_closed, is_won, score_signal) values
  ('new',               'New',               10,  'slate',   true,  false, false, null),
  ('researching',       'Researching',       20,  'slate',   false, false, false, null),
  ('qualified',         'Qualified',         30,  'blue',    true,  false, false, null),
  ('contacted',         'Contacted',         40,  'indigo',  true,  false, false, null),
  ('replied',           'Replied',           50,  'violet',  false, false, false, 'engaged_replied'),
  ('meeting_scheduled', 'Meeting Scheduled', 60,  'purple',  true,  false, false, 'meeting_booked'),
  ('proposal_sent',     'Proposal Sent',     70,  'fuchsia', true,  false, false, null),
  ('negotiation',       'Negotiation',       80,  'amber',   true,  false, false, null),
  ('won',               'Won',               90,  'emerald', true,  true,  true,  null),
  ('lost',              'Lost',              100, 'rose',    true,  true,  false, null),
  ('not_interested',    'Not Interested',    110, 'zinc',    false, true,  false, null),
  ('follow_up_later',   'Follow Up Later',   120, 'sky',     false, false, false, null),
  ('disqualified',      'Disqualified',      130, 'zinc',    false, true,  false, null);

insert into public.services(key, name, position) values
  ('web_development',      'Web Development',              10),
  ('ecommerce',            'E-Commerce Development',       20),
  ('custom_software',      'Custom Software Development',  30),
  ('ui_ux',                'UI/UX Design',                 40),
  ('saas',                 'SaaS Development',             50),
  ('business_automation',  'Business Automation',          60),
  ('ai_automation',        'AI Automation',                70),
  ('digital_product',      'Digital Product Development',  80),
  ('custom_business_apps', 'Custom Business Applications', 90);

insert into public.industries(name, is_target) values
  ('Startups', true), ('Small Business', true), ('E-Commerce', true), ('Education', true),
  ('Restaurants & Hospitality', true), ('Retail', true), ('Professional Services', true),
  ('Healthcare', false), ('Real Estate', false), ('Manufacturing', false), ('Logistics', false),
  ('Finance', false), ('Non-profit', false), ('Other', false);

insert into public.scoring_rules(signal, label, points, params) values
  ('target_industry',  'Target industry',                  15, '{}'),
  ('target_country',   'Target country',                   15, '{}'),
  ('service_selected', 'Specific service requested',       10, '{}'),
  ('has_website',      'Business website exists',           5, '{}'),
  ('no_website',       'No website (build opportunity)',   10, '{}'),
  ('budget_known',     'Budget provided',                  10, '{}'),
  ('budget_high',      'Budget $5k or more',               15, '{"ranges": ["5k_15k", "15k_plus"]}'),
  ('contact_complete', 'Complete contact details',          5, '{}'),
  ('engaged_replied',  'Prospect replied',                 15, '{}'),
  ('meeting_booked',   'Meeting booked',                   20, '{}');

insert into public.settings(key, value) values
  ('branding', '{"company_name": "NovaTek", "tagline": "Digital Solutions • Web Development • E-Commerce • UI/UX • Custom Software", "contact_email": "", "contact_phone": "", "social": {}}');
