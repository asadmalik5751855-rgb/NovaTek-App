-- NovaTek platform — Marketing (campaigns, landing pages, site content), targets, integrations registry,
-- AI generation log, qualification settings, CSV import, global search and analytics.
-- Analytics functions are SECURITY INVOKER: every number is computed through the caller's RLS, so a sales
-- rep's "company" metrics only ever include records they are allowed to see.

-- ---------------------------------------------------------------------------
-- Campaigns
-- ---------------------------------------------------------------------------
create table public.campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(name) between 1 and 160),
  utm_campaign text not null unique check (utm_campaign ~ '^[a-z0-9][a-z0-9_-]{1,79}$'),
  channel text not null default 'other' check (channel in ('email', 'social', 'ads', 'seo', 'content', 'events', 'referral', 'outreach', 'other')),
  status text not null default 'draft' check (status in ('draft', 'active', 'paused', 'completed')),
  description text check (length(description) <= 5000),
  start_date date,
  end_date date,
  budget numeric(14, 2) check (budget >= 0),
  spend numeric(14, 2) not null default 0 check (spend >= 0),
  currency char(3) not null default 'USD' check (currency ~ '^[A-Z]{3}$'),
  target_industry_id uuid references public.industries(id) on delete set null,
  target_country_code char(2) references public.countries(code) on delete set null,
  service_id uuid references public.services(id) on delete set null,
  owner_id uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (end_date is null or start_date is null or end_date >= start_date)
);
create trigger campaigns_updated_at before update on public.campaigns for each row execute function public.set_updated_at();
create trigger campaigns_audit after insert or update or delete on public.campaigns
  for each row execute function public.audit_config_change();

create table public.campaign_leads (
  campaign_id uuid not null references public.campaigns(id) on delete cascade,
  lead_id uuid not null references public.leads(id) on delete cascade,
  added_at timestamptz not null default now(),
  primary key (campaign_id, lead_id)
);
create index campaign_leads_lead_idx on public.campaign_leads(lead_id);

create or replace function public.campaigns_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  new.utm_campaign := lower(btrim(new.utm_campaign));
  if is_api_caller() then
    if tg_op = 'INSERT' then new.created_by := auth.uid(); new.owner_id := coalesce(new.owner_id, auth.uid());
    else new.id := old.id; new.created_by := old.created_by; new.created_at := old.created_at; end if;
  end if;
  return new;
end $$;
create trigger campaigns_a_guard before insert or update on public.campaigns
  for each row execute function public.campaigns_guard();

-- Attribute leads to campaigns by utm_campaign (case-insensitive). Runs for every lead source.
create or replace function public.leads_campaign_link() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.utm_campaign is not null and (tg_op = 'INSERT' or new.utm_campaign is distinct from old.utm_campaign) then
    insert into campaign_leads(campaign_id, lead_id)
    select c.id, new.id from campaigns c where c.utm_campaign = lower(btrim(new.utm_campaign))
    on conflict do nothing;
  end if;
  return null;
end $$;
create trigger leads_e_campaign after insert or update of utm_campaign on public.leads
  for each row execute function public.leads_campaign_link();

-- ---------------------------------------------------------------------------
-- Landing pages (public at /l/<slug>, each with its own campaign attribution)
-- ---------------------------------------------------------------------------
create table public.landing_pages (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,79}$'),
  campaign_id uuid references public.campaigns(id) on delete set null,
  service_id uuid references public.services(id) on delete set null,
  headline text not null check (length(headline) between 3 and 160),
  subheadline text check (length(subheadline) <= 400),
  hero_image_url text check (hero_image_url is null or (hero_image_url ~ '^https://' and length(hero_image_url) <= 500)),
  benefits jsonb not null default '[]'::jsonb check (jsonb_typeof(benefits) = 'array' and jsonb_array_length(benefits) <= 12),
  cta_label text not null default 'Get a free consultation' check (length(cta_label) between 2 and 60),
  -- Only real testimonials used with permission (the editor requires confirming this).
  testimonials jsonb not null default '[]'::jsonb check (jsonb_typeof(testimonials) = 'array' and jsonb_array_length(testimonials) <= 6),
  faq jsonb not null default '[]'::jsonb check (jsonb_typeof(faq) = 'array' and jsonb_array_length(faq) <= 12),
  status text not null default 'draft' check (status in ('draft', 'published', 'archived')),
  published_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger landing_pages_updated_at before update on public.landing_pages for each row execute function public.set_updated_at();
create trigger landing_pages_audit after insert or update or delete on public.landing_pages
  for each row execute function public.audit_config_change();

create or replace function public.landing_pages_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  new.slug := lower(btrim(new.slug));
  if new.status = 'published' and (tg_op = 'INSERT' or old.status <> 'published') then new.published_at := now(); end if;
  if is_api_caller() then
    if tg_op = 'INSERT' then new.created_by := auth.uid();
    else new.id := old.id; new.created_by := old.created_by; new.created_at := old.created_at; end if;
  end if;
  return new;
end $$;
create trigger landing_pages_a_guard before insert or update on public.landing_pages
  for each row execute function public.landing_pages_guard();

-- ---------------------------------------------------------------------------
-- Public website content: portfolio + case studies (published by staff; never fabricated)
-- ---------------------------------------------------------------------------
create table public.site_entries (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('portfolio', 'case_study')),
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{1,79}$'),
  title text not null check (length(title) between 3 and 160),
  client_name text check (length(client_name) <= 160),
  client_permission boolean not null default false,
  industry_id uuid references public.industries(id) on delete set null,
  service_id uuid references public.services(id) on delete set null,
  summary text not null check (length(summary) between 10 and 600),
  challenge text check (length(challenge) <= 5000),
  solution text check (length(solution) <= 5000),
  results text check (length(results) <= 5000),
  image_url text check (image_url is null or (image_url ~ '^https://' and length(image_url) <= 500)),
  project_url text check (project_url is null or (project_url ~ '^https://' and length(project_url) <= 500)),
  status text not null default 'draft' check (status in ('draft', 'published', 'archived')),
  position int not null default 0,
  published_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (kind, slug),
  -- A named client can only be published with their permission on record.
  check (status <> 'published' or client_name is null or client_permission)
);
create trigger site_entries_updated_at before update on public.site_entries for each row execute function public.set_updated_at();
create trigger site_entries_audit after insert or update or delete on public.site_entries
  for each row execute function public.audit_config_change();

create or replace function public.site_entries_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  if new.status = 'published' and (tg_op = 'INSERT' or old.status <> 'published') then new.published_at := now(); end if;
  if is_api_caller() then
    if tg_op = 'INSERT' then new.created_by := auth.uid();
    else new.id := old.id; new.created_by := old.created_by; new.created_at := old.created_at; end if;
  end if;
  return new;
end $$;
create trigger site_entries_a_guard before insert or update on public.site_entries
  for each row execute function public.site_entries_guard();

-- ---------------------------------------------------------------------------
-- Public intake v2: landing pages + campaign attribution
-- ---------------------------------------------------------------------------
create or replace function public.submit_public_lead(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_ip text := p ->> 'ip_hash';
  v_email text := normalize_email(p ->> 'email');
  v_source uuid; v_status uuid; v_service uuid; v_country char(2);
  v_lead leads;
  v_source_key text;
  v_page landing_pages;
  v_utm_campaign text := nullif(left(p ->> 'utm_campaign', 200), '');
  u uuid;
begin
  if v_ip is null or length(v_ip) < 16 then raise exception 'ip_hash required'; end if;
  if v_email is null or v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
    return jsonb_build_object('ok', false, 'error', 'invalid_email');
  end if;
  if length(coalesce(p ->> 'company', '')) < 1 or length(coalesce(p ->> 'name', '')) < 1 then
    return jsonb_build_object('ok', false, 'error', 'missing_fields');
  end if;

  if (select count(*) from lead_submissions where ip_hash = v_ip and created_at > now() - interval '10 minutes') >= 5 then
    return jsonb_build_object('ok', false, 'error', 'rate_limited');
  end if;
  if exists (select 1 from lead_submissions where email_normalized = v_email and created_at > now() - interval '2 minutes') then
    return jsonb_build_object('ok', false, 'error', 'duplicate_submission');
  end if;
  if (select count(*) from lead_submissions where email_normalized = v_email and created_at > now() - interval '24 hours') >= 5 then
    return jsonb_build_object('ok', false, 'error', 'rate_limited');
  end if;

  if nullif(p ->> 'landing_page', '') is not null then
    select * into v_page from landing_pages where slug = lower(p ->> 'landing_page') and status = 'published';
  end if;
  if v_page.id is not null and v_page.campaign_id is not null and v_utm_campaign is null then
    select utm_campaign into v_utm_campaign from campaigns where id = v_page.campaign_id;
  end if;

  v_source_key := case
    when v_page.id is not null then 'landing_page'
    when v_utm_campaign is not null then 'campaign'
    else 'website' end;
  select id into v_source from lead_sources where key = v_source_key and active;
  if v_source is null then select id into v_source from lead_sources where key = 'website'; end if;
  if v_source is null then raise exception 'lead source not configured'; end if;

  select id into v_status from lead_statuses where active order by position limit 1;
  if v_status is null then raise exception 'lead statuses not configured'; end if;

  select id into v_service from services where key = p ->> 'service' and active;
  v_service := coalesce(v_service, v_page.service_id);
  select code into v_country from countries where code = upper(p ->> 'country') and active;

  insert into leads(company_name, contact_name, email, phone, country_code, service_id, budget_range,
                    message, source_id, source_reference, status_id, consent_status,
                    utm_source, utm_medium, utm_campaign, utm_content, utm_term, website)
  values (left(p ->> 'company', 200), left(p ->> 'name', 120), left(p ->> 'email', 254),
          nullif(left(p ->> 'phone', 40), ''), v_country, v_service,
          case when p ->> 'budget' in ('under_1k', '1k_5k', '5k_15k', '15k_plus', 'not_sure') then p ->> 'budget' end,
          nullif(left(p ->> 'message', 5000), ''), v_source,
          coalesce(case when v_page.id is not null then '/l/' || v_page.slug end, nullif(left(p ->> 'page_path', 500), '')),
          v_status,
          case when (p ->> 'consent')::boolean then 'granted' else 'unknown' end,
          nullif(left(p ->> 'utm_source', 200), ''), nullif(left(p ->> 'utm_medium', 200), ''),
          v_utm_campaign, nullif(left(p ->> 'utm_content', 200), ''),
          nullif(left(p ->> 'utm_term', 200), ''), nullif(left(p ->> 'website', 300), ''))
  returning * into v_lead;

  if v_page.campaign_id is not null then
    insert into campaign_leads(campaign_id, lead_id) values (v_page.campaign_id, v_lead.id) on conflict do nothing;
  end if;

  insert into lead_submissions(lead_id, ip_hash, email_normalized, user_agent, page_path)
  values (v_lead.id, v_ip, v_email, left(p ->> 'user_agent', 300), left(p ->> 'page_path', 500));

  for u in select * from users_with_permission('leads.assign') loop
    perform notify_user(u, 'lead.inbound',
                        case when v_page.id is not null then 'New landing page lead: ' else 'New website lead: ' end || v_lead.company_name,
                        case when v_lead.possible_duplicate_of is not null then 'Possible duplicate of an existing lead' end,
                        '/app/leads/' || v_lead.id, 'high');
  end loop;

  return jsonb_build_object('ok', true, 'lead_id', v_lead.id,
                            'possible_duplicate', v_lead.possible_duplicate_of is not null);
end $$;

-- ---------------------------------------------------------------------------
-- Employee targets (progress is always computed from real records)
-- ---------------------------------------------------------------------------
create table public.employee_targets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  metric text not null check (metric in ('leads_created', 'leads_qualified', 'meetings_booked', 'proposals_sent',
                                         'deals_won', 'revenue_won', 'tasks_completed')),
  period_start date not null,
  period_end date not null,
  target_value numeric(14, 2) not null check (target_value > 0),
  currency char(3) check (currency ~ '^[A-Z]{3}$'),
  notes text check (length(notes) <= 1000),
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  check (period_end >= period_start),
  check ((metric = 'revenue_won') = (currency is not null))
);
create index employee_targets_user_idx on public.employee_targets(user_id, period_end desc);
create trigger employee_targets_audit after insert or update or delete on public.employee_targets
  for each row execute function public.audit_config_change();

create or replace function public.employee_targets_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  if is_api_caller() then
    if tg_op = 'INSERT' then new.created_by := auth.uid();
    else new.id := old.id; new.created_by := old.created_by; new.created_at := old.created_at; end if;
  end if;
  return new;
end $$;
create trigger employee_targets_a_guard before insert or update on public.employee_targets
  for each row execute function public.employee_targets_guard();

-- Actual for one target. DEFINER so the number is the employee's true figure, but it only answers
-- for targets the caller is allowed to see (own, targets.manage or reports.view).
create or replace function public.target_actual(p_target uuid) returns numeric
language plpgsql stable security definer set search_path = public as $$
declare t employee_targets; v numeric; f timestamptz; e timestamptz;
begin
  select * into t from employee_targets where id = p_target;
  if t.id is null or not (t.user_id = auth.uid() or has_permission('targets.manage') or has_permission('reports.view')) then
    return null;
  end if;
  f := t.period_start::timestamptz; e := (t.period_end + 1)::timestamptz;
  v := case t.metric
    when 'leads_created' then (select count(*) from leads where created_by = t.user_id and created_at >= f and created_at < e and merged_into is null)
    when 'leads_qualified' then (select count(*) from leads where assigned_to = t.user_id and max_funnel_rank >= 1 and created_at >= f and created_at < e)
    when 'meetings_booked' then (select count(*) from meetings where organizer_id = t.user_id and status in ('scheduled', 'completed') and created_at >= f and created_at < e)
    when 'proposals_sent' then (select count(*) from proposals where created_by = t.user_id and sent_at >= f and sent_at < e)
    when 'deals_won' then (select count(*) from deals where owner_id = t.user_id and won_at >= f and won_at < e)
    when 'revenue_won' then (select coalesce(sum(value), 0) from deals where owner_id = t.user_id and won_at >= f and won_at < e and currency = t.currency)
    when 'tasks_completed' then (select count(*) from tasks where assignee_id = t.user_id and completed_at >= f and completed_at < e)
  end;
  return v;
end $$;

-- ---------------------------------------------------------------------------
-- Integrations registry (secrets are environment variables — never stored here)
-- ---------------------------------------------------------------------------
create table public.integrations (
  key text primary key check (key ~ '^[a-z][a-z0-9_]{1,40}$'),
  name text not null,
  category text not null,
  description text not null,
  required_env text[] not null default '{}',
  enabled boolean not null default false,
  config jsonb not null default '{}'::jsonb,
  last_checked_at timestamptz,
  last_status text check (last_status in ('ok', 'error', 'not_configured')),
  last_error text check (length(last_error) <= 1000),
  updated_by uuid references public.profiles(id) on delete set null,
  updated_at timestamptz not null default now()
);
create trigger integrations_audit after insert or update or delete on public.integrations
  for each row execute function public.audit_config_change();

create or replace function public.integrations_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  if is_api_caller() then
    new.key := old.key; new.name := old.name; new.category := old.category; new.description := old.description;
    new.required_env := old.required_env; new.updated_by := auth.uid(); new.updated_at := now();
    new.last_checked_at := old.last_checked_at; new.last_status := old.last_status; new.last_error := old.last_error;
    -- Enabling requires a successful configuration check by the server.
    if new.enabled and not old.enabled and coalesce(old.last_status, '') <> 'ok' then
      raise exception 'Run a successful connection check before enabling this integration' using errcode = '42501';
    end if;
  end if;
  return new;
end $$;
create trigger integrations_a_guard before update on public.integrations
  for each row execute function public.integrations_guard();

-- Server records the outcome of a real configuration check (service role only).
create or replace function public.record_integration_check(p_key text, p_status text, p_error text, p_actor uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_status not in ('ok', 'error', 'not_configured') then raise exception 'invalid status'; end if;
  update integrations set last_checked_at = now(), last_status = p_status, last_error = left(p_error, 1000),
    enabled = case when p_status = 'ok' then enabled else false end, updated_by = p_actor
  where key = p_key;
  perform write_audit('integration.checked', 'integration', p_key, jsonb_build_object('status', p_status), p_actor);
end $$;

insert into public.integrations(key, name, category, description, required_env) values
  ('anthropic_ai', 'Claude (Anthropic) AI', 'AI', 'Drafts outreach and proposals, summarises leads and meetings. Output is always labelled AI-generated and never sent automatically.', array['ANTHROPIC_API_KEY']),
  ('email_smtp', 'Email (SMTP)', 'Communication', 'Send proposal links and notifications by email from your domain.', array['SMTP_HOST', 'SMTP_PORT', 'SMTP_USER', 'SMTP_PASSWORD', 'SMTP_FROM']),
  ('whatsapp_business', 'WhatsApp Business API', 'Communication', 'Message leads who have consented, through the official WhatsApp Cloud API.', array['WHATSAPP_TOKEN', 'WHATSAPP_PHONE_NUMBER_ID']),
  ('google_calendar', 'Google Calendar', 'Scheduling', 'Mirror NovaTek meetings into team calendars.', array['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET']),
  ('stripe', 'Stripe payments', 'Payments', 'Collect deposits and invoice payments.', array['STRIPE_SECRET_KEY', 'STRIPE_WEBHOOK_SECRET']),
  ('google_analytics', 'Google Analytics 4', 'Analytics', 'Website traffic metrics for the CMO portal.', array['GA4_PROPERTY_ID', 'GA4_SERVICE_ACCOUNT_JSON']);

-- ---------------------------------------------------------------------------
-- AI generation log (every AI output is attributable and auditable)
-- ---------------------------------------------------------------------------
create table public.ai_generations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  feature text not null check (feature ~ '^[a-z_]{3,40}$'),
  entity text check (entity in ('lead', 'deal', 'proposal', 'meeting', 'client')),
  entity_id uuid,
  model text not null,
  input_summary text check (length(input_summary) <= 2000),
  output text not null check (length(output) <= 20000),
  input_tokens int,
  output_tokens int,
  created_at timestamptz not null default now()
);
create index ai_generations_user_idx on public.ai_generations(user_id, created_at desc);

-- ---------------------------------------------------------------------------
-- CSV import (atomic: all rows or none). DEFINER so it can write one audit entry for the batch; it applies
-- the same rules the API guard would: importer must hold leads.import + leads.create, rows are attributed to
-- the importer, and assigning to other people requires leads.assign.
-- ---------------------------------------------------------------------------
create or replace function public.import_leads(p_rows jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  r jsonb; v_source uuid; v_status uuid; v_lead leads; n int := 0; dups int := 0; v_batch uuid := gen_random_uuid();
  v_can_assign boolean := has_permission('leads.assign');
begin
  if not (has_permission('leads.import') and has_permission('leads.create')) then
    raise exception 'Not allowed to import leads' using errcode = '42501';
  end if;
  if jsonb_typeof(p_rows) <> 'array' or jsonb_array_length(p_rows) = 0 then raise exception 'Nothing to import' using errcode = '23514'; end if;
  if jsonb_array_length(p_rows) > 2000 then raise exception 'Import at most 2,000 rows at a time' using errcode = '23514'; end if;
  select id into v_source from lead_sources where key = 'import';
  select id into v_status from lead_statuses where active order by position limit 1;

  for r in select * from jsonb_array_elements(p_rows) loop
    if nullif(r ->> 'assigned_to', '') is not null and (r ->> 'assigned_to')::uuid <> auth.uid() and not v_can_assign then
      raise exception 'Not allowed to assign leads to other users' using errcode = '42501';
    end if;
    insert into leads(company_name, contact_name, email, phone, website, city, country_code, industry_id, service_id,
                      estimated_value, currency, message, source_id, source_reference, status_id, assigned_to, created_by)
    values (r ->> 'company_name', nullif(r ->> 'contact_name', ''), nullif(r ->> 'email', ''), nullif(r ->> 'phone', ''),
            nullif(r ->> 'website', ''), nullif(r ->> 'city', ''), nullif(r ->> 'country_code', ''),
            nullif(r ->> 'industry_id', '')::uuid, nullif(r ->> 'service_id', '')::uuid,
            nullif(r ->> 'estimated_value', '')::numeric, coalesce(nullif(r ->> 'currency', ''), 'USD'),
            nullif(r ->> 'notes', ''), v_source, 'CSV import ' || left(v_batch::text, 8), v_status,
            nullif(r ->> 'assigned_to', '')::uuid, auth.uid())
    returning * into v_lead;
    n := n + 1;
    if v_lead.possible_duplicate_of is not null then dups := dups + 1; end if;
  end loop;
  perform write_audit('lead.imported', 'lead', null, jsonb_build_object('rows', n, 'possible_duplicates', dups, 'batch', v_batch));
  return jsonb_build_object('inserted', n, 'possible_duplicates', dups, 'batch', v_batch);
end $$;

-- Read-only duplicate check for the import preview. Returns only row numbers (never ids or names),
-- and only to importers, so it cannot be used to discover leads the caller can't see.
create or replace function public.preview_duplicates(p_rows jsonb) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r jsonb; i int := 0; out jsonb := '[]'::jsonb; v uuid;
begin
  if not has_permission('leads.import') then raise exception 'Not allowed' using errcode = '42501'; end if;
  if jsonb_array_length(p_rows) > 2000 then raise exception 'Too many rows' using errcode = '23514'; end if;
  for r in select * from jsonb_array_elements(p_rows) loop
    v := find_duplicate_lead(null, normalize_domain(r ->> 'website'), normalize_email(r ->> 'email'),
                             phone_key(r ->> 'phone'), normalize_company_name(r ->> 'company_name'));
    if v is not null then out := out || jsonb_build_array(jsonb_build_object('row', i)); end if;
    i := i + 1;
  end loop;
  return out;
end $$;

-- ---------------------------------------------------------------------------
-- Global search (invoker: results respect every table's RLS)
-- ---------------------------------------------------------------------------
create or replace function public.global_search(p_q text, p_limit int default 6)
returns table(kind text, id uuid, title text, subtitle text, href text)
language plpgsql stable set search_path = public as $$
declare pat text;
begin
  if length(btrim(coalesce(p_q, ''))) < 2 then return; end if;
  pat := '%' || replace(replace(replace(left(btrim(p_q), 80), '\', '\\'), '%', '\%'), '_', '\_') || '%';
  p_limit := least(greatest(p_limit, 1), 20);
  return query (select 'lead'::text, l.id, l.company_name, coalesce(l.contact_name, l.email), '/app/leads/' || l.id
                from leads l where l.archived_at is null and (l.company_name ilike pat or l.contact_name ilike pat or l.email ilike pat)
                order by l.created_at desc limit p_limit);
  return query (select 'client'::text, c.id, c.company_name, c.contact_name, '/app/clients/' || c.id
                from clients c where c.archived_at is null and (c.company_name ilike pat or c.contact_name ilike pat or c.email ilike pat)
                order by c.created_at desc limit p_limit);
  return query (select 'deal'::text, d.id, d.name, d.currency || ' ' || d.value::text, '/app/deals/' || d.id
                from deals d where d.archived_at is null and d.name ilike pat order by d.created_at desc limit p_limit);
  return query (select 'project'::text, p.id, p.name, p.status, '/app/projects/' || p.id
                from projects p where p.archived_at is null and p.name ilike pat order by p.created_at desc limit p_limit);
  return query (select 'task'::text, t.id, t.title, t.status, '/app/tasks/' || t.id
                from tasks t where t.title ilike pat order by t.created_at desc limit p_limit);
  return query (select 'person'::text, d.id, d.full_name, d.designation, '/app/people/' || d.id
                from directory d where d.status = 'active' and d.full_name ilike pat order by d.full_name limit p_limit);
end $$;

-- ---------------------------------------------------------------------------
-- Analytics (SECURITY INVOKER — all numbers respect the caller's RLS)
-- Cohort definition for funnel metrics: leads CREATED in the period and the furthest stage they reached.
-- ---------------------------------------------------------------------------
create or replace function public.analytics_summary(p_from timestamptz, p_to timestamptz) returns jsonb
language sql stable set search_path = public as $$
  with l as (
    select l.*, s.is_won, s.is_closed from leads l join lead_statuses s on s.id = l.status_id
    where l.created_at >= p_from and l.created_at < p_to and l.merged_into is null
  ),
  won as (select * from deals where won_at >= p_from and won_at < p_to),
  cyc as (select extract(epoch from (d.won_at - le.created_at)) / 86400.0 as days
          from won d join leads le on le.id = d.lead_id)
  select jsonb_build_object(
    'leads', (select count(*) from l),
    'qualified', (select count(*) from l where max_funnel_rank >= 1),
    'contacted', (select count(*) from l where max_funnel_rank >= 2),
    'replied', (select count(*) from l where max_funnel_rank >= 3),
    'meetings', (select count(*) from l where max_funnel_rank >= 4),
    'proposals', (select count(*) from l where max_funnel_rank >= 5),
    'won_leads', (select count(*) from l where is_won),
    'closed_leads', (select count(*) from l where is_closed),
    'deals_won', (select count(*) from won),
    'deals_lost', (select count(*) from deals where lost_at >= p_from and lost_at < p_to),
    'revenue', coalesce((select jsonb_agg(jsonb_build_object('currency', currency, 'amount', amt, 'count', n, 'average', avg_v) order by amt desc)
                         from (select currency, sum(value) amt, count(*) n, round(avg(value), 2) avg_v from won group by currency) x), '[]'::jsonb),
    'forecast', coalesce((select jsonb_agg(jsonb_build_object('currency', currency, 'pipeline', pipe, 'forecast', fc) order by fc desc)
                          from (select d.currency, sum(d.value) pipe, sum(d.forecast_value) fc from deals d
                                join deal_stages s on s.id = d.stage_id
                                where not s.is_won and not s.is_lost and d.archived_at is null group by d.currency) y), '[]'::jsonb),
    'avg_sales_cycle_days', (select round(avg(days)::numeric, 1) from cyc),
    'active_clients', (select count(*) from clients where archived_at is null and status = 'active'),
    'active_projects', (select count(*) from projects where archived_at is null and status in ('planning', 'active', 'review')),
    'open_tasks', (select count(*) from tasks where status not in ('completed', 'cancelled')),
    'overdue_tasks', (select count(*) from tasks where status not in ('completed', 'cancelled') and due_at < now()),
    'meetings_scheduled', (select count(*) from meetings where status = 'scheduled' and starts_at >= now()),
    'proposals_open', (select count(*) from proposals where status in ('sent', 'viewed')),
    'employees', (select count(*) from directory where status = 'active')
  )
$$;

create or replace function public.analytics_breakdown(p_dim text, p_from timestamptz, p_to timestamptz)
returns table(key text, label text, leads bigint, qualified bigint, won bigint, revenue jsonb)
language plpgsql stable set search_path = public as $$
begin
  if p_dim not in ('source', 'industry', 'country', 'service', 'owner', 'campaign') then
    raise exception 'unknown dimension' using errcode = '22023';
  end if;
  return query
  with l as (
    select l.*, s.is_won,
      case p_dim when 'source' then l.source_id::text when 'industry' then l.industry_id::text
                 when 'country' then l.country_code::text when 'service' then l.service_id::text
                 when 'owner' then l.assigned_to::text when 'campaign' then lower(l.utm_campaign) end as k
    from leads l join lead_statuses s on s.id = l.status_id
    where l.created_at >= p_from and l.created_at < p_to and l.merged_into is null
  ),
  rev as (
    select l.k, d.currency, sum(d.value) amt from l join deals d on d.lead_id = l.id and d.won_at is not null
    group by l.k, d.currency
  )
  select coalesce(l.k, '∅'),
    coalesce(case p_dim
      when 'source' then (select ls.name from lead_sources ls where ls.id::text = l.k)
      when 'industry' then (select i.name from industries i where i.id::text = l.k)
      when 'country' then (select c.name from countries c where c.code = l.k)
      when 'service' then (select sv.name from services sv where sv.id::text = l.k)
      when 'owner' then (select dr.full_name from directory dr where dr.id::text = l.k)
      when 'campaign' then coalesce((select cp.name from campaigns cp where cp.utm_campaign = l.k), l.k)
    end, case when p_dim = 'owner' then 'Unassigned' else 'Not set' end),
    count(*), count(*) filter (where l.max_funnel_rank >= 1), count(*) filter (where l.is_won),
    coalesce((select jsonb_agg(jsonb_build_object('currency', r.currency, 'amount', r.amt)) from rev r where r.k is not distinct from l.k), '[]'::jsonb)
  from l group by l.k
  order by count(*) desc;
end $$;

create or replace function public.analytics_timeseries(p_from timestamptz, p_to timestamptz, p_bucket text, p_tz text default 'UTC')
returns table(bucket date, leads bigint, qualified bigint, deals_won bigint, revenue jsonb)
language plpgsql stable set search_path = public as $$
begin
  if p_bucket not in ('day', 'week', 'month') then raise exception 'invalid bucket' using errcode = '22023'; end if;
  if not exists (select 1 from pg_timezone_names where name = p_tz) then raise exception 'invalid timezone' using errcode = '22023'; end if;
  -- Buckets follow the company's calendar (p_tz), not UTC.
  return query
  with b as (
    select generate_series(date_trunc(p_bucket, p_from, p_tz), date_trunc(p_bucket, p_to - interval '1 second', p_tz), ('1 ' || p_bucket)::interval) as t
  ),
  l as (select date_trunc(p_bucket, created_at, p_tz) t, count(*) n, count(*) filter (where max_funnel_rank >= 1) q
        from leads where created_at >= p_from and created_at < p_to and merged_into is null group by 1),
  w as (select date_trunc(p_bucket, won_at, p_tz) t, currency, count(*) n, sum(value) amt
        from deals where won_at >= p_from and won_at < p_to group by 1, 2)
  select (b.t at time zone p_tz)::date, coalesce(l.n, 0), coalesce(l.q, 0),
    coalesce((select sum(w.n) from w where w.t = b.t), 0)::bigint,
    coalesce((select jsonb_agg(jsonb_build_object('currency', w.currency, 'amount', w.amt)) from w where w.t = b.t), '[]'::jsonb)
  from b left join l on l.t = b.t order by b.t;
end $$;

create or replace function public.employee_performance(p_from timestamptz, p_to timestamptz)
returns table(user_id uuid, full_name text, designation text, leads_assigned bigint, leads_created bigint, leads_qualified bigint,
              contacts_logged bigint, meetings_booked bigint, proposals_sent bigint, deals_won bigint, revenue jsonb,
              tasks_completed bigint, overdue_followups bigint)
language sql stable set search_path = public as $$
  select d.id, d.full_name, d.designation,
    (select count(*) from leads l where l.assigned_to = d.id and l.created_at >= p_from and l.created_at < p_to and l.merged_into is null),
    (select count(*) from leads l where l.created_by = d.id and l.created_at >= p_from and l.created_at < p_to and l.merged_into is null),
    (select count(*) from leads l where l.assigned_to = d.id and l.max_funnel_rank >= 1 and l.created_at >= p_from and l.created_at < p_to),
    (select count(*) from lead_activities a where a.actor_id = d.id and a.type in ('call', 'email', 'message', 'meeting')
       and a.created_at >= p_from and a.created_at < p_to),
    (select count(*) from meetings m where m.organizer_id = d.id and m.status in ('scheduled', 'completed')
       and m.created_at >= p_from and m.created_at < p_to),
    (select count(*) from proposals p where p.created_by = d.id and p.sent_at >= p_from and p.sent_at < p_to),
    (select count(*) from deals x where x.owner_id = d.id and x.won_at >= p_from and x.won_at < p_to),
    coalesce((select jsonb_agg(jsonb_build_object('currency', currency, 'amount', amt))
              from (select currency, sum(value) amt from deals x where x.owner_id = d.id and x.won_at >= p_from and x.won_at < p_to group by currency) z), '[]'::jsonb),
    (select count(*) from tasks t where t.assignee_id = d.id and t.completed_at >= p_from and t.completed_at < p_to),
    (select count(*) from leads l where l.assigned_to = d.id and l.archived_at is null and l.next_follow_up_at < now()
       and not exists (select 1 from lead_statuses s where s.id = l.status_id and s.is_closed))
  from directory d
  where d.status = 'active'
  order by d.full_name
$$;

-- ---------------------------------------------------------------------------
-- Settings: qualification questions + finance base currency
-- ---------------------------------------------------------------------------
insert into public.settings(key, value) values
  ('crm.qualification_questions', '[
    {"key": "service_needed", "label": "What service do you need?", "type": "text"},
    {"key": "estimated_budget", "label": "What is your estimated budget?", "type": "text"},
    {"key": "has_website", "label": "Do you already have a website?", "type": "yesno"},
    {"key": "has_store", "label": "Do you already have an e-commerce store?", "type": "yesno"},
    {"key": "problem", "label": "What problem are you trying to solve?", "type": "longtext"},
    {"key": "timeline", "label": "Expected timeline?", "type": "text"},
    {"key": "preferred_contact", "label": "Preferred communication method?", "type": "choice", "options": ["Email", "Phone", "WhatsApp", "Video call"]}
  ]'::jsonb),
  ('finance.base_currency', '"USD"'::jsonb),
  ('security.reauth_minutes', '10'::jsonb);

-- The qualification setting can also be edited by CRM configurators (COO/CMO), not only settings.manage.
create policy settings_qualification_write on public.settings for update to authenticated
  using (key = 'crm.qualification_questions' and has_permission('crm.configure'))
  with check (key = 'crm.qualification_questions' and has_permission('crm.configure'));

-- ---------------------------------------------------------------------------
-- RLS
-- ---------------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['campaigns', 'campaign_leads', 'landing_pages', 'site_entries', 'employee_targets',
                           'integrations', 'ai_generations']
  loop
    execute format('alter table public.%I enable row level security', t);
    execute format('alter table public.%I force row level security', t);
    execute format('revoke all on public.%I from anon', t);
  end loop;
end $$;

create policy campaigns_select on public.campaigns for select to authenticated
  using (has_permission('campaigns.view') or has_permission('campaigns.manage') or has_permission('reports.view'));
create policy campaigns_insert on public.campaigns for insert to authenticated with check (has_permission('campaigns.manage'));
create policy campaigns_update on public.campaigns for update to authenticated
  using (has_permission('campaigns.manage')) with check (has_permission('campaigns.manage'));

create policy campaign_leads_select on public.campaign_leads for select to authenticated
  using (exists (select 1 from public.campaigns c where c.id = campaign_id) and exists (select 1 from public.leads l where l.id = lead_id));
create policy campaign_leads_insert on public.campaign_leads for insert to authenticated
  with check (has_permission('campaigns.manage') and can_edit_lead(lead_id));
create policy campaign_leads_delete on public.campaign_leads for delete to authenticated using (has_permission('campaigns.manage'));

grant select on public.landing_pages, public.site_entries to anon;
create policy landing_pages_public on public.landing_pages for select to anon using (status = 'published');
create policy landing_pages_select on public.landing_pages for select to authenticated
  using (status = 'published' or has_permission('campaigns.view') or has_permission('campaigns.manage'));
create policy landing_pages_insert on public.landing_pages for insert to authenticated with check (has_permission('campaigns.manage'));
create policy landing_pages_update on public.landing_pages for update to authenticated
  using (has_permission('campaigns.manage')) with check (has_permission('campaigns.manage'));

create policy site_entries_public on public.site_entries for select to anon using (status = 'published');
create policy site_entries_select on public.site_entries for select to authenticated
  using (status = 'published' or has_permission('site.manage'));
create policy site_entries_insert on public.site_entries for insert to authenticated with check (has_permission('site.manage'));
create policy site_entries_update on public.site_entries for update to authenticated
  using (has_permission('site.manage')) with check (has_permission('site.manage'));

-- anon needs to resolve names on public case studies
grant select on public.industries to anon;
create policy industries_select_public on public.industries for select to anon using (active);

create policy employee_targets_select on public.employee_targets for select to authenticated
  using ((is_active_user() and user_id = auth.uid()) or has_permission('targets.manage') or has_permission('reports.view'));
create policy employee_targets_insert on public.employee_targets for insert to authenticated with check (has_permission('targets.manage'));
create policy employee_targets_update on public.employee_targets for update to authenticated
  using (has_permission('targets.manage')) with check (has_permission('targets.manage'));
create policy employee_targets_delete on public.employee_targets for delete to authenticated using (has_permission('targets.manage'));

create policy integrations_select on public.integrations for select to authenticated using (has_permission('settings.manage'));
create policy integrations_update on public.integrations for update to authenticated
  using (has_permission('settings.manage')) with check (has_permission('settings.manage'));
revoke insert, delete on public.integrations from authenticated;

create policy ai_generations_select on public.ai_generations for select to authenticated
  using ((is_active_user() and user_id = auth.uid()) or has_permission('audit.view'));
revoke insert, update, delete on public.ai_generations from authenticated; -- written by the server after a real model call

revoke delete on public.campaigns, public.landing_pages, public.site_entries from authenticated;

-- Indexes for analytics
create index leads_utm_campaign_idx on public.leads(lower(utm_campaign)) where utm_campaign is not null;
create index leads_funnel_idx on public.leads(created_at, max_funnel_rank);
create index deals_lost_idx on public.deals(lost_at) where lost_at is not null;
create index proposals_sent_idx on public.proposals(sent_at) where sent_at is not null;
create index tasks_completed_idx on public.tasks(completed_at) where completed_at is not null;

-- ---------------------------------------------------------------------------
-- Function grants
-- ---------------------------------------------------------------------------
revoke execute on function
  public.campaigns_guard(), public.leads_campaign_link(), public.landing_pages_guard(), public.site_entries_guard(),
  public.submit_public_lead(jsonb), public.employee_targets_guard(), public.target_actual(uuid), public.integrations_guard(),
  public.record_integration_check(text, text, text, uuid), public.import_leads(jsonb), public.preview_duplicates(jsonb),
  public.global_search(text, int), public.analytics_summary(timestamptz, timestamptz),
  public.analytics_breakdown(text, timestamptz, timestamptz), public.analytics_timeseries(timestamptz, timestamptz, text, text),
  public.employee_performance(timestamptz, timestamptz)
from public, anon, authenticated;

grant execute on function public.target_actual(uuid), public.import_leads(jsonb), public.preview_duplicates(jsonb),
  public.global_search(text, int), public.analytics_summary(timestamptz, timestamptz),
  public.analytics_breakdown(text, timestamptz, timestamptz), public.analytics_timeseries(timestamptz, timestamptz, text, text),
  public.employee_performance(timestamptz, timestamptz)
to authenticated;
grant execute on function public.submit_public_lead(jsonb), public.record_integration_check(text, text, text, uuid)
to service_role;
