-- NovaTek platform — public branding read, permission matrix helpers, notification read-all.

-- Public website reads branding text (tagline, contact details, social links, footer).
-- The logo and the company name's wordmark are files in the app and are never stored or editable here.
create or replace function public.public_branding() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce((select value - 'company_name' from settings where key = 'branding'), '{}'::jsonb)
$$;
revoke execute on function public.public_branding() from public;
grant execute on function public.public_branding() to anon, authenticated;

-- Settings rows that only super admins may change (security posture).
create or replace function public.settings_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  if is_api_caller() then
    if (new.key like 'security.%' or (tg_op = 'UPDATE' and old.key like 'security.%')) and not is_superuser() then
      raise exception 'Only a Super Admin can change security settings' using errcode = '42501';
    end if;
    if new.key = 'branding' and new.value ? 'company_name' then
      new.value := new.value - 'company_name'; -- the company name is fixed (brand lock)
    end if;
    new.updated_by := auth.uid();
    new.updated_at := now();
  end if;
  return new;
end $$;
create trigger settings_a_guard before insert or update on public.settings
  for each row execute function public.settings_guard();
revoke execute on function public.settings_guard() from public, anon, authenticated;

update public.settings set value = value - 'company_name' where key = 'branding';

-- Mark all of the caller's notifications read in one statement.
create or replace function public.mark_all_notifications_read() returns int
language sql security invoker set search_path = public as $$
  with u as (update notifications set read_at = now() where user_id = auth.uid() and read_at is null returning 1)
  select count(*)::int from u
$$;
revoke execute on function public.mark_all_notifications_read() from public, anon;
grant execute on function public.mark_all_notifications_read() to authenticated;

-- Departments: audit already attached; add rename/delete safety (cannot delete a department in use).
create or replace function public.departments_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  if exists (select 1 from profiles where department_id = old.id) then
    raise exception 'This department still has people in it' using errcode = '23503';
  end if;
  return old;
end $$;
create trigger departments_guard before delete on public.departments for each row execute function public.departments_guard();
revoke execute on function public.departments_guard() from public, anon, authenticated;
