-- NovaTek platform — Work: projects, members, tasks, meetings, documents, scheduled notifications, announcements.

-- ---------------------------------------------------------------------------
-- Projects
-- ---------------------------------------------------------------------------
create table public.projects (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(name) between 1 and 200),
  client_id uuid references public.clients(id) on delete set null,
  deal_id uuid references public.deals(id) on delete set null,
  service_id uuid references public.services(id) on delete set null,
  description text check (length(description) <= 10000),
  start_date date,
  deadline date,
  status text not null default 'planning' check (status in ('planning', 'active', 'review', 'completed', 'paused', 'cancelled')),
  budget numeric(14, 2) check (budget >= 0 and budget <= 1000000000),
  currency char(3) not null default 'USD' check (currency ~ '^[A-Z]{3}$'),
  progress int not null default 0 check (progress between 0 and 100),
  priority text not null default 'medium' check (priority in ('low', 'medium', 'high', 'urgent')),
  manager_id uuid references public.profiles(id) on delete set null,
  department_id uuid references public.departments(id) on delete set null,
  completed_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (deadline is null or start_date is null or deadline >= start_date)
);
create index projects_status_idx on public.projects(status) where archived_at is null;
create index projects_client_idx on public.projects(client_id);
create index projects_manager_idx on public.projects(manager_id);
create trigger projects_updated_at before update on public.projects for each row execute function public.set_updated_at();

create table public.project_members (
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (length(role) between 1 and 60),
  added_by uuid references public.profiles(id) on delete set null,
  added_at timestamptz not null default now(),
  primary key (project_id, user_id)
);
create index project_members_user_idx on public.project_members(user_id);

create or replace function public.is_project_member(p_project uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from project_members where project_id = p_project and user_id = auth.uid())
      or exists (select 1 from projects where id = p_project and manager_id = auth.uid())
$$;

create or replace function public.can_manage_project(p_project uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select has_permission('projects.manage')
      or exists (select 1 from projects where id = p_project and manager_id = auth.uid() and is_active_user())
$$;

create or replace function public.projects_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
begin
  if new.status = 'completed' and (tg_op = 'INSERT' or old.status <> 'completed') then
    new.completed_at := now(); new.progress := 100;
  elsif new.status <> 'completed' then
    new.completed_at := null;
  end if;
  if not is_api_caller() then return new; end if;
  if tg_op = 'INSERT' then
    new.created_by := auth.uid(); new.archived_at := null;
    if new.client_id is not null and not exists (select 1 from clients where id = new.client_id) then
      raise exception 'Client not found' using errcode = '42501';
    end if;
    return new;
  end if;
  new.id := old.id; new.created_by := old.created_by; new.created_at := old.created_at;
  if not has_permission('projects.manage') then
    -- Project managers (manager_id) may update delivery fields, not ownership/budget.
    new.manager_id := old.manager_id; new.budget := old.budget; new.currency := old.currency;
    new.client_id := old.client_id; new.deal_id := old.deal_id; new.archived_at := old.archived_at;
  end if;
  return new;
end $$;
create trigger projects_a_guard before insert or update on public.projects
  for each row execute function public.projects_guard();

create or replace function public.projects_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    perform write_audit('project.created', 'project', new.id::text, jsonb_build_object('client_id', new.client_id, 'deal_id', new.deal_id));
    if new.manager_id is not null and new.manager_id is distinct from auth.uid() then
      perform notify_user(new.manager_id, 'project.assigned', 'You manage a new project: ' || new.name, null, '/app/projects/' || new.id, 'normal');
    end if;
  else
    if new.status is distinct from old.status then
      perform write_audit('project.status_changed', 'project', new.id::text, jsonb_build_object('from', old.status, 'to', new.status));
    end if;
    if new.manager_id is distinct from old.manager_id and new.manager_id is not null and new.manager_id is distinct from auth.uid() then
      perform notify_user(new.manager_id, 'project.assigned', 'You now manage: ' || new.name, null, '/app/projects/' || new.id, 'normal');
    end if;
  end if;
  return null;
end $$;
create trigger projects_b_after after insert or update on public.projects
  for each row execute function public.projects_after();

create or replace function public.project_members_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_name text;
begin
  if tg_op = 'INSERT' then
    select name into v_name from projects where id = new.project_id;
    perform write_audit('project.member_added', 'project', new.project_id::text, jsonb_build_object('user_id', new.user_id));
    if new.user_id is distinct from auth.uid() then
      perform notify_user(new.user_id, 'project.member', 'Added to project: ' || v_name, null, '/app/projects/' || new.project_id, 'normal');
    end if;
  else
    perform write_audit('project.member_removed', 'project', old.project_id::text, jsonb_build_object('user_id', old.user_id));
  end if;
  return null;
end $$;
create trigger project_members_after after insert or delete on public.project_members
  for each row execute function public.project_members_after();

create or replace function public.project_members_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  if is_api_caller() then new.added_by := auth.uid(); new.added_at := now(); end if;
  return new;
end $$;
create trigger project_members_guard before insert on public.project_members
  for each row execute function public.project_members_guard();

-- ---------------------------------------------------------------------------
-- Tasks
-- ---------------------------------------------------------------------------
create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(title) between 1 and 200),
  description text check (length(description) <= 10000),
  kind text not null default 'general' check (kind in ('general', 'technical', 'bug', 'design', 'marketing', 'sales')),
  assignee_id uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  priority text not null default 'medium' check (priority in ('low', 'medium', 'high', 'urgent')),
  due_at timestamptz,
  status text not null default 'todo' check (status in ('todo', 'in_progress', 'review', 'completed', 'cancelled')),
  department_id uuid references public.departments(id) on delete set null,
  lead_id uuid references public.leads(id) on delete set null,
  client_id uuid references public.clients(id) on delete set null,
  project_id uuid references public.projects(id) on delete cascade,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index tasks_assignee_idx on public.tasks(assignee_id, status);
create index tasks_project_idx on public.tasks(project_id);
create index tasks_due_idx on public.tasks(due_at) where status not in ('completed', 'cancelled');
create index tasks_lead_idx on public.tasks(lead_id) where lead_id is not null;
create trigger tasks_updated_at before update on public.tasks for each row execute function public.set_updated_at();

create or replace function public.can_view_task_row(p_assignee uuid, p_creator uuid, p_project uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select is_active_user() and (
    p_assignee = auth.uid() or p_creator = auth.uid()
    or has_permission('projects.view') or has_permission('tasks.assign')
    or (p_project is not null and is_project_member(p_project))
  )
$$;

create or replace function public.can_edit_task_row(p_assignee uuid, p_creator uuid, p_project uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select is_active_user() and (
    p_assignee = auth.uid() or p_creator = auth.uid()
    or has_permission('projects.manage') or has_permission('tasks.assign')
    or (p_project is not null and can_manage_project(p_project))
  )
$$;

create or replace function public.tasks_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
declare v_can_assign boolean;
begin
  if new.status = 'completed' and (tg_op = 'INSERT' or old.status <> 'completed') then new.completed_at := now();
  elsif new.status <> 'completed' then new.completed_at := null; end if;
  if not is_api_caller() then return new; end if;

  v_can_assign := has_permission('tasks.assign') or has_permission('projects.manage')
                  or (new.project_id is not null and can_manage_project(new.project_id));
  if tg_op = 'INSERT' then
    new.created_by := auth.uid();
    new.assignee_id := coalesce(new.assignee_id, auth.uid());
    if new.assignee_id <> auth.uid() and not v_can_assign then
      raise exception 'Not allowed to assign tasks to other people' using errcode = '42501';
    end if;
  else
    new.id := old.id; new.created_by := old.created_by; new.created_at := old.created_at;
    if new.assignee_id is distinct from old.assignee_id and not v_can_assign then
      raise exception 'Not allowed to reassign tasks' using errcode = '42501';
    end if;
    if new.project_id is distinct from old.project_id and not v_can_assign then
      raise exception 'Not allowed to move tasks between projects' using errcode = '42501';
    end if;
  end if;
  -- Linked records must be visible to the caller.
  if new.lead_id is not null and (tg_op = 'INSERT' or new.lead_id is distinct from old.lead_id)
     and not exists (select 1 from leads where id = new.lead_id) then
    raise exception 'Lead not found' using errcode = '42501';
  end if;
  if new.client_id is not null and (tg_op = 'INSERT' or new.client_id is distinct from old.client_id)
     and not exists (select 1 from clients where id = new.client_id) then
    raise exception 'Client not found' using errcode = '42501';
  end if;
  if new.project_id is not null and (tg_op = 'INSERT' or new.project_id is distinct from old.project_id)
     and not exists (select 1 from projects where id = new.project_id) then
    raise exception 'Project not found' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger tasks_a_guard before insert or update on public.tasks
  for each row execute function public.tasks_guard();

create or replace function public.tasks_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if new.assignee_id is not null and new.assignee_id is distinct from auth.uid() then
      perform notify_user(new.assignee_id, 'task.assigned', 'New task: ' || new.title, null, '/app/tasks/' || new.id,
                          case when new.priority in ('high', 'urgent') then 'high' else 'normal' end);
    end if;
    if new.lead_id is not null then
      insert into lead_activities(lead_id, actor_id, type, body, metadata)
      values (new.lead_id, auth.uid(), 'task', new.title, jsonb_build_object('task_id', new.id, 'assignee_id', new.assignee_id));
    end if;
  else
    if new.assignee_id is distinct from old.assignee_id then
      perform write_audit('task.reassigned', 'task', new.id::text, jsonb_build_object('from', old.assignee_id, 'to', new.assignee_id));
      if new.assignee_id is not null and new.assignee_id is distinct from auth.uid() then
        perform notify_user(new.assignee_id, 'task.assigned', 'Task assigned to you: ' || new.title, null, '/app/tasks/' || new.id, 'normal');
      end if;
    end if;
    if new.status is distinct from old.status and new.status = 'completed' and new.created_by is not null
       and new.created_by is distinct from auth.uid() then
      perform notify_user(new.created_by, 'task.completed', 'Task completed: ' || new.title, null, '/app/tasks/' || new.id, 'low');
    end if;
  end if;
  return null;
end $$;
create trigger tasks_b_after after insert or update on public.tasks
  for each row execute function public.tasks_after();

-- Project progress from tasks (when a project has tasks): completed / non-cancelled.
create or replace function public.refresh_project_progress() returns trigger
language plpgsql security definer set search_path = public as $$
declare p uuid; v_total int; v_done int;
begin
  foreach p in array array_remove(array[
    case when tg_op <> 'INSERT' then old.project_id end,
    case when tg_op <> 'DELETE' then new.project_id end], null) loop
    select count(*) filter (where status <> 'cancelled'), count(*) filter (where status = 'completed')
      into v_total, v_done from tasks where project_id = p;
    if v_total > 0 then
      update projects set progress = round(100.0 * v_done / v_total) where id = p and status <> 'completed';
    end if;
  end loop;
  return null;
end $$;
create trigger tasks_c_progress after insert or update of status, project_id or delete on public.tasks
  for each row execute function public.refresh_project_progress();

-- ---------------------------------------------------------------------------
-- Meetings
-- ---------------------------------------------------------------------------
create table public.meetings (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(title) between 1 and 200),
  lead_id uuid references public.leads(id) on delete set null,
  client_id uuid references public.clients(id) on delete set null,
  deal_id uuid references public.deals(id) on delete set null,
  project_id uuid references public.projects(id) on delete set null,
  starts_at timestamptz not null,
  duration_minutes int not null default 30 check (duration_minutes between 5 and 600),
  meeting_link text check (meeting_link is null or (meeting_link ~ '^https://' and length(meeting_link) <= 500)),
  location text check (length(location) <= 200),
  external_attendees text check (length(external_attendees) <= 1000),
  notes text check (length(notes) <= 10000),
  outcome text check (length(outcome) <= 5000),
  status text not null default 'scheduled' check (status in ('scheduled', 'completed', 'cancelled', 'no_show')),
  organizer_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index meetings_starts_idx on public.meetings(starts_at) where status = 'scheduled';
create index meetings_organizer_idx on public.meetings(organizer_id);
create index meetings_lead_idx on public.meetings(lead_id) where lead_id is not null;
create trigger meetings_updated_at before update on public.meetings for each row execute function public.set_updated_at();

create table public.meeting_participants (
  meeting_id uuid not null references public.meetings(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  primary key (meeting_id, user_id)
);
create index meeting_participants_user_idx on public.meeting_participants(user_id);

create or replace function public.is_meeting_participant(p_meeting uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from meeting_participants where meeting_id = p_meeting and user_id = auth.uid())
$$;

create or replace function public.meetings_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
begin
  if not is_api_caller() then return new; end if;
  if tg_op = 'INSERT' then
    new.organizer_id := auth.uid();
    if new.status <> 'scheduled' then raise exception 'New meetings start as scheduled' using errcode = '42501'; end if;
  else
    new.id := old.id; new.organizer_id := old.organizer_id; new.created_at := old.created_at;
    if new.status is distinct from old.status and old.status <> 'scheduled' then
      raise exception 'This meeting is already closed' using errcode = '42501';
    end if;
    if new.status = 'completed' and old.status = 'scheduled' and new.starts_at > now() then
      raise exception 'A meeting cannot be completed before it starts' using errcode = '42501';
    end if;
    if new.status = 'no_show' and new.starts_at > now() then
      raise exception 'A no-show can only be recorded after the start time' using errcode = '42501';
    end if;
  end if;
  if new.lead_id is not null and (tg_op = 'INSERT' or new.lead_id is distinct from old.lead_id)
     and not can_edit_lead(new.lead_id) then
    raise exception 'Lead not found' using errcode = '42501';
  end if;
  if new.client_id is not null and (tg_op = 'INSERT' or new.client_id is distinct from old.client_id)
     and not exists (select 1 from clients where id = new.client_id) then
    raise exception 'Client not found' using errcode = '42501';
  end if;
  if new.deal_id is not null and (tg_op = 'INSERT' or new.deal_id is distinct from old.deal_id)
     and not exists (select 1 from deals where id = new.deal_id) then
    raise exception 'Deal not found' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger meetings_a_guard before insert or update on public.meetings
  for each row execute function public.meetings_guard();

create or replace function public.meetings_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if new.lead_id is not null then
      insert into lead_activities(lead_id, actor_id, type, body, metadata)
      values (new.lead_id, auth.uid(), 'meeting_scheduled', new.title,
              jsonb_build_object('meeting_id', new.id, 'starts_at', new.starts_at));
      update leads set score = score where id = new.lead_id; -- rescore (meeting booked signal)
    end if;
    perform write_audit('meeting.scheduled', 'meeting', new.id::text, jsonb_build_object('lead_id', new.lead_id));
    return null;
  end if;
  if new.status is distinct from old.status then
    perform write_audit('meeting.' || new.status, 'meeting', new.id::text, '{}'::jsonb);
    if new.lead_id is not null then
      if new.status = 'completed' then
        -- A completed meeting is real contact: it updates last-contacted via the activity trigger.
        insert into lead_activities(lead_id, actor_id, type, body, metadata)
        values (new.lead_id, auth.uid(), 'meeting', coalesce(nullif(btrim(new.outcome), ''), new.title),
                jsonb_build_object('meeting_id', new.id, 'held_at', new.starts_at));
      elsif new.status in ('cancelled', 'no_show') then
        insert into lead_activities(lead_id, actor_id, type, body, metadata)
        values (new.lead_id, auth.uid(), 'meeting_cancelled',
                new.title || case when new.status = 'no_show' then ' — no show' else ' — cancelled' end,
                jsonb_build_object('meeting_id', new.id, 'status', new.status));
      end if;
      update leads set score = score where id = new.lead_id;
    end if;
    perform notify_user(mp.user_id, 'meeting.' || new.status, 'Meeting ' || replace(new.status, '_', ' ') || ': ' || new.title,
                        null, '/app/meetings/' || new.id, 'normal')
    from meeting_participants mp where mp.meeting_id = new.id and mp.user_id is distinct from auth.uid();
  end if;
  return null;
end $$;
create trigger meetings_b_after after insert or update on public.meetings
  for each row execute function public.meetings_after();

create or replace function public.meeting_participants_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare m meetings;
begin
  select * into m from meetings where id = new.meeting_id;
  if new.user_id is distinct from auth.uid() then
    perform notify_user(new.user_id, 'meeting.invited', 'Meeting: ' || m.title, to_char(m.starts_at at time zone 'UTC', 'DD Mon YYYY HH24:MI') || ' UTC',
                        '/app/meetings/' || m.id, 'normal');
  end if;
  return null;
end $$;
create trigger meeting_participants_after after insert on public.meeting_participants
  for each row execute function public.meeting_participants_after();

-- Scoring: "meeting booked" is also proven by a real, non-cancelled meeting with the lead.
create or replace function public.compute_lead_score(l public.leads) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  r record;
  matched boolean;
  total int := 0;
  breakdown jsonb := '[]'::jsonb;
begin
  for r in select * from scoring_rules where active order by signal loop
    matched := case r.signal
      when 'target_industry' then exists (select 1 from industries where id = l.industry_id and is_target)
      when 'target_country' then exists (select 1 from countries where code = l.country_code and is_target)
      when 'service_selected' then l.service_id is not null
      when 'has_website' then l.website_domain is not null
      when 'no_website' then l.website_domain is null and l.website is null
      when 'budget_known' then l.budget_range is not null and l.budget_range <> 'not_sure' or l.estimated_value is not null
      when 'budget_high' then l.budget_range = any (
        coalesce((select array_agg(x) from jsonb_array_elements_text(r.params -> 'ranges') x), array[]::text[]))
      when 'contact_complete' then l.email_normalized is not null and l.phone_key is not null and coalesce(l.contact_name, '') <> ''
      else false
    end;

    if r.signal in ('engaged_replied', 'meeting_booked') then
      matched := exists (select 1 from lead_statuses s where s.id = l.status_id and s.score_signal = r.signal)
        or exists (
          select 1 from lead_activities a
          join lead_statuses s on s.id = (a.metadata ->> 'to_status_id')::uuid
          where a.lead_id = l.id and a.type = 'status_change' and s.score_signal = r.signal
        );
      if r.signal = 'meeting_booked' and not matched then
        matched := exists (select 1 from meetings m where m.lead_id = l.id and m.status in ('scheduled', 'completed'));
      end if;
      if r.signal = 'engaged_replied' and not matched then
        matched := exists (select 1 from meetings m where m.lead_id = l.id and m.status = 'completed');
      end if;
    end if;

    if matched then
      total := total + r.points;
      breakdown := breakdown || jsonb_build_array(jsonb_build_object('signal', r.signal, 'label', r.label, 'points', r.points));
    end if;
  end loop;

  total := greatest(0, least(100, total));
  return jsonb_build_object('score', total, 'breakdown', breakdown, 'temperature', temperature_for(total));
end $$;

-- ---------------------------------------------------------------------------
-- Documents (files live in the private Supabase Storage bucket "documents")
-- ---------------------------------------------------------------------------
create table public.documents (
  id uuid primary key default gen_random_uuid(),
  entity text not null check (entity in ('client', 'project', 'deal', 'lead')),
  entity_id uuid not null,
  name text not null check (length(name) between 1 and 200),
  storage_path text not null unique check (length(storage_path) <= 500),
  size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 26214400),
  mime_type text not null check (length(mime_type) <= 120),
  uploaded_by uuid references public.profiles(id) on delete set null,
  archived_at timestamptz,
  created_at timestamptz not null default now()
);
create index documents_entity_idx on public.documents(entity, entity_id);

-- The caller can access the parent record (RLS of the parent table applies: invoker).
create or replace function public.can_access_entity(p_entity text, p_id uuid) returns boolean
language plpgsql stable set search_path = public as $$
begin
  return case p_entity
    when 'client' then exists (select 1 from clients where id = p_id)
    when 'project' then exists (select 1 from projects where id = p_id)
    when 'deal' then exists (select 1 from deals where id = p_id)
    when 'lead' then exists (select 1 from leads where id = p_id)
    else false end;
end $$;

create or replace function public.documents_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform write_audit(case when tg_op = 'INSERT' then 'document.uploaded' else 'document.archived' end,
                      'document', new.id::text, jsonb_build_object('entity', new.entity, 'entity_id', new.entity_id, 'name', new.name));
  return null;
end $$;
create trigger documents_after after insert or update of archived_at on public.documents
  for each row execute function public.documents_after();

create or replace function public.documents_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  if is_api_caller() then
    if tg_op = 'INSERT' then new.uploaded_by := auth.uid(); new.archived_at := null;
    else
      new.id := old.id; new.entity := old.entity; new.entity_id := old.entity_id; new.storage_path := old.storage_path;
      new.uploaded_by := old.uploaded_by; new.size_bytes := old.size_bytes; new.mime_type := old.mime_type; new.created_at := old.created_at;
    end if;
  end if;
  return new;
end $$;
create trigger documents_guard before insert or update on public.documents
  for each row execute function public.documents_guard();

-- Storage bucket + policies (only on real Supabase, where the storage schema exists).
do $$
begin
  if exists (select 1 from pg_namespace where nspname = 'storage')
     and exists (select 1 from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'storage' and c.relname = 'buckets') then
    insert into storage.buckets(id, name, public, file_size_limit)
    values ('documents', 'documents', false, 26214400) on conflict (id) do nothing;
    -- Object paths are "<entity>/<entity_id>/<uuid>-<name>"; access follows the parent record.
    execute $p$create policy documents_read on storage.objects for select to authenticated
      using (bucket_id = 'documents' and public.can_access_entity(split_part(name, '/', 1), (split_part(name, '/', 2))::uuid))$p$;
    execute $p$create policy documents_write on storage.objects for insert to authenticated
      with check (bucket_id = 'documents' and public.can_access_entity(split_part(name, '/', 1), (split_part(name, '/', 2))::uuid))$p$;
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- Notifications: de-duplication + scheduled reminders + announcements
-- ---------------------------------------------------------------------------
alter table public.notifications add column dedupe_key text check (length(dedupe_key) <= 200);
create unique index notifications_dedupe_idx on public.notifications(user_id, dedupe_key) where dedupe_key is not null;

create or replace function public.notify_once(
  p_user uuid, p_key text, p_type text, p_title text, p_body text, p_link text, p_priority text default 'normal'
) returns boolean
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if p_user is null then return false; end if;
  insert into notifications(user_id, type, title, body, link, priority, dedupe_key)
  values (p_user, p_type, p_title, p_body, p_link, p_priority, p_key)
  on conflict (user_id, dedupe_key) where dedupe_key is not null do nothing;
  get diagnostics n = row_count;
  return n > 0;
end $$;

-- Run by the scheduler (service role) every few minutes. Idempotent: each reminder is sent once.
create or replace function public.run_scheduled_notifications() returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_tasks_due int := 0; v_tasks_overdue int := 0; v_meetings int := 0; v_followups int := 0; v_proposals int := 0; r record;
begin
  -- Tasks due within 24h
  for r in select t.* from tasks t join profiles p on p.id = t.assignee_id and p.status = 'active'
           where t.status not in ('completed', 'cancelled') and t.due_at between now() and now() + interval '24 hours' loop
    if notify_once(r.assignee_id, 'task.due:' || r.id || ':' || to_char(r.due_at, 'YYYYMMDDHH24MI'), 'task.due',
                   'Task due soon: ' || r.title, null, '/app/tasks/' || r.id, 'normal') then v_tasks_due := v_tasks_due + 1; end if;
  end loop;
  -- Tasks overdue
  for r in select t.* from tasks t join profiles p on p.id = t.assignee_id and p.status = 'active'
           where t.status not in ('completed', 'cancelled') and t.due_at < now() loop
    if notify_once(r.assignee_id, 'task.overdue:' || r.id || ':' || to_char(r.due_at, 'YYYYMMDDHH24MI'), 'task.overdue',
                   'Task overdue: ' || r.title, null, '/app/tasks/' || r.id, 'high') then v_tasks_overdue := v_tasks_overdue + 1; end if;
  end loop;
  -- Meetings starting within 60 minutes (organizer + participants)
  for r in select m.id, m.title, m.starts_at, u.user_id
           from meetings m
           cross join lateral (select m.organizer_id as user_id union select mp.user_id from meeting_participants mp where mp.meeting_id = m.id) u
           join profiles p on p.id = u.user_id and p.status = 'active'
           where m.status = 'scheduled' and m.starts_at between now() and now() + interval '60 minutes' loop
    if notify_once(r.user_id, 'meeting.soon:' || r.id || ':' || to_char(r.starts_at, 'YYYYMMDDHH24MI'), 'meeting.approaching',
                   'Meeting soon: ' || r.title, to_char(r.starts_at at time zone 'UTC', 'HH24:MI') || ' UTC',
                   '/app/meetings/' || r.id, 'high') then v_meetings := v_meetings + 1; end if;
  end loop;
  -- Lead follow-ups overdue
  for r in select l.* from leads l join profiles p on p.id = l.assigned_to and p.status = 'active'
           where l.archived_at is null and l.next_follow_up_at < now()
             and not exists (select 1 from lead_statuses s where s.id = l.status_id and s.is_closed) loop
    if notify_once(r.assigned_to, 'followup.overdue:' || r.id || ':' || to_char(r.next_follow_up_at, 'YYYYMMDDHH24MI'),
                   'followup.overdue', 'Follow-up overdue: ' || r.company_name, null, '/app/leads/' || r.id, 'high')
    then v_followups := v_followups + 1; end if;
  end loop;
  v_proposals := expire_due_proposals();
  return jsonb_build_object('tasks_due', v_tasks_due, 'tasks_overdue', v_tasks_overdue, 'meetings', v_meetings,
                            'followups_overdue', v_followups, 'proposals_expired', v_proposals);
end $$;

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(title) between 3 and 160),
  body text check (length(body) <= 4000),
  priority text not null default 'normal' check (priority in ('normal', 'high')),
  sent_by uuid references public.profiles(id) on delete set null,
  recipient_count int not null default 0,
  created_at timestamptz not null default now()
);

create or replace function public.send_announcement(p_title text, p_body text, p_priority text default 'normal') returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; n int;
begin
  if not has_permission('settings.manage') then raise exception 'Not allowed' using errcode = '42501'; end if;
  if length(btrim(coalesce(p_title, ''))) < 3 then raise exception 'Title is required' using errcode = '23514'; end if;
  insert into announcements(title, body, priority, sent_by)
  values (btrim(p_title), nullif(btrim(p_body), ''), case when p_priority = 'high' then 'high' else 'normal' end, auth.uid())
  returning id into v_id;
  insert into notifications(user_id, type, title, body, link, priority, dedupe_key)
  select p.id, 'announcement', btrim(p_title), nullif(btrim(p_body), ''), '/app/notifications',
         case when p_priority = 'high' then 'high' else 'normal' end, 'announcement:' || v_id
  from profiles p where p.status = 'active';
  get diagnostics n = row_count;
  update announcements set recipient_count = n where id = v_id;
  perform write_audit('announcement.sent', 'announcement', v_id::text, jsonb_build_object('recipients', n));
  return v_id;
end $$;

-- ---------------------------------------------------------------------------
-- RLS
-- ---------------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['projects', 'project_members', 'tasks', 'meetings', 'meeting_participants', 'documents', 'announcements']
  loop
    execute format('alter table public.%I enable row level security', t);
    execute format('alter table public.%I force row level security', t);
    execute format('revoke all on public.%I from anon', t);
  end loop;
end $$;

create policy projects_select on public.projects for select to authenticated
  using (is_active_user() and (has_permission('projects.view') or has_permission('projects.manage') or manager_id = auth.uid()
         or created_by = auth.uid() or is_project_member(id)));
create policy projects_insert on public.projects for insert to authenticated with check (has_permission('projects.manage'));
create policy projects_update on public.projects for update to authenticated
  using (can_manage_project(id)) with check (can_manage_project(id));

create policy project_members_select on public.project_members for select to authenticated
  using (exists (select 1 from public.projects p where p.id = project_id));
create policy project_members_insert on public.project_members for insert to authenticated
  with check (can_manage_project(project_id));
create policy project_members_delete on public.project_members for delete to authenticated
  using (can_manage_project(project_id));

create policy tasks_select on public.tasks for select to authenticated using (can_view_task_row(assignee_id, created_by, project_id));
create policy tasks_insert on public.tasks for insert to authenticated with check (is_active_user());
create policy tasks_update on public.tasks for update to authenticated
  using (can_edit_task_row(assignee_id, created_by, project_id)) with check (can_edit_task_row(assignee_id, created_by, project_id));

create policy meetings_select on public.meetings for select to authenticated
  using (is_active_user() and (organizer_id = auth.uid() or is_meeting_participant(id) or has_permission('sales.manage')
         or (lead_id is not null and exists (select 1 from public.leads l where l.id = lead_id))));
create policy meetings_insert on public.meetings for insert to authenticated with check (is_active_user());
create policy meetings_update on public.meetings for update to authenticated
  using (is_active_user() and (organizer_id = auth.uid() or has_permission('sales.manage')))
  with check (is_active_user() and (organizer_id = auth.uid() or has_permission('sales.manage')));

create policy meeting_participants_select on public.meeting_participants for select to authenticated
  using (exists (select 1 from public.meetings m where m.id = meeting_id));
create policy meeting_participants_insert on public.meeting_participants for insert to authenticated
  with check (exists (select 1 from public.meetings m where m.id = meeting_id and (m.organizer_id = auth.uid() or has_permission('sales.manage'))));
create policy meeting_participants_delete on public.meeting_participants for delete to authenticated
  using (exists (select 1 from public.meetings m where m.id = meeting_id and (m.organizer_id = auth.uid() or has_permission('sales.manage'))));

create policy documents_select on public.documents for select to authenticated
  using (is_active_user() and can_access_entity(entity, entity_id));
create policy documents_insert on public.documents for insert to authenticated
  with check (is_active_user() and can_access_entity(entity, entity_id));
create policy documents_update on public.documents for update to authenticated
  using (uploaded_by = auth.uid() or has_permission('settings.manage'))
  with check (uploaded_by = auth.uid() or has_permission('settings.manage'));

create policy announcements_select on public.announcements for select to authenticated using (is_active_user());

revoke delete on public.projects, public.tasks, public.meetings, public.documents from authenticated;
revoke insert, update, delete on public.announcements from authenticated;

-- ---------------------------------------------------------------------------
-- Function grants
-- ---------------------------------------------------------------------------
revoke execute on function
  public.is_project_member(uuid), public.can_manage_project(uuid), public.projects_guard(), public.projects_after(),
  public.project_members_after(), public.project_members_guard(), public.can_view_task_row(uuid, uuid, uuid),
  public.can_edit_task_row(uuid, uuid, uuid), public.tasks_guard(), public.tasks_after(), public.refresh_project_progress(),
  public.is_meeting_participant(uuid), public.meetings_guard(), public.meetings_after(), public.meeting_participants_after(),
  public.compute_lead_score(public.leads), public.can_access_entity(text, uuid), public.documents_after(),
  public.documents_guard(), public.notify_once(uuid, text, text, text, text, text, text),
  public.run_scheduled_notifications(), public.send_announcement(text, text, text)
from public, anon, authenticated;

grant execute on function public.is_project_member(uuid), public.can_manage_project(uuid),
  public.can_view_task_row(uuid, uuid, uuid), public.can_edit_task_row(uuid, uuid, uuid), public.is_meeting_participant(uuid),
  public.can_access_entity(text, uuid), public.send_announcement(text, text, text)
to authenticated;
grant execute on function public.run_scheduled_notifications() to service_role;
