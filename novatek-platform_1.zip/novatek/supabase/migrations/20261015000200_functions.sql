-- NovaTek platform — authorization helpers, normalization, scoring, dedupe, timeline, audit, intake.
-- SECURITY DEFINER functions always pin search_path and have EXECUTE revoked unless a role needs it.

-- ---------------------------------------------------------------------------
-- Authorization helpers (used by RLS)
-- ---------------------------------------------------------------------------
create or replace function public.is_active_user() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and status = 'active')
$$;

create or replace function public.is_superuser() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from user_roles ur
    join roles r on r.id = ur.role_id
    join profiles p on p.id = ur.user_id
    where ur.user_id = auth.uid() and p.status = 'active' and r.is_superuser
  )
$$;

create or replace function public.has_permission(p_key text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from user_roles ur
    join profiles p on p.id = ur.user_id and p.status = 'active'
    join roles r on r.id = ur.role_id
    left join role_permissions rp on rp.role_id = r.id and rp.permission_key = p_key
    where ur.user_id = auth.uid() and (r.is_superuser or rp.permission_key is not null)
  )
$$;

create or replace function public.my_permissions() returns setof text
language sql stable security definer set search_path = public as $$
  select pm.key from permissions pm
  where exists (
    select 1 from user_roles ur
    join profiles p on p.id = ur.user_id and p.status = 'active'
    join roles r on r.id = ur.role_id
    left join role_permissions rp on rp.role_id = r.id and rp.permission_key = pm.key
    where ur.user_id = auth.uid() and (r.is_superuser or rp.permission_key is not null)
  )
$$;

create or replace function public.user_has_superuser_role(p_user uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles ur join roles r on r.id = ur.role_id
                 where ur.user_id = p_user and r.is_superuser)
$$;

create or replace function public.users_with_permission(p_key text) returns setof uuid
language sql stable security definer set search_path = public as $$
  select distinct ur.user_id from user_roles ur
  join profiles p on p.id = ur.user_id and p.status = 'active'
  join roles r on r.id = ur.role_id
  left join role_permissions rp on rp.role_id = r.id and rp.permission_key = p_key
  where r.is_superuser or rp.permission_key is not null
$$;

-- Callers acting directly through the API (PostgREST roles). Definer functions run as owner,
-- so column guards below apply only to direct API writes.
create or replace function public.is_api_caller() returns boolean
language sql stable as $$
  select current_user in ('authenticated', 'anon')
$$;

-- ---------------------------------------------------------------------------
-- Audit & notifications (internal)
-- ---------------------------------------------------------------------------
create or replace function public.write_audit(
  p_action text, p_entity text, p_entity_id text, p_metadata jsonb default '{}'::jsonb,
  p_actor uuid default null
) returns void
language plpgsql security definer set search_path = public as $$
begin
  insert into audit_logs(actor_id, action, entity, entity_id, metadata)
  values (coalesce(p_actor, auth.uid()), p_action, p_entity, p_entity_id, coalesce(p_metadata, '{}'::jsonb));
end $$;

-- For server-side events with a verified actor (login, logout, export). Service role only.
create or replace function public.log_audit_event(
  p_actor uuid, p_action text, p_entity text, p_entity_id text, p_metadata jsonb default '{}'::jsonb
) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_action !~ '^[a-z_]+\.[a-z_]+$' then
    raise exception 'invalid audit action';
  end if;
  perform write_audit(p_action, p_entity, p_entity_id, p_metadata, p_actor);
end $$;

create or replace function public.notify_user(
  p_user uuid, p_type text, p_title text, p_body text, p_link text, p_priority text default 'normal'
) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_user is null then return; end if;
  insert into notifications(user_id, type, title, body, link, priority)
  values (p_user, p_type, p_title, p_body, p_link, p_priority);
end $$;

-- ---------------------------------------------------------------------------
-- Normalization (mirrored in src/lib/leads/normalize.ts — parity is tested)
-- ---------------------------------------------------------------------------
create or replace function public.normalize_company_name(p text) returns text
language sql immutable as $$
  select btrim(regexp_replace(
    regexp_replace(
      regexp_replace(replace(lower(coalesce(p, '')), '&', ' and '), '[^a-z0-9]+', ' ', 'g'),
      '\m(the|pvt|private|ltd|limited|llc|inc|incorporated|co|company|corp|corporation|plc|gmbh|fze|fzco|fz|smc)\M', ' ', 'g'),
    '\s+', ' ', 'g'))
$$;

create or replace function public.normalize_domain(p text) returns text
language plpgsql immutable as $$
declare d text;
begin
  if p is null or btrim(p) = '' then return null; end if;
  d := lower(btrim(p));
  d := regexp_replace(d, '^[a-z][a-z0-9+.-]*://', '');
  d := regexp_replace(d, '^//', '');
  d := regexp_replace(d, '^[^@/]*@', '');      -- strip userinfo
  d := split_part(d, '/', 1);
  d := split_part(d, '?', 1);
  d := split_part(d, '#', 1);
  d := split_part(d, ':', 1);
  d := regexp_replace(d, '^www\.', '');
  d := regexp_replace(d, '\.+$', '');
  if d !~ '^[a-z0-9-]+(\.[a-z0-9-]+)+$' then return null; end if;
  return d;
end $$;

create or replace function public.normalize_email(p text) returns text
language sql immutable as $$
  select nullif(lower(btrim(coalesce(p, ''))), '')
$$;

create or replace function public.phone_key(p text) returns text
language sql immutable as $$
  select case when length(regexp_replace(coalesce(p, ''), '\D', '', 'g')) >= 7
    then right(regexp_replace(p, '\D', '', 'g'), 9) end
$$;

create or replace function public.temperature_for(p_score int) returns text
language sql immutable as $$
  select case when p_score <= 30 then 'cold' when p_score <= 60 then 'warm'
              when p_score <= 80 then 'hot' else 'very_hot' end
$$;

-- ---------------------------------------------------------------------------
-- Scoring — only signals that real data proves. Unproven signals contribute nothing.
-- ---------------------------------------------------------------------------
create or replace function public.compute_lead_score(l public.leads) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  r record;
  matched boolean;
  total int := 0;
  breakdown jsonb := '[]'::jsonb;
begin
  for r in select * from scoring_rules where active order by signal loop
    matched := case r.signal
      when 'target_industry' then exists (select 1 from industries where id = l.industry_id and is_target)
      when 'target_country' then exists (select 1 from countries where code = l.country_code and is_target)
      when 'service_selected' then l.service_id is not null
      when 'has_website' then l.website_domain is not null
      when 'no_website' then l.website_domain is null and l.website is null
      when 'budget_known' then l.budget_range is not null and l.budget_range <> 'not_sure' or l.estimated_value is not null
      when 'budget_high' then l.budget_range = any (
        coalesce((select array_agg(x) from jsonb_array_elements_text(r.params -> 'ranges') x), array[]::text[]))
      when 'contact_complete' then l.email_normalized is not null and l.phone_key is not null and coalesce(l.contact_name, '') <> ''
      else false
    end;

    -- Engagement signals: true if the lead is in, or has ever been moved to, a status carrying that signal.
    if r.signal in ('engaged_replied', 'meeting_booked') then
      matched := exists (select 1 from lead_statuses s where s.id = l.status_id and s.score_signal = r.signal)
        or exists (
          select 1 from lead_activities a
          join lead_statuses s on s.id = (a.metadata ->> 'to_status_id')::uuid
          where a.lead_id = l.id and a.type = 'status_change' and s.score_signal = r.signal
        );
    end if;

    if matched then
      total := total + r.points;
      breakdown := breakdown || jsonb_build_array(jsonb_build_object('signal', r.signal, 'label', r.label, 'points', r.points));
    end if;
  end loop;

  total := greatest(0, least(100, total));
  return jsonb_build_object('score', total, 'breakdown', breakdown, 'temperature', temperature_for(total));
end $$;

-- ---------------------------------------------------------------------------
-- Deduplication — flags only, never destroys data.
-- ---------------------------------------------------------------------------
create or replace function public.find_duplicate_lead(
  p_exclude uuid, p_domain text, p_email text, p_phone_key text, p_name_norm text
) returns uuid
language sql stable security definer set search_path = public as $$
  select id from leads
  where archived_at is null
    and (p_exclude is null or id <> p_exclude)
    and (
      (p_domain is not null and website_domain = p_domain)
      or (p_email is not null and email_normalized = p_email)
      or (p_phone_key is not null and phone_key = p_phone_key)
      or (length(coalesce(p_name_norm, '')) >= 3 and company_name_normalized = p_name_norm)
    )
  order by created_at asc
  limit 1
$$;

-- ---------------------------------------------------------------------------
-- Lead triggers
-- ---------------------------------------------------------------------------
create or replace function public.leads_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
begin
  if not is_api_caller() then return new; end if;

  if tg_op = 'INSERT' then
    new.created_by := auth.uid();
    new.archived_at := null;
    new.archived_by := null;
    if new.assigned_to is not null and new.assigned_to <> auth.uid() and not has_permission('leads.assign') then
      raise exception 'Not allowed to assign leads to other users' using errcode = '42501';
    end if;
    return new;
  end if;

  -- UPDATE
  new.id := old.id;
  new.created_by := old.created_by;
  new.created_at := old.created_at;
  new.archived_by := old.archived_by;

  if new.assigned_to is distinct from old.assigned_to and not has_permission('leads.assign') then
    raise exception 'Not allowed to reassign leads' using errcode = '42501';
  end if;

  if new.archived_at is distinct from old.archived_at then
    if not has_permission('leads.delete') then
      raise exception 'Not allowed to archive leads' using errcode = '42501';
    end if;
    new.archived_by := case when new.archived_at is null then null else auth.uid() end;
  end if;

  -- Duplicate flag can only be dismissed (set to null), and only by mergers.
  if new.possible_duplicate_of is distinct from old.possible_duplicate_of then
    if new.possible_duplicate_of is not null or not has_permission('leads.merge') then
      new.possible_duplicate_of := old.possible_duplicate_of;
    end if;
  end if;
  return new;
end $$;

create or replace function public.leads_prepare() returns trigger
language plpgsql security definer set search_path = public as $$
declare s jsonb;
begin
  new.company_name := btrim(new.company_name);
  new.company_name_normalized := normalize_company_name(new.company_name);
  new.website_domain := normalize_domain(new.website);
  new.email := nullif(btrim(new.email), '');
  new.email_normalized := normalize_email(new.email);
  new.phone_key := phone_key(new.phone);

  if tg_op = 'INSERT' then
    new.possible_duplicate_of := find_duplicate_lead(
      new.id, new.website_domain, new.email_normalized, new.phone_key, new.company_name_normalized);
  end if;

  s := compute_lead_score(new);
  new.score := (s ->> 'score')::int;
  new.score_breakdown := s -> 'breakdown';
  new.temperature := s ->> 'temperature';
  return new;
end $$;

create or replace function public.leads_after_insert() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_source text;
begin
  select name into v_source from lead_sources where id = new.source_id;
  insert into lead_activities(lead_id, actor_id, type, body, metadata)
  values (new.id, auth.uid(), 'created', null,
          jsonb_build_object('source', v_source, 'possible_duplicate_of', new.possible_duplicate_of));

  if new.assigned_to is not null then
    insert into lead_activities(lead_id, actor_id, type, metadata)
    values (new.id, auth.uid(), 'assigned', jsonb_build_object('to', new.assigned_to));
    if new.assigned_to is distinct from auth.uid() then
      perform notify_user(new.assigned_to, 'lead.assigned', 'New lead assigned: ' || new.company_name,
                          null, '/app/leads/' || new.id, 'normal');
    end if;
  end if;

  perform write_audit('lead.created', 'lead', new.id::text,
    jsonb_build_object('source', v_source, 'possible_duplicate_of', new.possible_duplicate_of));
  return null;
end $$;

create or replace function public.leads_after_update() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_from text; v_to text; v_changed text[];
begin
  if new.status_id is distinct from old.status_id then
    select name into v_from from lead_statuses where id = old.status_id;
    select name into v_to from lead_statuses where id = new.status_id;
    insert into lead_activities(lead_id, actor_id, type, metadata)
    values (new.id, auth.uid(), 'status_change', jsonb_build_object(
      'from_status_id', old.status_id, 'to_status_id', new.status_id, 'from', v_from, 'to', v_to));
    perform write_audit('lead.status_changed', 'lead', new.id::text, jsonb_build_object('from', v_from, 'to', v_to));
  end if;

  if new.assigned_to is distinct from old.assigned_to then
    insert into lead_activities(lead_id, actor_id, type, metadata)
    values (new.id, auth.uid(), case when new.assigned_to is null then 'unassigned' else 'assigned' end,
            jsonb_build_object('from', old.assigned_to, 'to', new.assigned_to));
    perform write_audit('lead.assigned', 'lead', new.id::text, jsonb_build_object('from', old.assigned_to, 'to', new.assigned_to));
    if new.assigned_to is not null and new.assigned_to is distinct from auth.uid() then
      perform notify_user(new.assigned_to,
        case when old.assigned_to is null then 'lead.assigned' else 'lead.reassigned' end,
        'Lead assigned to you: ' || new.company_name, null, '/app/leads/' || new.id, 'normal');
    end if;
  end if;

  if new.archived_at is distinct from old.archived_at then
    insert into lead_activities(lead_id, actor_id, type)
    values (new.id, auth.uid(), case when new.archived_at is null then 'restored' else 'archived' end);
    perform write_audit(case when new.archived_at is null then 'lead.restored' else 'lead.archived' end,
                        'lead', new.id::text, '{}'::jsonb);
  end if;

  -- Record which other fields changed (names only; values stay in the row).
  select array_agg(n.key order by n.key) into v_changed
  from jsonb_each(to_jsonb(new)) n
  join jsonb_each(to_jsonb(old)) o on o.key = n.key
  where n.value is distinct from o.value
    and n.key not in ('updated_at', 'score', 'score_breakdown', 'temperature', 'status_id', 'assigned_to',
                      'archived_at', 'archived_by', 'last_contacted_at', 'company_name_normalized',
                      'website_domain', 'email_normalized', 'phone_key');
  if v_changed is not null then
    insert into lead_activities(lead_id, actor_id, type, metadata)
    values (new.id, auth.uid(), 'updated', jsonb_build_object('fields', to_jsonb(v_changed)));
    perform write_audit('lead.updated', 'lead', new.id::text, jsonb_build_object('fields', to_jsonb(v_changed)));
  end if;
  return null;
end $$;

create trigger leads_a_guard before insert or update on public.leads
  for each row execute function public.leads_guard();
create trigger leads_b_prepare before insert or update on public.leads
  for each row execute function public.leads_prepare();
create trigger leads_c_after_insert after insert on public.leads
  for each row execute function public.leads_after_insert();
create trigger leads_d_after_update after update on public.leads
  for each row execute function public.leads_after_update();

-- Contact activities update last_contacted_at.
create or replace function public.lead_activities_after_insert() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.type in ('call', 'email', 'message', 'meeting') then
    update leads set last_contacted_at = greatest(coalesce(last_contacted_at, new.created_at), new.created_at)
    where id = new.lead_id;
  end if;
  return null;
end $$;
create trigger lead_activities_after_insert after insert on public.lead_activities
  for each row execute function public.lead_activities_after_insert();

-- Direct API inserts into the timeline: force actor and timestamp, allow only manual types.
create or replace function public.lead_activities_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
begin
  if not is_api_caller() then return new; end if;
  if new.type not in ('note', 'call', 'email', 'message', 'meeting', 'follow_up') then
    raise exception 'Activity type is system-managed' using errcode = '42501';
  end if;
  new.actor_id := auth.uid();
  new.created_at := now();
  new.metadata := '{}'::jsonb;
  return new;
end $$;
create trigger lead_activities_guard before insert on public.lead_activities
  for each row execute function public.lead_activities_guard();

-- Rescore after scoring-rule changes (touching rows re-runs leads_prepare).
create or replace function public.rescore_all_leads() returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if is_api_caller() and not has_permission('crm.configure') then
    raise exception 'Not allowed' using errcode = '42501';
  end if;
  update leads set score = score where archived_at is null;
  get diagnostics n = row_count;
  perform write_audit('scoring.rescored', 'lead', null, jsonb_build_object('count', n));
  return n;
end $$;

-- ---------------------------------------------------------------------------
-- Profiles: provisioning + guards
-- ---------------------------------------------------------------------------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, email, full_name)
  values (new.id, coalesce(new.email, ''), coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.profiles_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
declare target_is_super boolean;
begin
  if not is_api_caller() then return new; end if;
  new.id := old.id;
  new.email := old.email;
  new.created_at := old.created_at;

  if not has_permission('employees.manage') then
    new.status := old.status;
    new.department_id := old.department_id;
    new.designation := old.designation;
    new.joining_date := old.joining_date;
  elsif new.status is distinct from old.status then
    if old.id = auth.uid() then
      raise exception 'You cannot change your own account status' using errcode = '42501';
    end if;
    target_is_super := user_has_superuser_role(old.id);
    if target_is_super and not is_superuser() then
      raise exception 'Only a Super Admin can change a Super Admin account' using errcode = '42501';
    end if;
  end if;
  return new;
end $$;
create trigger profiles_guard before update on public.profiles
  for each row execute function public.profiles_guard();

create or replace function public.profiles_after_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status is distinct from old.status then
    perform write_audit(case when new.status = 'active' then 'user.activated' else 'user.disabled' end,
                        'user', new.id::text, '{}'::jsonb);
  end if;
  if (new.department_id, new.designation, new.joining_date) is distinct from (old.department_id, old.designation, old.joining_date) then
    perform write_audit('user.employment_updated', 'user', new.id::text, '{}'::jsonb);
  end if;
  return null;
end $$;
create trigger profiles_after_update after update on public.profiles
  for each row execute function public.profiles_after_update();

-- ---------------------------------------------------------------------------
-- Role assignment guards + audit
-- ---------------------------------------------------------------------------
create or replace function public.user_roles_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
declare v_role_super boolean; v_row user_roles;
begin
  v_row := case when tg_op = 'DELETE' then old else new end;
  if is_api_caller() then
    if v_row.user_id = auth.uid() then
      raise exception 'You cannot change your own roles' using errcode = '42501';
    end if;
    select is_superuser into v_role_super from roles where id = v_row.role_id;
    if v_role_super and not is_superuser() then
      raise exception 'Only a Super Admin can grant or revoke Super Admin' using errcode = '42501';
    end if;
    if tg_op = 'INSERT' then
      new.assigned_by := auth.uid();
      new.assigned_at := now();
    end if;
  end if;
  return case when tg_op = 'DELETE' then old else new end;
end $$;
create trigger user_roles_guard before insert or delete on public.user_roles
  for each row execute function public.user_roles_guard();

create or replace function public.user_roles_audit() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_key text; v_row user_roles;
begin
  v_row := case when tg_op = 'DELETE' then old else new end;
  select key into v_key from roles where id = v_row.role_id;
  perform write_audit(case when tg_op = 'DELETE' then 'role.revoked' else 'role.granted' end,
                      'user', v_row.user_id::text, jsonb_build_object('role', v_key));
  return null;
end $$;
create trigger user_roles_audit after insert or delete on public.user_roles
  for each row execute function public.user_roles_audit();

-- Generic audit for configuration tables.
create or replace function public.audit_config_change() returns trigger
language plpgsql security definer set search_path = public as $$
declare v jsonb;
begin
  v := to_jsonb(case when tg_op = 'DELETE' then old else new end);
  perform write_audit(tg_table_name || '.' || lower(tg_op), tg_table_name,
    coalesce(v ->> 'id', v ->> 'key', v ->> 'signal', v ->> 'code',
             (v ->> 'role_id') || ':' || (v ->> 'permission_key')),
    case when tg_op = 'UPDATE' then jsonb_build_object('before', to_jsonb(old), 'after', to_jsonb(new))
         else jsonb_build_object('row', v) end);
  return null;
end $$;

do $$
declare t text;
begin
  foreach t in array array['roles', 'role_permissions', 'permissions', 'lead_sources', 'lead_statuses',
                           'services', 'industries', 'countries', 'scoring_rules', 'settings', 'departments']
  loop
    execute format('create trigger %I after insert or update or delete on public.%I
                    for each row execute function public.audit_config_change()', t || '_audit', t);
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- Public lead intake — called only by the server (service role) after validation.
-- One transaction: rate-limit, resolve refs, insert lead (dedupe+score via triggers), notify.
-- ---------------------------------------------------------------------------
create or replace function public.submit_public_lead(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_ip text := p ->> 'ip_hash';
  v_email text := normalize_email(p ->> 'email');
  v_source uuid; v_status uuid; v_service uuid; v_country char(2);
  v_lead leads;
  v_source_key text;
  u uuid;
begin
  if v_ip is null or length(v_ip) < 16 then raise exception 'ip_hash required'; end if;
  if v_email is null or v_email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' then
    return jsonb_build_object('ok', false, 'error', 'invalid_email');
  end if;
  if length(coalesce(p ->> 'company', '')) < 1 or length(coalesce(p ->> 'name', '')) < 1 then
    return jsonb_build_object('ok', false, 'error', 'missing_fields');
  end if;

  -- Abuse controls
  if (select count(*) from lead_submissions where ip_hash = v_ip and created_at > now() - interval '10 minutes') >= 5 then
    return jsonb_build_object('ok', false, 'error', 'rate_limited');
  end if;
  if exists (select 1 from lead_submissions where email_normalized = v_email and created_at > now() - interval '2 minutes') then
    return jsonb_build_object('ok', false, 'error', 'duplicate_submission');
  end if;
  if (select count(*) from lead_submissions where email_normalized = v_email and created_at > now() - interval '24 hours') >= 5 then
    return jsonb_build_object('ok', false, 'error', 'rate_limited');
  end if;

  v_source_key := case
    when nullif(p ->> 'utm_campaign', '') is not null then 'campaign'
    when nullif(p ->> 'landing_page', '') is not null then 'landing_page'
    else 'website' end;
  select id into v_source from lead_sources where key = v_source_key and active;
  if v_source is null then select id into v_source from lead_sources where key = 'website'; end if;
  if v_source is null then raise exception 'lead source not configured'; end if;

  select id into v_status from lead_statuses where active order by position limit 1;
  if v_status is null then raise exception 'lead statuses not configured'; end if;

  select id into v_service from services where key = p ->> 'service' and active;
  select code into v_country from countries where code = upper(p ->> 'country') and active;

  insert into leads(company_name, contact_name, email, phone, country_code, service_id, budget_range,
                    message, source_id, source_reference, status_id, consent_status,
                    utm_source, utm_medium, utm_campaign, utm_content, utm_term, website)
  values (left(p ->> 'company', 200), left(p ->> 'name', 120), left(p ->> 'email', 254),
          nullif(left(p ->> 'phone', 40), ''), v_country, v_service,
          case when p ->> 'budget' in ('under_1k', '1k_5k', '5k_15k', '15k_plus', 'not_sure') then p ->> 'budget' end,
          nullif(left(p ->> 'message', 5000), ''), v_source, nullif(left(p ->> 'page_path', 500), ''), v_status,
          case when (p ->> 'consent')::boolean then 'granted' else 'unknown' end,
          nullif(left(p ->> 'utm_source', 200), ''), nullif(left(p ->> 'utm_medium', 200), ''),
          nullif(left(p ->> 'utm_campaign', 200), ''), nullif(left(p ->> 'utm_content', 200), ''),
          nullif(left(p ->> 'utm_term', 200), ''), nullif(left(p ->> 'website', 300), ''))
  returning * into v_lead;

  insert into lead_submissions(lead_id, ip_hash, email_normalized, user_agent, page_path)
  values (v_lead.id, v_ip, v_email, left(p ->> 'user_agent', 300), left(p ->> 'page_path', 500));

  for u in select * from users_with_permission('leads.assign') loop
    perform notify_user(u, 'lead.inbound', 'New website lead: ' || v_lead.company_name,
                        case when v_lead.possible_duplicate_of is not null then 'Possible duplicate of an existing lead' end,
                        '/app/leads/' || v_lead.id, 'high');
  end loop;

  return jsonb_build_object('ok', true, 'lead_id', v_lead.id,
                            'possible_duplicate', v_lead.possible_duplicate_of is not null);
end $$;

-- ---------------------------------------------------------------------------
-- Execute grants: deny by default, open only what clients need.
-- ---------------------------------------------------------------------------
revoke execute on all functions in schema public from public, anon, authenticated;

grant execute on function public.is_active_user(), public.is_superuser(), public.has_permission(text),
  public.my_permissions(), public.is_api_caller(), public.user_has_superuser_role(uuid) to authenticated;
grant execute on function public.rescore_all_leads() to authenticated;
grant execute on function public.normalize_company_name(text), public.normalize_domain(text),
  public.normalize_email(text), public.phone_key(text), public.temperature_for(int) to authenticated;
grant execute on function public.submit_public_lead(jsonb), public.log_audit_event(uuid, text, text, text, jsonb)
  to service_role;
