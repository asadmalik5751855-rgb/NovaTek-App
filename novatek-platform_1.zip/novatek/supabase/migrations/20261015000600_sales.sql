-- NovaTek platform — Sales: clients, deal stages, deals, proposals, commissions, conversion, merge.
-- Rules enforced here (not just in the UI):
--  * Won/lost is only reachable through mark_deal_won / mark_deal_lost (atomic: lead, client, commission, notifications).
--  * A won lead becomes one client — reused, never duplicated (by source lead, domain or email).
--  * Proposals can only be "viewed" with a real view of the public link, and "accepted/rejected" either by the
--    client on that link or by staff recording written evidence.
--  * Commissions are calculated from approved rules only and need approval by someone else before payment.

-- ---------------------------------------------------------------------------
-- New permissions + default grants
-- ---------------------------------------------------------------------------
insert into public.permissions(key, category, description) values
  ('leads.import',       'Leads',     'Import leads from CSV'),
  ('commissions.manage', 'Sales',     'Configure commission rules, approve and pay commissions'),
  ('targets.manage',     'People',    'Set employee targets'),
  ('tasks.assign',       'Projects',  'Create tasks for other people'),
  ('site.manage',        'Marketing', 'Manage public website content (portfolio, case studies)'),
  ('ai.use',             'AI',        'Use AI assistance (drafts and summaries; always labelled)');

insert into public.role_permissions(role_id, permission_key)
select r.id, x.perm
from (values
  ('coo', 'leads.import'), ('coo', 'targets.manage'), ('coo', 'tasks.assign'), ('coo', 'ai.use'),
  ('cto', 'tasks.assign'), ('cto', 'ai.use'),
  ('cmo', 'leads.import'), ('cmo', 'tasks.assign'), ('cmo', 'site.manage'), ('cmo', 'ai.use'),
  ('sales_manager', 'leads.import'), ('sales_manager', 'targets.manage'), ('sales_manager', 'tasks.assign'),
  ('sales_manager', 'ai.use'),
  ('sales_rep', 'ai.use'),
  ('marketing', 'ai.use')
) as x(role_key, perm)
join public.roles r on r.key = x.role_key;

-- ---------------------------------------------------------------------------
-- Funnel tracking on leads (for honest conversion rates: "ever reached stage X")
-- ---------------------------------------------------------------------------
alter table public.lead_statuses add column funnel_rank int check (funnel_rank between 1 and 20);
update public.lead_statuses set funnel_rank = case key
  when 'qualified' then 1 when 'contacted' then 2 when 'replied' then 3 when 'meeting_scheduled' then 4
  when 'proposal_sent' then 5 when 'negotiation' then 6 when 'won' then 7 end;

alter table public.leads
  add column max_funnel_rank int not null default 0,
  add column client_id uuid,
  add column merged_into uuid references public.leads(id) on delete set null;

alter table public.lead_activities drop constraint lead_activities_type_check;
alter table public.lead_activities add constraint lead_activities_type_check check (type in (
  'created', 'assigned', 'unassigned', 'status_change', 'note', 'call', 'email', 'message', 'meeting',
  'follow_up', 'archived', 'restored', 'merged', 'updated',
  'deal', 'deal_won', 'deal_lost', 'proposal', 'converted', 'meeting_scheduled', 'meeting_cancelled',
  'task', 'qualification'
));

create or replace function public.leads_funnel() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply (a DEFINER trigger would
-- always look like the owner and silently let API callers forge client/merge links).
language plpgsql set search_path = public as $$
declare r int;
begin
  select funnel_rank into r from lead_statuses where id = new.status_id;
  if tg_op = 'INSERT' then
    new.max_funnel_rank := coalesce(r, 0);
    new.client_id := null;
    new.merged_into := null;
  else
    -- conversion/merge links and funnel history are system-managed
    if is_api_caller() then
      new.client_id := old.client_id;
      new.merged_into := old.merged_into;
      new.max_funnel_rank := greatest(old.max_funnel_rank, coalesce(r, 0));
    else
      new.max_funnel_rank := greatest(new.max_funnel_rank, old.max_funnel_rank, coalesce(r, 0));
    end if;
  end if;
  return new;
end $$;
create trigger leads_b2_funnel before insert or update on public.leads
  for each row execute function public.leads_funnel();

-- ---------------------------------------------------------------------------
-- Clients
-- ---------------------------------------------------------------------------
create table public.clients (
  id uuid primary key default gen_random_uuid(),
  company_name text not null check (length(company_name) between 1 and 200),
  company_name_normalized text not null default '',
  website text check (length(website) <= 300),
  website_domain text,
  industry_id uuid references public.industries(id) on delete set null,
  country_code char(2) references public.countries(code) on delete set null,
  city text check (length(city) <= 120),
  contact_name text check (length(contact_name) <= 120),
  email text check (length(email) <= 254),
  email_normalized text,
  phone text check (length(phone) <= 40),
  account_manager_id uuid references public.profiles(id) on delete set null,
  source_lead_id uuid unique references public.leads(id) on delete set null,
  status text not null default 'active' check (status in ('active', 'inactive')),
  notes text check (length(notes) <= 10000),
  created_by uuid references public.profiles(id) on delete set null,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index clients_manager_idx on public.clients(account_manager_id);
create index clients_domain_idx on public.clients(website_domain) where website_domain is not null;
create index clients_email_idx on public.clients(email_normalized) where email_normalized is not null;
create index clients_name_idx on public.clients(company_name_normalized);
create trigger clients_updated_at before update on public.clients for each row execute function public.set_updated_at();

alter table public.leads add constraint leads_client_fk foreign key (client_id) references public.clients(id) on delete set null;
create index leads_client_idx on public.leads(client_id) where client_id is not null;

create or replace function public.clients_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
begin
  new.company_name := btrim(new.company_name);
  new.company_name_normalized := normalize_company_name(new.company_name);
  new.website_domain := normalize_domain(new.website);
  new.email := nullif(btrim(new.email), '');
  new.email_normalized := normalize_email(new.email);
  if not is_api_caller() then return new; end if;
  if tg_op = 'INSERT' then
    new.created_by := auth.uid();
    new.source_lead_id := null; -- only conversion links a lead
    new.archived_at := null;
    if new.account_manager_id is not null and new.account_manager_id <> auth.uid() and not has_permission('sales.manage') then
      raise exception 'Not allowed to assign account managers' using errcode = '42501';
    end if;
    return new;
  end if;
  new.id := old.id;
  new.created_by := old.created_by;
  new.created_at := old.created_at;
  new.source_lead_id := old.source_lead_id;
  if new.account_manager_id is distinct from old.account_manager_id and not has_permission('sales.manage') then
    raise exception 'Not allowed to change the account manager' using errcode = '42501';
  end if;
  if new.archived_at is distinct from old.archived_at and not has_permission('sales.manage') then
    raise exception 'Not allowed to archive clients' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger clients_a_guard before insert or update on public.clients
  for each row execute function public.clients_guard();

create or replace function public.clients_audit() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    perform write_audit('client.created', 'client', new.id::text, jsonb_build_object('source_lead_id', new.source_lead_id));
  elsif new.account_manager_id is distinct from old.account_manager_id then
    perform write_audit('client.manager_changed', 'client', new.id::text,
      jsonb_build_object('from', old.account_manager_id, 'to', new.account_manager_id));
    if new.account_manager_id is not null and new.account_manager_id is distinct from auth.uid() then
      perform notify_user(new.account_manager_id, 'client.assigned', 'You are now account manager for ' || new.company_name,
                          null, '/app/clients/' || new.id, 'normal');
    end if;
  elsif new.archived_at is distinct from old.archived_at then
    perform write_audit(case when new.archived_at is null then 'client.restored' else 'client.archived' end,
                        'client', new.id::text, '{}'::jsonb);
  end if;
  return null;
end $$;
create trigger clients_b_audit after insert or update on public.clients
  for each row execute function public.clients_audit();

-- ---------------------------------------------------------------------------
-- Deal stages + deals
-- ---------------------------------------------------------------------------
create table public.deal_stages (
  id uuid primary key default gen_random_uuid(),
  key text not null unique check (key ~ '^[a-z][a-z0-9_]{1,40}$'),
  name text not null check (length(name) between 1 and 60),
  position int not null,
  default_probability int not null default 10 check (default_probability between 0 and 100),
  color text not null default 'slate' check (color ~ '^[a-z]{3,12}$'),
  is_won boolean not null default false,
  is_lost boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  check (not (is_won and is_lost))
);

create table public.deals (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(name) between 1 and 200),
  lead_id uuid references public.leads(id) on delete set null,
  client_id uuid references public.clients(id) on delete set null,
  stage_id uuid not null references public.deal_stages(id),
  value numeric(14, 2) not null default 0 check (value >= 0 and value <= 1000000000),
  currency char(3) not null default 'USD' check (currency ~ '^[A-Z]{3}$'),
  probability int not null default 10 check (probability between 0 and 100),
  forecast_value numeric(14, 2) generated always as (round(value * probability / 100.0, 2)) stored,
  expected_close_date date,
  owner_id uuid references public.profiles(id) on delete set null,
  service_id uuid references public.services(id) on delete set null,
  notes text check (length(notes) <= 10000),
  won_at timestamptz,
  lost_at timestamptz,
  lost_reason text check (length(lost_reason) <= 1000),
  closed_by uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (lead_id is not null or client_id is not null)
);
create index deals_stage_idx on public.deals(stage_id) where archived_at is null;
create index deals_owner_idx on public.deals(owner_id) where archived_at is null;
create index deals_lead_idx on public.deals(lead_id);
create index deals_client_idx on public.deals(client_id);
create index deals_won_idx on public.deals(won_at) where won_at is not null;
create trigger deals_updated_at before update on public.deals for each row execute function public.set_updated_at();

create or replace function public.can_view_deal_row(p_owner uuid, p_created uuid, p_lead uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select has_permission('sales.view') and (
    has_permission('sales.manage')
    or has_permission('leads.view_all')
    or (auth.uid() is not null and (p_owner = auth.uid() or p_created = auth.uid()))
    or (p_lead is not null and exists (select 1 from leads l where l.id = p_lead and l.assigned_to = auth.uid()))
  )
$$;

create or replace function public.can_edit_deal_row(p_owner uuid, p_created uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select has_permission('sales.manage')
      or (has_permission('sales.view') and auth.uid() is not null and (p_owner = auth.uid() or p_created = auth.uid()))
$$;

create or replace function public.deals_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
declare v_new deal_stages; v_old deal_stages;
begin
  if not is_api_caller() then return new; end if;
  select * into v_new from deal_stages where id = new.stage_id;

  if tg_op = 'INSERT' then
    new.created_by := auth.uid();
    new.owner_id := coalesce(new.owner_id, auth.uid());
    new.won_at := null; new.lost_at := null; new.closed_by := null; new.lost_reason := null; new.archived_at := null;
    if v_new.is_won or v_new.is_lost then
      raise exception 'A new deal cannot start as won or lost' using errcode = '42501';
    end if;
    if new.owner_id <> auth.uid() and not has_permission('sales.manage') then
      raise exception 'Not allowed to create deals for other people' using errcode = '42501';
    end if;
    -- Linked records must be visible to the caller (RLS applies to these selects).
    if new.lead_id is not null and not exists (select 1 from leads where id = new.lead_id) then
      raise exception 'Lead not found' using errcode = '42501';
    end if;
    if new.client_id is not null and not exists (select 1 from clients where id = new.client_id) then
      raise exception 'Client not found' using errcode = '42501';
    end if;
    return new;
  end if;

  select * into v_old from deal_stages where id = old.stage_id;
  new.id := old.id;
  new.created_by := old.created_by;
  new.created_at := old.created_at;
  new.won_at := old.won_at; new.lost_at := old.lost_at; new.closed_by := old.closed_by;
  new.lead_id := old.lead_id;

  if v_old.is_won then
    raise exception 'Won deals are closed. Ask an administrator to correct them.' using errcode = '42501';
  end if;
  if new.stage_id is distinct from old.stage_id then
    if v_new.is_won or v_new.is_lost then
      raise exception 'Use "Mark won" or "Mark lost" to close a deal' using errcode = '42501';
    end if;
    if v_old.is_lost then
      if not has_permission('sales.manage') then
        raise exception 'Only sales managers can reopen lost deals' using errcode = '42501';
      end if;
      new.lost_at := null; new.lost_reason := null; new.closed_by := null;
    end if;
  end if;
  if new.owner_id is distinct from old.owner_id and not has_permission('sales.manage') then
    raise exception 'Not allowed to reassign deals' using errcode = '42501';
  end if;
  if new.client_id is distinct from old.client_id and new.client_id is not null
     and not exists (select 1 from clients where id = new.client_id) then
    raise exception 'Client not found' using errcode = '42501';
  end if;
  if new.archived_at is distinct from old.archived_at and not has_permission('sales.manage') then
    raise exception 'Not allowed to archive deals' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger deals_a_guard before insert or update on public.deals
  for each row execute function public.deals_guard();

create or replace function public.deals_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_from text; v_to text;
begin
  if tg_op = 'INSERT' then
    if new.lead_id is not null then
      insert into lead_activities(lead_id, actor_id, type, body, metadata)
      values (new.lead_id, auth.uid(), 'deal', new.name,
              jsonb_build_object('deal_id', new.id, 'value', new.value, 'currency', new.currency));
    end if;
    perform write_audit('deal.created', 'deal', new.id::text,
      jsonb_build_object('value', new.value, 'currency', new.currency, 'lead_id', new.lead_id, 'client_id', new.client_id));
    if new.owner_id is not null and new.owner_id is distinct from auth.uid() then
      perform notify_user(new.owner_id, 'deal.assigned', 'Deal assigned to you: ' || new.name, null, '/app/deals/' || new.id, 'normal');
    end if;
    return null;
  end if;

  if new.stage_id is distinct from old.stage_id and new.won_at is null and new.lost_at is null then
    select name into v_from from deal_stages where id = old.stage_id;
    select name into v_to from deal_stages where id = new.stage_id;
    perform write_audit('deal.stage_changed', 'deal', new.id::text, jsonb_build_object('from', v_from, 'to', v_to));
  end if;
  if new.owner_id is distinct from old.owner_id then
    perform write_audit('deal.reassigned', 'deal', new.id::text, jsonb_build_object('from', old.owner_id, 'to', new.owner_id));
    if new.owner_id is not null and new.owner_id is distinct from auth.uid() then
      perform notify_user(new.owner_id, 'deal.assigned', 'Deal assigned to you: ' || new.name, null, '/app/deals/' || new.id, 'normal');
    end if;
  end if;
  if (new.value, new.probability, new.currency) is distinct from (old.value, old.probability, old.currency) then
    perform write_audit('deal.updated', 'deal', new.id::text, jsonb_build_object(
      'value', jsonb_build_array(old.value, new.value), 'probability', jsonb_build_array(old.probability, new.probability),
      'currency', jsonb_build_array(old.currency, new.currency)));
  end if;
  return null;
end $$;
create trigger deals_b_after after insert or update on public.deals
  for each row execute function public.deals_after();

-- ---------------------------------------------------------------------------
-- Proposals
-- ---------------------------------------------------------------------------
create table public.proposals (
  id uuid primary key default gen_random_uuid(),
  deal_id uuid not null references public.deals(id) on delete cascade,
  title text not null check (length(title) between 1 and 200),
  service_id uuid references public.services(id) on delete set null,
  scope text check (length(scope) <= 20000),
  price numeric(14, 2) not null default 0 check (price >= 0 and price <= 1000000000),
  currency char(3) not null default 'USD' check (currency ~ '^[A-Z]{3}$'),
  timeline text check (length(timeline) <= 2000),
  terms text check (length(terms) <= 20000),
  expiry_date date,
  status text not null default 'draft' check (status in ('draft', 'sent', 'viewed', 'accepted', 'rejected', 'expired')),
  public_token text not null unique default replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', ''),
  sent_at timestamptz,
  first_viewed_at timestamptz,
  last_viewed_at timestamptz,
  view_count int not null default 0,
  responded_at timestamptz,
  response_source text check (response_source in ('client_link', 'staff_recorded')),
  response_name text check (length(response_name) <= 120),
  response_evidence text check (length(response_evidence) <= 2000),
  response_ip_hash text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index proposals_deal_idx on public.proposals(deal_id);
create index proposals_status_idx on public.proposals(status);
create trigger proposals_updated_at before update on public.proposals for each row execute function public.set_updated_at();

create or replace function public.proposals_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
begin
  if not is_api_caller() then return new; end if;
  if tg_op = 'INSERT' then
    new.created_by := auth.uid();
    new.status := 'draft';
    new.public_token := replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', '');
    new.sent_at := null; new.first_viewed_at := null; new.last_viewed_at := null; new.view_count := 0;
    new.responded_at := null; new.response_source := null; new.response_name := null;
    new.response_evidence := null; new.response_ip_hash := null;
    return new;
  end if;

  -- System-managed evidence fields never change through the API.
  new.id := old.id; new.deal_id := old.deal_id; new.created_by := old.created_by; new.created_at := old.created_at;
  new.public_token := old.public_token; new.first_viewed_at := old.first_viewed_at;
  new.last_viewed_at := old.last_viewed_at; new.view_count := old.view_count; new.response_ip_hash := old.response_ip_hash;
  new.sent_at := old.sent_at; new.responded_at := old.responded_at; new.response_source := old.response_source;

  if old.status <> 'draft' and (new.title, new.scope, new.price, new.currency, new.timeline, new.terms, new.service_id, new.expiry_date)
     is distinct from (old.title, old.scope, old.price, old.currency, old.timeline, old.terms, old.service_id, old.expiry_date) then
    raise exception 'A sent proposal cannot be edited. Create a new version instead.' using errcode = '42501';
  end if;

  if new.status is distinct from old.status then
    if new.status = 'viewed' then
      raise exception 'Viewed is recorded automatically when the client opens the proposal link' using errcode = '42501';
    elsif new.status = 'sent' then
      if old.status <> 'draft' then raise exception 'Only drafts can be sent' using errcode = '42501'; end if;
      new.sent_at := now();
    elsif new.status in ('accepted', 'rejected') then
      if old.status not in ('sent', 'viewed') then
        raise exception 'Only sent proposals can be accepted or rejected' using errcode = '42501';
      end if;
      if length(btrim(coalesce(new.response_evidence, ''))) < 10 then
        raise exception 'Record how the client responded (evidence) before marking it %', new.status using errcode = '23514';
      end if;
      new.responded_at := now();
      new.response_source := 'staff_recorded';
    elsif new.status = 'expired' then
      if old.status not in ('sent', 'viewed') then raise exception 'Only open proposals can expire' using errcode = '42501'; end if;
    elsif new.status = 'draft' then
      raise exception 'A sent proposal cannot return to draft' using errcode = '42501';
    end if;
  else
    new.response_evidence := old.response_evidence;
    new.response_name := old.response_name;
  end if;
  return new;
end $$;
create trigger proposals_a_guard before insert or update on public.proposals
  for each row execute function public.proposals_guard();

create or replace function public.proposals_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_deal deals; v_body text;
begin
  select * into v_deal from deals where id = new.deal_id;
  if tg_op = 'INSERT' then
    perform write_audit('proposal.created', 'proposal', new.id::text, jsonb_build_object('deal_id', new.deal_id));
    return null;
  end if;
  if new.status is distinct from old.status then
    perform write_audit('proposal.' || new.status, 'proposal', new.id::text,
      jsonb_build_object('from', old.status, 'source', new.response_source));
    v_body := new.title || ' — ' || initcap(new.status) ||
      case when new.response_source = 'client_link' then ' by the client via the proposal link'
           when new.response_source = 'staff_recorded' and new.status in ('accepted', 'rejected') then ' (recorded by staff)'
           else '' end;
    if v_deal.lead_id is not null then
      insert into lead_activities(lead_id, actor_id, type, body, metadata)
      values (v_deal.lead_id, auth.uid(), 'proposal', v_body,
              jsonb_build_object('proposal_id', new.id, 'status', new.status, 'deal_id', new.deal_id));
    end if;
    if new.status in ('viewed', 'accepted', 'rejected') then
      perform notify_user(u, 'proposal.' || new.status, 'Proposal ' || new.status || ': ' || new.title, null,
                          '/app/deals/' || new.deal_id, case when new.status = 'viewed' then 'normal' else 'high' end)
      from (select distinct x from unnest(array[new.created_by, v_deal.owner_id]) x where x is not null and x is distinct from auth.uid()) s(u);
    end if;
  end if;
  return null;
end $$;
create trigger proposals_b_after after insert or update on public.proposals
  for each row execute function public.proposals_after();

-- Public proposal link (server-side, service role). Records real views — never on behalf of staff.
create or replace function public.view_public_proposal(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare p proposals; d deals; s text;
begin
  if p_token is null or p_token !~ '^[0-9a-f]{64}$' then return null; end if;
  select * into p from proposals where public_token = p_token for update;
  if p.id is null or p.status = 'draft' then return null; end if;
  if p.status in ('sent', 'viewed') and p.expiry_date is not null and p.expiry_date < current_date then
    update proposals set status = 'expired' where id = p.id returning * into p;
  end if;
  if p.status in ('sent', 'viewed') then
    update proposals set status = 'viewed', view_count = view_count + 1,
      first_viewed_at = coalesce(first_viewed_at, now()), last_viewed_at = now()
    where id = p.id returning * into p;
  end if;
  select * into d from deals where id = p.deal_id;
  select name into s from services where id = p.service_id;
  return jsonb_build_object('title', p.title, 'scope', p.scope, 'price', p.price, 'currency', p.currency,
    'timeline', p.timeline, 'terms', p.terms, 'expiry_date', p.expiry_date, 'status', p.status, 'service', s,
    'sent_at', p.sent_at, 'responded_at', p.responded_at, 'response_name', p.response_name,
    'client', coalesce((select company_name from clients where id = d.client_id),
                       (select company_name from leads where id = d.lead_id)));
end $$;

create or replace function public.respond_public_proposal(p_token text, p_accept boolean, p_name text, p_ip_hash text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare p proposals;
begin
  if p_token is null or p_token !~ '^[0-9a-f]{64}$' then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if length(btrim(coalesce(p_name, ''))) < 2 then return jsonb_build_object('ok', false, 'error', 'name_required'); end if;
  select * into p from proposals where public_token = p_token for update;
  if p.id is null or p.status = 'draft' then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  if p.status not in ('sent', 'viewed') then return jsonb_build_object('ok', false, 'error', 'closed'); end if;
  if p.expiry_date is not null and p.expiry_date < current_date then
    update proposals set status = 'expired' where id = p.id;
    return jsonb_build_object('ok', false, 'error', 'expired');
  end if;
  update proposals set status = case when p_accept then 'accepted' else 'rejected' end,
    responded_at = now(), response_source = 'client_link', response_name = left(btrim(p_name), 120),
    response_ip_hash = left(p_ip_hash, 128)
  where id = p.id;
  return jsonb_build_object('ok', true);
end $$;

-- Scheduled job (service role): close proposals past their expiry date.
create or replace function public.expire_due_proposals() returns int
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update proposals set status = 'expired'
  where status in ('sent', 'viewed') and expiry_date is not null and expiry_date < current_date;
  get diagnostics n = row_count;
  return n;
end $$;

-- ---------------------------------------------------------------------------
-- Commissions
-- ---------------------------------------------------------------------------
create table public.commission_rules (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(name) between 1 and 120),
  service_id uuid references public.services(id) on delete cascade,      -- null = any service
  eligible_role_id uuid references public.roles(id) on delete cascade,   -- null = any role
  eligible_user_id uuid references public.profiles(id) on delete cascade, -- null = anyone eligible by role
  percent numeric(5, 2) not null default 0 check (percent between 0 and 100),
  fixed_amount numeric(14, 2) not null default 0 check (fixed_amount >= 0),
  currency char(3) not null default 'USD' check (currency ~ '^[A-Z]{3}$'),
  effective_from date not null default current_date,
  effective_to date,
  status text not null default 'pending' check (status in ('pending', 'approved', 'retired')),
  approved_by uuid references public.profiles(id) on delete set null,
  approved_at timestamptz,
  notes text check (length(notes) <= 2000),
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (effective_to is null or effective_to >= effective_from),
  check (percent > 0 or fixed_amount > 0)
);
create trigger commission_rules_updated_at before update on public.commission_rules for each row execute function public.set_updated_at();

create table public.commissions (
  id uuid primary key default gen_random_uuid(),
  deal_id uuid not null references public.deals(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  rule_id uuid references public.commission_rules(id) on delete set null,
  base_amount numeric(14, 2) not null,
  currency char(3) not null,
  percent numeric(5, 2) not null,
  fixed_amount numeric(14, 2) not null,
  amount numeric(14, 2) not null check (amount >= 0),
  status text not null default 'estimated' check (status in ('estimated', 'approved', 'paid', 'void')),
  approved_by uuid references public.profiles(id) on delete set null,
  approved_at timestamptz,
  paid_by uuid references public.profiles(id) on delete set null,
  paid_at timestamptz,
  paid_reference text check (length(paid_reference) <= 200),
  notes text check (length(notes) <= 2000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (deal_id, user_id)
);
create index commissions_user_idx on public.commissions(user_id, status);
create trigger commissions_updated_at before update on public.commissions for each row execute function public.set_updated_at();

create or replace function public.commission_rules_guard() returns trigger
-- SECURITY INVOKER on purpose: must see the API caller's role to apply.
language plpgsql set search_path = public as $$
begin
  if not is_api_caller() then return new; end if;
  if tg_op = 'INSERT' then
    new.created_by := auth.uid(); new.status := 'pending'; new.approved_by := null; new.approved_at := null;
    return new;
  end if;
  new.id := old.id; new.created_by := old.created_by; new.created_at := old.created_at;
  new.approved_by := old.approved_by; new.approved_at := old.approved_at;
  if old.status = 'approved' and (new.service_id, new.eligible_role_id, new.eligible_user_id, new.percent, new.fixed_amount,
       new.currency, new.effective_from) is distinct from
     (old.service_id, old.eligible_role_id, old.eligible_user_id, old.percent, old.fixed_amount, old.currency, old.effective_from) then
    raise exception 'Approved rules cannot be changed. Retire it (set an end date) and create a new rule.' using errcode = '42501';
  end if;
  if new.status is distinct from old.status then
    if new.status = 'approved' then
      if old.status <> 'pending' then raise exception 'Only pending rules can be approved' using errcode = '42501'; end if;
      if old.created_by = auth.uid() and not is_superuser() then
        raise exception 'A rule must be approved by someone other than its author' using errcode = '42501';
      end if;
      new.approved_by := auth.uid(); new.approved_at := now();
    elsif new.status = 'pending' then
      raise exception 'Rules cannot return to pending' using errcode = '42501';
    end if;
  end if;
  return new;
end $$;
create trigger commission_rules_a_guard before insert or update on public.commission_rules
  for each row execute function public.commission_rules_guard();

create trigger commission_rules_audit after insert or update or delete on public.commission_rules
  for each row execute function public.audit_config_change();

-- Picks the most specific approved rule effective on p_on for this person + service.
create or replace function public.commission_rule_for(p_user uuid, p_service uuid, p_currency text, p_on date)
returns public.commission_rules
language sql stable security definer set search_path = public as $$
  select r.* from commission_rules r
  where r.status = 'approved'
    and r.effective_from <= p_on and (r.effective_to is null or r.effective_to >= p_on)
    and (r.service_id is null or r.service_id = p_service)
    and (r.eligible_user_id is null or r.eligible_user_id = p_user)
    and (r.eligible_role_id is null or exists (select 1 from user_roles ur where ur.user_id = p_user and ur.role_id = r.eligible_role_id))
    and (r.fixed_amount = 0 or r.currency = p_currency)
  order by (r.eligible_user_id is not null) desc, (r.service_id is not null) desc, (r.eligible_role_id is not null) desc,
           r.effective_from desc, r.created_at desc
  limit 1
$$;

create or replace function public.calculate_commission(p_deal uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare d deals; r commission_rules; v_amount numeric; v_id uuid;
begin
  select * into d from deals where id = p_deal;
  if d.id is null or d.won_at is null or d.owner_id is null then return null; end if;
  r := commission_rule_for(d.owner_id, d.service_id, d.currency, d.won_at::date);
  if r.id is null then return null; end if;
  v_amount := round(d.value * r.percent / 100.0 + r.fixed_amount, 2);
  insert into commissions(deal_id, user_id, rule_id, base_amount, currency, percent, fixed_amount, amount)
  values (d.id, d.owner_id, r.id, d.value, d.currency, r.percent, r.fixed_amount, v_amount)
  on conflict (deal_id, user_id) do update set rule_id = excluded.rule_id, base_amount = excluded.base_amount,
    currency = excluded.currency, percent = excluded.percent, fixed_amount = excluded.fixed_amount, amount = excluded.amount
    where commissions.status = 'estimated'
  returning id into v_id;
  if v_id is null then return null; end if; -- already approved/paid: never recalculated
  perform write_audit('commission.estimated', 'commission', v_id::text,
    jsonb_build_object('deal_id', d.id, 'user_id', d.owner_id, 'amount', v_amount, 'currency', d.currency, 'rule_id', r.id));
  return v_id;
end $$;

create or replace function public.set_commission_status(p_id uuid, p_status text, p_reference text default null)
returns void
language plpgsql security definer set search_path = public as $$
declare c commissions;
begin
  if not has_permission('commissions.manage') then raise exception 'Not allowed' using errcode = '42501'; end if;
  select * into c from commissions where id = p_id for update;
  if c.id is null then raise exception 'Commission not found' using errcode = 'P0002'; end if;
  if c.user_id = auth.uid() then
    raise exception 'You cannot approve or pay your own commission' using errcode = '42501';
  end if;
  if p_status = 'approved' and c.status = 'estimated' then
    update commissions set status = 'approved', approved_by = auth.uid(), approved_at = now() where id = p_id;
  elsif p_status = 'paid' and c.status = 'approved' then
    if length(btrim(coalesce(p_reference, ''))) < 3 then
      raise exception 'Enter the payment reference' using errcode = '23514';
    end if;
    update commissions set status = 'paid', paid_by = auth.uid(), paid_at = now(), paid_reference = btrim(p_reference) where id = p_id;
  elsif p_status = 'void' and c.status in ('estimated', 'approved') then
    update commissions set status = 'void', notes = coalesce(nullif(btrim(p_reference), ''), notes) where id = p_id;
  else
    raise exception 'Commission cannot move from % to %', c.status, p_status using errcode = '42501';
  end if;
  perform write_audit('commission.' || p_status, 'commission', p_id::text, jsonb_build_object('from', c.status));
  perform notify_user(c.user_id, 'commission.' || p_status, 'Commission ' || p_status, null, '/app/commissions', 'normal');
end $$;

-- ---------------------------------------------------------------------------
-- Conversion: lead → client (reuse, never duplicate)
-- ---------------------------------------------------------------------------
create or replace function public.ensure_client_for_lead(p_lead uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare l leads; v_client uuid; v_new boolean := false;
begin
  select * into l from leads where id = p_lead for update;
  if l.id is null then raise exception 'Lead not found' using errcode = 'P0002'; end if;
  if l.client_id is not null then return l.client_id; end if;

  select id into v_client from clients where source_lead_id = l.id;
  if v_client is null then
    select id into v_client from clients
    where archived_at is null and (
      (l.website_domain is not null and website_domain = l.website_domain)
      or (l.email_normalized is not null and email_normalized = l.email_normalized))
    order by created_at limit 1;
  end if;
  if v_client is null then
    insert into clients(company_name, website, industry_id, country_code, city, contact_name, email, phone,
                        account_manager_id, source_lead_id, created_by)
    values (l.company_name, l.website, l.industry_id, l.country_code, l.city, l.contact_name, l.email, l.phone,
            coalesce(l.assigned_to, auth.uid()), l.id, auth.uid())
    returning id into v_client;
    v_new := true;
  end if;

  update leads set client_id = v_client where id = l.id;
  insert into lead_activities(lead_id, actor_id, type, body, metadata)
  values (l.id, auth.uid(), 'converted', case when v_new then 'Converted to a new client' else 'Linked to an existing client' end,
          jsonb_build_object('client_id', v_client, 'new_client', v_new));
  perform write_audit('lead.converted', 'lead', l.id::text, jsonb_build_object('client_id', v_client, 'new_client', v_new));
  return v_client;
end $$;

create or replace function public.convert_lead_to_client(p_lead uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare l leads; won boolean;
begin
  if not has_permission('sales.manage') or not can_edit_lead(p_lead) then
    raise exception 'Not allowed' using errcode = '42501';
  end if;
  select * into l from leads where id = p_lead;
  select is_won into won from lead_statuses where id = l.status_id;
  if not coalesce(won, false) then
    raise exception 'Only won leads can be converted to clients' using errcode = '42501';
  end if;
  return ensure_client_for_lead(p_lead);
end $$;

-- ---------------------------------------------------------------------------
-- Closing deals (atomic)
-- ---------------------------------------------------------------------------
create or replace function public.mark_deal_won(p_deal uuid, p_value numeric default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare d deals; v_stage uuid; v_lead_won uuid; v_client uuid; v_commission uuid; u uuid;
begin
  select * into d from deals where id = p_deal for update;
  if d.id is null or not can_view_deal_row(d.owner_id, d.created_by, d.lead_id) or not can_edit_deal_row(d.owner_id, d.created_by) then
    raise exception 'Deal not found' using errcode = '42501';
  end if;
  if d.won_at is not null then raise exception 'This deal is already won' using errcode = '42501'; end if;
  if d.archived_at is not null then raise exception 'Archived deals cannot be closed' using errcode = '42501'; end if;
  if p_value is not null and (p_value < 0 or p_value > 1000000000) then raise exception 'Invalid value' using errcode = '23514'; end if;

  select id into v_stage from deal_stages where is_won and active order by position limit 1;
  if v_stage is null then raise exception 'No won stage configured' using errcode = 'P0002'; end if;

  update deals set stage_id = v_stage, probability = 100, won_at = now(), lost_at = null, lost_reason = null,
    closed_by = auth.uid(), value = coalesce(p_value, value)
  where id = d.id returning * into d;

  if d.lead_id is not null then
    select id into v_lead_won from lead_statuses where is_won and active order by position limit 1;
    if v_lead_won is not null then
      update leads set status_id = v_lead_won where id = d.lead_id and status_id is distinct from v_lead_won;
    end if;
    insert into lead_activities(lead_id, actor_id, type, body, metadata)
    values (d.lead_id, auth.uid(), 'deal_won', d.name, jsonb_build_object('deal_id', d.id, 'value', d.value, 'currency', d.currency));
    if d.client_id is null then
      v_client := ensure_client_for_lead(d.lead_id);
      update deals set client_id = v_client where id = d.id;
    end if;
  end if;
  v_client := coalesce(v_client, d.client_id);

  v_commission := calculate_commission(d.id);

  perform write_audit('deal.won', 'deal', d.id::text,
    jsonb_build_object('value', d.value, 'currency', d.currency, 'client_id', v_client, 'commission_id', v_commission));
  for u in select x from (select distinct x from unnest(array[d.owner_id]) x
                          union select users_with_permission('sales.manage')) s(x)
           where x is not null and x is distinct from auth.uid() loop
    perform notify_user(u, 'deal.won', 'Deal won: ' || d.name, null, '/app/deals/' || d.id, 'high');
  end loop;
  return jsonb_build_object('deal_id', d.id, 'client_id', v_client, 'commission_id', v_commission);
end $$;

create or replace function public.mark_deal_lost(p_deal uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare d deals; v_stage uuid; v_lead_lost uuid; u uuid;
begin
  select * into d from deals where id = p_deal for update;
  if d.id is null or not can_view_deal_row(d.owner_id, d.created_by, d.lead_id) or not can_edit_deal_row(d.owner_id, d.created_by) then
    raise exception 'Deal not found' using errcode = '42501';
  end if;
  if d.won_at is not null then raise exception 'Won deals cannot be marked lost' using errcode = '42501'; end if;
  if d.lost_at is not null then raise exception 'This deal is already lost' using errcode = '42501'; end if;
  if length(btrim(coalesce(p_reason, ''))) < 3 then raise exception 'Give a reason' using errcode = '23514'; end if;

  select id into v_stage from deal_stages where is_lost and active order by position limit 1;
  if v_stage is null then raise exception 'No lost stage configured' using errcode = 'P0002'; end if;
  update deals set stage_id = v_stage, probability = 0, lost_at = now(), lost_reason = left(btrim(p_reason), 1000),
    closed_by = auth.uid()
  where id = d.id;

  if d.lead_id is not null then
    -- Only move the lead to Lost if it has no other open deal.
    if not exists (select 1 from deals x join deal_stages s on s.id = x.stage_id
                   where x.lead_id = d.lead_id and x.id <> d.id and not s.is_won and not s.is_lost and x.archived_at is null) then
      select id into v_lead_lost from lead_statuses where key = 'lost' and active;
      if v_lead_lost is not null then
        update leads set status_id = v_lead_lost where id = d.lead_id
          and not exists (select 1 from lead_statuses s where s.id = leads.status_id and s.is_closed);
      end if;
    end if;
    insert into lead_activities(lead_id, actor_id, type, body, metadata)
    values (d.lead_id, auth.uid(), 'deal_lost', d.name || ': ' || left(btrim(p_reason), 500), jsonb_build_object('deal_id', d.id));
  end if;
  perform write_audit('deal.lost', 'deal', d.id::text, jsonb_build_object('reason', left(btrim(p_reason), 500)));
  for u in select x from (select distinct x from unnest(array[d.owner_id]) x
                          union select users_with_permission('sales.manage')) s(x)
           where x is not null and x is distinct from auth.uid() loop
    perform notify_user(u, 'deal.lost', 'Deal lost: ' || d.name, null, '/app/deals/' || d.id, 'normal');
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- Lead merge (atomic; preserves activities, notes, tags, deals, history, timestamps)
-- ---------------------------------------------------------------------------
create or replace function public.merge_leads(p_survivor uuid, p_duplicate uuid) returns void
language plpgsql security definer set search_path = public as $$
declare s leads; d leads;
begin
  if not has_permission('leads.merge') then raise exception 'Not allowed' using errcode = '42501'; end if;
  if p_survivor = p_duplicate then raise exception 'Choose two different leads' using errcode = '23514'; end if;
  if not can_edit_lead(p_survivor) or not can_edit_lead(p_duplicate) then
    raise exception 'Lead not found' using errcode = '42501';
  end if;
  -- lock in a stable order to avoid deadlocks
  perform 1 from leads where id in (p_survivor, p_duplicate) order by id for update;
  select * into s from leads where id = p_survivor;
  select * into d from leads where id = p_duplicate;
  if s.archived_at is not null or d.archived_at is not null then
    raise exception 'Restore archived leads before merging' using errcode = '42501';
  end if;
  if d.client_id is not null and s.client_id is not null and d.client_id <> s.client_id then
    raise exception 'Both leads are linked to different clients' using errcode = '42501';
  end if;

  -- Move history and relations to the survivor (timestamps preserved).
  update lead_activities set lead_id = s.id where lead_id = d.id;
  insert into lead_tag_relations(lead_id, tag_id) select s.id, tag_id from lead_tag_relations where lead_id = d.id
    on conflict do nothing;
  delete from lead_tag_relations where lead_id = d.id;
  update deals set lead_id = s.id where lead_id = d.id;
  update lead_submissions set lead_id = s.id where lead_id = d.id;

  -- Fill gaps on the survivor; never overwrite existing values.
  update leads set
    website = coalesce(s.website, d.website),
    industry_id = coalesce(s.industry_id, d.industry_id),
    country_code = coalesce(s.country_code, d.country_code),
    city = coalesce(s.city, d.city),
    business_size = coalesce(s.business_size, d.business_size),
    contact_name = coalesce(s.contact_name, d.contact_name),
    email = coalesce(s.email, d.email),
    phone = coalesce(s.phone, d.phone),
    service_id = coalesce(s.service_id, d.service_id),
    budget_range = coalesce(s.budget_range, d.budget_range),
    estimated_value = coalesce(s.estimated_value, d.estimated_value),
    message = case when d.message is null then s.message when s.message is null then d.message
                   else left(s.message || E'\n\n--- merged ---\n' || d.message, 5000) end,
    assigned_to = coalesce(s.assigned_to, d.assigned_to),
    client_id = coalesce(s.client_id, d.client_id),
    next_follow_up_at = coalesce(least(s.next_follow_up_at, d.next_follow_up_at), s.next_follow_up_at, d.next_follow_up_at),
    last_contacted_at = greatest(s.last_contacted_at, d.last_contacted_at),
    max_funnel_rank = greatest(s.max_funnel_rank, d.max_funnel_rank),
    qualification = d.qualification || s.qualification,
    possible_duplicate_of = case when s.possible_duplicate_of = d.id then null else s.possible_duplicate_of end,
    created_at = least(s.created_at, d.created_at)
  where id = s.id;

  update leads set archived_at = now(), archived_by = auth.uid(), merged_into = s.id, possible_duplicate_of = null,
    client_id = null
  where id = d.id;
  update leads set possible_duplicate_of = s.id where possible_duplicate_of = d.id;

  insert into lead_activities(lead_id, actor_id, type, body, metadata)
  values (s.id, auth.uid(), 'merged', 'Merged “' || d.company_name || '” into this lead',
          jsonb_build_object('merged_lead_id', d.id, 'merged_company', d.company_name, 'merged_source_id', d.source_id,
                             'merged_created_at', d.created_at));
  insert into lead_activities(lead_id, actor_id, type, body, metadata)
  values (d.id, auth.uid(), 'merged', 'Merged into “' || s.company_name || '”', jsonb_build_object('survivor_id', s.id));
  perform write_audit('lead.merged', 'lead', s.id::text, jsonb_build_object('merged_lead_id', d.id));
end $$;

-- ---------------------------------------------------------------------------
-- RLS
-- ---------------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array['clients', 'deal_stages', 'deals', 'proposals', 'commission_rules', 'commissions']
  loop
    execute format('alter table public.%I enable row level security', t);
    execute format('alter table public.%I force row level security', t);
    execute format('revoke all on public.%I from anon', t);
  end loop;
end $$;

create policy clients_select on public.clients for select to authenticated using (
  has_permission('sales.manage')
  or (has_permission('sales.view') and has_permission('leads.view_all'))
  or has_permission('projects.view')
  or (is_active_user() and (account_manager_id = auth.uid() or created_by = auth.uid()))
);
create policy clients_insert on public.clients for insert to authenticated with check (has_permission('sales.manage'));
create policy clients_update on public.clients for update to authenticated
  using (has_permission('sales.manage') or (has_permission('sales.view') and account_manager_id = auth.uid()))
  with check (has_permission('sales.manage') or (has_permission('sales.view') and account_manager_id = auth.uid()));

create policy deal_stages_select on public.deal_stages for select to authenticated using (is_active_user());
create policy deal_stages_insert on public.deal_stages for insert to authenticated with check (has_permission('crm.configure'));
create policy deal_stages_update on public.deal_stages for update to authenticated
  using (has_permission('crm.configure')) with check (has_permission('crm.configure'));

create policy deals_select on public.deals for select to authenticated using (can_view_deal_row(owner_id, created_by, lead_id));
create policy deals_insert on public.deals for insert to authenticated
  with check (has_permission('sales.manage') or (has_permission('sales.view') and has_permission('leads.edit')));
create policy deals_update on public.deals for update to authenticated
  using (can_edit_deal_row(owner_id, created_by)) with check (can_edit_deal_row(owner_id, created_by));

create policy proposals_select on public.proposals for select to authenticated
  using (exists (select 1 from public.deals d where d.id = deal_id));
create policy proposals_insert on public.proposals for insert to authenticated
  with check (exists (select 1 from public.deals d where d.id = deal_id and can_edit_deal_row(d.owner_id, d.created_by)));
create policy proposals_update on public.proposals for update to authenticated
  using (exists (select 1 from public.deals d where d.id = deal_id and can_edit_deal_row(d.owner_id, d.created_by)))
  with check (exists (select 1 from public.deals d where d.id = deal_id and can_edit_deal_row(d.owner_id, d.created_by)));
create policy proposals_delete on public.proposals for delete to authenticated
  using (status = 'draft' and exists (select 1 from public.deals d where d.id = deal_id and can_edit_deal_row(d.owner_id, d.created_by)));

create policy commission_rules_select on public.commission_rules for select to authenticated
  using (has_permission('commissions.manage') or has_permission('reports.view') or (is_active_user() and status = 'approved'));
create policy commission_rules_insert on public.commission_rules for insert to authenticated
  with check (has_permission('commissions.manage'));
create policy commission_rules_update on public.commission_rules for update to authenticated
  using (has_permission('commissions.manage')) with check (has_permission('commissions.manage'));

create policy commissions_select on public.commissions for select to authenticated
  using ((is_active_user() and user_id = auth.uid()) or has_permission('commissions.manage') or has_permission('reports.view'));
-- Writes only through calculate_commission / set_commission_status.
revoke insert, update, delete on public.commissions from authenticated;
revoke delete on public.deals, public.clients, public.commission_rules from authenticated;

-- ---------------------------------------------------------------------------
-- Function grants
-- ---------------------------------------------------------------------------
revoke execute on function
  public.leads_funnel(), public.clients_guard(), public.clients_audit(), public.can_view_deal_row(uuid, uuid, uuid),
  public.can_edit_deal_row(uuid, uuid), public.deals_guard(), public.deals_after(), public.proposals_guard(),
  public.proposals_after(), public.view_public_proposal(text), public.respond_public_proposal(text, boolean, text, text),
  public.expire_due_proposals(), public.commission_rules_guard(), public.commission_rule_for(uuid, uuid, text, date),
  public.calculate_commission(uuid), public.set_commission_status(uuid, text, text), public.ensure_client_for_lead(uuid),
  public.convert_lead_to_client(uuid), public.mark_deal_won(uuid, numeric), public.mark_deal_lost(uuid, text),
  public.merge_leads(uuid, uuid)
from public, anon, authenticated;

grant execute on function public.can_view_deal_row(uuid, uuid, uuid), public.can_edit_deal_row(uuid, uuid),
  public.set_commission_status(uuid, text, text), public.convert_lead_to_client(uuid),
  public.mark_deal_won(uuid, numeric), public.mark_deal_lost(uuid, text), public.merge_leads(uuid, uuid)
to authenticated;
grant execute on function public.view_public_proposal(text), public.respond_public_proposal(text, boolean, text, text),
  public.expire_due_proposals()
to service_role;

-- ---------------------------------------------------------------------------
-- Reference data
-- ---------------------------------------------------------------------------
insert into public.deal_stages(key, name, position, default_probability, color, is_won, is_lost) values
  ('qualification', 'Qualification', 10, 10,  'slate',   false, false),
  ('discovery',     'Discovery',     20, 25,  'blue',    false, false),
  ('proposal',      'Proposal',      30, 50,  'violet',  false, false),
  ('negotiation',   'Negotiation',   40, 75,  'amber',   false, false),
  ('won',           'Won',           50, 100, 'emerald', true,  false),
  ('lost',          'Lost',          60, 0,   'rose',    false, true);

create trigger deal_stages_audit after insert or update or delete on public.deal_stages
  for each row execute function public.audit_config_change();

-- Timeline: system link fields are not 'edits'; qualification gets its own entry.
create or replace function public.leads_after_update() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_from text; v_to text; v_changed text[];
begin
  if new.status_id is distinct from old.status_id then
    select name into v_from from lead_statuses where id = old.status_id;
    select name into v_to from lead_statuses where id = new.status_id;
    insert into lead_activities(lead_id, actor_id, type, metadata)
    values (new.id, auth.uid(), 'status_change', jsonb_build_object(
      'from_status_id', old.status_id, 'to_status_id', new.status_id, 'from', v_from, 'to', v_to));
    perform write_audit('lead.status_changed', 'lead', new.id::text, jsonb_build_object('from', v_from, 'to', v_to));
  end if;

  if new.assigned_to is distinct from old.assigned_to then
    insert into lead_activities(lead_id, actor_id, type, metadata)
    values (new.id, auth.uid(), case when new.assigned_to is null then 'unassigned' else 'assigned' end,
            jsonb_build_object('from', old.assigned_to, 'to', new.assigned_to));
    perform write_audit('lead.assigned', 'lead', new.id::text, jsonb_build_object('from', old.assigned_to, 'to', new.assigned_to));
    if new.assigned_to is not null and new.assigned_to is distinct from auth.uid() then
      perform notify_user(new.assigned_to,
        case when old.assigned_to is null then 'lead.assigned' else 'lead.reassigned' end,
        'Lead assigned to you: ' || new.company_name, null, '/app/leads/' || new.id, 'normal');
    end if;
  end if;

  if new.archived_at is distinct from old.archived_at then
    insert into lead_activities(lead_id, actor_id, type)
    values (new.id, auth.uid(), case when new.archived_at is null then 'restored' else 'archived' end);
    perform write_audit(case when new.archived_at is null then 'lead.restored' else 'lead.archived' end,
                        'lead', new.id::text, '{}'::jsonb);
  end if;

  -- Record which other fields changed (names only; values stay in the row).
  select array_agg(n.key order by n.key) into v_changed
  from jsonb_each(to_jsonb(new)) n
  join jsonb_each(to_jsonb(old)) o on o.key = n.key
  where n.value is distinct from o.value
    and n.key not in ('updated_at', 'score', 'score_breakdown', 'temperature', 'status_id', 'assigned_to',
                      'archived_at', 'archived_by', 'last_contacted_at', 'company_name_normalized',
                      'website_domain', 'email_normalized', 'phone_key', 'client_id', 'merged_into',
                      'max_funnel_rank', 'qualification');
  if v_changed is not null then
    insert into lead_activities(lead_id, actor_id, type, metadata)
    values (new.id, auth.uid(), 'updated', jsonb_build_object('fields', to_jsonb(v_changed)));
    perform write_audit('lead.updated', 'lead', new.id::text, jsonb_build_object('fields', to_jsonb(v_changed)));
  end if;
  if new.qualification is distinct from old.qualification then
    insert into lead_activities(lead_id, actor_id, type, body, metadata)
    values (new.id, auth.uid(), 'qualification', 'Qualification answers updated',
            jsonb_build_object('answered', (select count(*) from jsonb_object_keys(new.qualification))));
  end if;
  return null;
end $$;

