# Security model

## Authentication

- Supabase Auth, email + password. **No public sign-up**: administrators create accounts (`users.manage_roles`).
- Sessions are verified on every request (`getClaims` in the proxy; `getUser` per page/action).
- Disabled users (`profiles.status = 'disabled'`) have **no permissions at the database level**, even with a valid token.
- Sensitive actions (exports, security settings) require the password again. A successful check sets a signed,
  httpOnly, SameSite=Strict cookie valid for the window in Settings → Security (default 10 minutes).
- Login, logout and failed logins are audited.

## Authorisation — three layers

1. **Database (authoritative).** Row Level Security is enabled and *forced* on every table, default deny. Policies call
   `has_permission('…')`, which reads `user_roles → role_permissions` for active users. Guard triggers (SECURITY INVOKER,
   so they see the real API caller) stop field-level abuse: changing `created_by`, assigning to others without
   `leads.assign`, closing deals without the close functions, forging client/merge links, marking proposals viewed, etc.
2. **Server.** Every server action and route handler calls `authorize()`/`requirePermission()` and validates input with
   Zod before touching data, then uses the **user's own** Supabase client so RLS applies.
3. **UI.** Hides what a user can't do. Convenience only.

Checks are always on **permissions** (e.g. `leads.assign`), never role names. Roles are bundles of permissions and are
editable by a Super Admin in **Roles & permissions**. Users can never change their own roles or status; only a Super
Admin can grant Super Admin.

### Default roles

| Role | Highlights |
|---|---|
| Super Admin | Everything |
| CEO | Company-wide read: leads, sales, projects, reports, audit, CEO portal |
| COO | Operations: leads (all), assignment, merge, CRM config, sales, projects, targets, import, COO portal |
| CTO | Projects (manage), tasks, team, CTO portal |
| CMO | Leads (all), campaigns, landing pages, website content, CRM config, export, import, CMO portal |
| Sales Manager | Leads (all), assign, merge, export, import, deals (manage), targets, team performance |
| Sales Representative | Own leads, own deals, own commissions |
| Developer / UI/UX Designer | Projects and tasks |
| Marketing Employee | Own leads, campaigns (view) |
| Employee | Base access; extend via permissions |

## Privileged code paths (service role)

The service-role key is imported only from `src/lib/supabase/admin.ts` (`server-only`). It is used, each after its own
check, for: public lead intake (`submit_public_lead`), user provisioning, audit events with a verified actor, the public
proposal link (`view_public_proposal` / `respond_public_proposal`), integration check results, AI generation logging
and the cron endpoint. Database functions callable by these paths are granted to `service_role` only.

## Evidence rules (no fake success)

- Public forms show success only after the database confirms the insert.
- Proposal **Viewed** is recorded only when the client opens the private link (link-preview bots and prefetches are
  ignored). **Accepted/Rejected** come from the client on the link, or from staff recording written evidence.
- Meetings can't be marked completed before they start; a completed meeting is what counts as contact.
- Commissions are calculated only from approved rules; approval and payment need someone other than the earner.
- Integrations can't be enabled without a successful live check; a failed check disables them.
- AI output is logged (`ai_generations`) with user, record and model, labelled "AI-generated draft", and never sent.

## Abuse controls (public forms)

Server-side Zod validation, honeypot field, minimum fill time, per-IP-hash and per-email rate limits, duplicate
submission window. Visitor IPs are stored only as salted SHA-256 hashes.

## Data handling

- Leads, clients, deals and projects are archived, never hard-deleted; merges preserve all history.
- The audit log is append-only for clients and readable only with `audit.view`.
- CSV exports neutralise spreadsheet formula injection and are audited.
- Uploaded documents: type allowlist checked against file signatures, 25 MB cap, private bucket, access follows the parent
  record's RLS, downloads via 60-second signed URLs.
- HTTP security headers: CSP, HSTS, X-Frame-Options DENY, nosniff, Referrer-Policy, Permissions-Policy; authenticated
  pages and proposal links are `Cache-Control: private, no-store`; the service worker never caches private pages.
