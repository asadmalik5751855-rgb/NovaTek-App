# NovaTek Platform — Architecture & Implementation Plan

Status: all milestones implemented (see §9). This document records the decisions the code follows.

## 0. Inspection result

No existing project was supplied, so this is a greenfield build. Nothing to preserve or migrate.
Assets supplied: `novatek-logo-horizontal-color.png` (horizontal lockup) and `novatek-app-icon-1024.png` (app icon).

## 1. Brand rule (non-negotiable)

- The logo and the "NovaTek" wordmark are **only ever rendered from the supplied image files**
  (`public/brand/`). The wordmark is never retyped in a web font, recoloured, stretched, cropped,
  redrawn or re-traced as SVG.
- Favicons/PWA icons are produced **only by proportional resizing** of the supplied app icon.
- On dark backgrounds the horizontal lockup sits on a light "plate" rather than being inverted, because
  inverting would change the logo. (A supplied official dark/white variant can be dropped in later.)
- **Locked by owner instruction:** the logo and the name's font are never changed on the website. Admin
  "Branding" settings cover tagline, colours of the UI, contact details, social links and footer only — there is
  no control to replace, recolour or restyle the logo or wordmark.
- Enforced by `tests/brand/brand-lock.test.ts`: byte-exact SHA-256 pin of both files, dimension check, single
  rendering component, no filters/transforms, and no standalone "NovaTek" text element imitating the wordmark.
- Components never reference logo paths directly — they use `<BrandLogo/>` / `<BrandMark/>` which read
  centralized brand config.

## 2. Stack

| Concern | Choice | Why |
|---|---|---|
| Framework | Next.js (App Router) + TypeScript | Server components, server actions, route handlers |
| Styling | Tailwind CSS v4 with CSS-variable design tokens | Dark/light mode via tokens |
| Icons | lucide-react | |
| DB / Auth / Storage | Supabase (Postgres 15+, Auth, Storage) | |
| Data access | `@supabase/ssr` with the **user's JWT** | RLS is enforced on every query |
| Privileged ops | Service-role client, server-only module, never imported by client code | |
| Validation | Zod (shared client/server schemas) | |
| Forms | React Hook Form + zodResolver | |
| Charts | Recharts (lazy-loaded) — milestone 2 | |
| Tests | Vitest (unit) + SQL test suite against real Postgres (RLS/security) | |

## 3. Folder structure

```
src/
  app/
    (public)/            public website: /, /services, /about, /contact
    (auth)/login         sign-in
    (app)/app/...        authenticated platform (dashboard, leads, pipeline, admin)
    api/                 route handlers (health)
  components/
    brand/               BrandLogo, BrandMark (image-only)
    ui/                  primitives (Button, Input, Badge, Card, EmptyState…)
    app/                 shell, sidebar, mobile nav
    leads/ public/ admin/
  lib/
    config/brand.ts      centralized brand configuration
    supabase/            server.ts, client.ts, admin.ts (server-only), middleware.ts
    auth/                session + permission helpers (requirePermission)
    leads/               scoring.ts, dedupe.ts, normalize.ts (pure, unit-tested)
    validation/          zod schemas
    errors.ts            safe error mapping (never leak raw DB errors)
  middleware.ts          session refresh + route protection
supabase/
  migrations/            ordered SQL migrations
  seed/                  reference data (roles, permissions, statuses) — NOT fake business data
  tests/                 SQL security tests
docs/
```

## 4. Database architecture

Normalized Postgres. Every business table has `id uuid`, `created_at`, `updated_at`, and where
history matters `archived_at` (soft delete). Lookups (statuses, sources, services, industries,
countries, departments) are tables, not enums, so admins can edit them.

Core groups:
- **Identity/RBAC**: `profiles` (1:1 auth.users), `departments`, `roles`, `permissions`,
  `role_permissions`, `user_roles`.
- **Reference data**: `lead_sources`, `lead_statuses`, `services`, `industries`, `countries`,
  `scoring_rules`, `settings`.
- **Leads/CRM**: `leads`, `lead_activities`, `lead_tags`, `lead_tag_relations`,
  `lead_submissions` (raw inbound form payloads + rate-limit evidence).
- **Sales (M2 — schema ships with its UI and tests)**: `deals`, `deal_stages`, `proposals`, `clients`.
- **Work (M2)**: `projects`, `project_members`, `tasks`, `meetings`.
- **Marketing (M2)**: `campaigns`.
- **Ops**: `notifications`, `audit_logs`.
- **Commission (M3)**: `commission_rules`, `commissions`, `employee_targets`.

Deliberate changes vs. the brief's table list:
- `lead_scores` → score stored on `leads` with `score_breakdown jsonb` + computed by a DB function
  from `scoring_rules`; history goes to `lead_activities`. Avoids a second source of truth.
- `lead_assignments` → assignment is `leads.assigned_to`; every change is written to
  `lead_activities` + `audit_logs`, which gives full assignment history.
- `employees` → merged into `profiles` (department, designation, joining date, status).
  One person = one row.
- Added `lead_submissions` for inbound abuse control and evidence.
- Added a `directory` view (names/titles only) so assignee names show without exposing HR/contact fields.
- Guard triggers are SECURITY INVOKER on purpose: inside a DEFINER function the caller appears as the owner,
  which silently disabled the guards (caught by the security tests).

## 5. Authentication & RBAC

- Supabase Auth (email/password). No public sign-up: users are provisioned by an admin
  (internal platform). First Super Admin is created via a documented SQL/CLI step.
- Permissions are granular strings (`leads.view_all`, `leads.assign`, …). Roles are bundles.
  A user may have several roles. Checks are always on **permissions**, never role names.
- Enforcement at three layers:
  1. **Database (authoritative)**: RLS policies call `public.has_permission('x')`
     (SECURITY DEFINER, stable, reads `user_roles → role_permissions`).
  2. **Server**: every server action / route calls `requirePermission()` before work.
  3. **UI**: hides what the user cannot do (convenience only).
- Disabled users (`profiles.status <> 'active'`) get no permissions at the DB level.
- Privilege escalation guards: users cannot update their own `user_roles`; the profile update
  policy prevents a user from changing their own status/department; role assignment requires
  `users.manage_roles` and is audited.

## 6. Lead-generation architecture

Sources (configurable table): Website, Landing Page, Campaign, Referral, Manual, Import, Integration.

Inbound flow (public form):
1. Server action validates with Zod (never trusts client).
2. Honeypot field + minimum fill-time check + per-IP-hash and per-email rate limit
   (counted in `lead_submissions`) — legitimate abuse protection, not a CAPTCHA bypass.
3. Calls `public.submit_public_lead()` (SECURITY DEFINER, granted to `anon`) which inside
   **one transaction**: normalizes, finds possible duplicates (domain / email / phone /
   normalized company name), inserts the lead flagged `possible_duplicate_of` if needed,
   computes the score, writes the "Lead created" activity and audit entry.
4. Only after the DB confirms the insert does the UI show success.
- UTM params captured from the URL and stored on the lead.
- No scraping module. Integration adapters (M3) only for permitted APIs, disabled until configured.

Scoring: `scoring_rules` rows (`signal`, `points`, `active`). `compute_lead_score()` sums matched
signals and clamps 0–100. Temperature: 0–30 Cold, 31–60 Warm, 61–80 Hot, 81–100 Very Hot.
A lead with no evaluable signals scores 0 (Cold) — never an invented number.
The same logic exists in `src/lib/leads/scoring.ts` for preview, with tests asserting parity of rules.

Dedupe: never auto-merges. Shows "Possible Duplicate". Merge (M2) is a transactional DB function
moving activities/notes/tags to the survivor and archiving the other.

## 7. CRM

`lead_activities` is the append-only timeline: actor, type, body, metadata, timestamp.
Status changes, assignments and notes are written via DB functions/triggers so the timeline cannot
drift from the data. Pipeline drag-and-drop calls a server action → `change_lead_status()`.

## 8. Security

- RLS on every table; default deny.
- Service-role key only in `lib/supabase/admin.ts` with `import "server-only"`; not `NEXT_PUBLIC_`.
- Zod on every input; parameterized queries only (Supabase client).
- Server actions are POST + same-origin (Next.js built-in CSRF protection for actions).
- Security headers (CSP, HSTS, X-Frame-Options, Referrer-Policy, Permissions-Policy) in `next.config`.
- Errors mapped to safe messages; details logged server-side only.
- Audit log is insert-only via SECURITY DEFINER function; readable only with `audit.view`.

## 9. Sales, work and insights (milestones 2–3)

- **Deals** carry value, currency, probability and a generated `forecast_value` (value × probability), always labelled
  as a projection. Won/lost are reachable only via `mark_deal_won` / `mark_deal_lost`, which run atomically: deal stage,
  lead status, client creation/reuse (`ensure_client_for_lead` — by source lead, domain or email, never duplicated),
  commission calculation, timeline, audit and notifications.
- **Proposals** are locked once sent. `viewed` is set only by the public link (`view_public_proposal`, bots/prefetch
  ignored); `accepted/rejected` by the client on the link or by staff with written evidence.
- **Commissions**: rules (service / role / person, % and/or fixed, effective dates) need approval by someone other than
  the author; approved rules are immutable (retire + replace). The most specific approved rule effective on the close
  date applies. Status flow estimated → approved → paid (with reference); nobody approves or pays their own.
- **Lead merge** (`merge_leads`) moves activities, tags, deals and submissions to the survivor, fills gaps without
  overwriting, archives the duplicate with `merged_into`, and audits it.
- **Funnel analytics** use `leads.max_funnel_rank` (furthest stage ever reached, maintained by trigger) over the cohort
  of leads created in the period. Revenue is reported **per currency** — never silently converted.
- **Analytics functions are SECURITY INVOKER**, so every number is computed through the viewer's RLS.
- **Time**: everything is stored as UTC instants; display and daily/weekly buckets use `NEXT_PUBLIC_APP_TIMEZONE`
  (default Asia/Karachi). Date-time inputs are converted in the browser.
- **Projects/tasks/meetings**: project progress follows task completion; tasks for others need `tasks.assign`;
  meetings can't be completed before they start; a completed meeting counts as contact and proves "meeting booked".
- **Notifications**: event-driven (triggers) plus `run_scheduled_notifications()` (cron) with per-reminder de-duplication.
- **Integrations** live behind adapters (`src/lib/integrations`); secrets only in env vars; enabling requires a live
  check; no simulated success. AI output is logged and labelled.
- **Public site content** (portfolio, case studies, landing pages) is DB-driven; empty states are honest; a named
  client can't be published without recorded permission; testimonials require confirmation they're real.

## 10. Delivery status

| Milestone | Contents | Status |
|---|---|---|
| M1 | Schema, RLS, RBAC, auth, public site + lead capture, leads, timeline, scoring, dedupe, pipeline, admin users, audit | Done |
| M2 | Deals, proposals, clients, conversion, projects, tasks, meetings, notifications, follow-ups, role dashboards, search, import/export, merge | Done |
| M3 | Campaigns, landing pages, commissions, targets, performance, reports, analytics, integrations layer, AI assist, PWA, settings, docs | Done |
