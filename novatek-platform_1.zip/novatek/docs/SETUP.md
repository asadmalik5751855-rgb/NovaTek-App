# Setup

## 1. Environment variables

Copy `.env.example` to `.env.local` and fill it in. Rules:

- Only `NEXT_PUBLIC_*` values reach the browser (Supabase URL + anon key, site URL, timezone). RLS protects data.
- `SUPABASE_SERVICE_ROLE_KEY`, `LEAD_IP_HASH_SALT` and `CRON_SECRET` are **server-only** and must never be prefixed
  with `NEXT_PUBLIC_`.
- Generate secrets with `openssl rand -hex 32`.
- Optional integrations (AI, Stripe, WhatsApp…) stay disabled until their variables are set **and** a live check passes
  in Settings → Integrations.

| Variable | Required | Purpose |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | yes | Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | yes | Public anon key (RLS applies) |
| `SUPABASE_SERVICE_ROLE_KEY` | yes | Lead intake, user provisioning, audit events, proposal links, cron |
| `NEXT_PUBLIC_SITE_URL` | yes | Absolute site URL for proposal links, sitemap, metadata |
| `NEXT_PUBLIC_APP_TIMEZONE` | no (Asia/Karachi) | Timezone for displaying dates and report buckets |
| `LEAD_IP_HASH_SALT` | yes | Hashes visitor IPs; signs re-authentication cookies |
| `CRON_SECRET` | yes in prod | Protects `/api/cron/notifications` |
| `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL` | no | AI assist |
| `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` | no | Payments connector check |
| `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID` | no | WhatsApp connector check |

## 2. Supabase project

1. Create a project (Postgres 15+). In **Authentication → Providers → Email**: enable email, **disable sign-ups**
   (accounts are created by administrators), and keep "Confirm email" on.
2. Apply migrations **in filename order** from `supabase/migrations/`:
   - With the Supabase CLI: `supabase link --project-ref <ref>` then `supabase db push`, or
   - In the SQL editor: run each file in order (`…000100_core_schema.sql` → `…000900_platform.sql`).
3. Migration `…000700_work.sql` creates the private Storage bucket **`documents`** and its access policies when the
   `storage` schema exists (always true on Supabase). Files are capped at 25 MB.
4. Do **not** run `supabase/tests/supabase_shim.sql` against Supabase — it is only for local plain-Postgres tests.

The migrations load **reference data only** (roles, permissions, statuses, sources, services, industries, countries,
deal stages, scoring rules, qualification questions, integrations registry). There are no fake leads, clients, revenue
or employees.

## 3. First administrator

```bash
NEXT_PUBLIC_SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... npm run admin:create -- admin@company.com "Admin Name"
```

The password is prompted (or read from `SUPER_ADMIN_PASSWORD`). Then sign in at `/login` and create the rest of the
team in **Users** — each person gets roles; permissions come from roles (editable in **Roles & permissions**).

## 4. Configure the business

In **Settings**: branding text and contact details (the logo is locked), target industries and countries, lead
statuses, deal stages, scoring points, qualification questions, departments. In **Commissions → Rules**: create rules;
a second manager approves them before they apply.

## 5. Local development and tests

```bash
npm install
npm run dev                    # http://localhost:3000
```

Database tests run against **plain local Postgres 15+** with a small Supabase shim:

```bash
createdb novatek_test   # or use any URL
DATABASE_URL=postgres://user:pass@localhost:5432/novatek_test npm run db:reset:local
TEST_DATABASE_URL=postgres://user:pass@localhost:5432/novatek_test npm test
```

The suite (`tests/db/*.test.ts`) attacks the rules directly in SQL as different roles: RLS isolation, IDOR, privilege
escalation, forged links, evidence rules for proposals, commission approval, atomic conversion, merge, analytics
scoping, import rollback. `tests/brand/` enforces the logo lock.

End-to-end (`tests/e2e/flow.mjs`) runs Playwright against a running app backed by a real Supabase-compatible stack
(Supabase Auth + PostgREST). Set `BASE_URL` and seed the test users listed at the top of the file.
