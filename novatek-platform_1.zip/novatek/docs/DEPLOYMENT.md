# Deployment (Vercel + Supabase)

## 1. Supabase (production project)

1. Create the project in the region closest to your users.
2. Auth → Email: sign-ups **disabled**, email confirmation on. Set **Site URL** to your domain and add it to redirect URLs.
3. Apply all migrations in order (`supabase db push` or the SQL editor). Never apply `supabase/tests/supabase_shim.sql`.
4. Create the first Super Admin: `npm run admin:create -- admin@company.com "Name"` with production env vars.

## 2. Vercel

1. Import the repository. Framework: Next.js. Build command `next build`.
2. Add environment variables from `.env.example` for **Production** (and Preview, pointing at a separate Supabase
   project — never share production data with previews).
3. **Cron:** `vercel.json` schedules `/api/cron/notifications` every 15 minutes (due/overdue tasks, meetings in the next
   hour, overdue follow-ups, proposal expiry). Set `CRON_SECRET`; Vercel sends it as a Bearer token. On plans that
   limit cron frequency, use the most frequent schedule available, or call the endpoint from any scheduler with
   `Authorization: Bearer $CRON_SECRET`.
4. **Domain:** add your domain in Vercel, set `NEXT_PUBLIC_SITE_URL` to it, and update Supabase Auth's Site URL.
5. Security headers, CSP and caching rules are in `next.config.ts` and apply automatically.

## 3. Release checklist

- `npm run typecheck && npm run lint && npm test && npm run build` all pass.
- New migrations applied to production **before** deploying code that uses them.
- `/api/health` returns `{"status":"ok"}` after deploy (use it for uptime monitoring).
- Sign in as a non-admin and confirm admin pages redirect to "Access denied".

## 4. Monitoring

- `/api/health` — liveness + database reachability (no secrets).
- Server errors are logged with a context tag (`[action:…]`, `[export]`, `[cron:…]`) — connect Vercel Log Drains or
  your log tool. Users only ever see safe messages.
- The audit log (Administration → Audit log) records security-relevant events.

## 5. Backup & recovery

- Enable Supabase **Point-in-Time Recovery** (Pro plan) or at minimum daily backups. Test a restore into a separate
  project quarterly.
- Storage (`documents` bucket) is not covered by database PITR — schedule a periodic copy of the bucket.
- To recover a single record, prefer the in-app **restore** (archived leads/clients/deals) — nothing is hard-deleted.
- Keep migrations as the single source of schema truth; never edit production schema by hand.

## 6. Admin provisioning

- Create users in **Users** (requires `users.manage_roles`), assign roles; set department/designation in the profile.
- Disable leavers (Account status → Disabled) instead of deleting them, so their history remains attributed.
- Review **Roles & permissions** after adding custom roles; changes are audited.
