import "server-only";
import { envPresent, integrationEnv } from "@/lib/env.server";

/**
 * Integration adapters. Each one performs a REAL check against the provider. Nothing here simulates success:
 * missing credentials → "not_configured"; a failed call → "error"; no adapter yet → stays disabled.
 */
export type CheckResult = { status: "ok" | "error" | "not_configured"; message: string };

type Adapter = { check: () => Promise<CheckResult> };

async function httpCheck(url: string, init: RequestInit, label: string): Promise<CheckResult> {
  try {
    const res = await fetch(url, { ...init, signal: AbortSignal.timeout(10_000), cache: "no-store" });
    if (res.ok) return { status: "ok", message: `${label} responded successfully.` };
    return { status: "error", message: `${label} returned HTTP ${res.status}. Check the credentials.` };
  } catch (e) {
    return { status: "error", message: `Could not reach ${label}: ${(e as Error).message}`.slice(0, 300) };
  }
}

const ADAPTERS: Record<string, Adapter> = {
  anthropic_ai: {
    check: () =>
      httpCheck("https://api.anthropic.com/v1/models?limit=1", {
        headers: { "x-api-key": integrationEnv.anthropicApiKey, "anthropic-version": "2023-06-01" },
      }, "Anthropic API"),
  },
  stripe: {
    check: () => httpCheck("https://api.stripe.com/v1/balance", { headers: { Authorization: `Bearer ${integrationEnv.stripeSecretKey}` } }, "Stripe"),
  },
  whatsapp_business: {
    check: () =>
      httpCheck(`https://graph.facebook.com/v21.0/${encodeURIComponent(integrationEnv.whatsappPhoneNumberId)}`, {
        headers: { Authorization: `Bearer ${integrationEnv.whatsappToken}` },
      }, "WhatsApp Cloud API"),
  },
};

export async function checkIntegration(key: string, requiredEnv: string[]): Promise<CheckResult> {
  if (!envPresent(requiredEnv)) {
    return { status: "not_configured", message: `Set ${requiredEnv.join(", ")} on the server, then check again.` };
  }
  const adapter = ADAPTERS[key];
  if (!adapter) {
    return { status: "not_configured", message: "Credentials are present, but this connector isn't built yet, so it stays disabled." };
  }
  return adapter.check();
}

export function hasAdapter(key: string) {
  return key in ADAPTERS;
}
