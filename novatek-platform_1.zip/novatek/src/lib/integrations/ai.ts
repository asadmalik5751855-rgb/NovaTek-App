import "server-only";
import { integrationEnv } from "@/lib/env.server";

export type AiFeature = "lead_summary" | "outreach_draft" | "next_best_action" | "proposal_draft" | "meeting_summary";

export const AI_FEATURES: Record<AiFeature, { label: string; entity: "lead" | "deal" | "meeting"; instruction: string }> = {
  lead_summary: {
    label: "Summarise this lead",
    entity: "lead",
    instruction: "Summarise this sales lead for a NovaTek salesperson in 4-6 short bullet points: who they are, what they asked for, budget/timeline signals, and open questions.",
  },
  outreach_draft: {
    label: "Draft an outreach email",
    entity: "lead",
    instruction: "Draft a short, personal first-reply email from NovaTek to this prospect. Reference only what they actually told us. Ask one or two clarifying questions and propose a short call. Plain text, under 160 words, with a subject line.",
  },
  next_best_action: {
    label: "Suggest next steps",
    entity: "lead",
    instruction: "Based on the lead's data and timeline, suggest the 3 most useful next actions for the salesperson, each with a one-line reason.",
  },
  proposal_draft: {
    label: "Draft proposal scope",
    entity: "deal",
    instruction: "Draft a clear scope-of-work outline for a NovaTek proposal for this deal: deliverables, phases, assumptions and what's out of scope. Use only the information provided and mark anything that needs confirming with [confirm].",
  },
  meeting_summary: {
    label: "Summarise meeting notes",
    entity: "meeting",
    instruction: "Summarise these meeting notes into: key points, decisions, action items (with owners if stated), and follow-ups. Do not add anything that is not in the notes.",
  },
};

const SYSTEM = `You assist NovaTek, a software services company, inside its CRM.
Rules you must follow:
- Use ONLY the facts in the provided record. Never invent company details, contact details, numbers, replies or meetings.
- If something important is unknown, say it is unknown or mark it [confirm].
- Your output is a draft for a human to review. Never claim anything was sent or agreed.`;

export function isAiConfigured() {
  return Boolean(integrationEnv.anthropicApiKey);
}

export async function generate(feature: AiFeature, record: Record<string, unknown>) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": integrationEnv.anthropicApiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: integrationEnv.anthropicModel,
      max_tokens: 900,
      system: SYSTEM,
      messages: [
        {
          role: "user",
          content: `${AI_FEATURES[feature].instruction}\n\n<record>\n${JSON.stringify(record, null, 2).slice(0, 12000)}\n</record>`,
        },
      ],
    }),
    signal: AbortSignal.timeout(45_000),
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`AI provider returned HTTP ${res.status}`);
  const json = (await res.json()) as {
    content?: { type: string; text?: string }[];
    model?: string;
    usage?: { input_tokens?: number; output_tokens?: number };
  };
  const text = (json.content ?? []).filter((c) => c.type === "text").map((c) => c.text ?? "").join("\n").trim();
  if (!text) throw new Error("AI provider returned no text");
  return { text, model: json.model ?? integrationEnv.anthropicModel, inputTokens: json.usage?.input_tokens, outputTokens: json.usage?.output_tokens };
}
