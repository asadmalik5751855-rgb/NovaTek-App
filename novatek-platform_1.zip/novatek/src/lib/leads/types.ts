import type { Temperature } from "./normalize";

export type LeadStatus = {
  id: string;
  key: string;
  name: string;
  position: number;
  color: string;
  show_in_pipeline: boolean;
  is_closed: boolean;
  is_won: boolean;
};

export type Lookup = { id: string; name: string; key?: string };
export type Country = { code: string; name: string };
export type DirectoryUser = { id: string; full_name: string; designation: string | null };

export type LeadListItem = {
  id: string;
  company_name: string;
  contact_name: string | null;
  email: string | null;
  country_code: string | null;
  score: number;
  temperature: Temperature;
  status_id: string;
  source_id: string;
  service_id: string | null;
  assigned_to: string | null;
  estimated_value: number | null;
  currency: string;
  next_follow_up_at: string | null;
  possible_duplicate_of: string | null;
  created_at: string;
};

export type Lead = LeadListItem & {
  website: string | null;
  website_domain: string | null;
  industry_id: string | null;
  city: string | null;
  business_size: string | null;
  phone: string | null;
  source_reference: string | null;
  budget_range: string | null;
  message: string | null;
  score_breakdown: { signal: string; label: string; points: number }[];
  created_by: string | null;
  last_contacted_at: string | null;
  follow_up_type: string | null;
  follow_up_priority: string | null;
  consent_status: string;
  utm_source: string | null;
  utm_medium: string | null;
  utm_campaign: string | null;
  utm_content: string | null;
  utm_term: string | null;
  archived_at: string | null;
  updated_at: string;
  qualification: Record<string, string>;
  client_id: string | null;
  merged_into: string | null;
  max_funnel_rank: number;
};

export type LeadActivity = {
  id: string;
  type: string;
  body: string | null;
  metadata: Record<string, unknown>;
  actor_id: string | null;
  created_at: string;
};

export const BUDGET_RANGES = [
  { value: "under_1k", label: "Under $1,000" },
  { value: "1k_5k", label: "$1,000 – $5,000" },
  { value: "5k_15k", label: "$5,000 – $15,000" },
  { value: "15k_plus", label: "$15,000+" },
  { value: "not_sure", label: "Not sure yet" },
] as const;

export const BUSINESS_SIZES = [
  { value: "solo", label: "Just me" },
  { value: "2_10", label: "2–10" },
  { value: "11_50", label: "11–50" },
  { value: "51_200", label: "51–200" },
  { value: "201_1000", label: "201–1,000" },
  { value: "1000_plus", label: "1,000+" },
] as const;

export const TEMPERATURE_COLOR: Record<Temperature, string> = {
  cold: "sky",
  warm: "amber",
  hot: "rose",
  very_hot: "fuchsia",
};
