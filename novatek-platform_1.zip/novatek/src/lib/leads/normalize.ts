/**
 * Lead normalization — mirrors the SQL functions in
 * supabase/migrations/20261015000200_functions.sql. Parity is enforced by tests/db/normalize-parity.test.ts.
 * The database is the source of truth; these are used for client-side hints and import previews.
 */

const COMPANY_SUFFIXES =
  /\b(the|pvt|private|ltd|limited|llc|inc|incorporated|co|company|corp|corporation|plc|gmbh|fze|fzco|fz|smc)\b/g;

export function normalizeCompanyName(input: string | null | undefined): string {
  return (input ?? "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(COMPANY_SUFFIXES, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function normalizeDomain(input: string | null | undefined): string | null {
  if (!input || !input.trim()) return null;
  let d = input.trim().toLowerCase();
  d = d.replace(/^[a-z][a-z0-9+.-]*:\/\//, "");
  d = d.replace(/^\/\//, "");
  d = d.replace(/^[^@/]*@/, "");
  d = d.split("/")[0].split("?")[0].split("#")[0].split(":")[0];
  d = d.replace(/^www\./, "").replace(/\.+$/, "");
  return /^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(d) ? d : null;
}

export function normalizeEmail(input: string | null | undefined): string | null {
  const e = (input ?? "").trim().toLowerCase();
  return e === "" ? null : e;
}

export function phoneKey(input: string | null | undefined): string | null {
  const digits = (input ?? "").replace(/\D/g, "");
  return digits.length >= 7 ? digits.slice(-9) : null;
}

export type Temperature = "cold" | "warm" | "hot" | "very_hot";

export function temperatureFor(score: number): Temperature {
  if (score <= 30) return "cold";
  if (score <= 60) return "warm";
  if (score <= 80) return "hot";
  return "very_hot";
}

export const TEMPERATURE_LABEL: Record<Temperature, string> = {
  cold: "Cold",
  warm: "Warm",
  hot: "Hot",
  very_hot: "Very Hot",
};
