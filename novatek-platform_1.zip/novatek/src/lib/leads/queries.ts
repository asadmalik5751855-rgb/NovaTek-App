import "server-only";
import { cache } from "react";
import { createClient } from "@/lib/supabase/server";
import type { Country, DirectoryUser, Lead, LeadActivity, LeadListItem, LeadStatus, Lookup } from "./types";

export const LEAD_LIST_COLUMNS =
  "id, company_name, contact_name, email, country_code, score, temperature, status_id, source_id, service_id, assigned_to, estimated_value, currency, next_follow_up_at, possible_duplicate_of, created_at";

export const getLookups = cache(async () => {
  const supabase = await createClient();
  const [statuses, sources, services, industries, countries, directory] = await Promise.all([
    supabase.from("lead_statuses").select("id, key, name, position, color, show_in_pipeline, is_closed, is_won").eq("active", true).order("position"),
    supabase.from("lead_sources").select("id, key, name").eq("active", true).order("name"),
    supabase.from("services").select("id, key, name").eq("active", true).order("position"),
    supabase.from("industries").select("id, name").eq("active", true).order("name"),
    supabase.from("countries").select("code, name").eq("active", true).order("name"),
    supabase.from("directory").select("id, full_name, designation").eq("status", "active").order("full_name"),
  ]);
  for (const r of [statuses, sources, services, industries, countries, directory]) if (r.error) throw r.error;
  const s = (statuses.data ?? []) as LeadStatus[];
  return {
    statuses: s,
    statusById: new Map(s.map((x) => [x.id, x])),
    sources: (sources.data ?? []) as Lookup[],
    services: (services.data ?? []) as Lookup[],
    industries: (industries.data ?? []) as Lookup[],
    countries: (countries.data ?? []) as Country[],
    people: (directory.data ?? []) as DirectoryUser[],
  };
});

export type Lookups = Awaited<ReturnType<typeof getLookups>>;

export type LeadFilters = {
  q?: string;
  status?: string;
  temperature?: string;
  assigned?: string; // user id | "me" | "unassigned"
  source?: string;
  archived?: boolean;
  page?: number;
};

export const PAGE_SIZE = 25;

export async function listLeads(filters: LeadFilters, userId: string) {
  const supabase = await createClient();
  const page = Math.max(1, filters.page ?? 1);
  let q = supabase.from("leads").select(LEAD_LIST_COLUMNS, { count: "exact" });

  q = filters.archived ? q.not("archived_at", "is", null) : q.is("archived_at", null);
  if (filters.status) q = q.eq("status_id", filters.status);
  if (filters.temperature === "hot_plus") q = q.in("temperature", ["hot", "very_hot"]);
  else if (filters.temperature) q = q.eq("temperature", filters.temperature);
  if (filters.source) q = q.eq("source_id", filters.source);
  if (filters.assigned === "me") q = q.eq("assigned_to", userId);
  else if (filters.assigned === "unassigned") q = q.is("assigned_to", null);
  else if (filters.assigned) q = q.eq("assigned_to", filters.assigned);
  if (filters.q) {
    // Escape PostgREST filter syntax characters; values are still parameterized server-side.
    const term = filters.q.replace(/[%,()*\\]/g, " ").trim().slice(0, 80);
    if (term) q = q.or(`company_name.ilike.%${term}%,contact_name.ilike.%${term}%,email.ilike.%${term}%`);
  }

  const { data, count, error } = await q
    .order("created_at", { ascending: false })
    .range((page - 1) * PAGE_SIZE, page * PAGE_SIZE - 1);
  if (error) throw error;
  return { leads: (data ?? []) as LeadListItem[], total: count ?? 0, page };
}

export async function getLead(id: string) {
  const supabase = await createClient();
  const [lead, activities, tags] = await Promise.all([
    supabase.from("leads").select("*").eq("id", id).maybeSingle(),
    supabase.from("lead_activities").select("id, type, body, metadata, actor_id, created_at").eq("lead_id", id).order("created_at", { ascending: false }).limit(200),
    supabase.from("lead_tag_relations").select("lead_tags(id, name, color)").eq("lead_id", id),
  ]);
  if (lead.error) throw lead.error;
  if (!lead.data) return null;
  let duplicate: { id: string; company_name: string } | null = null;
  if (lead.data.possible_duplicate_of) {
    // RLS decides whether the user may see the other lead; if not, it's reported as restricted.
    const { data } = await supabase.from("leads").select("id, company_name").eq("id", lead.data.possible_duplicate_of).maybeSingle();
    duplicate = data;
  }
  return {
    lead: lead.data as Lead,
    activities: (activities.data ?? []) as LeadActivity[],
    tags: ((tags.data ?? []) as unknown as { lead_tags: { id: string; name: string; color: string } }[]).map((t) => t.lead_tags),
    duplicate,
  };
}
