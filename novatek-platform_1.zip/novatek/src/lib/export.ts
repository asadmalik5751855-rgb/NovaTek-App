import type { PermissionCheck } from "@/lib/auth/permissions";

/** What can be exported, and who may export it. Data is always read through the user's RLS. */
export const EXPORTS: Record<string, { label: string; description: string; check: PermissionCheck }> = {
  leads: { label: "Leads", description: "All leads you can see, with status, score, source, owner and attribution.", check: "leads.export" },
  clients: { label: "Clients", description: "Client companies and primary contacts.", check: "sales.manage" },
  deals: { label: "Deals", description: "Deals with value, probability, stage and close dates.", check: { anyOf: ["sales.manage", "reports.view"] } },
  commissions: { label: "Commissions", description: "Commission records with status and payment references.", check: "commissions.manage" },
  audit: { label: "Audit log (last 10,000)", description: "Security and change history.", check: "audit.view" },
};
