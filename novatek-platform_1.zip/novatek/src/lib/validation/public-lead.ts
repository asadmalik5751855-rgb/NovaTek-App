import { z } from "zod";

const utm = z.string().trim().max(200).optional().default("");

export const publicLeadSchema = z.object({
  name: z.string().trim().min(2, "Enter your name").max(120),
  company: z.string().trim().min(1, "Enter your company or organisation").max(200),
  email: z.email("Enter a valid email address").max(254),
  phone: z
    .string()
    .trim()
    .max(40)
    .refine((v) => v === "" || /^[+()\-.\s\d]{6,40}$/.test(v), "Enter a valid phone number")
    .default(""),
  country: z.union([z.string().regex(/^[A-Z]{2}$/), z.literal("")]).default(""),
  service: z.union([z.string().regex(/^[a-z][a-z0-9_]{1,40}$/), z.literal("")]).default(""),
  budget: z.union([z.enum(["under_1k", "1k_5k", "5k_15k", "15k_plus", "not_sure"]), z.literal("")]).default(""),
  website: z.string().trim().max(300).default(""),
  message: z.string().trim().min(10, "Tell us a little about the project (at least 10 characters)").max(5000),
  consent: z.literal(true, { error: "Please confirm we may contact you about your enquiry" }),
  // Attribution
  utm_source: utm,
  utm_medium: utm,
  utm_campaign: utm,
  utm_content: utm,
  utm_term: utm,
  page_path: z.string().max(500).default("/contact"),
  landing_page: z.union([z.string().regex(/^[a-z0-9][a-z0-9-]{1,79}$/), z.literal("")]).default(""),
  // Abuse controls
  company_website: z.string().max(0).default(""), // honeypot: must stay empty
  started_at: z.coerce.number().int().positive(),
});

export type PublicLeadInput = z.input<typeof publicLeadSchema>;
