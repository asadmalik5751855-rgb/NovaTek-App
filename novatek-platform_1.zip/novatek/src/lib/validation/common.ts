import { z } from "zod";

/** Shared Zod building blocks. Empty strings from forms become null. Used on client (RHF) and server (authoritative). */

export const idSchema = z.uuid();

export const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max, `Use at most ${max} characters`)
    .transform((v) => (v === "" ? null : v))
    .nullable()
    .optional();

export const requiredText = (label: string, max: number, min = 1) =>
  z.string().trim().min(min, `${label} is required`).max(max, `Use at most ${max} characters`);

export const optionalUuid = z
  .union([z.uuid(), z.literal("")])
  .transform((v) => (v === "" ? null : v))
  .nullable()
  .optional();

export const optionalDate = z
  .union([z.iso.date("Enter a valid date"), z.literal("")])
  .transform((v) => (v === "" ? null : v))
  .nullable()
  .optional();

export const requiredDate = (label: string) => z.iso.date(`${label} is required`);

/** <input type="datetime-local"> value (local time) → ISO string with offset. */
export const optionalDateTime = z
  .union([z.iso.datetime({ local: true, offset: true }), z.literal("")])
  .transform((v) => (v === "" ? null : new Date(v).toISOString()))
  .nullable()
  .optional();

export const requiredDateTime = (label: string) =>
  z.iso.datetime({ local: true, offset: true, message: `${label} is required` }).transform((v) => new Date(v).toISOString());

export const money = z
  .union([z.coerce.number({ message: "Enter a number" }).min(0, "Must be 0 or more").max(1_000_000_000), z.literal("")])
  .transform((v) => (v === "" ? null : v))
  .nullable()
  .optional();

export const requiredMoney = (label: string) =>
  z.coerce.number({ message: `${label} must be a number` }).min(0, "Must be 0 or more").max(1_000_000_000);

export const percent = z.coerce.number({ message: "Enter a number" }).int("Whole numbers only").min(0).max(100);

export const CURRENCIES = ["USD", "PKR", "AED", "SAR", "EUR", "GBP"] as const;
export const currency = z.enum(CURRENCIES).default("USD");

export const httpsUrl = z
  .union([z.url({ protocol: /^https$/, message: "Use a full https:// link" }).max(500), z.literal("")])
  .transform((v) => (v === "" ? null : v))
  .nullable()
  .optional();

export const slug = z
  .string()
  .trim()
  .toLowerCase()
  .regex(/^[a-z0-9][a-z0-9-]{1,79}$/, "Use lowercase letters, numbers and dashes (2–80 characters)");

export const checkbox = z
  .union([z.boolean(), z.literal("on"), z.literal("true"), z.literal("false"), z.literal("")])
  .transform((v) => v === true || v === "on" || v === "true")
  .default(false);

/** Newline-separated textarea → array of trimmed non-empty lines. */
export const lines = (maxItems: number, maxLen: number) =>
  z
    .string()
    .transform((v) => v.split("\n").map((x) => x.trim()).filter(Boolean))
    .pipe(z.array(z.string().max(maxLen, `Each line must be at most ${maxLen} characters`)).max(maxItems, `At most ${maxItems} lines`));
