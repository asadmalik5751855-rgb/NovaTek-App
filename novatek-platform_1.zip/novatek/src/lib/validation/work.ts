import { z } from "zod";
import {
  CURRENCIES,
  httpsUrl,
  money,
  optionalDate,
  optionalDateTime,
  optionalText,
  optionalUuid,
  requiredDateTime,
  requiredText,
} from "./common";

export const TASK_STATUSES = ["todo", "in_progress", "review", "completed", "cancelled"] as const;
export const PRIORITIES = ["low", "medium", "high", "urgent"] as const;
export const TASK_KINDS = ["general", "technical", "bug", "design", "marketing", "sales"] as const;
export const PROJECT_STATUSES = ["planning", "active", "review", "completed", "paused", "cancelled"] as const;

export const taskSchema = z.object({
  title: requiredText("Title", 200),
  description: optionalText(10000),
  kind: z.enum(TASK_KINDS).default("general"),
  assignee_id: optionalUuid,
  priority: z.enum(PRIORITIES).default("medium"),
  due_at: optionalDateTime,
  status: z.enum(TASK_STATUSES).default("todo"),
  department_id: optionalUuid,
  lead_id: optionalUuid,
  client_id: optionalUuid,
  project_id: optionalUuid,
});

export const projectSchema = z
  .object({
    name: requiredText("Project name", 200),
    client_id: optionalUuid,
    deal_id: optionalUuid,
    service_id: optionalUuid,
    description: optionalText(10000),
    start_date: optionalDate,
    deadline: optionalDate,
    status: z.enum(PROJECT_STATUSES).default("planning"),
    budget: money,
    currency: z.enum(CURRENCIES).default("USD"),
    priority: z.enum(PRIORITIES).default("medium"),
    manager_id: optionalUuid,
    department_id: optionalUuid,
  })
  .refine((p) => !p.deadline || !p.start_date || p.deadline >= p.start_date, { message: "Deadline must be after the start date", path: ["deadline"] });

export const meetingSchema = z.object({
  title: requiredText("Title", 200),
  starts_at: requiredDateTime("Date and time"),
  duration_minutes: z.coerce.number({ message: "Enter minutes" }).int().min(5, "At least 5 minutes").max(600),
  meeting_link: httpsUrl,
  location: optionalText(200),
  external_attendees: optionalText(1000),
  notes: optionalText(10000),
  lead_id: optionalUuid,
  client_id: optionalUuid,
  deal_id: optionalUuid,
  project_id: optionalUuid,
  participant_ids: z.array(z.uuid()).max(30).default([]),
});

export const meetingNotesSchema = z.object({ notes: optionalText(10000) });
