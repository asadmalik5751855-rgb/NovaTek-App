import { z } from "zod";
import { CURRENCIES, optionalText } from "./common";

export const targetSchema = z
  .object({
    user_id: z.uuid("Choose a person"),
    metric: z.enum(["leads_created", "leads_qualified", "meetings_booked", "proposals_sent", "deals_won", "revenue_won", "tasks_completed"]),
    period_start: z.iso.date("Choose a start date"),
    period_end: z.iso.date("Choose an end date"),
    target_value: z.coerce.number({ message: "Enter a number" }).positive("Must be more than 0").max(1_000_000_000),
    currency: z.union([z.enum(CURRENCIES), z.literal("")]).transform((v) => (v === "" ? null : v)).nullable().optional(),
    notes: optionalText(1000),
  })
  .refine((t) => t.period_end >= t.period_start, { message: "End must be after start", path: ["period_end"] })
  .transform((t) => ({ ...t, currency: t.metric === "revenue_won" ? (t.currency ?? "USD") : null }));

