import { z } from "zod";
import {
  CURRENCIES,
  money,
  optionalDate,
  optionalText,
  optionalUuid,
  percent,
  requiredMoney,
  requiredText,
} from "./common";

export const dealSchema = z.object({
  name: requiredText("Deal name", 200),
  lead_id: optionalUuid,
  client_id: optionalUuid,
  stage_id: z.uuid("Choose a stage"),
  value: requiredMoney("Value"),
  currency: z.enum(CURRENCIES),
  probability: percent,
  expected_close_date: optionalDate,
  owner_id: optionalUuid,
  service_id: optionalUuid,
  notes: optionalText(10000),
}).refine((d) => d.lead_id || d.client_id, { message: "Link the deal to a lead or a client", path: ["lead_id"] });

export const dealUpdateSchema = z.object({
  name: requiredText("Deal name", 200),
  client_id: optionalUuid,
  stage_id: z.uuid("Choose a stage"),
  value: requiredMoney("Value"),
  currency: z.enum(CURRENCIES),
  probability: percent,
  expected_close_date: optionalDate,
  owner_id: optionalUuid,
  service_id: optionalUuid,
  notes: optionalText(10000),
});

export const proposalSchema = z.object({
  title: requiredText("Title", 200),
  service_id: optionalUuid,
  scope: optionalText(20000),
  price: requiredMoney("Price"),
  currency: z.enum(CURRENCIES),
  timeline: optionalText(2000),
  terms: optionalText(20000),
  expiry_date: optionalDate,
});

export const clientSchema = z.object({
  company_name: requiredText("Company name", 200),
  website: optionalText(300),
  industry_id: optionalUuid,
  country_code: z
    .union([z.string().regex(/^[A-Z]{2}$/), z.literal("")])
    .transform((v) => (v === "" ? null : v))
    .nullable()
    .optional(),
  city: optionalText(120),
  contact_name: optionalText(120),
  email: z
    .union([z.email("Enter a valid email").max(254), z.literal("")])
    .transform((v) => (v === "" ? null : v))
    .nullable()
    .optional(),
  phone: optionalText(40).refine((v) => !v || /^[+()\-.\s\d]{5,40}$/.test(v), "Enter a valid phone number"),
  account_manager_id: optionalUuid,
  status: z.enum(["active", "inactive"]).default("active"),
  notes: optionalText(10000),
});

export const commissionRuleSchema = z
  .object({
    name: requiredText("Name", 120),
    service_id: optionalUuid,
    eligible_role_id: optionalUuid,
    eligible_user_id: optionalUuid,
    percent: z.coerce.number({ message: "Enter a number" }).min(0).max(100),
    fixed_amount: money.transform((v) => v ?? 0),
    currency: z.enum(CURRENCIES),
    effective_from: z.iso.date("Choose a start date"),
    effective_to: optionalDate,
    notes: optionalText(2000),
  })
  .refine((r) => r.percent > 0 || (r.fixed_amount ?? 0) > 0, { message: "Set a percentage or a fixed amount", path: ["percent"] })
  .refine((r) => !r.effective_to || r.effective_to >= r.effective_from, { message: "End date must be after the start date", path: ["effective_to"] });
