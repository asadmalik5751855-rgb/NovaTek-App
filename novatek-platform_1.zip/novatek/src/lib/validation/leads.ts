import { z } from "zod";

const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .transform((v) => (v === "" ? null : v))
    .nullable()
    .optional();

const optionalUuid = z
  .union([z.uuid(), z.literal("")])
  .transform((v) => (v === "" ? null : v))
  .nullable()
  .optional();

export const leadFieldsSchema = z.object({
  company_name: z.string().trim().min(1, "Company name is required").max(200),
  contact_name: optionalText(120),
  email: z
    .union([z.email("Enter a valid email").max(254), z.literal("")])
    .transform((v) => (v === "" ? null : v.trim()))
    .nullable()
    .optional(),
  phone: optionalText(40).refine((v) => !v || /^[+()\-.\s\d]{5,40}$/.test(v), "Enter a valid phone number"),
  website: optionalText(300),
  industry_id: optionalUuid,
  country_code: z
    .union([z.string().regex(/^[A-Z]{2}$/), z.literal("")])
    .transform((v) => (v === "" ? null : v))
    .nullable()
    .optional(),
  city: optionalText(120),
  business_size: z
    .union([z.enum(["solo", "2_10", "11_50", "51_200", "201_1000", "1000_plus"]), z.literal("")])
    .transform((v) => (v === "" ? null : v))
    .nullable()
    .optional(),
  service_id: optionalUuid,
  budget_range: z
    .union([z.enum(["under_1k", "1k_5k", "5k_15k", "15k_plus", "not_sure"]), z.literal("")])
    .transform((v) => (v === "" ? null : v))
    .nullable()
    .optional(),
  estimated_value: z
    .union([z.coerce.number().min(0).max(1_000_000_000), z.literal("")])
    .transform((v) => (v === "" ? null : v))
    .nullable()
    .optional(),
  currency: z.string().regex(/^[A-Z]{3}$/).default("USD"),
  source_reference: optionalText(500),
  message: optionalText(5000),
});

export const createLeadSchema = leadFieldsSchema.extend({
  source_id: z.uuid("Choose a source"),
  status_id: z.uuid("Choose a status"),
  assigned_to: optionalUuid,
});

export type CreateLeadInput = z.input<typeof createLeadSchema>;

export const activitySchema = z.object({
  type: z.enum(["note", "call", "email", "message", "meeting"]),
  body: z.string().trim().min(1, "Write something first").max(5000),
});

export const followUpSchema = z.object({
  next_follow_up_at: z
    .union([z.iso.datetime({ local: true, offset: true }), z.literal("")])
    .transform((v) => (v === "" ? null : new Date(v).toISOString()))
    .nullable(),
  follow_up_type: z
    .union([z.enum(["call", "email", "message", "meeting", "other"]), z.literal("")])
    .transform((v) => (v === "" ? null : v))
    .nullable(),
  follow_up_priority: z
    .union([z.enum(["low", "medium", "high"]), z.literal("")])
    .transform((v) => (v === "" ? null : v))
    .nullable(),
});

export const idSchema = z.uuid();
