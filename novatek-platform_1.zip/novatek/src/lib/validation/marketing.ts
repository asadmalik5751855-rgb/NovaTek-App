import { z } from "zod";
import { CURRENCIES, checkbox, httpsUrl, lines, money, optionalDate, optionalText, optionalUuid, requiredText, slug } from "./common";

export const campaignSchema = z
  .object({
    name: requiredText("Name", 160),
    utm_campaign: z.string().trim().toLowerCase().regex(/^[a-z0-9][a-z0-9_-]{1,79}$/, "Lowercase letters, numbers, - and _ (2–80 chars)"),
    channel: z.enum(["email", "social", "ads", "seo", "content", "events", "referral", "outreach", "other"]),
    status: z.enum(["draft", "active", "paused", "completed"]),
    description: optionalText(5000),
    start_date: optionalDate,
    end_date: optionalDate,
    budget: money,
    spend: money.transform((v) => v ?? 0),
    currency: z.enum(CURRENCIES),
    target_industry_id: optionalUuid,
    target_country_code: z.union([z.string().regex(/^[A-Z]{2}$/), z.literal("")]).transform((v) => (v === "" ? null : v)).nullable().optional(),
    service_id: optionalUuid,
    owner_id: optionalUuid,
  })
  .refine((c) => !c.end_date || !c.start_date || c.end_date >= c.start_date, { message: "End date must be after the start date", path: ["end_date"] });

/** Testimonials are entered one per line as: quote | name | role. */
const testimonials = z
  .string()
  .transform((v) => v.split("\n").map((x) => x.trim()).filter(Boolean))
  .pipe(z.array(z.string().max(700)).max(6, "At most 6 testimonials"))
  .transform((rows) => rows.map((r) => {
    const [quote, author, role] = r.split("|").map((x) => x.trim());
    return { quote, author: author ?? "", role: role ?? "" };
  }))
  .refine((rows) => rows.every((t) => t.quote && t.author), "Each testimonial needs: quote | name | role");

/** FAQ: one per line as: question | answer. */
const faq = z
  .string()
  .transform((v) => v.split("\n").map((x) => x.trim()).filter(Boolean))
  .pipe(z.array(z.string().max(1200)).max(12, "At most 12 questions"))
  .transform((rows) => rows.map((r) => {
    const i = r.indexOf("|");
    return { q: (i > 0 ? r.slice(0, i) : r).trim(), a: (i > 0 ? r.slice(i + 1) : "").trim() };
  }))
  .refine((rows) => rows.every((f) => f.q && f.a), "Each FAQ line needs: question | answer");

export const landingPageSchema = z
  .object({
    slug,
    campaign_id: optionalUuid,
    service_id: optionalUuid,
    headline: requiredText("Headline", 160, 3),
    subheadline: optionalText(400),
    hero_image_url: httpsUrl,
    benefits: lines(12, 200),
    cta_label: requiredText("Button label", 60, 2),
    testimonials,
    testimonials_confirmed: checkbox,
    faq,
    status: z.enum(["draft", "published", "archived"]),
  })
  .refine((p) => p.testimonials.length === 0 || p.testimonials_confirmed, {
    message: "Confirm these are real testimonials you have permission to publish",
    path: ["testimonials_confirmed"],
  });

export const siteEntrySchema = z
  .object({
    kind: z.enum(["portfolio", "case_study"]),
    slug,
    title: requiredText("Title", 160, 3),
    client_name: optionalText(160),
    client_permission: checkbox,
    industry_id: optionalUuid,
    service_id: optionalUuid,
    summary: requiredText("Summary", 600, 10),
    challenge: optionalText(5000),
    solution: optionalText(5000),
    results: optionalText(5000),
    image_url: httpsUrl,
    project_url: httpsUrl,
    status: z.enum(["draft", "published", "archived"]),
    position: z.coerce.number().int().min(0).max(1000).default(0),
  })
  .refine((e) => e.status !== "published" || !e.client_name || e.client_permission, {
    message: "You need the client's permission to publish their name",
    path: ["client_permission"],
  });
