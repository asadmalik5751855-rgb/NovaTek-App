import "server-only";
import { createHash } from "node:crypto";
import { headers } from "next/headers";
import { serverEnv } from "@/lib/env.server";

/** Salted hash of the visitor IP — used for abuse limits and evidence without storing raw IPs. */
export async function visitorIpHash() {
  const h = await headers();
  const ip = (h.get("x-forwarded-for")?.split(",")[0] ?? h.get("x-real-ip") ?? "unknown").trim();
  return createHash("sha256").update(`${serverEnv.leadIpHashSalt}:${ip}`).digest("hex");
}

const BOT = /bot|crawler|spider|preview|facebookexternalhit|whatsapp|slack|telegram|discord|skype|linkedin|embedly|vkshare|pinterest|quora|outlook|bitly|curl|wget|python-requests|headless/i;

/** Link-preview bots and prefetches must never count as a client "view". */
export async function isAutomatedOrPrefetch() {
  const h = await headers();
  const ua = h.get("user-agent") ?? "";
  const purpose = `${h.get("purpose") ?? ""} ${h.get("sec-purpose") ?? ""} ${h.get("x-purpose") ?? ""}`.toLowerCase();
  return !ua || BOT.test(ua) || purpose.includes("prefetch") || purpose.includes("preview");
}
