export const IMPORT_COLUMNS = ["company_name", "contact_name", "email", "phone", "website", "city", "country", "industry", "service", "estimated_value", "currency", "notes"];
