/**
 * Centralized brand configuration. Components never hardcode logo paths or the company name.
 *
 * BRAND RULE: the NovaTek logo and wordmark are only ever rendered from these image files.
 * Never retype "NovaTek" as styled text in place of the logo, never recolour, crop, stretch or redraw it.
 * OWNER INSTRUCTION: the logo and the name's font are LOCKED. Settings → Branding must not offer controls to
 * replace, recolour or restyle them. Enforced by tests/brand/brand-lock.test.ts (byte-exact hash pin).
 */
export const brand = {
  companyName: "NovaTek",
  tagline: "Digital Solutions • Web Development • E-Commerce • UI/UX • Custom Software",
  logo: {
    /** Horizontal lockup: symbol + wordmark. Opaque white background — on dark UI show it on a light plate. */
    horizontal: { src: "/brand/novatek-logo-horizontal.png", width: 3000, height: 563 },
    /** App icon: symbol on the brand base colour, rounded. Safe on any background. */
    icon: { src: "/brand/novatek-app-icon.png", width: 1024, height: 1024 },
  },
  contact: {
    email: "novatek360@gmail.com",
    whatsapp: "+92 314 3049846",
    whatsappLink: "https://wa.me/923143049846",
  },
  colors: { base: "#0B0F1A", blue: "#1060F9", violet: "#7B3FF2" },
} as const;
