import "server-only";

/** Server-only secrets. Never prefix these with NEXT_PUBLIC_. */
export const serverEnv = {
  supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY ?? "",
  /** Salt for hashing visitor IPs (rate limiting without storing raw IPs). */
  leadIpHashSalt: process.env.LEAD_IP_HASH_SALT ?? "",
};

export function isServiceRoleConfigured() {
  return Boolean(serverEnv.supabaseServiceRoleKey && serverEnv.leadIpHashSalt);
}

/** Optional integrations — each stays disabled until its variables are set AND a live check passes. */
export const integrationEnv = {
  anthropicApiKey: process.env.ANTHROPIC_API_KEY ?? "",
  anthropicModel: process.env.ANTHROPIC_MODEL ?? "claude-sonnet-5-5",
  stripeSecretKey: process.env.STRIPE_SECRET_KEY ?? "",
  whatsappToken: process.env.WHATSAPP_TOKEN ?? "",
  whatsappPhoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID ?? "",
  cronSecret: process.env.CRON_SECRET ?? "",
};

export function envPresent(names: string[]) {
  return names.every((n) => Boolean(process.env[n]));
}
