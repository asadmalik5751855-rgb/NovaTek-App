import "server-only";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize, type Session } from "@/lib/auth/session";
import type { PermissionCheck } from "@/lib/auth/permissions";
import { toActionError, type ActionResult } from "@/lib/errors";
import { idSchema } from "@/lib/validation/common";

export const NOT_FOUND = { ok: false as const, error: "Not found, or you don't have access to it." };

export function invalid(err: z.ZodError) {
  return { ok: false as const, error: "Please fix the highlighted fields.", fieldErrors: z.flattenError(err).fieldErrors };
}

export const ok = <T = undefined>(data?: T): ActionResult<T> => ({ ok: true, data: data as T });

/**
 * Standard server-action wrapper:
 *  1. verifies the session and permission (server-side; the UI check is only cosmetic),
 *  2. validates input with Zod,
 *  3. runs the work with the user's own Supabase client (RLS applies),
 *  4. maps any error to a safe message (raw DB errors are logged, never shown).
 */
export async function runAction<S extends z.ZodType, T>(
  name: string,
  check: PermissionCheck | null,
  schema: S,
  input: unknown,
  fn: (data: z.output<S>, session: Session) => Promise<ActionResult<T>>,
): Promise<ActionResult<T>> {
  try {
    const session = await authorize(check ?? undefined);
    const parsed = schema.safeParse(input);
    if (!parsed.success) return invalid(parsed.error);
    return await fn(parsed.data, session);
  } catch (e) {
    return friendlyDbError(e, name);
  }
}

export function validId(id: unknown): id is string {
  return idSchema.safeParse(id).success;
}

export function refresh(...paths: string[]) {
  for (const p of paths) revalidatePath(p);
}

/** Supabase/PostgREST errors carry the Postgres message; expose it only for our own guard messages (P0001/42501/23514 raised by NovaTek functions). */
export function friendlyDbError(err: unknown, name: string) {
  const e = err as { code?: string; message?: string };
  const ours = typeof e?.message === "string" && /^[A-Z][^\n]{3,200}$/.test(e.message) && !/violates|syntax|column|relation|function|permission denied/i.test(e.message);
  if (ours && (e.code === "42501" || e.code === "23514" || e.code === "P0001" || e.code === "P0002")) {
    return { ok: false as const, error: e.message!.endsWith(".") ? e.message! : `${e.message}.` };
  }
  return toActionError(err, name);
}
