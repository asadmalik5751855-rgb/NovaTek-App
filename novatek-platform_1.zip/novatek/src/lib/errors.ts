import "server-only";
import { AuthorizationError } from "@/lib/auth/session";

export type ActionResult<T = undefined> =
  | { ok: true; data: T }
  | { ok: false; error: string; fieldErrors?: Record<string, string[] | undefined> };

type PgLikeError = { code?: string; message?: string };

/**
 * Converts any error into a message safe to show users. Raw database errors are logged server-side only.
 */
export function toActionError(err: unknown, context: string): { ok: false; error: string } {
  if (err instanceof AuthorizationError) {
    return {
      ok: false,
      error: err.code === "unauthenticated" ? "Your session has expired. Please sign in again." : "You don't have permission to do that.",
    };
  }
  const e = err as PgLikeError;
  if (e?.code === "42501") return { ok: false, error: "You don't have permission to do that." };
  if (e?.code === "23505") return { ok: false, error: "That record already exists." };
  if (e?.code === "23503") return { ok: false, error: "A referenced record no longer exists. Refresh and try again." };
  if (e?.code === "23514" || e?.code === "22P02") return { ok: false, error: "Some values are invalid." };
  console.error(`[action:${context}]`, err);
  return { ok: false, error: "Something went wrong. Please try again." };
}

/** Throws the Supabase/Postgres error object if present, so toActionError can classify it. */
export function check<T>(res: { data: T; error: PgLikeError | null }): T {
  if (res.error) throw res.error;
  return res.data;
}

/** Like check(), but also treats an empty result as an error (for .single() inserts). */
export function checkRow(res: { data: unknown; error: PgLikeError | null }): Record<string, unknown> {
  if (res.error) throw res.error;
  if (res.data === null || res.data === undefined) throw new Error("No row returned");
  return res.data as Record<string, unknown>;
}
