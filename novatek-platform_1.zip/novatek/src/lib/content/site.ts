/**
 * Public website content. Kept in one place so it can move to admin-editable settings (M2)
 * without touching components. No invented statistics, clients or testimonials.
 */
export const SERVICES = [
  {
    key: "web_development",
    name: "Web development",
    summary: "Fast, accessible business websites that are easy to update and built to be found.",
    detail: "Marketing sites, company websites and content platforms on modern frameworks, with an editor your team can actually use, technical SEO in place from day one, and performance budgets we test against.",
  },
  {
    key: "ecommerce",
    name: "E-commerce",
    summary: "Online stores that turn browsing into orders, on Shopify or fully custom.",
    detail: "Store setup and migration, custom themes, product catalogues, payments and checkout, and the integrations with stock, shipping and accounting that keep orders moving.",
  },
  {
    key: "custom_software",
    name: "Custom software",
    summary: "Internal tools and business applications shaped around how your team works.",
    detail: "Portals, dashboards, booking and management systems — built with proper permissions, audit trails and data you own, so they keep working as you grow.",
  },
  {
    key: "ui_ux",
    name: "UI/UX design",
    summary: "Interfaces people understand on first use, designed before they are built.",
    detail: "Research, user flows, wireframes and high-fidelity designs delivered as a working design system, so development matches what you approved.",
  },
  {
    key: "saas",
    name: "SaaS products",
    summary: "From first version to subscription product, with multi-tenant foundations.",
    detail: "Accounts, roles, billing, onboarding and the admin tooling you need to support customers — scoped to ship a usable first release quickly.",
  },
  {
    key: "ai_automation",
    name: "AI & business automation",
    summary: "Remove repetitive work: connect your tools and add AI where it is reliable.",
    detail: "Workflow automation between the systems you already use, document and enquiry processing, and AI assistants with human review where accuracy matters.",
  },
] as const;

export const INDUSTRIES = [
  "Startups",
  "Small and medium businesses",
  "E-commerce brands",
  "Schools, colleges and institutes",
  "Restaurants and hospitality",
  "Retail",
  "Professional services",
];

/** A real sequence: how an engagement runs. */
export const PROCESS = [
  { name: "Discovery call", text: "We learn what you need, your timeline and budget, and tell you honestly whether we're the right fit." },
  { name: "Proposal", text: "A written scope with deliverables, price and schedule. Nothing starts until you approve it." },
  { name: "Design and build", text: "Work in short cycles with a preview link you can review at every step." },
  { name: "Launch and support", text: "We deploy, hand over access and documentation, and stay available for improvements." },
];

/** Outcome-oriented packages for the Solutions page. Descriptions of what we do — no invented results. */
export const SOLUTIONS = [
  {
    key: "launch",
    name: "Launch or relaunch your website",
    for: "Businesses with no site, an outdated one, or one that doesn't work on phones.",
    includes: ["Content structure and copy guidance", "Responsive design", "Technical SEO foundations", "Contact and enquiry forms wired to your inbox or CRM", "Training to update it yourself"],
    service: "web_development",
  },
  {
    key: "sell",
    name: "Start selling online",
    for: "Retailers and brands moving from social media or in-store sales to a real online store.",
    includes: ["Store setup on Shopify or custom", "Product catalogue and variants", "Local and international payments", "Shipping and stock rules", "Order notifications"],
    service: "ecommerce",
  },
  {
    key: "operate",
    name: "Run operations from one system",
    for: "Teams juggling spreadsheets, WhatsApp groups and paper for bookings, admissions or orders.",
    includes: ["Process mapping with your team", "Role-based portal for staff", "Customer-facing forms or portal", "Reports managers can trust", "Audit trail of every change"],
    service: "custom_business_apps",
  },
  {
    key: "automate",
    name: "Automate repetitive admin",
    for: "Teams re-typing the same data between tools, or answering the same enquiries all day.",
    includes: ["Integrations between your existing tools", "Document and enquiry processing", "AI drafts with human review", "Alerts when something needs attention"],
    service: "ai_automation",
  },
  {
    key: "product",
    name: "Build a SaaS product",
    for: "Founders validating a software idea who need a reliable first version.",
    includes: ["Scope for a first release", "Accounts, roles and billing", "Admin tooling", "Analytics events", "A codebase you own"],
    service: "saas",
  },
] as const;

export const INDUSTRY_DETAILS = [
  { name: "Schools, colleges and institutes", text: "Admissions and enquiry forms, fee information, notices and parent communication portals." },
  { name: "E-commerce brands", text: "Stores, catalogue management, payments and the integrations behind order fulfilment." },
  { name: "Restaurants and hospitality", text: "Menus, reservations, ordering and loyalty that work well on a phone." },
  { name: "Retail", text: "Moving in-store catalogues online and connecting stock across channels." },
  { name: "Professional services", text: "Credible websites, client intake, booking and document workflows." },
  { name: "Startups", text: "First product versions, landing pages and the internal tools a small team needs." },
  { name: "Small and medium businesses", text: "Replacing spreadsheets and manual steps with systems your team can rely on." },
] as const;
