import "server-only";
import { isServiceRoleConfigured } from "@/lib/env.server";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Records a server-verified event (login, logout, export) for a known actor.
 * Database-side changes are audited by triggers; this is only for events with no row change.
 * Failure to audit is logged but never silently reported as success elsewhere.
 */
export async function auditEvent(
  actorId: string,
  action: `${string}.${string}`,
  entity: string,
  entityId: string | null,
  metadata: Record<string, unknown> = {},
) {
  if (!isServiceRoleConfigured()) {
    console.warn(`[audit] service role not configured; event not recorded: ${action}`);
    return;
  }
  const { error } = await createAdminClient().rpc("log_audit_event", {
    p_actor: actorId,
    p_action: action,
    p_entity: entity,
    p_entity_id: entityId,
    p_metadata: metadata,
  });
  if (error) console.error("[audit] failed to record", action, error);
}
