/** Display labels and badge colours shared by server and client components. */

export const TASK_STATUS = {
  todo: { label: "To do", color: "slate" },
  in_progress: { label: "In progress", color: "blue" },
  review: { label: "Review", color: "violet" },
  completed: { label: "Completed", color: "emerald" },
  cancelled: { label: "Cancelled", color: "zinc" },
} as const;

export const PRIORITY = {
  low: { label: "Low", color: "slate" },
  medium: { label: "Medium", color: "sky" },
  high: { label: "High", color: "amber" },
  urgent: { label: "Urgent", color: "rose" },
} as const;

export const TASK_KIND = {
  general: "General",
  technical: "Technical",
  bug: "Bug",
  design: "Design",
  marketing: "Marketing",
  sales: "Sales",
} as const;

export const PROJECT_STATUS = {
  planning: { label: "Planning", color: "slate" },
  active: { label: "Active", color: "blue" },
  review: { label: "Review", color: "violet" },
  completed: { label: "Completed", color: "emerald" },
  paused: { label: "Paused", color: "amber" },
  cancelled: { label: "Cancelled", color: "zinc" },
} as const;

export const MEETING_STATUS = {
  scheduled: { label: "Scheduled", color: "blue" },
  completed: { label: "Completed", color: "emerald" },
  cancelled: { label: "Cancelled", color: "zinc" },
  no_show: { label: "No show", color: "rose" },
} as const;

export const PROPOSAL_STATUS = {
  draft: { label: "Draft", color: "slate" },
  sent: { label: "Sent", color: "blue" },
  viewed: { label: "Viewed", color: "violet" },
  accepted: { label: "Accepted", color: "emerald" },
  rejected: { label: "Rejected", color: "rose" },
  expired: { label: "Expired", color: "zinc" },
} as const;

export const COMMISSION_STATUS = {
  estimated: { label: "Estimated", color: "sky" },
  approved: { label: "Approved", color: "violet" },
  paid: { label: "Paid", color: "emerald" },
  void: { label: "Void", color: "zinc" },
} as const;

export const RULE_STATUS = {
  pending: { label: "Pending approval", color: "amber" },
  approved: { label: "Approved", color: "emerald" },
  retired: { label: "Retired", color: "zinc" },
} as const;

export const CAMPAIGN_STATUS = {
  draft: { label: "Draft", color: "slate" },
  active: { label: "Active", color: "emerald" },
  paused: { label: "Paused", color: "amber" },
  completed: { label: "Completed", color: "zinc" },
} as const;

export const CAMPAIGN_CHANNEL = {
  email: "Email",
  social: "Social",
  ads: "Paid ads",
  seo: "SEO",
  content: "Content",
  events: "Events",
  referral: "Referral",
  outreach: "Outreach",
  other: "Other",
} as const;

export const PUBLISH_STATUS = {
  draft: { label: "Draft", color: "slate" },
  published: { label: "Published", color: "emerald" },
  archived: { label: "Archived", color: "zinc" },
} as const;

export const TARGET_METRIC = {
  leads_created: "Leads created",
  leads_qualified: "Leads qualified",
  meetings_booked: "Meetings booked",
  proposals_sent: "Proposals sent",
  deals_won: "Deals won",
  revenue_won: "Revenue won",
  tasks_completed: "Tasks completed",
} as const;

export function options<T extends Record<string, string | { label: string }>>(map: T) {
  return Object.entries(map).map(([value, v]) => ({ value, label: typeof v === "string" ? v : v.label }));
}
