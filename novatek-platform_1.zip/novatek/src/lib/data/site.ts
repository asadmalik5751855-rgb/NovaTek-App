import "server-only";
import { cache } from "react";
import { createClient } from "@supabase/supabase-js";
import { isSupabaseConfigured, publicEnv } from "@/lib/env";

export type SiteEntry = {
  id: string; kind: "portfolio" | "case_study"; slug: string; title: string; client_name: string | null; summary: string;
  challenge: string | null; solution: string | null; results: string | null; image_url: string | null; project_url: string | null;
  industry: string | null; service: string | null;
};

/**
 * Published entries only, read as an anonymous visitor (no cookies → the pages stay cacheable; refreshed every
 * 5 minutes and immediately when an editor saves). Drafts are never visible here.
 */
export const getPublishedEntries = cache(async (): Promise<SiteEntry[]> => {
  if (!isSupabaseConfigured()) return [];
  try {
    const supabase = createClient(publicEnv.supabaseUrl, publicEnv.supabaseAnonKey, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: { fetch: (u, i) => fetch(u, { ...i, next: { revalidate: 300 } } as RequestInit) },
    });
    const { data, error } = await supabase
      .from("site_entries")
      .select("id, kind, slug, title, client_name, client_permission, summary, challenge, solution, results, image_url, project_url, industries(name), services(name)")
      .eq("status", "published")
      .order("position")
      .order("published_at", { ascending: false });
    if (error) throw error;
    type Row = Omit<SiteEntry, "industry" | "service"> & { client_permission: boolean; industries: { name: string } | null; services: { name: string } | null };
    return ((data ?? []) as unknown as Row[]).map((r) => ({
      ...r,
      client_name: r.client_permission ? r.client_name : null,
      industry: r.industries?.name ?? null,
      service: r.services?.name ?? null,
    }));
  } catch (e) {
    console.error("[site entries]", e);
    return [];
  }
});
