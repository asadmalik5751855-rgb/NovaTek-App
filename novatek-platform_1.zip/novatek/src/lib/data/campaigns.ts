import "server-only";
import { createClient } from "@/lib/supabase/server";

export type CampaignStats = { leads: number; qualified: number; won: number; revenue: { currency: string; amount: number }[] };

/** Per-campaign results from real attributed leads (RLS applies: counts include only leads the viewer may see). */
export async function campaignStats(ids: string[]): Promise<Map<string, CampaignStats>> {
  const out = new Map<string, CampaignStats>(ids.map((id) => [id, { leads: 0, qualified: 0, won: 0, revenue: [] }]));
  if (!ids.length) return out;
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("campaign_leads")
    .select("campaign_id, leads(id, max_funnel_rank, lead_statuses(is_won), deals(value, currency, won_at))")
    .in("campaign_id", ids)
    .limit(20000);
  if (error) throw error;
  type Row = { campaign_id: string; leads: { id: string; max_funnel_rank: number; lead_statuses: { is_won: boolean } | null; deals: { value: number; currency: string; won_at: string | null }[] } | null };
  for (const r of (data ?? []) as unknown as Row[]) {
    const s = out.get(r.campaign_id);
    if (!s || !r.leads) continue;
    s.leads += 1;
    if (r.leads.max_funnel_rank >= 1) s.qualified += 1;
    if (r.leads.lead_statuses?.is_won) s.won += 1;
    for (const d of r.leads.deals ?? []) if (d.won_at) s.revenue.push({ currency: d.currency, amount: Number(d.value) });
  }
  return out;
}
