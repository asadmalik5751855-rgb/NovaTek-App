import "server-only";
import type { PermissionCheck } from "@/lib/auth/permissions";
import { getBreakdown, getSummary, pct, rates, type Breakdown } from "@/lib/data/analytics";
import { getPeopleMap } from "@/lib/data/lookups";
import { employeePerformance } from "@/lib/data/performance";
import { createClient } from "@/lib/supabase/server";
import { formatDate } from "@/lib/utils";

export type ReportSection = { title: string; headers: string[]; rows: (string | number | null)[][] };

export const REPORTS: Record<string, { title: string; audience: string; description: string; check: PermissionCheck }> = {
  executive: { title: "Executive summary", audience: "CEO", description: "Leads, conversion, revenue, forecast, services and markets.", check: "reports.view" },
  operations: { title: "Team performance", audience: "COO", description: "Per-person activity, results and overdue work.", check: { anyOf: ["portal.coo", "portal.ceo", "employees.view"] } },
  marketing: { title: "Marketing performance", audience: "CMO", description: "Lead sources, campaigns, industries and countries.", check: "reports.view" },
  technology: { title: "Delivery report", audience: "CTO", description: "Projects, progress, deadlines and technical workload.", check: { anyOf: ["portal.cto", "projects.view"] } },
  sales: { title: "Sales report", audience: "Sales Manager", description: "Deals won and lost, by owner, with values.", check: { anyOf: ["sales.manage", "portal.ceo"] } },
};

const money = (items: { currency: string; amount: number }[]) => items.map((m) => `${m.currency} ${Math.round(m.amount).toLocaleString("en-US")}`).join(" + ") || "0";
const bd = (title: string, rows: Breakdown[], label: string): ReportSection => ({
  title, headers: [label, "Leads", "Qualified", "Won", "Conversion %", "Revenue"],
  rows: rows.map((r) => [r.label, r.leads, r.qualified, r.won, pct(r.won, r.leads), money(r.revenue)]),
});

export async function buildReport(kind: string, from: Date, to: Date): Promise<ReportSection[]> {
  if (kind === "executive") {
    const [s, service, country] = await Promise.all([getSummary(from, to), getBreakdown("service", from, to), getBreakdown("country", from, to)]);
    const r = rates(s);
    return [
      { title: "Headline metrics", headers: ["Metric", "Value"], rows: [
        ["Leads created", s.leads], ["Qualified", s.qualified], ["Qualified rate %", r.qualifiedRate], ["Contact rate %", r.contactRate],
        ["Response rate %", r.responseRate], ["Meeting rate %", r.meetingRate], ["Proposal rate %", r.proposalRate],
        ["Deals won", s.deals_won], ["Deals lost", s.deals_lost], ["Win rate %", r.winRate], ["Revenue won", money(s.revenue)],
        ["Average deal value", s.revenue.map((x) => `${x.currency} ${Math.round(x.average).toLocaleString("en-US")}`).join(" + ") || "—"],
        ["Open pipeline", money(s.forecast.map((f) => ({ currency: f.currency, amount: f.pipeline })))],
        ["Forecast (pipeline × probability, not revenue)", money(s.forecast.map((f) => ({ currency: f.currency, amount: f.forecast })))],
        ["Average sales cycle (days)", s.avg_sales_cycle_days], ["Active clients", s.active_clients], ["Active projects", s.active_projects], ["Employees", s.employees],
      ] },
      bd("By service", service, "Service"),
      bd("By country", country, "Country"),
    ];
  }
  if (kind === "operations") {
    const perf = await employeePerformance(from, to);
    return [{
      title: "Per person",
      headers: ["Person", "Designation", "Leads owned", "Leads created", "Qualified", "Contacts logged", "Meetings", "Proposals sent", "Deals won", "Revenue", "Tasks completed", "Overdue follow-ups (now)"],
      rows: perf.map((p) => [p.full_name, p.designation, p.leads_assigned, p.leads_created, p.leads_qualified, p.contacts_logged, p.meetings_booked, p.proposals_sent, p.deals_won, money(p.revenue), p.tasks_completed, p.overdue_followups]),
    }];
  }
  if (kind === "marketing") {
    const supabase = await createClient();
    const [source, campaign, industry, country, { data: camps }] = await Promise.all([
      getBreakdown("source", from, to), getBreakdown("campaign", from, to), getBreakdown("industry", from, to), getBreakdown("country", from, to),
      supabase.from("campaigns").select("name, utm_campaign, channel, status, spend, currency"),
    ]);
    const leadsByUtm = new Map(campaign.map((c) => [c.key, c.leads]));
    return [
      bd("Lead sources", source, "Source"), bd("Campaigns (attributed in period)", campaign, "Campaign"),
      { title: "Campaign cost", headers: ["Campaign", "utm_campaign", "Channel", "Status", "Spend", "Leads in period", "Cost per lead"],
        rows: (camps ?? []).map((c) => { const n = leadsByUtm.get(c.utm_campaign) ?? 0; return [c.name, c.utm_campaign, c.channel, c.status, `${c.currency} ${c.spend}`, n, n && Number(c.spend) > 0 ? `${c.currency} ${(Number(c.spend) / n).toFixed(2)}` : null]; }) },
      bd("Industries", industry, "Industry"), bd("Countries", country, "Country"),
    ];
  }
  if (kind === "technology") {
    const supabase = await createClient();
    const people = await getPeopleMap();
    const [{ data: projects }, { data: tasks }] = await Promise.all([
      supabase.from("projects").select("name, status, progress, start_date, deadline, manager_id, clients(company_name)").is("archived_at", null).order("deadline", { ascending: true, nullsFirst: false }),
      supabase.from("tasks").select("assignee_id, status, kind, completed_at, due_at").in("kind", ["technical", "bug", "design"]),
    ]);
    const per = new Map<string, { open: number; done: number; bugs: number; overdue: number }>();
    const now = new Date();
    for (const t of tasks ?? []) {
      const k = t.assignee_id ?? "unassigned";
      const c = per.get(k) ?? { open: 0, done: 0, bugs: 0, overdue: 0 };
      if (["completed", "cancelled"].includes(t.status)) { if (t.completed_at && new Date(t.completed_at) >= from && new Date(t.completed_at) < to) c.done++; }
      else { c.open++; if (t.kind === "bug") c.bugs++; if (t.due_at && new Date(t.due_at) < now) c.overdue++; }
      per.set(k, c);
    }
    return [
      { title: "Projects", headers: ["Project", "Client", "Status", "Progress %", "Start", "Deadline", "Manager"],
        rows: ((projects ?? []) as unknown as { name: string; status: string; progress: number; start_date: string | null; deadline: string | null; manager_id: string | null; clients: { company_name: string } | null }[])
          .map((p) => [p.name, p.clients?.company_name ?? "Internal", p.status, p.progress, p.start_date ? formatDate(p.start_date) : null, p.deadline ? formatDate(p.deadline) : null, p.manager_id ? people.get(p.manager_id) ?? null : null]) },
      { title: "Technical workload", headers: ["Person", "Open tasks", "Open bugs", "Overdue", "Completed in period"],
        rows: [...per.entries()].map(([k, v]) => [k === "unassigned" ? "Unassigned" : people.get(k) ?? "—", v.open, v.bugs, v.overdue, v.done]) },
    ];
  }
  if (kind === "sales") {
    const supabase = await createClient();
    const people = await getPeopleMap();
    const [owners, { data: won }, { data: lost }] = await Promise.all([
      getBreakdown("owner", from, to),
      supabase.from("deals").select("name, value, currency, owner_id, won_at, clients(company_name)").gte("won_at", from.toISOString()).lt("won_at", to.toISOString()).order("won_at"),
      supabase.from("deals").select("name, value, currency, owner_id, lost_at, lost_reason").gte("lost_at", from.toISOString()).lt("lost_at", to.toISOString()).order("lost_at"),
    ]);
    return [
      bd("By lead owner (leads created in period)", owners, "Owner"),
      { title: "Deals won", headers: ["Deal", "Client", "Value", "Currency", "Owner", "Won on"],
        rows: ((won ?? []) as unknown as { name: string; value: number; currency: string; owner_id: string | null; won_at: string; clients: { company_name: string } | null }[])
          .map((d) => [d.name, d.clients?.company_name ?? null, Number(d.value), d.currency, d.owner_id ? people.get(d.owner_id) ?? null : null, formatDate(d.won_at)]) },
      { title: "Deals lost", headers: ["Deal", "Value", "Currency", "Owner", "Lost on", "Reason"],
        rows: (lost ?? []).map((d) => [d.name, Number(d.value), d.currency, d.owner_id ? people.get(d.owner_id) ?? null : null, formatDate(d.lost_at), d.lost_reason]) },
    ];
  }
  return [];
}
