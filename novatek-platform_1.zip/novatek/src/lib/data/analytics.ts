import "server-only";
import { createClient } from "@/lib/supabase/server";
import { APP_TIMEZONE, dayKey } from "@/lib/utils";

export type Money = { currency: string; amount: number };
export type Summary = {
  leads: number; qualified: number; contacted: number; replied: number; meetings: number; proposals: number; won_leads: number; closed_leads: number;
  deals_won: number; deals_lost: number; revenue: (Money & { count: number; average: number })[]; forecast: { currency: string; pipeline: number; forecast: number }[];
  avg_sales_cycle_days: number | null; active_clients: number; active_projects: number; open_tasks: number; overdue_tasks: number;
  meetings_scheduled: number; proposals_open: number; employees: number;
};
export type Breakdown = { key: string; label: string; leads: number; qualified: number; won: number; revenue: Money[] };
export type SeriesPoint = { bucket: string; leads: number; qualified: number; deals_won: number; revenue: Money[] };

export const RANGES = { today: "Today", "7d": "7 days", "30d": "30 days", "90d": "90 days", "12m": "12 months", custom: "Custom" } as const;
export type RangeKey = keyof typeof RANGES;

/** Resolves ?range= / ?from=&to= into an instant window [from, to) and a sensible bucket size. */
export function resolveRange(sp: Record<string, string | string[] | undefined>) {
  const key = (typeof sp.range === "string" && sp.range in RANGES ? sp.range : "30d") as RangeKey;
  const now = new Date();
  const startOfToday = zonedMidnight(dayKey(now));
  let from: Date; let to = new Date(startOfToday.getTime() + 864e5);
  if (key === "today") from = startOfToday;
  else if (key === "7d") from = new Date(startOfToday.getTime() - 6 * 864e5);
  else if (key === "90d") from = new Date(startOfToday.getTime() - 89 * 864e5);
  else if (key === "12m") from = new Date(startOfToday.getTime() - 364 * 864e5);
  else if (key === "custom" && typeof sp.from === "string" && typeof sp.to === "string" && /^\d{4}-\d{2}-\d{2}$/.test(sp.from) && /^\d{4}-\d{2}-\d{2}$/.test(sp.to) && sp.from <= sp.to) {
    from = zonedMidnight(sp.from);
    to = new Date(zonedMidnight(sp.to).getTime() + 864e5);
  } else from = new Date(startOfToday.getTime() - 29 * 864e5);
  const days = Math.round((to.getTime() - from.getTime()) / 864e5);
  const bucket = days <= 45 ? "day" : days <= 200 ? "week" : "month";
  const valid = key !== "custom" || (typeof sp.from === "string" && typeof sp.to === "string");
  return { key: valid ? key : ("30d" as RangeKey), from, to, days, bucket: bucket as "day" | "week" | "month",
    fromDate: dayKey(from), toDate: dayKey(new Date(to.getTime() - 1)) };
}

/** Midnight of a calendar date in the company timezone, as an instant. */
function zonedMidnight(date: string) {
  const utc = new Date(`${date}T00:00:00Z`);
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: APP_TIMEZONE, timeZoneName: "longOffset" }).formatToParts(utc);
  const off = parts.find((p) => p.type === "timeZoneName")?.value.replace("GMT", "") || "+00:00";
  const m = /([+-])(\d{2}):?(\d{2})?/.exec(off);
  const mins = m ? (m[1] === "-" ? -1 : 1) * (Number(m[2]) * 60 + Number(m[3] ?? 0)) : 0;
  return new Date(utc.getTime() - mins * 60_000);
}

const n = (v: unknown) => Number(v ?? 0);

export async function getSummary(from: Date, to: Date): Promise<Summary> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("analytics_summary", { p_from: from.toISOString(), p_to: to.toISOString() });
  if (error) throw error;
  const s = data as Summary;
  return {
    ...s,
    revenue: (s.revenue ?? []).map((r) => ({ ...r, amount: n(r.amount), average: n(r.average), count: n(r.count) })),
    forecast: (s.forecast ?? []).map((r) => ({ ...r, pipeline: n(r.pipeline), forecast: n(r.forecast) })),
    avg_sales_cycle_days: s.avg_sales_cycle_days === null ? null : n(s.avg_sales_cycle_days),
  };
}

export async function getBreakdown(dim: "source" | "industry" | "country" | "service" | "owner" | "campaign", from: Date, to: Date): Promise<Breakdown[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("analytics_breakdown", { p_dim: dim, p_from: from.toISOString(), p_to: to.toISOString() });
  if (error) throw error;
  return ((data ?? []) as Breakdown[]).map((r) => ({ ...r, leads: n(r.leads), qualified: n(r.qualified), won: n(r.won), revenue: (r.revenue ?? []).map((x) => ({ currency: x.currency, amount: n(x.amount) })) }));
}

export async function getSeries(from: Date, to: Date, bucket: "day" | "week" | "month"): Promise<SeriesPoint[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("analytics_timeseries", { p_from: from.toISOString(), p_to: to.toISOString(), p_bucket: bucket, p_tz: APP_TIMEZONE });
  if (error) throw error;
  return ((data ?? []) as SeriesPoint[]).map((r) => ({ ...r, leads: n(r.leads), qualified: n(r.qualified), deals_won: n(r.deals_won), revenue: (r.revenue ?? []).map((x) => ({ currency: x.currency, amount: n(x.amount) })) }));
}

export const pct = (a: number, b: number) => (b > 0 ? Math.round((a / b) * 1000) / 10 : null);

/** Conversion rates over the cohort of leads created in the window. */
export function rates(s: Summary) {
  return {
    qualifiedRate: pct(s.qualified, s.leads),
    contactRate: pct(s.contacted, s.leads),
    responseRate: pct(s.replied, s.contacted),
    meetingRate: pct(s.meetings, s.leads),
    proposalRate: pct(s.proposals, s.leads),
    winRate: pct(s.deals_won, s.deals_won + s.deals_lost),
    leadToWin: pct(s.won_leads, s.leads),
  };
}
