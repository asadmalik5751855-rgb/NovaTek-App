import "server-only";
import { createClient } from "@/lib/supabase/server";

export type PerformanceRow = {
  user_id: string; full_name: string; designation: string | null; leads_assigned: number; leads_created: number; leads_qualified: number;
  contacts_logged: number; meetings_booked: number; proposals_sent: number; deals_won: number; revenue: { currency: string; amount: number }[];
  tasks_completed: number; overdue_followups: number;
};

/** Real per-person metrics for a period, computed in the database through the viewer's RLS. */
export async function employeePerformance(from: Date, to: Date): Promise<PerformanceRow[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("employee_performance", { p_from: from.toISOString(), p_to: to.toISOString() });
  if (error) throw error;
  return ((data ?? []) as PerformanceRow[]).map((r) => ({
    ...r,
    leads_assigned: Number(r.leads_assigned), leads_created: Number(r.leads_created), leads_qualified: Number(r.leads_qualified),
    contacts_logged: Number(r.contacts_logged), meetings_booked: Number(r.meetings_booked), proposals_sent: Number(r.proposals_sent),
    deals_won: Number(r.deals_won), tasks_completed: Number(r.tasks_completed), overdue_followups: Number(r.overdue_followups),
  }));
}

export type Target = {
  id: string; user_id: string; metric: string; period_start: string; period_end: string; target_value: number; currency: string | null;
  notes: string | null; actual: number | null;
};

export async function targetsWithProgress(userId?: string): Promise<Target[]> {
  const supabase = await createClient();
  let q = supabase.from("employee_targets").select("id, user_id, metric, period_start, period_end, target_value, currency, notes").order("period_end", { ascending: false }).limit(200);
  if (userId) q = q.eq("user_id", userId);
  const { data, error } = await q;
  if (error) throw error;
  const rows = data ?? [];
  const actuals = await Promise.all(rows.map((t) => supabase.rpc("target_actual", { p_target: t.id })));
  return rows.map((t, i) => ({ ...t, target_value: Number(t.target_value), actual: actuals[i].data === null ? null : Number(actuals[i].data) }));
}
