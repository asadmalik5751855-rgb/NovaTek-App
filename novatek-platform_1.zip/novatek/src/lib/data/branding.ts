import "server-only";
import { createClient } from "@supabase/supabase-js";
import { brand } from "@/lib/config/brand";
import { isSupabaseConfigured, publicEnv } from "@/lib/env";

export type PublicBranding = {
  tagline: string; email: string; phone: string; whatsapp: string; whatsappLink: string; address: string; footerNote: string;
  social: { label: string; href: string }[];
};

/**
 * Public branding TEXT from Settings (cached 5 minutes), falling back to the built-in defaults.
 * The logo and the company name are never read from here — they are locked files/constants.
 */
export async function getPublicBranding(): Promise<PublicBranding> {
  let b: Record<string, unknown> = {};
  if (isSupabaseConfigured()) {
    try {
      const client = createClient(publicEnv.supabaseUrl, publicEnv.supabaseAnonKey, {
        auth: { persistSession: false, autoRefreshToken: false },
        global: { fetch: (u, i) => fetch(u, { ...i, next: { revalidate: 300 } } as RequestInit) },
      });
      const { data } = await client.rpc("public_branding");
      b = (data as Record<string, unknown>) ?? {};
    } catch {
      b = {};
    }
  }
  const s = (k: string) => (typeof b[k] === "string" ? (b[k] as string) : "");
  const whatsapp = s("whatsapp") || brand.contact.whatsapp;
  const social = (b.social ?? {}) as Record<string, string>;
  return {
    tagline: s("tagline") || brand.tagline,
    email: s("contact_email") || brand.contact.email,
    phone: s("contact_phone"),
    whatsapp,
    whatsappLink: `https://wa.me/${whatsapp.replace(/\D/g, "")}`,
    address: s("address"),
    footerNote: s("footer_note"),
    social: (["linkedin", "facebook", "instagram", "x"] as const)
      .filter((k) => typeof social[k] === "string" && social[k].startsWith("https://"))
      .map((k) => ({ label: { linkedin: "LinkedIn", facebook: "Facebook", instagram: "Instagram", x: "X" }[k], href: social[k] })),
  };
}
