import "server-only";
import { cache } from "react";
import { createClient } from "@/lib/supabase/server";

export type DealStage = {
  id: string; key: string; name: string; position: number; default_probability: number; color: string;
  is_won: boolean; is_lost: boolean;
};
export type Person = { id: string; full_name: string; designation: string | null; department_id: string | null };
export type Named = { id: string; name: string };

/** Everything here is read with the user's session — RLS decides what comes back. */
export const getDealStages = cache(async () => {
  const supabase = await createClient();
  const { data, error } = await supabase.from("deal_stages").select("id, key, name, position, default_probability, color, is_won, is_lost")
    .eq("active", true).order("position");
  if (error) throw error;
  return (data ?? []) as DealStage[];
});

export const getPeople = cache(async () => {
  const supabase = await createClient();
  const { data, error } = await supabase.from("directory").select("id, full_name, designation, department_id").eq("status", "active").order("full_name");
  if (error) throw error;
  return (data ?? []) as Person[];
});

export const getPeopleMap = cache(async () => new Map((await getPeople()).map((p) => [p.id, p.full_name || "Unnamed user"])));

export const getDepartments = cache(async () => {
  const supabase = await createClient();
  const { data, error } = await supabase.from("departments").select("id, name").order("name");
  if (error) throw error;
  return (data ?? []) as Named[];
});

export const getServices = cache(async () => {
  const supabase = await createClient();
  const { data, error } = await supabase.from("services").select("id, key, name").eq("active", true).order("position");
  if (error) throw error;
  return (data ?? []) as (Named & { key: string })[];
});

export const getClientOptions = cache(async () => {
  const supabase = await createClient();
  const { data, error } = await supabase.from("clients").select("id, company_name").is("archived_at", null).order("company_name").limit(1000);
  if (error) throw error;
  return (data ?? []).map((c) => ({ id: c.id as string, name: c.company_name as string }));
});

export const getProjectOptions = cache(async () => {
  const supabase = await createClient();
  const { data, error } = await supabase.from("projects").select("id, name").is("archived_at", null)
    .not("status", "in", "(completed,cancelled)").order("name").limit(1000);
  if (error) throw error;
  return (data ?? []) as Named[];
});

export const getRoles = cache(async () => {
  const supabase = await createClient();
  const { data, error } = await supabase.from("roles").select("id, key, name, description, is_superuser, is_system").order("name");
  if (error) throw error;
  return (data ?? []) as { id: string; key: string; name: string; description: string | null; is_superuser: boolean; is_system: boolean }[];
});

export async function getSetting<T>(key: string, fallback: T): Promise<T> {
  const supabase = await createClient();
  const { data } = await supabase.from("settings").select("value").eq("key", key).maybeSingle();
  return (data?.value as T) ?? fallback;
}

export const opts = (rows: { id: string; name?: string; full_name?: string }[]) =>
  rows.map((r) => ({ value: r.id, label: r.name ?? r.full_name ?? "—" }));
