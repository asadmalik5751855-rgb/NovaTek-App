import "server-only";
import { createClient } from "@supabase/supabase-js";
import { publicEnv } from "@/lib/env";
import { serverEnv } from "@/lib/env.server";

/**
 * Service-role client — BYPASSES RLS. Server-only.
 * Allowed uses (each must be preceded by its own authorization check):
 *  - public lead intake (submit_public_lead, after validation + abuse checks)
 *  - admin user provisioning via the Auth admin API (after requirePermission('users.manage_roles'))
 *  - audit events for verified actors (login/logout)
 */
export function createAdminClient() {
  if (!serverEnv.supabaseServiceRoleKey) {
    throw new Error("SUPABASE_SERVICE_ROLE_KEY is not configured");
  }
  return createClient(publicEnv.supabaseUrl, serverEnv.supabaseServiceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
