import "server-only";
import { cache } from "react";
import { redirect } from "next/navigation";
import { connection } from "next/server";
import { isSupabaseConfigured } from "@/lib/env";
import { createClient } from "@/lib/supabase/server";
import { allows, isPermission, type Permission, type PermissionCheck } from "./permissions";

export type SessionProfile = {
  id: string;
  email: string;
  full_name: string;
  avatar_url: string | null;
  designation: string | null;
  status: "active" | "disabled";
  department: string | null;
};

export type Session = {
  userId: string;
  profile: SessionProfile;
  permissions: ReadonlySet<Permission>;
  roles: { key: string; name: string }[];
  can: (check: PermissionCheck) => boolean;
};

type SessionState = { kind: "anonymous" } | { kind: "disabled"; email: string } | { kind: "active"; session: Session };

/**
 * Loads the verified user, profile, roles and effective permissions once per request.
 * Permissions come from the database (my_permissions), the same source RLS uses.
 */
export const getSessionState = cache(async (): Promise<SessionState> => {
  // Session-dependent pages must never be prerendered, whatever the build-time configuration.
  await connection();
  if (!isSupabaseConfigured()) return { kind: "anonymous" };
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { kind: "anonymous" };

  const [profileRes, permsRes, rolesRes] = await Promise.all([
    supabase
      .from("profiles")
      .select("id, email, full_name, avatar_url, designation, status, departments(name)")
      .eq("id", user.id)
      .maybeSingle(),
    supabase.rpc("my_permissions"),
    supabase.from("user_roles").select("roles(key, name)").eq("user_id", user.id),
  ]);

  const p = profileRes.data as
    | (Omit<SessionProfile, "department"> & { departments: { name: string } | null })
    | null;
  if (!p) return { kind: "anonymous" };
  if (p.status !== "active") return { kind: "disabled", email: p.email };

  const permissions = new Set<Permission>(
    ((permsRes.data as string[] | null) ?? []).filter(isPermission),
  );
  const roles = ((rolesRes.data as unknown as { roles: { key: string; name: string } | null }[] | null) ?? [])
    .map((r) => r.roles)
    .filter((r): r is { key: string; name: string } => Boolean(r));

  const session: Session = {
    userId: user.id,
    profile: { ...p, department: p.departments?.name ?? null },
    permissions,
    roles,
    can: (check) => allows(permissions, check),
  };
  return { kind: "active", session };
});

export async function getSession(): Promise<Session | null> {
  const s = await getSessionState();
  return s.kind === "active" ? s.session : null;
}

/** For pages: redirect to login when not signed in or disabled. */
export async function requireUser(): Promise<Session> {
  const s = await getSessionState();
  if (s.kind === "active") return s.session;
  redirect(s.kind === "disabled" ? "/login?error=disabled" : "/login");
}

/** For pages: require a permission or show the access-denied page. */
export async function requirePermission(check: PermissionCheck): Promise<Session> {
  const session = await requireUser();
  if (!session.can(check)) redirect("/app/denied");
  return session;
}

export class AuthorizationError extends Error {
  constructor(public readonly code: "unauthenticated" | "forbidden") {
    super(code);
  }
}

/** For server actions: throw instead of redirecting so the action can return a typed error. */
export async function authorize(check?: PermissionCheck): Promise<Session> {
  const session = await getSession();
  if (!session) throw new AuthorizationError("unauthenticated");
  if (check && !session.can(check)) throw new AuthorizationError("forbidden");
  return session;
}
