import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { serverEnv } from "@/lib/env.server";
import { createClient } from "@supabase/supabase-js";
import { publicEnv } from "@/lib/env";

/**
 * Re-authentication for sensitive actions (exports, security settings, permission changes).
 * Verifies the password against Supabase Auth with a throwaway, non-persisting client — the user's
 * own session cookies are untouched.
 */
export async function confirmPassword(email: string, password: string): Promise<boolean> {
  if (!email || !password || password.length > 200) return false;
  const client = createClient(publicEnv.supabaseUrl, publicEnv.supabaseAnonKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
  const { data, error } = await client.auth.signInWithPassword({ email, password });
  if (error || !data.session) return false;
  // Revoke the extra session immediately.
  await client.auth.signOut({ scope: "local" }).catch(() => undefined);
  return true;
}


const COOKIE = "nt_reauth";
const sign = (payload: string) => createHmac("sha256", `reauth:${serverEnv.leadIpHashSalt || serverEnv.supabaseServiceRoleKey}`).update(payload).digest("hex");

/** After a successful password confirmation: remember it for this user in a signed, httpOnly cookie. */
export async function markReauthenticated(userId: string) {
  const payload = `${userId}.${Date.now()}`;
  (await cookies()).set(COOKIE, `${payload}.${sign(payload)}`, {
    httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", path: "/app", maxAge: 60 * 120,
  });
}

/** True if this user confirmed their password within the configured window. */
export async function recentlyReauthenticated(userId: string, minutes: number) {
  const raw = (await cookies()).get(COOKIE)?.value ?? "";
  const parts = raw.split(".");
  if (parts.length !== 3) return false;
  const [uid, ts, sig] = parts;
  const expected = sign(`${uid}.${ts}`);
  if (sig.length !== expected.length || !timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
  return uid === userId && Date.now() - Number(ts) < minutes * 60_000;
}
