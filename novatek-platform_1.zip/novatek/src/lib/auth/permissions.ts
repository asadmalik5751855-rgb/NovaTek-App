/** Permission keys (must match public.permissions). Checks are always on permissions, never role names. */
export const PERMISSIONS = [
  "leads.view_own",
  "leads.view_all",
  "leads.create",
  "leads.edit",
  "leads.assign",
  "leads.delete",
  "leads.merge",
  "leads.export",
  "crm.configure",
  "campaigns.view",
  "campaigns.manage",
  "employees.view",
  "employees.manage",
  "users.manage_roles",
  "sales.view",
  "sales.manage",
  "projects.view",
  "projects.manage",
  "reports.view",
  "settings.manage",
  "audit.view",
  "portal.ceo",
  "portal.coo",
  "portal.cto",
  "portal.cmo",
  "leads.import",
  "commissions.manage",
  "targets.manage",
  "tasks.assign",
  "site.manage",
  "ai.use",
] as const;

export type Permission = (typeof PERMISSIONS)[number];

export function isPermission(v: string): v is Permission {
  return (PERMISSIONS as readonly string[]).includes(v);
}

export type PermissionCheck = Permission | { anyOf: Permission[] };

export function allows(perms: ReadonlySet<string>, check: PermissionCheck) {
  return typeof check === "string" ? perms.has(check) : check.anyOf.some((p) => perms.has(p));
}

export const canViewLeads = { anyOf: ["leads.view_all", "leads.view_own"] } satisfies PermissionCheck;
export const canViewSales = { anyOf: ["sales.view", "sales.manage"] } satisfies PermissionCheck;
export const canViewClients = { anyOf: ["sales.view", "sales.manage", "projects.view"] } satisfies PermissionCheck;
export const canViewCampaigns = { anyOf: ["campaigns.view", "campaigns.manage"] } satisfies PermissionCheck;
export const canViewPeople = { anyOf: ["employees.view", "users.manage_roles", "reports.view"] } satisfies PermissionCheck;
export const canConfigure = { anyOf: ["crm.configure", "settings.manage"] } satisfies PermissionCheck;
