"use client";

import { useEffect, useState, useTransition } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CheckCircle2, Loader2 } from "lucide-react";
import { Alert, Button, Field, Input, Select, Textarea } from "@/components/ui/primitives";
import { BUDGET_RANGES } from "@/lib/leads/types";
import { publicLeadSchema, type PublicLeadInput } from "@/lib/validation/public-lead";
import { submitEnquiry } from "@/app/(public)/contact/actions";

const UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"] as const;

export function EnquiryForm({
  services,
  countries,
  defaultService,
  landingPage,
  submitLabel,
}: {
  services: { key: string; name: string }[];
  countries: { code: string; name: string }[];
  defaultService?: string;
  /** Slug of the published landing page this form is embedded in (for attribution). */
  landingPage?: string;
  submitLabel?: string;
}) {
  const [pending, start] = useTransition();
  const [serverError, setServerError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const {
    register,
    handleSubmit,
    setValue,
    setError,
    formState: { errors },
  } = useForm<PublicLeadInput>({
    resolver: zodResolver(publicLeadSchema),
    defaultValues: { service: defaultService ?? "", country: "", budget: "", company_website: "", started_at: 0, landing_page: landingPage ?? "" },
  });

  // Capture timing + attribution on the client; the server re-validates everything.
  useEffect(() => {
    setValue("started_at", Date.now());
    const params = new URLSearchParams(window.location.search);
    for (const k of UTM_KEYS) setValue(k, params.get(k)?.slice(0, 200) ?? "");
    setValue("page_path", window.location.pathname);
  }, [setValue]);

  const onSubmit = handleSubmit((values) => {
    setServerError(null);
    start(async () => {
      const r = await submitEnquiry(values);
      if (r.ok) {
        setSent(true);
        return;
      }
      setServerError(r.error);
      for (const [k, v] of Object.entries(r.fieldErrors ?? {})) if (v?.[0]) setError(k as keyof PublicLeadInput, { message: v[0] });
    });
  });

  if (sent) {
    return (
      <div role="status" className="py-10 text-center">
        <CheckCircle2 className="mx-auto size-10 text-success" />
        <h2 className="mt-4 text-xl font-semibold">Enquiry received</h2>
        <p className="mx-auto mt-2 max-w-sm text-text-2">Thank you. Your details reached our team and someone will be in touch with you soon.</p>
      </div>
    );
  }

  const e = (k: keyof PublicLeadInput) => errors[k]?.message as string | undefined;
  const a = (k: keyof PublicLeadInput) => ({ "aria-invalid": Boolean(errors[k]) || undefined, "aria-describedby": errors[k] ? `${k}-error` : undefined });

  return (
    <form onSubmit={onSubmit} noValidate className="grid gap-5 sm:grid-cols-2">
      {serverError && <div className="sm:col-span-2"><Alert tone="error">{serverError}</Alert></div>}

      <Field label="Your name" htmlFor="name" error={e("name")} required>
        <Input id="name" autoComplete="name" {...register("name")} {...a("name")} />
      </Field>
      <Field label="Company or organisation" htmlFor="company" error={e("company")} required>
        <Input id="company" autoComplete="organization" {...register("company")} {...a("company")} />
      </Field>
      <Field label="Email" htmlFor="email" error={e("email")} required>
        <Input id="email" type="email" autoComplete="email" {...register("email")} {...a("email")} />
      </Field>
      <Field label="Phone or WhatsApp" htmlFor="phone" error={e("phone")}>
        <Input id="phone" type="tel" autoComplete="tel" {...register("phone")} {...a("phone")} />
      </Field>
      <Field label="Country" htmlFor="country" error={e("country")}>
        <Select id="country" autoComplete="country" {...register("country")}>
          <option value="">Select…</option>
          {countries.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
        </Select>
      </Field>
      <Field label="Service" htmlFor="service" error={e("service")}>
        <Select id="service" {...register("service")}>
          <option value="">Not sure yet</option>
          {services.map((s) => <option key={s.key} value={s.key}>{s.name}</option>)}
        </Select>
      </Field>
      <Field label="Budget" htmlFor="budget" error={e("budget")}>
        <Select id="budget" {...register("budget")}>
          <option value="">Prefer not to say</option>
          {BUDGET_RANGES.map((b) => <option key={b.value} value={b.value}>{b.label}</option>)}
        </Select>
      </Field>
      <Field label="Current website" htmlFor="website" error={e("website")} hint="If you have one">
        <Input id="website" inputMode="url" placeholder="yourcompany.com" {...register("website")} />
      </Field>
      <Field label="What do you want to build?" htmlFor="message" error={e("message")} required className="sm:col-span-2">
        <Textarea id="message" rows={5} placeholder="The problem you're solving, what you have today, and any deadline." {...register("message")} {...a("message")} />
      </Field>

      {/* Honeypot: hidden from people and assistive tech; bots tend to fill it. */}
      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label htmlFor="company_website">Leave this empty</label>
        <input id="company_website" tabIndex={-1} autoComplete="off" {...register("company_website")} />
      </div>

      <div className="sm:col-span-2">
        <label className="flex gap-3 text-sm text-text-2">
          <input type="checkbox" className="mt-0.5 size-4 accent-[var(--accent)]" {...register("consent")} {...a("consent")} />
          NovaTek may contact me by email, phone or WhatsApp about this enquiry.
        </label>
        {e("consent") && <p id="consent-error" className="mt-1 text-xs text-danger">{e("consent")}</p>}
      </div>

      <div className="sm:col-span-2">
        <Button type="submit" variant="brand" size="lg" disabled={pending} className="w-full sm:w-auto">
          {pending && <Loader2 className="size-4 animate-spin" />}
          {pending ? "Sending…" : submitLabel ?? "Send enquiry"}
        </Button>
      </div>
    </form>
  );
}
