import * as React from "react";
import { Badge, Card } from "@/components/ui/primitives";
import { cn, formatMoney } from "@/lib/utils";

type LabelMap = Record<string, { label: string; color: string }>;

export function MapBadge({ map, value }: { map: LabelMap; value: string | null | undefined }) {
  if (!value) return null;
  const v = map[value];
  return <Badge color={v?.color ?? "slate"}>{v?.label ?? value.replace(/_/g, " ")}</Badge>;
}

/** Sums amounts per currency and renders "USD 1,200 + PKR 50,000" — never converts currencies. */
export function MoneyList({ items, empty = "—", className }: { items: { currency: string; amount: number | string }[]; empty?: string; className?: string }) {
  const by = new Map<string, number>();
  for (const i of items) by.set(i.currency, (by.get(i.currency) ?? 0) + Number(i.amount));
  const parts = [...by.entries()].filter(([, v]) => v !== 0).sort((a, b) => b[1] - a[1]);
  if (!parts.length) return <span className={className}>{empty}</span>;
  return (
    <span className={cn("tabular-nums", className)}>
      {parts.map(([c, v], i) => (
        <span key={c}>
          {i > 0 && <span className="text-text-3"> + </span>}
          {formatMoney(v, c)}
        </span>
      ))}
    </span>
  );
}

export function StatCard({
  label, value, hint, icon, tone, href,
}: { label: string; value: React.ReactNode; hint?: React.ReactNode; icon?: React.ReactNode; tone?: "danger" | "success"; href?: string }) {
  const body = (
    <Card className={cn("h-full p-4", href && "transition-colors hover:border-border-strong")}>
      <div className="flex items-center justify-between gap-2 text-text-3">
        <span className="text-xs font-medium uppercase tracking-wide">{label}</span>
        {icon}
      </div>
      <p className={cn("mt-3 text-2xl font-semibold tabular-nums", tone === "danger" && "text-danger", tone === "success" && "text-success")}>{value}</p>
      {hint && <p className="mt-1 text-xs text-text-3">{hint}</p>}
    </Card>
  );
  return href ? <a href={href} className="block">{body}</a> : body;
}

export function DescRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-3 gap-3 py-2 text-sm">
      <dt className="text-text-3">{label}</dt>
      <dd className="col-span-2 break-words text-text">{children === null || children === undefined || children === "" ? "—" : children}</dd>
    </div>
  );
}

export function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-text-3">{children}</h2>;
}

export function Progress({ value, className }: { value: number; className?: string }) {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div className={cn("h-1.5 overflow-hidden rounded-full bg-surface-2", className)} role="progressbar" aria-valuenow={v} aria-valuemin={0} aria-valuemax={100}>
      <div className="brand-gradient h-full rounded-full" style={{ width: `${v}%` }} />
    </div>
  );
}
