"use client";

import * as React from "react";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Alert, Button, Input, Textarea } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";

type Result = { ok: true; data?: unknown } | { ok: false; error: string };

type Props = {
  action: (input?: string) => Promise<Result>;
  children: React.ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger" | "brand";
  size?: "sm" | "md" | "lg";
  /** Ask for confirmation first (sensitive or irreversible actions). */
  confirm?: string;
  /** Ask for a value first (reason, evidence, password, payment reference). */
  prompt?: { label: string; placeholder?: string; minLength?: number; multiline?: boolean; type?: "text" | "password"; hint?: string };
  confirmLabel?: string;
  /** Where to go on success. "{key}" placeholders are filled from the action's result, e.g. "/app/clients/{client_id}". */
  redirectTo?: string;
  successMessage?: string;
  className?: string;
  disabled?: boolean;
};

/** A button that runs a server action with optional confirmation/prompt, shows real errors, and refreshes on success. */
export function ActionButton({
  action, children, variant = "secondary", size = "md", confirm, prompt, confirmLabel, redirectTo, successMessage, className, disabled,
}: Props) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const needsPanel = Boolean(confirm || prompt);

  const run = () => {
    setError(null);
    setDone(null);
    if (prompt?.minLength && value.trim().length < prompt.minLength) {
      setError(`${prompt.label} must be at least ${prompt.minLength} characters.`);
      return;
    }
    start(async () => {
      const r = await action(prompt ? value : undefined);
      if (!r.ok) {
        setError(r.error);
        return;
      }
      setOpen(false);
      setValue("");
      if (redirectTo) {
        const data = (r.data ?? {}) as Record<string, unknown>;
        router.push(redirectTo.replace(/\{(\w+)\}/g, (_, k: string) => encodeURIComponent(String(data[k] ?? ""))));
      } else if (successMessage) {
        setDone(successMessage);
      }
      router.refresh();
    });
  };

  if (open) {
    return (
      <div className={cn("w-full space-y-2 rounded-lg border border-border bg-surface-2/50 p-3", className)}>
        {confirm && <p className="text-sm text-text-2">{confirm}</p>}
        {prompt && (
          <label className="block space-y-1.5">
            <span className="text-sm font-medium">{prompt.label}</span>
            {prompt.multiline ? (
              <Textarea value={value} onChange={(e) => setValue(e.target.value)} placeholder={prompt.placeholder} autoFocus />
            ) : (
              <Input
                type={prompt.type ?? "text"}
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder={prompt.placeholder}
                autoFocus
                autoComplete={prompt.type === "password" ? "current-password" : "off"}
              />
            )}
            {prompt.hint && <span className="block text-xs text-text-3">{prompt.hint}</span>}
          </label>
        )}
        {error && <Alert tone="error">{error}</Alert>}
        <div className="flex gap-2">
          <Button size="sm" variant={variant === "danger" ? "danger" : "brand"} onClick={run} disabled={pending}>
            {pending && <Loader2 className="size-3.5 animate-spin" />} {confirmLabel ?? "Confirm"}
          </Button>
          <Button size="sm" variant="ghost" onClick={() => { setOpen(false); setError(null); }} disabled={pending}>
            Cancel
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("space-y-2", className)}>
      <Button variant={variant} size={size} disabled={disabled || pending} onClick={() => (needsPanel ? setOpen(true) : run())} className="w-full sm:w-auto">
        {pending && <Loader2 className="size-4 animate-spin" />} {children}
      </Button>
      {error && <Alert tone="error">{error}</Alert>}
      {done && <Alert tone="success">{done}</Alert>}
    </div>
  );
}
