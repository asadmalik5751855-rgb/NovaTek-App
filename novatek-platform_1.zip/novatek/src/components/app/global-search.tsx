"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Building2, CalendarCheck2, FolderKanban, Handshake, ListChecks, Loader2, Search, Target, UserRound, type LucideIcon } from "lucide-react";
import { searchAll, type SearchHit } from "@/app/app/search/actions";
import { cn } from "@/lib/utils";

const KIND: Record<string, { label: string; icon: LucideIcon }> = {
  lead: { label: "Lead", icon: Target },
  client: { label: "Client", icon: Building2 },
  deal: { label: "Deal", icon: Handshake },
  project: { label: "Project", icon: FolderKanban },
  task: { label: "Task", icon: ListChecks },
  person: { label: "Person", icon: UserRound },
  meeting: { label: "Meeting", icon: CalendarCheck2 },
};

export function GlobalSearch() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const [pending, start] = useTransition();
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        input.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (q.trim().length < 2) return;
    const t = setTimeout(() => start(async () => { setHits(await searchAll(q)); setActive(0); }), 220);
    return () => clearTimeout(t);
  }, [q]);

  const shown = q.trim().length < 2 ? [] : hits;
  const go = (h: SearchHit) => {
    setOpen(false);
    setQ("");
    router.push(h.href);
  };

  return (
    <div className="relative w-full max-w-md">
      <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-text-3" />
      <input
        ref={input}
        value={q}
        onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        onBlur={() => setTimeout(() => setOpen(false), 150)}
        onKeyDown={(e) => {
          if (e.key === "ArrowDown") { e.preventDefault(); setActive((a) => Math.min(a + 1, shown.length - 1)); }
          if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
          if (e.key === "Enter" && shown[active]) go(shown[active]);
          if (e.key === "Escape") input.current?.blur();
        }}
        placeholder="Search leads, clients, deals, projects, people…"
        aria-label="Search everything"
        role="combobox"
        aria-expanded={open && shown.length > 0}
        aria-controls="global-search-results"
        className="h-9 w-full rounded-lg border border-border bg-surface pl-9 pr-14 text-sm placeholder:text-text-3 focus:border-accent focus:outline-none focus:ring-2 focus:ring-[var(--ring)]"
      />
      <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[11px] text-text-3">
        {pending ? <Loader2 className="size-3.5 animate-spin" /> : "Ctrl K"}
      </span>
      {open && q.trim().length >= 2 && (
        <ul
          id="global-search-results"
          role="listbox"
          className="absolute inset-x-0 top-11 z-50 max-h-96 overflow-y-auto rounded-xl border border-border bg-surface p-1 shadow-card"
        >
          {shown.length === 0 ? (
            <li className="px-3 py-3 text-sm text-text-3">{pending ? "Searching…" : "No results you have access to."}</li>
          ) : (
            shown.map((h, i) => {
              const k = KIND[h.kind] ?? KIND.lead;
              return (
                <li key={`${h.kind}-${h.id}`} role="option" aria-selected={i === active}>
                  <button
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => go(h)}
                    onMouseEnter={() => setActive(i)}
                    className={cn("flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left", i === active && "bg-surface-2")}
                  >
                    <k.icon className="size-4 shrink-0 text-text-3" />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm">{h.title}</span>
                      {h.subtitle && <span className="block truncate text-xs text-text-3">{h.subtitle}</span>}
                    </span>
                    <span className="text-[11px] text-text-3">{k.label}</span>
                  </button>
                </li>
              );
            })
          )}
        </ul>
      )}
    </div>
  );
}
