import {
  allows,
  canConfigure,
  canViewCampaigns,
  canViewClients,
  canViewLeads,
  canViewPeople,
  canViewSales,
  type PermissionCheck,
} from "@/lib/auth/permissions";

export type NavIcon =
  | "dashboard" | "leads" | "pipeline" | "bell" | "users" | "shield" | "deals" | "clients" | "commission" | "tasks"
  | "projects" | "meetings" | "campaigns" | "landing" | "site" | "people" | "target" | "analytics" | "reports"
  | "settings" | "plug" | "roles" | "import" | "ceo" | "coo" | "cto" | "cmo" | "search";

export type NavItem = { href: string; label: string; icon: NavIcon; check?: PermissionCheck; mobile?: boolean };
export type NavGroup = { label: string; items: NavItem[] };

/** Only shipped, working sections appear here — no placeholder links. */
export const NAV: NavGroup[] = [
  {
    label: "Overview",
    items: [
      { href: "/app", label: "Dashboard", icon: "dashboard", mobile: true },
      { href: "/app/portals/ceo", label: "CEO portal", icon: "ceo", check: "portal.ceo" },
      { href: "/app/portals/coo", label: "COO portal", icon: "coo", check: "portal.coo" },
      { href: "/app/portals/cto", label: "CTO portal", icon: "cto", check: "portal.cto" },
      { href: "/app/portals/cmo", label: "CMO portal", icon: "cmo", check: "portal.cmo" },
      { href: "/app/analytics", label: "Analytics", icon: "analytics", check: "reports.view" },
      { href: "/app/reports", label: "Reports", icon: "reports", check: "reports.view" },
    ],
  },
  {
    label: "Sales",
    items: [
      { href: "/app/leads", label: "Leads", icon: "leads", check: canViewLeads, mobile: true },
      { href: "/app/pipeline", label: "Lead pipeline", icon: "pipeline", check: canViewLeads },
      { href: "/app/deals", label: "Deals", icon: "deals", check: canViewSales },
      { href: "/app/clients", label: "Clients", icon: "clients", check: canViewClients },
      { href: "/app/commissions", label: "Commissions", icon: "commission" },
    ],
  },
  {
    label: "Work",
    items: [
      { href: "/app/tasks", label: "Tasks", icon: "tasks", mobile: true },
      { href: "/app/meetings", label: "Meetings", icon: "meetings" },
      { href: "/app/projects", label: "Projects", icon: "projects" },
    ],
  },
  {
    label: "Marketing",
    items: [
      { href: "/app/campaigns", label: "Campaigns", icon: "campaigns", check: canViewCampaigns },
      { href: "/app/landing-pages", label: "Landing pages", icon: "landing", check: canViewCampaigns },
      { href: "/app/site", label: "Website content", icon: "site", check: "site.manage" },
    ],
  },
  {
    label: "Team",
    items: [
      { href: "/app/people", label: "People", icon: "people", check: canViewPeople },
      { href: "/app/targets", label: "Targets", icon: "target" },
      { href: "/app/notifications", label: "Notifications", icon: "bell", mobile: true },
    ],
  },
  {
    label: "Administration",
    items: [
      { href: "/app/admin/users", label: "Users", icon: "users", check: { anyOf: ["employees.view", "users.manage_roles"] } },
      { href: "/app/admin/roles", label: "Roles & permissions", icon: "roles", check: { anyOf: ["users.manage_roles", "settings.manage"] } },
      { href: "/app/settings", label: "Settings", icon: "settings", check: canConfigure },
      { href: "/app/settings/integrations", label: "Integrations", icon: "plug", check: "settings.manage" },
      { href: "/app/admin/audit", label: "Audit log", icon: "shield", check: "audit.view" },
    ],
  },
];

export function navFor(perms: ReadonlySet<string>): NavGroup[] {
  return NAV.map((g) => ({ ...g, items: g.items.filter((i) => !i.check || allows(perms, i.check)) })).filter((g) => g.items.length);
}

/** Back-compat: flat list. */
export const NAV_ITEMS: NavItem[] = NAV.flatMap((g) => g.items);
