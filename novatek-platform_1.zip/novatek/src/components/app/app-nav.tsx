"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3, Bell, Building2, CalendarDays, Cog, Crown, Cpu, FileBarChart, FolderKanban, Globe,
  Handshake, KanbanSquare, LayoutDashboard, ListChecks, Megaphone, Menu, PanelsTopLeft, Plug, Search, ShieldCheck,
  Target, TrendingUp, Upload, UserCog, Users, UsersRound, Wallet, Workflow, X, type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { NavGroup, NavIcon } from "./nav";

const ICONS: Record<NavIcon, LucideIcon> = {
  dashboard: LayoutDashboard, leads: Target, pipeline: KanbanSquare, bell: Bell, users: Users, shield: ShieldCheck,
  deals: Handshake, clients: Building2, commission: Wallet, tasks: ListChecks, projects: FolderKanban, meetings: CalendarDays,
  campaigns: Megaphone, landing: PanelsTopLeft, site: Globe, people: UsersRound, target: TrendingUp, analytics: BarChart3,
  reports: FileBarChart, settings: Cog, plug: Plug, roles: UserCog, import: Upload, ceo: Crown, coo: Workflow, cto: Cpu,
  cmo: Megaphone, search: Search,
};

function isActive(pathname: string, href: string) {
  if (href === "/app") return pathname === "/app";
  if (href === "/app/settings") return pathname === "/app/settings" || (pathname.startsWith("/app/settings/") && !pathname.startsWith("/app/settings/integrations"));
  return pathname === href || pathname.startsWith(href + "/");
}

function NavLink({ href, label, icon, unread, onClick }: { href: string; label: string; icon: NavIcon; unread: number; onClick?: () => void }) {
  const pathname = usePathname();
  const Icon = ICONS[icon];
  const active = isActive(pathname, href);
  return (
    <Link
      href={href}
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={cn(
        "group flex items-center gap-3 rounded-lg px-3 py-1.5 text-sm transition-colors",
        active ? "bg-surface-2 font-medium text-text" : "text-text-2 hover:bg-surface-2/60 hover:text-text",
      )}
    >
      <Icon className={cn("size-4 shrink-0", active ? "text-accent" : "text-text-3 group-hover:text-text-2")} />
      <span className="flex-1 truncate">{label}</span>
      {icon === "bell" && unread > 0 && (
        <span className="rounded-full bg-accent px-1.5 text-[10px] font-semibold leading-4 text-white">{unread > 99 ? "99+" : unread}</span>
      )}
    </Link>
  );
}

export function SidebarNav({ groups, unread, onNavigate }: { groups: NavGroup[]; unread: number; onNavigate?: () => void }) {
  return (
    <nav className="space-y-5" aria-label="Main">
      {groups.map((g) => (
        <div key={g.label}>
          <p className="mb-1 px-3 text-[11px] font-medium uppercase tracking-wider text-text-3">{g.label}</p>
          <div className="space-y-0.5">
            {g.items.map((i) => (
              <NavLink key={i.href} {...i} unread={unread} onClick={onNavigate} />
            ))}
          </div>
        </div>
      ))}
    </nav>
  );
}

export function MobileNav({ groups, unread }: { groups: NavGroup[]; unread: number }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const mobile = groups.flatMap((g) => g.items).filter((i) => i.mobile).slice(0, 4);

  return (
    <>
      {open && (
        <div className="fixed inset-0 z-50 flex flex-col bg-bg lg:hidden" role="dialog" aria-modal="true" aria-label="All sections">
          <div className="flex h-14 items-center justify-between border-b border-border px-4">
            <span className="text-sm font-semibold">All sections</span>
            <button type="button" onClick={() => setOpen(false)} className="grid size-9 place-items-center rounded-lg hover:bg-surface-2" aria-label="Close menu">
              <X className="size-5" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-3 py-4">
            <SidebarNav groups={groups} unread={unread} onNavigate={() => setOpen(false)} />
          </div>
        </div>
      )}
      <nav
        aria-label="Quick"
        className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden"
      >
        <ul className="grid" style={{ gridTemplateColumns: `repeat(${mobile.length + 1}, minmax(0, 1fr))` }}>
          {mobile.map((item) => {
            const Icon = ICONS[item.icon];
            const active = isActive(pathname, item.href);
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  onClick={() => setOpen(false)}
                  aria-current={active ? "page" : undefined}
                  className={cn("relative flex flex-col items-center gap-1 py-2.5 text-[11px]", active ? "text-text" : "text-text-3")}
                >
                  <Icon className={cn("size-5", active && "text-accent")} />
                  {item.label}
                  {item.icon === "bell" && unread > 0 && (
                    <span className="absolute right-1/2 top-1.5 size-2 translate-x-4 rounded-full bg-accent" aria-label={`${unread} unread`} />
                  )}
                </Link>
              </li>
            );
          })}
          <li>
            <button type="button" onClick={() => setOpen(true)} className="flex w-full flex-col items-center gap-1 py-2.5 text-[11px] text-text-3">
              <Menu className="size-5" /> More
            </button>
          </li>
        </ul>
      </nav>
    </>
  );
}
