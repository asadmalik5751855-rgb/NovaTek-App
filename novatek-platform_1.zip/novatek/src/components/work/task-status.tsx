"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { TASK_STATUS } from "@/lib/labels";
import { cn } from "@/lib/utils";
import { setTaskStatus } from "@/app/app/tasks/actions";

/** Inline status changer for list rows and the task page. */
export function TaskStatusSelect({ id, value, compact }: { id: string; value: string; compact?: boolean }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  return (
    <span className="inline-flex flex-col">
      <select
        aria-label="Task status"
        defaultValue={value}
        disabled={pending}
        onChange={(e) => {
          const v = e.target.value;
          setError(null);
          start(async () => {
            const r = await setTaskStatus(id, v);
            if (!r.ok) setError(r.error);
            router.refresh();
          });
        }}
        className={cn("rounded-md border border-border bg-surface text-text-2", compact ? "h-7 px-1.5 text-xs" : "h-10 px-3 text-sm")}
      >
        {Object.entries(TASK_STATUS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
      </select>
      {error && <span className="mt-1 text-xs text-danger" role="alert">{error}</span>}
    </span>
  );
}
