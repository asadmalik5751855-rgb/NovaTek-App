"use client";

import { Form, FormSection, SelectField, TextAreaField, TextField, type Option } from "@/components/forms/form";
import { PRIORITY, PROJECT_STATUS, options } from "@/lib/labels";
import { CURRENCIES } from "@/lib/validation/common";
import { projectSchema } from "@/lib/validation/work";
import { addProjectMember, createProject, updateProject } from "@/app/app/projects/actions";
import { z } from "zod";

export function ProjectForm({ projectId, defaults, clients, services, people, departments, canManageAll }: {
  projectId?: string; defaults: Record<string, unknown>; clients: Option[]; services: Option[]; people: Option[]; departments: Option[]; canManageAll: boolean;
}) {
  return (
    <Form
      schema={projectSchema}
      action={projectId ? updateProject.bind(null, projectId) : createProject}
      defaultValues={defaults}
      submitLabel={projectId ? "Save project" : "Create project"}
      redirectTo={(data) => `/app/projects/${projectId ?? (data as { id: string }).id}`}
    >
      <FormSection title="Project">
        <TextField name="name" label="Project name" required className="sm:col-span-2" />
        <SelectField name="client_id" label="Client" options={clients} placeholder="—" />
        <SelectField name="service_id" label="Service" options={services} placeholder="—" />
        <TextAreaField name="description" label="Description" rows={3} className="sm:col-span-2" />
      </FormSection>
      <FormSection title="Delivery" columns={3}>
        <SelectField name="status" label="Status" options={options(PROJECT_STATUS)} />
        <SelectField name="priority" label="Priority" options={options(PRIORITY)} />
        <SelectField name="department_id" label="Department" options={departments} placeholder="—" />
        <TextField name="start_date" label="Start date" type="date" />
        <TextField name="deadline" label="Deadline" type="date" />
        {canManageAll && <SelectField name="manager_id" label="Project manager" options={people} placeholder="—" />}
      </FormSection>
      {canManageAll && (
        <FormSection title="Budget">
          <TextField name="budget" label="Budget" inputMode="decimal" />
          <SelectField name="currency" label="Currency" options={CURRENCIES.map((c) => ({ value: c, label: c }))} />
        </FormSection>
      )}
    </Form>
  );
}

const memberSchema = z.object({ user_id: z.uuid("Choose a person"), role: z.string().trim().min(1, "Role is required").max(60) });

export function AddMemberForm({ projectId, people }: { projectId: string; people: Option[] }) {
  return (
    <Form schema={memberSchema} action={addProjectMember.bind(null, projectId)} defaultValues={{ user_id: "", role: "Member" }} submitLabel="Add member" successMessage="Member added." resetOnSuccess>
      <div className="grid gap-3 sm:grid-cols-2">
        <SelectField name="user_id" label="Person" options={people} placeholder="Choose…" />
        <TextField name="role" label="Role on project" placeholder="e.g. Frontend, QA, Designer" />
      </div>
    </Form>
  );
}
