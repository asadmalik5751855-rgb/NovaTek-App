"use client";

import { DateTimeField, Form, FormSection, SelectField, TextAreaField, TextField, type Option } from "@/components/forms/form";
import { PRIORITY, TASK_KIND, TASK_STATUS, options } from "@/lib/labels";
import { taskSchema } from "@/lib/validation/work";
import { createTask, updateTask } from "@/app/app/tasks/actions";

export function TaskForm({ taskId, defaults, people, departments, projects, canAssign, links }: {
  taskId?: string;
  defaults: Record<string, unknown>;
  people: Option[];
  departments: Option[];
  projects: Option[];
  canAssign: boolean;
  links: { lead?: string; client?: string };
}) {
  return (
    <Form
      schema={taskSchema}
      action={taskId ? updateTask.bind(null, taskId) : createTask}
      defaultValues={defaults}
      submitLabel={taskId ? "Save task" : "Create task"}
      redirectTo={(data) => `/app/tasks/${taskId ?? (data as { id: string }).id}`}
    >
      <FormSection title="Task">
        <TextField name="title" label="Title" required className="sm:col-span-2" />
        <TextAreaField name="description" label="Description" rows={4} className="sm:col-span-2" />
        <SelectField name="kind" label="Type" options={options(TASK_KIND)} />
        <SelectField name="priority" label="Priority" options={options(PRIORITY)} />
        <DateTimeField name="due_at" label="Due" />
        <SelectField name="status" label="Status" options={options(TASK_STATUS)} />
      </FormSection>
      <FormSection title="Ownership & links">
        {canAssign ? (
          <SelectField name="assignee_id" label="Assignee" options={people} placeholder="Me" />
        ) : (
          <p className="text-sm text-text-3 sm:col-span-2">This task will be assigned to you.</p>
        )}
        <SelectField name="department_id" label="Department" options={departments} placeholder="—" />
        <SelectField name="project_id" label="Project" options={projects} placeholder="—" />
        {links.lead && <p className="text-sm text-text-3">Linked to lead: <span className="text-text">{links.lead}</span></p>}
        {links.client && <p className="text-sm text-text-3">Linked to client: <span className="text-text">{links.client}</span></p>}
      </FormSection>
    </Form>
  );
}
