"use client";

import { useFormContext } from "react-hook-form";
import { DateTimeField, Form, FormSection, SelectField, TextAreaField, TextField, type Option } from "@/components/forms/form";
import { meetingSchema } from "@/lib/validation/work";
import { createMeeting } from "@/app/app/meetings/actions";

function Participants({ people }: { people: Option[] }) {
  const { register } = useFormContext();
  return (
    <fieldset className="sm:col-span-2">
      <legend className="mb-2 text-sm font-medium">NovaTek participants</legend>
      {people.length === 0 ? <p className="text-sm text-text-3">No colleagues available.</p> : (
        <div className="grid max-h-56 gap-1.5 overflow-y-auto rounded-lg border border-border p-2 sm:grid-cols-2">
          {people.map((p) => (
            <label key={p.value} className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1 text-sm hover:bg-surface-2/60">
              <input type="checkbox" value={p.value} className="size-4 accent-[var(--accent)]" {...register("participant_ids")} />
              {p.label}
            </label>
          ))}
        </div>
      )}
      <p className="mt-1 text-xs text-text-3">They are notified and get a reminder an hour before.</p>
    </fieldset>
  );
}

export function MeetingForm({ defaults, people, links }: {
  defaults: Record<string, unknown>; people: Option[]; links: { label: string; value: string }[];
}) {
  return (
    <Form schema={meetingSchema} action={createMeeting} defaultValues={defaults} submitLabel="Schedule meeting" redirectTo={(d) => `/app/meetings/${(d as { id: string }).id}`}>
      <FormSection title="Meeting">
        <TextField name="title" label="Title" required className="sm:col-span-2" />
        <DateTimeField name="starts_at" label="Date & time" required hint="In your local time" />
        <SelectField name="duration_minutes" label="Duration" options={[15, 30, 45, 60, 90, 120].map((m) => ({ value: String(m), label: `${m} minutes` }))} />
        <TextField name="meeting_link" label="Meeting link" placeholder="https://meet.google.com/…" />
        <TextField name="location" label="Location" placeholder="Office, client site…" />
        <TextField name="external_attendees" label="Client attendees" placeholder="Names / roles" className="sm:col-span-2" />
        {links.length > 0 && (
          <p className="text-sm text-text-3 sm:col-span-2">Linked to: {links.map((l) => <span key={l.label} className="mr-3 text-text">{l.label}: {l.value}</span>)}</p>
        )}
      </FormSection>
      <FormSection title="People" columns={1}>
        <Participants people={people} />
      </FormSection>
      <FormSection title="Agenda" columns={1}>
        <TextAreaField name="notes" label="Agenda / notes" rows={4} />
      </FormSection>
    </Form>
  );
}
