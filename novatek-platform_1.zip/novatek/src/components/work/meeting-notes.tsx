"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Alert, Button, Textarea } from "@/components/ui/primitives";
import { updateMeetingNotes } from "@/app/app/meetings/actions";

export function MeetingNotes({ id, notes, canEdit }: { id: string; notes: string; canEdit: boolean }) {
  const router = useRouter();
  const [value, setValue] = useState(notes);
  const [pending, start] = useTransition();
  const [msg, setMsg] = useState<{ tone: "error" | "success"; text: string } | null>(null);
  if (!canEdit) return <p className="whitespace-pre-wrap text-sm">{notes || <span className="text-text-3">No notes.</span>}</p>;
  return (
    <div className="space-y-2">
      <Textarea aria-label="Meeting notes" value={value} onChange={(e) => setValue(e.target.value)} rows={8} maxLength={10000} />
      {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
      <Button
        size="sm"
        variant="secondary"
        disabled={pending || value === notes}
        onClick={() => start(async () => {
          const r = await updateMeetingNotes(id, { notes: value });
          setMsg(r.ok ? { tone: "success", text: "Notes saved." } : { tone: "error", text: r.error });
          if (r.ok) router.refresh();
        })}
      >
        {pending && <Loader2 className="size-3.5 animate-spin" />} Save notes
      </Button>
    </div>
  );
}
