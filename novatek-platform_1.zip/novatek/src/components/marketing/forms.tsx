"use client";

import { CheckboxField, Form, FormSection, SelectField, TextAreaField, TextField, type Option } from "@/components/forms/form";
import { CAMPAIGN_CHANNEL, CAMPAIGN_STATUS, PUBLISH_STATUS, options } from "@/lib/labels";
import { CURRENCIES } from "@/lib/validation/common";
import { campaignSchema, landingPageSchema, siteEntrySchema } from "@/lib/validation/marketing";
import { createCampaign, saveLandingPage, saveSiteEntry, updateCampaign } from "@/app/app/campaigns/actions";

export function CampaignForm({ id, defaults, industries, countries, services, people }: {
  id?: string; defaults: Record<string, unknown>; industries: Option[]; countries: Option[]; services: Option[]; people: Option[];
}) {
  return (
    <Form schema={campaignSchema} action={id ? updateCampaign.bind(null, id) : createCampaign} defaultValues={defaults}
      submitLabel={id ? "Save campaign" : "Create campaign"} redirectTo={(d) => `/app/campaigns/${id ?? (d as { id: string }).id}`}>
      <FormSection title="Campaign">
        <TextField name="name" label="Name" required />
        <TextField name="utm_campaign" label="utm_campaign value" required hint="Leads arriving with this utm_campaign are attributed automatically" />
        <SelectField name="channel" label="Channel" options={options(CAMPAIGN_CHANNEL)} />
        <SelectField name="status" label="Status" options={options(CAMPAIGN_STATUS)} />
        <TextAreaField name="description" label="Description" rows={3} className="sm:col-span-2" />
      </FormSection>
      <FormSection title="Targeting" columns={3}>
        <SelectField name="target_industry_id" label="Target industry" options={industries} placeholder="Any" />
        <SelectField name="target_country_code" label="Target country" options={countries} placeholder="Any" />
        <SelectField name="service_id" label="Service promoted" options={services} placeholder="—" />
      </FormSection>
      <FormSection title="Budget & dates" columns={3}>
        <TextField name="budget" label="Budget" inputMode="decimal" />
        <TextField name="spend" label="Actual spend to date" inputMode="decimal" hint="Used for cost per lead" />
        <SelectField name="currency" label="Currency" options={CURRENCIES.map((c) => ({ value: c, label: c }))} />
        <TextField name="start_date" label="Start" type="date" />
        <TextField name="end_date" label="End" type="date" />
        <SelectField name="owner_id" label="Owner" options={people} placeholder="Me" />
      </FormSection>
    </Form>
  );
}

export function LandingPageForm({ id, defaults, campaigns, services }: { id?: string; defaults: Record<string, unknown>; campaigns: Option[]; services: Option[] }) {
  return (
    <Form schema={landingPageSchema} action={saveLandingPage.bind(null, id ?? null)} defaultValues={defaults}
      submitLabel={id ? "Save page" : "Create page"} redirectTo={(d) => `/app/landing-pages/${(d as { id: string }).id}`}>
      <FormSection title="Page">
        <TextField name="slug" label="URL slug" required hint="Public at /l/your-slug" />
        <SelectField name="status" label="Status" options={options(PUBLISH_STATUS)} />
        <SelectField name="campaign_id" label="Campaign" options={campaigns} placeholder="None" hint="Leads from this page are attributed to it" />
        <SelectField name="service_id" label="Service" options={services} placeholder="—" hint="Pre-selected on the lead" />
      </FormSection>
      <FormSection title="Content" columns={1}>
        <TextField name="headline" label="Headline" required />
        <TextAreaField name="subheadline" label="Subheadline" rows={2} />
        <TextField name="hero_image_url" label="Hero image URL" placeholder="https://…" hint="Optional. Use an image you own." />
        <TextAreaField name="benefits" label="Benefits" rows={5} hint="One per line" />
        <TextField name="cta_label" label="Button label" required />
      </FormSection>
      <FormSection title="Social proof & FAQ" columns={1}>
        <TextAreaField name="testimonials" label="Testimonials" rows={4} hint="One per line: quote | name | role. Only real quotes from real clients." />
        <CheckboxField name="testimonials_confirmed" label="These testimonials are real and we have permission to publish them" />
        <TextAreaField name="faq" label="FAQ" rows={5} hint="One per line: question | answer" />
      </FormSection>
    </Form>
  );
}

export function SiteEntryForm({ id, defaults, industries, services }: { id?: string; defaults: Record<string, unknown>; industries: Option[]; services: Option[] }) {
  return (
    <Form schema={siteEntrySchema} action={saveSiteEntry.bind(null, id ?? null)} defaultValues={defaults}
      submitLabel={id ? "Save" : "Create"} redirectTo={(d) => `/app/site/${(d as { id: string }).id}`}>
      <FormSection title="Entry">
        <SelectField name="kind" label="Type" options={[{ value: "case_study", label: "Case study" }, { value: "portfolio", label: "Portfolio item" }]} />
        <SelectField name="status" label="Status" options={options(PUBLISH_STATUS)} />
        <TextField name="title" label="Title" required className="sm:col-span-2" />
        <TextField name="slug" label="URL slug" required />
        <TextField name="position" label="Order" inputMode="numeric" hint="Lower numbers appear first" />
        <SelectField name="industry_id" label="Industry" options={industries} placeholder="—" />
        <SelectField name="service_id" label="Service" options={services} placeholder="—" />
      </FormSection>
      <FormSection title="Client">
        <TextField name="client_name" label="Client name" hint="Leave empty to keep the client anonymous" />
        <CheckboxField name="client_permission" label="The client has given written permission to be named" />
      </FormSection>
      <FormSection title="Story" columns={1}>
        <TextAreaField name="summary" label="Summary" rows={2} required />
        <TextAreaField name="challenge" label="Challenge" rows={3} />
        <TextAreaField name="solution" label="What we built" rows={4} />
        <TextAreaField name="results" label="Results" rows={3} hint="Only measured, verifiable results" />
        <TextField name="image_url" label="Image URL" placeholder="https://…" />
        <TextField name="project_url" label="Live project URL" placeholder="https://…" />
      </FormSection>
    </Form>
  );
}
