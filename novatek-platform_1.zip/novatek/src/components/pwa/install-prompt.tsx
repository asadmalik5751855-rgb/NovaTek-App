"use client";

import { useEffect, useState } from "react";
import { Download, X } from "lucide-react";

type BeforeInstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };

/** Offers "Install app" when the browser says the platform is installable. Dismissal is remembered. */
export function InstallPrompt() {
  const [evt, setEvt] = useState<BeforeInstallPromptEvent | null>(null);
  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      try { if (localStorage.getItem("nt-install-dismissed")) return; } catch { /* storage unavailable */ }
      setEvt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);
  if (!evt) return null;
  return (
    <div className="fixed inset-x-3 bottom-20 z-50 flex items-center gap-3 rounded-xl border border-border bg-surface p-3 shadow-card lg:bottom-4 lg:left-auto lg:right-4 lg:w-80">
      <Download className="size-5 shrink-0 text-accent" />
      <p className="flex-1 text-sm">Install the NovaTek app for quick access on this device.</p>
      <button type="button" className="rounded-md bg-accent px-2.5 py-1 text-sm text-white" onClick={async () => { await evt.prompt(); setEvt(null); }}>Install</button>
      <button type="button" aria-label="Dismiss" className="text-text-3 hover:text-text" onClick={() => { try { localStorage.setItem("nt-install-dismissed", "1"); } catch { /* ignore */ } setEvt(null); }}><X className="size-4" /></button>
    </div>
  );
}
