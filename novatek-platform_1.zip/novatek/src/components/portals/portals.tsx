import Link from "next/link";
import { Bug, CalendarClock, Flame, FolderKanban, Handshake, Inbox, ListChecks } from "lucide-react";
import { Badge, Card, CardHeader, EmptyState } from "@/components/ui/primitives";
import { MapBadge, MoneyList, Progress, StatCard } from "@/components/ui/status";
import { BarList } from "@/components/charts/bar-list";
import { BreakdownTable, FunnelCard, LeadsTrend, RevenueTrend, SalesKpis } from "@/components/insights/blocks";
import { TargetRow } from "@/components/people/target-progress";
import { StatusBadge, TemperatureBadge } from "@/components/leads/badges";
import type { Session } from "@/lib/auth/session";
import { getBreakdown, getSeries, getSummary, pct, type resolveRange } from "@/lib/data/analytics";
import { campaignStats } from "@/lib/data/campaigns";
import { getDepartments, getPeople, getPeopleMap, getSetting } from "@/lib/data/lookups";
import { employeePerformance, targetsWithProgress } from "@/lib/data/performance";
import { getLookups } from "@/lib/leads/queries";
import type { Temperature } from "@/lib/leads/normalize";
import { CAMPAIGN_STATUS, MEETING_STATUS, PRIORITY, PROJECT_STATUS, PROPOSAL_STATUS, TASK_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { cn, dayKey, formatDate, formatDateTime, formatMoney, formatTime } from "@/lib/utils";

type Range = ReturnType<typeof resolveRange>;

// ----------------------------------------------------------------------------- CEO
export async function CeoPortal({ r }: { r: Range }) {
  const [s, series, services, countries, owners, base, perf, people, depts, targets] = await Promise.all([
    getSummary(r.from, r.to), getSeries(r.from, r.to, r.bucket), getBreakdown("service", r.from, r.to),
    getBreakdown("country", r.from, r.to), getBreakdown("owner", r.from, r.to), getSetting<string>("finance.base_currency", "USD"),
    employeePerformance(r.from, r.to), getPeople(), getDepartments(), targetsWithProgress(),
  ]);
  const deptOf = new Map(people.map((p) => [p.id, p.department_id]));
  const byDept = new Map<string, { deals: number; revenue: { currency: string; amount: number }[]; tasks: number; contacts: number }>();
  for (const p of perf) {
    const d = depts.find((x) => x.id === deptOf.get(p.user_id))?.name ?? "No department";
    const cur = byDept.get(d) ?? { deals: 0, revenue: [], tasks: 0, contacts: 0 };
    cur.deals += p.deals_won; cur.revenue.push(...p.revenue); cur.tasks += p.tasks_completed; cur.contacts += p.contacts_logged;
    byDept.set(d, cur);
  }
  const top = [...perf].sort((a, b) => b.deals_won - a.deals_won || b.leads_qualified - a.leads_qualified).filter((p) => p.deals_won || p.leads_qualified).slice(0, 5);
  const today = dayKey(new Date());
  const activeTargets = targets.filter((t) => t.period_start <= today && t.period_end >= today);
  const onTrack = activeTargets.filter((t) => (t.actual ?? 0) >= t.target_value).length;

  return (
    <div className="space-y-8">
      <SalesKpis s={s} />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Active clients" value={s.active_clients} />
        <StatCard label="Active projects" value={s.active_projects} />
        <StatCard label="Employees" value={s.employees} />
        <StatCard label="Monthly targets" value={activeTargets.length ? `${onTrack}/${activeTargets.length}` : "—"} hint={activeTargets.length ? "achieved so far" : "No active targets"} />
      </div>
      <div className="grid gap-6 xl:grid-cols-2">
        <RevenueTrend series={series} bucket={r.bucket} currency={base} />
        <LeadsTrend series={series} bucket={r.bucket} />
      </div>
      <div className="grid gap-6 xl:grid-cols-3">
        <FunnelCard s={s} />
        <Card className="xl:col-span-2">
          <CardHeader title="Department performance" description="Activity and results by department in this period" />
          {byDept.size === 0 ? <p className="px-5 py-6 text-sm text-text-3">No activity yet.</p> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border text-left text-xs uppercase tracking-wide text-text-3">
                  <tr><th className="px-4 py-2">Department</th><th className="px-4 py-2 text-right">Contacts logged</th><th className="px-4 py-2 text-right">Deals won</th><th className="px-4 py-2">Revenue</th><th className="px-4 py-2 text-right">Tasks done</th></tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {[...byDept.entries()].map(([d, v]) => (
                    <tr key={d}><td className="px-4 py-2">{d}</td><td className="px-4 py-2 text-right tabular-nums">{v.contacts}</td><td className="px-4 py-2 text-right tabular-nums">{v.deals}</td>
                      <td className="px-4 py-2"><MoneyList items={v.revenue} /></td><td className="px-4 py-2 text-right tabular-nums">{v.tasks}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>
      <div className="grid gap-6 xl:grid-cols-2">
        <BreakdownTable title="Top services" rows={services} nameLabel="Service" />
        <BreakdownTable title="Top markets" rows={countries} nameLabel="Country" />
      </div>
      <div className="grid gap-6 xl:grid-cols-3">
        <Card>
          <CardHeader title="Top performers" description="By deals won, then qualified leads" />
          <div className="p-5">
            <BarList rows={top.map((p) => ({ label: p.full_name || "—", value: p.deals_won, display: `${p.deals_won} won`, hint: `${p.leads_qualified} qualified` }))} empty="No wins or qualified leads yet" />
          </div>
        </Card>
        <div className="xl:col-span-2"><BreakdownTable title="Sales by owner" rows={owners} nameLabel="Owner" /></div>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------------- COO
export async function CooPortal({ session, r }: { session: Session; r: Range }) {
  const supabase = await createClient();
  const lookups = await getLookups();
  const closedIds = lookups.statuses.filter((s) => s.is_closed).map((s) => s.id);
  const closed = `(${closedIds.join(",") || "00000000-0000-0000-0000-000000000000"})`;
  const now = new Date();
  const end = new Date(now.getTime() + 864e5);
  const [s, perf, people, overdue, unassigned, meetings, tasksOpen, proposals, commissions] = await Promise.all([
    getSummary(r.from, r.to), employeePerformance(r.from, r.to), getPeopleMap(),
    supabase.from("leads").select("id, company_name, assigned_to, next_follow_up_at, status_id").is("archived_at", null).not("status_id", "in", closed).lt("next_follow_up_at", now.toISOString()).order("next_follow_up_at").limit(10),
    supabase.from("leads").select("id, company_name, created_at, score, temperature").is("archived_at", null).is("assigned_to", null).not("status_id", "in", closed).order("score", { ascending: false }).limit(8),
    supabase.from("meetings").select("id, title, starts_at, organizer_id, status").eq("status", "scheduled").gte("starts_at", now.toISOString()).lt("starts_at", end.toISOString()).order("starts_at").limit(10),
    supabase.from("tasks").select("assignee_id, due_at").not("status", "in", "(completed,cancelled)").limit(5000),
    supabase.from("proposals").select("id, title, status, sent_at").in("status", ["sent", "viewed"]).order("sent_at").limit(8),
    session.can("commissions.manage") ? supabase.from("commissions").select("id", { count: "exact", head: true }).eq("status", "estimated") : Promise.resolve({ count: null }),
  ]);
  const load = new Map<string, { open: number; overdue: number }>();
  for (const t of tasksOpen.data ?? []) {
    if (!t.assignee_id) continue;
    const c = load.get(t.assignee_id) ?? { open: 0, overdue: 0 };
    c.open++; if (t.due_at && new Date(t.due_at) < now) c.overdue++;
    load.set(t.assignee_id, c);
  }
  const workload = perf.map((p) => ({ ...p, tasks: load.get(p.user_id) ?? { open: 0, overdue: 0 } })).filter((p) => p.tasks.open || p.leads_assigned || p.overdue_followups)
    .sort((a, b) => b.tasks.overdue + b.overdue_followups - (a.tasks.overdue + a.overdue_followups));

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-6">
        <StatCard label="Leads" value={s.leads} hint="Created in period" />
        <StatCard label="Overdue follow-ups" value={(overdue.data ?? []).length >= 10 ? "10+" : (overdue.data ?? []).length} tone={(overdue.data ?? []).length ? "danger" : undefined} />
        <StatCard label="Unassigned" value={(unassigned.data ?? []).length >= 8 ? "8+" : (unassigned.data ?? []).length} tone={(unassigned.data ?? []).length ? "danger" : undefined} href="/app/leads?assigned=unassigned" />
        <StatCard label="Overdue tasks" value={s.overdue_tasks} tone={s.overdue_tasks ? "danger" : undefined} />
        <StatCard label="Meetings · 24h" value={(meetings.data ?? []).length} />
        <StatCard label="Pending approvals" value={(commissions.count ?? 0) + (proposals.data ?? []).length} hint={`${commissions.count ?? 0} commissions · ${(proposals.data ?? []).length} proposals awaiting client`} />
      </div>
      <div className="grid gap-6 xl:grid-cols-3">
        <Card>
          <CardHeader title="Overdue follow-ups" />
          {(overdue.data ?? []).length === 0 ? <p className="px-5 py-6 text-sm text-text-3">None overdue. </p> : (
            <ul className="divide-y divide-border">
              {(overdue.data ?? []).map((l) => (
                <li key={l.id}><Link href={`/app/leads/${l.id}`} className="block px-5 py-2.5 hover:bg-surface-2/50">
                  <span className="block truncate text-sm">{l.company_name}</span>
                  <span className="text-xs text-danger">Due {formatDateTime(l.next_follow_up_at)}</span>
                  <span className="text-xs text-text-3"> · {l.assigned_to ? people.get(l.assigned_to) ?? "—" : "Unassigned"}</span>
                </Link></li>
              ))}
            </ul>
          )}
        </Card>
        <Card>
          <CardHeader title="Unassigned leads" description="Highest score first" action={<Link href="/app/leads?assigned=unassigned" className="text-xs text-accent hover:underline">Assign</Link>} />
          {(unassigned.data ?? []).length === 0 ? <p className="px-5 py-6 text-sm text-text-3">Every open lead has an owner.</p> : (
            <ul className="divide-y divide-border">
              {(unassigned.data ?? []).map((l) => (
                <li key={l.id}><Link href={`/app/leads/${l.id}`} className="flex items-center gap-2 px-5 py-2.5 hover:bg-surface-2/50">
                  <span className="flex-1 truncate text-sm">{l.company_name}</span><TemperatureBadge temperature={l.temperature as Temperature} score={l.score} />
                </Link></li>
              ))}
            </ul>
          )}
        </Card>
        <Card>
          <CardHeader title="Next 24 hours" />
          {(meetings.data ?? []).length === 0 ? <p className="px-5 py-6 text-sm text-text-3">No meetings scheduled.</p> : (
            <ul className="divide-y divide-border">
              {(meetings.data ?? []).map((m) => (
                <li key={m.id}><Link href={`/app/meetings/${m.id}`} className="flex items-center gap-3 px-5 py-2.5 hover:bg-surface-2/50">
                  <span className="w-12 text-sm tabular-nums text-text-2">{formatTime(m.starts_at)}</span>
                  <span className="flex-1 truncate text-sm">{m.title}</span>
                  <span className="text-xs text-text-3">{m.organizer_id ? people.get(m.organizer_id) : ""}</span>
                </Link></li>
              ))}
            </ul>
          )}
        </Card>
      </div>
      <Card className="overflow-hidden">
        <CardHeader title="Team workload & activity" description="Open tasks, overdue items and sales activity in the period" />
        {workload.length === 0 ? <p className="px-5 py-6 text-sm text-text-3">No assigned work yet.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="border-b border-border text-left text-xs uppercase tracking-wide text-text-3">
                <tr><th className="px-4 py-2">Person</th><th className="px-4 py-2 text-right">Open tasks</th><th className="px-4 py-2 text-right">Overdue tasks</th><th className="px-4 py-2 text-right">Overdue follow-ups</th>
                  <th className="px-4 py-2 text-right">Leads owned</th><th className="px-4 py-2 text-right">Contacts logged</th><th className="px-4 py-2 text-right">Meetings</th><th className="px-4 py-2 text-right">Deals won</th></tr>
              </thead>
              <tbody className="divide-y divide-border">
                {workload.map((p) => (
                  <tr key={p.user_id}>
                    <td className="px-4 py-2"><Link href={`/app/people/${p.user_id}`} className="hover:text-accent">{p.full_name || "—"}</Link></td>
                    <td className="px-4 py-2 text-right tabular-nums">{p.tasks.open}</td>
                    <td className={cn("px-4 py-2 text-right tabular-nums", p.tasks.overdue && "text-danger")}>{p.tasks.overdue}</td>
                    <td className={cn("px-4 py-2 text-right tabular-nums", p.overdue_followups && "text-danger")}>{p.overdue_followups}</td>
                    <td className="px-4 py-2 text-right tabular-nums">{p.leads_assigned}</td>
                    <td className="px-4 py-2 text-right tabular-nums">{p.contacts_logged}</td>
                    <td className="px-4 py-2 text-right tabular-nums">{p.meetings_booked}</td>
                    <td className="px-4 py-2 text-right tabular-nums">{p.deals_won}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
      <div className="grid gap-6 xl:grid-cols-2">
        <FunnelCard s={s} />
        <Card>
          <CardHeader title="Proposals awaiting client" description="Sent or opened, no response yet" />
          {(proposals.data ?? []).length === 0 ? <p className="px-5 py-6 text-sm text-text-3">Nothing pending.</p> : (
            <ul className="divide-y divide-border">
              {(proposals.data ?? []).map((p) => (
                <li key={p.id}><Link href={`/app/proposals/${p.id}`} className="flex items-center gap-3 px-5 py-2.5 hover:bg-surface-2/50">
                  <span className="flex-1 truncate text-sm">{p.title}</span><span className="text-xs text-text-3">sent {formatDate(p.sent_at)}</span><MapBadge map={PROPOSAL_STATUS} value={p.status} />
                </Link></li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------------- CTO
export async function CtoPortal({ r }: { r: Range }) {
  const supabase = await createClient();
  const now = new Date();
  const [projects, tasks, people, perf] = await Promise.all([
    supabase.from("projects").select("id, name, status, progress, deadline, priority, manager_id, clients(company_name)").is("archived_at", null).in("status", ["planning", "active", "review", "paused"]).order("deadline", { ascending: true, nullsFirst: false }).limit(30),
    supabase.from("tasks").select("id, title, status, priority, kind, assignee_id, due_at, project_id").in("kind", ["technical", "bug", "design"]).not("status", "in", "(completed,cancelled)").order("due_at", { ascending: true, nullsFirst: false }).limit(1000),
    getPeopleMap(), employeePerformance(r.from, r.to),
  ]);
  const t = tasks.data ?? [];
  const bugs = t.filter((x) => x.kind === "bug");
  const overdue = t.filter((x) => x.due_at && new Date(x.due_at) < now);
  const byStatus = Object.entries(TASK_STATUS).filter(([k]) => !["completed", "cancelled"].includes(k)).map(([k, v]) => ({ label: v.label, value: t.filter((x) => x.status === k).length }));
  const load = new Map<string, number>();
  for (const x of t) if (x.assignee_id) load.set(x.assignee_id, (load.get(x.assignee_id) ?? 0) + 1);
  const done = new Map(perf.map((p) => [p.user_id, p.tasks_completed]));
  const today = new Date(dayKey(now));
  const ps = (projects.data ?? []) as unknown as { id: string; name: string; status: string; progress: number; deadline: string | null; priority: string; manager_id: string | null; clients: { company_name: string } | null }[];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <StatCard label="Active projects" value={ps.filter((p) => p.status !== "paused").length} icon={<FolderKanban className="size-4" />} />
        <StatCard label="Late projects" value={ps.filter((p) => p.deadline && new Date(p.deadline) < today).length} tone={ps.some((p) => p.deadline && new Date(p.deadline) < today) ? "danger" : undefined} />
        <StatCard label="Open technical tasks" value={t.length} />
        <StatCard label="Open bugs" value={bugs.length} icon={<Bug className="size-4" />} tone={bugs.length ? "danger" : undefined} />
        <StatCard label="Overdue" value={overdue.length} tone={overdue.length ? "danger" : undefined} />
      </div>
      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader title="Project progress" description="Progress follows task completion" />
          {ps.length === 0 ? <EmptyState icon={<FolderKanban className="size-5" />} title="No active projects" description="Projects appear here once created." /> : (
            <ul className="divide-y divide-border">
              {ps.map((p) => {
                const late = p.deadline && new Date(p.deadline) < today;
                return (
                  <li key={p.id}><Link href={`/app/projects/${p.id}`} className="block space-y-1.5 px-5 py-3 hover:bg-surface-2/50">
                    <div className="flex items-center gap-2"><span className="flex-1 truncate text-sm font-medium">{p.name}</span><MapBadge map={PROJECT_STATUS} value={p.status} /></div>
                    <Progress value={p.progress} />
                    <p className="text-xs text-text-3">{p.clients?.company_name ?? "Internal"} · {p.progress}% · <span className={cn(late && "text-danger")}>{p.deadline ? `${late ? "overdue, was due" : "due"} ${formatDate(p.deadline)}` : "no deadline"}</span> · {p.manager_id ? people.get(p.manager_id) : "no manager"}</p>
                  </Link></li>
                );
              })}
            </ul>
          )}
        </Card>
        <Card>
          <CardHeader title="Technical work by status" />
          <div className="p-5"><BarList rows={byStatus} empty="No open technical work" /></div>
        </Card>
      </div>
      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader title="Workload" description={`Open technical/design tasks · completed in period`} />
          <div className="p-5">
            <BarList rows={[...load.entries()].sort((a, b) => b[1] - a[1]).map(([u, n]) => ({ label: people.get(u) ?? "—", value: n, display: `${n} open`, hint: `${done.get(u) ?? 0} done` }))} empty="Nobody has open technical tasks" />
          </div>
        </Card>
        <Card>
          <CardHeader title="Open bugs" action={<Link href="/app/tasks/new" className="text-xs text-accent hover:underline">Log a bug</Link>} />
          {bugs.length === 0 ? <p className="px-5 py-6 text-sm text-text-3">No open bugs.</p> : (
            <ul className="divide-y divide-border">
              {bugs.slice(0, 12).map((b) => (
                <li key={b.id}><Link href={`/app/tasks/${b.id}`} className="flex items-center gap-2 px-5 py-2.5 hover:bg-surface-2/50">
                  <span className="flex-1 truncate text-sm">{b.title}</span>
                  <span className="text-xs text-text-3">{b.assignee_id ? people.get(b.assignee_id) : "Unassigned"}</span>
                  <MapBadge map={PRIORITY} value={b.priority} />
                </Link></li>
              ))}
            </ul>
          )}
        </Card>
      </div>
      <Card className="p-5 text-sm text-text-3">Deployment status and code-health metrics need a CI/hosting integration (e.g. GitHub, Vercel); none is connected, so they are not shown rather than estimated.</Card>
    </div>
  );
}

// ----------------------------------------------------------------------------- CMO
export async function CmoPortal({ r }: { r: Range }) {
  const supabase = await createClient();
  const [s, series, sources, campaignsBreak, industries, countries, campaigns, temps, pages] = await Promise.all([
    getSummary(r.from, r.to), getSeries(r.from, r.to, r.bucket), getBreakdown("source", r.from, r.to), getBreakdown("campaign", r.from, r.to),
    getBreakdown("industry", r.from, r.to), getBreakdown("country", r.from, r.to),
    supabase.from("campaigns").select("id, name, status, spend, currency, channel").in("status", ["active", "paused"]).order("created_at", { ascending: false }).limit(10),
    supabase.from("leads").select("temperature").gte("created_at", r.from.toISOString()).lt("created_at", r.to.toISOString()).is("merged_into", null).limit(10000),
    supabase.from("landing_pages").select("id", { count: "exact", head: true }).eq("status", "published"),
  ]);
  const cs = campaigns.data ?? [];
  const stats = await campaignStats(cs.map((c) => c.id));
  const tCount = (k: string) => (temps.data ?? []).filter((x) => x.temperature === k).length;
  const quality = [{ label: "Very hot", value: tCount("very_hot") }, { label: "Hot", value: tCount("hot") }, { label: "Warm", value: tCount("warm") }, { label: "Cold", value: tCount("cold") }];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <StatCard label="Leads" value={s.leads} />
        <StatCard label="Qualified rate" value={pct(s.qualified, s.leads) === null ? "—" : `${pct(s.qualified, s.leads)}%`} />
        <StatCard label="Lead → won" value={pct(s.won_leads, s.leads) === null ? "—" : `${pct(s.won_leads, s.leads)}%`} />
        <StatCard label="Active campaigns" value={cs.filter((c) => c.status === "active").length} />
        <StatCard label="Live landing pages" value={pages.count ?? 0} />
      </div>
      <div className="grid gap-6 xl:grid-cols-3">
        <div className="xl:col-span-2"><LeadsTrend series={series} bucket={r.bucket} /></div>
        <Card>
          <CardHeader title="Lead quality" description="Score temperature of leads created in the period" />
          <div className="p-5"><BarList rows={quality} max={Math.max(1, s.leads)} empty="No leads in this period" /></div>
        </Card>
      </div>
      <Card className="overflow-hidden">
        <CardHeader title="Active campaigns" description="All-time results from attributed leads; cost per lead uses recorded spend" action={<Link href="/app/campaigns" className="text-xs text-accent hover:underline">All campaigns</Link>} />
        {cs.length === 0 ? <p className="px-5 py-6 text-sm text-text-3">No active campaigns.</p> : (
          <ul className="divide-y divide-border">
            {cs.map((c) => {
              const st = stats.get(c.id)!;
              return (
                <li key={c.id}><Link href={`/app/campaigns/${c.id}`} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-5 py-3 hover:bg-surface-2/50">
                  <span className="min-w-0 flex-1 truncate text-sm font-medium">{c.name}</span>
                  <span className="text-xs text-text-3">{st.leads} leads · {st.qualified} qualified · {st.won} won</span>
                  <span className="text-xs tabular-nums">{st.leads && Number(c.spend) > 0 ? `${formatMoney(Number(c.spend) / st.leads, c.currency)} / lead` : "—"}</span>
                  <MapBadge map={CAMPAIGN_STATUS} value={c.status} />
                </Link></li>
              );
            })}
          </ul>
        )}
      </Card>
      <div className="grid gap-6 xl:grid-cols-2">
        <BreakdownTable title="Leads by source" description="Which channel produces business" rows={sources} nameLabel="Source" />
        <BreakdownTable title="Campaign attribution" rows={campaignsBreak} nameLabel="Campaign" />
        <BreakdownTable title="Industries" rows={industries} nameLabel="Industry" />
        <BreakdownTable title="Target markets" rows={countries} nameLabel="Country" />
      </div>
      <Card className="p-5 text-sm text-text-3">Website traffic appears here once Google Analytics 4 is connected in Settings → Integrations. Until then traffic is not shown rather than estimated.</Card>
    </div>
  );
}

// ----------------------------------------------------------------------------- Sales (rep / manager)
export async function SalesDashboard({ session, r }: { session: Session; r: Range }) {
  const supabase = await createClient();
  const lookups = await getLookups();
  const closed = `(${lookups.statuses.filter((s) => s.is_closed).map((s) => s.id).join(",") || "00000000-0000-0000-0000-000000000000"})`;
  const now = new Date();
  const me = session.userId;
  const [followUps, hot, deals, proposals, tasks, s, targets] = await Promise.all([
    supabase.from("leads").select("id, company_name, next_follow_up_at, status_id").is("archived_at", null).eq("assigned_to", me).not("next_follow_up_at", "is", null)
      .lte("next_follow_up_at", new Date(now.getTime() + 7 * 864e5).toISOString()).order("next_follow_up_at").limit(12),
    supabase.from("leads").select("id, company_name, score, temperature, status_id").is("archived_at", null).eq("assigned_to", me).in("temperature", ["hot", "very_hot"]).not("status_id", "in", closed).order("score", { ascending: false }).limit(8),
    supabase.from("deals").select("id, name, value, currency, probability, forecast_value, expected_close_date").is("archived_at", null).is("won_at", null).is("lost_at", null).eq("owner_id", me).order("expected_close_date", { ascending: true, nullsFirst: false }).limit(10),
    supabase.from("proposals").select("id, title, status, sent_at, deals!inner(owner_id)").in("status", ["sent", "viewed"]).eq("deals.owner_id", me).limit(10),
    supabase.from("tasks").select("id, title, due_at, status").eq("assignee_id", me).not("status", "in", "(completed,cancelled)").not("due_at", "is", null).lte("due_at", new Date(now.getTime() + 864e5).toISOString()).order("due_at").limit(10),
    getSummary(r.from, r.to), targetsWithProgress(me),
  ]);
  const today = dayKey(now);
  const bucket = (d: string) => (new Date(d) < now ? "Overdue" : dayKey(d) === today ? "Today" : "Upcoming");
  const fu = followUps.data ?? [];
  const activeTargets = targets.filter((t) => t.period_start <= today && t.period_end >= today);
  const ds = deals.data ?? [];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <StatCard label="Follow-ups overdue" value={fu.filter((l) => bucket(l.next_follow_up_at!) === "Overdue").length} tone={fu.some((l) => bucket(l.next_follow_up_at!) === "Overdue") ? "danger" : undefined} icon={<CalendarClock className="size-4" />} />
        <StatCard label="Due today" value={fu.filter((l) => bucket(l.next_follow_up_at!) === "Today").length} />
        <StatCard label="Hot leads" value={(hot.data ?? []).length} icon={<Flame className="size-4" />} href="/app/leads?temperature=hot_plus&assigned=me" />
        <StatCard label="My open deals" value={<MoneyList items={ds.map((d) => ({ currency: d.currency, amount: d.value }))} empty="0" className="text-lg" />} hint={`${ds.length} deal${ds.length === 1 ? "" : "s"}`} icon={<Handshake className="size-4" />} />
        <StatCard label="My forecast" value={<MoneyList items={ds.map((d) => ({ currency: d.currency, amount: d.forecast_value }))} empty="0" className="text-lg" />} hint="Projection, not revenue" />
      </div>
      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader title="My follow-ups" description="Overdue, today and the next 7 days" />
          {fu.length === 0 ? <EmptyState icon={<CalendarClock className="size-5" />} title="No follow-ups scheduled" description="Set a next follow-up on your leads and it appears here." /> : (
            <ul className="divide-y divide-border">
              {fu.map((l) => {
                const b = bucket(l.next_follow_up_at!);
                return (
                  <li key={l.id}><Link href={`/app/leads/${l.id}`} className="flex items-center gap-3 px-5 py-2.5 hover:bg-surface-2/50">
                    <span className={cn("w-20 text-xs font-medium", b === "Overdue" ? "text-danger" : b === "Today" ? "text-warning" : "text-text-3")}>{b}</span>
                    <span className="min-w-0 flex-1"><span className="block truncate text-sm">{l.company_name}</span><span className="text-xs text-text-3">{formatDateTime(l.next_follow_up_at)}</span></span>
                    <StatusBadge status={lookups.statusById.get(l.status_id)} />
                  </Link></li>
                );
              })}
            </ul>
          )}
        </Card>
        <Card>
          <CardHeader title="Due today" description="Tasks" />
          {(tasks.data ?? []).length === 0 ? <p className="px-5 py-6 text-sm text-text-3">Nothing due.</p> : (
            <ul className="divide-y divide-border">
              {(tasks.data ?? []).map((t) => (
                <li key={t.id}><Link href={`/app/tasks/${t.id}`} className="block px-5 py-2.5 hover:bg-surface-2/50">
                  <span className="block truncate text-sm">{t.title}</span>
                  <span className={cn("text-xs", new Date(t.due_at!) < now ? "text-danger" : "text-text-3")}>{formatDateTime(t.due_at)}</span>
                </Link></li>
              ))}
            </ul>
          )}
        </Card>
      </div>
      <div className="grid gap-6 xl:grid-cols-3">
        <Card>
          <CardHeader title="Hot prospects" />
          {(hot.data ?? []).length === 0 ? <p className="px-5 py-6 text-sm text-text-3">No hot leads right now.</p> : (
            <ul className="divide-y divide-border">
              {(hot.data ?? []).map((l) => (
                <li key={l.id}><Link href={`/app/leads/${l.id}`} className="flex items-center gap-2 px-5 py-2.5 hover:bg-surface-2/50">
                  <span className="flex-1 truncate text-sm">{l.company_name}</span><TemperatureBadge temperature={l.temperature as Temperature} score={l.score} />
                </Link></li>
              ))}
            </ul>
          )}
        </Card>
        <Card>
          <CardHeader title="Closest to closing" description="Open deals by expected close date" />
          {ds.length === 0 ? <p className="px-5 py-6 text-sm text-text-3">No open deals.</p> : (
            <ul className="divide-y divide-border">
              {ds.slice(0, 8).map((d) => (
                <li key={d.id}><Link href={`/app/deals/${d.id}`} className="block px-5 py-2.5 hover:bg-surface-2/50">
                  <span className="block truncate text-sm">{d.name}</span>
                  <span className="text-xs text-text-3">{formatMoney(d.value, d.currency)} · {d.probability}%{d.expected_close_date ? ` · ${formatDate(d.expected_close_date)}` : ""}</span>
                </Link></li>
              ))}
            </ul>
          )}
        </Card>
        <Card>
          <CardHeader title="Proposals pending" />
          {(proposals.data ?? []).length === 0 ? <p className="px-5 py-6 text-sm text-text-3">None waiting on a client.</p> : (
            <ul className="divide-y divide-border">
              {(proposals.data ?? []).map((p) => (
                <li key={p.id}><Link href={`/app/proposals/${p.id}`} className="flex items-center gap-2 px-5 py-2.5 hover:bg-surface-2/50">
                  <span className="flex-1 truncate text-sm">{p.title}</span><MapBadge map={PROPOSAL_STATUS} value={p.status} />
                </Link></li>
              ))}
            </ul>
          )}
        </Card>
      </div>
      {activeTargets.length > 0 && (
        <Card>
          <CardHeader title="My targets" />
          <div className="grid gap-5 p-5 md:grid-cols-2">{activeTargets.map((t) => <TargetRow key={t.id} t={t} />)}</div>
        </Card>
      )}
      {session.can("leads.view_all") && <FunnelCard s={s} />}
    </div>
  );
}

// ----------------------------------------------------------------------------- Work (developers, designers, others)
export async function WorkDashboard({ session }: { session: Session }) {
  const supabase = await createClient();
  const now = new Date();
  const me = session.userId;
  const [tasks, projects, meetings, targets] = await Promise.all([
    supabase.from("tasks").select("id, title, status, priority, due_at, kind, projects(name)").eq("assignee_id", me).not("status", "in", "(completed,cancelled)").order("due_at", { ascending: true, nullsFirst: false }).limit(20),
    supabase.from("project_members").select("role, projects(id, name, status, progress, deadline)").eq("user_id", me).limit(20),
    supabase.from("meetings").select("id, title, starts_at, status").eq("status", "scheduled").gte("starts_at", now.toISOString()).lt("starts_at", new Date(now.getTime() + 7 * 864e5).toISOString()).order("starts_at").limit(8),
    targetsWithProgress(me),
  ]);
  const ts = (tasks.data ?? []) as unknown as { id: string; title: string; status: string; priority: string; due_at: string | null; kind: string; projects: { name: string } | null }[];
  const ps = ((projects.data ?? []) as unknown as { role: string; projects: { id: string; name: string; status: string; progress: number; deadline: string | null } | null }[]).filter((p) => p.projects);
  const today = dayKey(now);
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="My open tasks" value={ts.length} icon={<ListChecks className="size-4" />} href="/app/tasks" />
        <StatCard label="Overdue" value={ts.filter((t) => t.due_at && new Date(t.due_at) < now).length} tone={ts.some((t) => t.due_at && new Date(t.due_at) < now) ? "danger" : undefined} />
        <StatCard label="My projects" value={ps.length} icon={<FolderKanban className="size-4" />} />
        <StatCard label="Meetings · 7 days" value={(meetings.data ?? []).length} />
      </div>
      <div className="grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader title="My tasks" action={<Link href="/app/tasks/new" className="text-xs text-accent hover:underline">New task</Link>} />
          {ts.length === 0 ? <EmptyState icon={<Inbox className="size-5" />} title="Nothing assigned" description="Tasks assigned to you appear here." /> : (
            <ul className="divide-y divide-border">
              {ts.map((t) => (
                <li key={t.id}><Link href={`/app/tasks/${t.id}`} className="flex items-center gap-3 px-5 py-2.5 hover:bg-surface-2/50">
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm">{t.title}</span>
                    <span className={cn("text-xs", t.due_at && new Date(t.due_at) < now ? "text-danger" : "text-text-3")}>{t.projects?.name ?? "No project"}{t.due_at ? ` · due ${formatDateTime(t.due_at)}` : ""}</span>
                  </span>
                  {t.kind === "bug" && <Badge color="rose">Bug</Badge>}
                  <MapBadge map={TASK_STATUS} value={t.status} />
                </Link></li>
              ))}
            </ul>
          )}
        </Card>
        <div className="space-y-6">
          <Card>
            <CardHeader title="My projects" />
            {ps.length === 0 ? <p className="px-5 py-6 text-sm text-text-3">You’re not on a project yet.</p> : (
              <ul className="divide-y divide-border">
                {ps.map((p) => (
                  <li key={p.projects!.id}><Link href={`/app/projects/${p.projects!.id}`} className="block space-y-1.5 px-5 py-3 hover:bg-surface-2/50">
                    <span className="flex items-center gap-2 text-sm"><span className="flex-1 truncate">{p.projects!.name}</span><span className="text-xs text-text-3">{p.role}</span></span>
                    <Progress value={p.projects!.progress} />
                  </Link></li>
                ))}
              </ul>
            )}
          </Card>
          <Card>
            <CardHeader title="Upcoming meetings" />
            {(meetings.data ?? []).length === 0 ? <p className="px-5 py-6 text-sm text-text-3">No meetings this week.</p> : (
              <ul className="divide-y divide-border">
                {(meetings.data ?? []).map((m) => (
                  <li key={m.id}><Link href={`/app/meetings/${m.id}`} className="flex items-center gap-2 px-5 py-2.5 hover:bg-surface-2/50">
                    <span className="flex-1 truncate text-sm">{m.title}</span><span className="text-xs text-text-3">{formatDateTime(m.starts_at)}</span><MapBadge map={MEETING_STATUS} value={m.status} />
                  </Link></li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
      {targets.filter((t) => t.period_end >= today).length > 0 && (
        <Card>
          <CardHeader title="My targets" />
          <div className="grid gap-5 p-5 md:grid-cols-2">{targets.filter((t) => t.period_end >= today).map((t) => <TargetRow key={t.id} t={t} />)}</div>
        </Card>
      )}
    </div>
  );
}
