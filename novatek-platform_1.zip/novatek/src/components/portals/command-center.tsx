import Link from "next/link";
import { AlarmClock, AlertTriangle, CalendarPlus, FolderPlus, Handshake, ListPlus, Megaphone, Plug, Plus, UserPlus, UserX } from "lucide-react";
import { Card } from "@/components/ui/primitives";
import type { Session } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";
import { cn } from "@/lib/utils";

/** Quick actions + live operational alerts. Every count comes from a real query through the viewer's RLS. */
export async function CommandCenter({ session }: { session: Session }) {
  const actions = [
    { href: "/app/leads/new", label: "Add lead", icon: Plus, ok: session.can("leads.create") },
    { href: "/app/admin/users/new", label: "Add employee", icon: UserPlus, ok: session.can("users.manage_roles") },
    { href: "/app/tasks/new", label: "Create task", icon: ListPlus, ok: true },
    { href: "/app/deals/new", label: "Create deal", icon: Handshake, ok: session.can({ anyOf: ["sales.view", "sales.manage"] }) },
    { href: "/app/clients/new", label: "Create client", icon: FolderPlus, ok: session.can("sales.manage") },
    { href: "/app/meetings/new", label: "Schedule meeting", icon: CalendarPlus, ok: true },
    { href: "/app/campaigns/new", label: "Create campaign", icon: Megaphone, ok: session.can("campaigns.manage") },
  ].filter((a) => a.ok);

  const supabase = await createClient();
  const now = new Date().toISOString();
  const { data: closed } = await supabase.from("lead_statuses").select("id").eq("is_closed", true);
  const closedIds = `(${(closed ?? []).map((c) => c.id).join(",") || "00000000-0000-0000-0000-000000000000"})`;
  const canLeads = session.can({ anyOf: ["leads.view_all", "leads.view_own"] });
  const [overdueLeads, unassigned, overdueTasks, failedIntegrations] = await Promise.all([
    canLeads ? supabase.from("leads").select("id", { count: "exact", head: true }).is("archived_at", null).not("status_id", "in", closedIds).lt("next_follow_up_at", now) : Promise.resolve({ count: null }),
    session.can("leads.assign") ? supabase.from("leads").select("id", { count: "exact", head: true }).is("archived_at", null).is("assigned_to", null).not("status_id", "in", closedIds) : Promise.resolve({ count: null }),
    (() => {
      const q = supabase.from("tasks").select("id", { count: "exact", head: true }).not("status", "in", "(completed,cancelled)").lt("due_at", now);
      return session.can({ anyOf: ["tasks.assign", "projects.view"] }) ? q : q.eq("assignee_id", session.userId);
    })(),
    session.can("settings.manage") ? supabase.from("integrations").select("key", { count: "exact", head: true }).eq("last_status", "error") : Promise.resolve({ count: null }),
  ]);
  const alerts = [
    overdueLeads.count ? { href: "/app/leads", text: `${overdueLeads.count} lead follow-up${overdueLeads.count === 1 ? "" : "s"} overdue`, icon: AlarmClock } : null,
    unassigned.count ? { href: "/app/leads?assigned=unassigned", text: `${unassigned.count} open lead${unassigned.count === 1 ? "" : "s"} unassigned`, icon: UserX } : null,
    overdueTasks.count ? { href: "/app/tasks?view=team", text: `${overdueTasks.count} task${overdueTasks.count === 1 ? "" : "s"} overdue`, icon: AlertTriangle } : null,
    failedIntegrations.count ? { href: "/app/settings/integrations", text: `${failedIntegrations.count} integration check${failedIntegrations.count === 1 ? "" : "s"} failing`, icon: Plug } : null,
  ].filter(Boolean) as { href: string; text: string; icon: typeof Plus }[];

  return (
    <div className="space-y-3">
      <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:px-0">
        {actions.map((a) => (
          <Link key={a.href} href={a.href} className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-border bg-surface px-3 py-1.5 text-sm text-text-2 hover:border-border-strong hover:text-text">
            <a.icon className="size-4 text-text-3" /> {a.label}
          </Link>
        ))}
      </div>
      {alerts.length > 0 && (
        <Card className="divide-y divide-border border-warning/30">
          {alerts.map((a) => (
            <Link key={a.href} href={a.href} className={cn("flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-surface-2/50")}>
              <a.icon className="size-4 text-warning" /> <span className="flex-1">{a.text}</span> <span className="text-xs text-accent">Review</span>
            </Link>
          ))}
        </Card>
      )}
    </div>
  );
}
