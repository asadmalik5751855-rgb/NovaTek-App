import { Card, CardHeader } from "@/components/ui/primitives";
import { MoneyList, StatCard } from "@/components/ui/status";
import { BarList } from "@/components/charts/bar-list";
import { ColumnChart } from "@/components/charts/column-chart";
import { pct, rates, type Breakdown, type SeriesPoint, type Summary } from "@/lib/data/analytics";
import { formatDate, formatMoney } from "@/lib/utils";

const fmtPct = (v: number | null) => (v === null ? "—" : `${v}%`);

export function SalesKpis({ s }: { s: Summary }) {
  const r = rates(s);
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
      <StatCard label="Leads" value={s.leads.toLocaleString()} hint="Created in period" />
      <StatCard label="Qualified" value={s.qualified.toLocaleString()} hint={`${fmtPct(r.qualifiedRate)} of leads`} />
      <StatCard label="Revenue won" value={<MoneyList items={s.revenue} empty="0" className="text-lg" />} hint={`${s.deals_won} deal${s.deals_won === 1 ? "" : "s"} won`} tone="success" />
      <StatCard label="Forecast" value={<MoneyList items={s.forecast.map((f) => ({ currency: f.currency, amount: f.forecast }))} empty="0" className="text-lg" />} hint="Open deals × probability (not revenue)" />
      <StatCard label="Win rate" value={fmtPct(r.winRate)} hint={`${s.deals_won} won / ${s.deals_lost} lost`} />
      <StatCard label="Sales cycle" value={s.avg_sales_cycle_days === null ? "—" : `${s.avg_sales_cycle_days} d`} hint="Lead created → deal won" />
    </div>
  );
}

export function FunnelCard({ s }: { s: Summary }) {
  const steps = [
    { label: "Leads created", value: s.leads },
    { label: "Qualified", value: s.qualified },
    { label: "Contacted", value: s.contacted },
    { label: "Replied", value: s.replied },
    { label: "Meeting", value: s.meetings },
    { label: "Proposal", value: s.proposals },
    { label: "Won", value: s.won_leads },
  ];
  const r = rates(s);
  return (
    <Card>
      <CardHeader title="Conversion funnel" description="Leads created in the period and the furthest stage each has reached" />
      <div className="p-5">
        <BarList rows={steps.map((x) => ({ ...x, hint: s.leads ? `${pct(x.value, s.leads)}%` : undefined }))} max={s.leads} />
        <dl className="mt-5 grid grid-cols-2 gap-3 border-t border-border pt-4 text-sm sm:grid-cols-4">
          {[["Contact rate", r.contactRate], ["Response rate", r.responseRate], ["Meeting rate", r.meetingRate], ["Proposal rate", r.proposalRate]].map(([l, v]) => (
            <div key={l as string}><dt className="text-xs text-text-3">{l}</dt><dd className="font-semibold tabular-nums">{fmtPct(v as number | null)}</dd></div>
          ))}
        </dl>
      </div>
    </Card>
  );
}

function bucketLabel(d: string, bucket: string) {
  if (bucket === "month") return formatDate(d, { day: undefined, year: "2-digit" });
  return formatDate(d, { year: undefined });
}

export function LeadsTrend({ series, bucket }: { series: SeriesPoint[]; bucket: string }) {
  return (
    <Card>
      <CardHeader title="Leads created" description={`Per ${bucket}`} />
      <div className="p-4">
        <ColumnChart title="Leads created" valueLabel="Leads"
          data={series.map((p) => ({ label: bucketLabel(p.bucket, bucket), detail: `${bucket === "week" ? "Week of " : ""}${formatDate(p.bucket)}`, value: p.leads,
            display: `${p.leads} (${p.qualified} qualified)` }))} />
      </div>
    </Card>
  );
}

export function RevenueTrend({ series, bucket, currency }: { series: SeriesPoint[]; bucket: string; currency: string }) {
  const others = new Set(series.flatMap((p) => p.revenue.map((r) => r.currency)).filter((c) => c !== currency));
  return (
    <Card>
      <CardHeader title={`Revenue won (${currency})`} description={others.size ? `Other currencies (${[...others].join(", ")}) are reported separately, never converted` : `Per ${bucket}`} />
      <div className="p-4">
        <ColumnChart title={`Revenue won in ${currency}`} valueLabel={currency}
          data={series.map((p) => {
            const v = p.revenue.filter((r) => r.currency === currency).reduce((a, r) => a + r.amount, 0);
            return { label: bucketLabel(p.bucket, bucket), detail: `${bucket === "week" ? "Week of " : ""}${formatDate(p.bucket)}`, value: v, display: formatMoney(v, currency) };
          })} />
      </div>
    </Card>
  );
}

export function BreakdownTable({ title, description, rows, nameLabel }: { title: string; description?: string; rows: Breakdown[]; nameLabel: string }) {
  const max = Math.max(1, ...rows.map((r) => r.leads));
  return (
    <Card className="overflow-hidden">
      <CardHeader title={title} description={description} />
      {rows.length === 0 ? <p className="px-5 py-6 text-center text-sm text-text-3">No leads in this period</p> : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="border-b border-border text-left text-xs uppercase tracking-wide text-text-3">
              <tr><th className="px-4 py-2">{nameLabel}</th><th className="px-4 py-2 text-right">Leads</th><th className="px-4 py-2 text-right">Qualified</th>
                <th className="px-4 py-2 text-right">Won</th><th className="px-4 py-2 text-right">Conv.</th><th className="px-4 py-2">Revenue</th></tr>
            </thead>
            <tbody className="divide-y divide-border">
              {rows.slice(0, 12).map((r) => (
                <tr key={r.key}>
                  <td className="px-4 py-2">
                    <span className="block truncate">{r.label}</span>
                    <span className="mt-1 block h-1 rounded-full bg-accent/70" style={{ width: `${(r.leads / max) * 100}%` }} aria-hidden />
                  </td>
                  <td className="px-4 py-2 text-right tabular-nums">{r.leads}</td>
                  <td className="px-4 py-2 text-right tabular-nums">{r.qualified}</td>
                  <td className="px-4 py-2 text-right tabular-nums">{r.won}</td>
                  <td className="px-4 py-2 text-right tabular-nums">{fmtPct(pct(r.won, r.leads))}</td>
                  <td className="px-4 py-2"><MoneyList items={r.revenue} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
