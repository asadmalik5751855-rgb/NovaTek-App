import { FileText } from "lucide-react";
import { Card, CardHeader } from "@/components/ui/primitives";
import { createClient } from "@/lib/supabase/server";
import { formatDate } from "@/lib/utils";
import { DocumentUpload, RemoveDocument } from "./document-upload";

function size(n: number) {
  return n < 1024 * 1024 ? `${Math.max(1, Math.round(n / 1024))} KB` : `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export async function DocumentsCard({ entity, entityId, canUpload, userId, isAdmin }: {
  entity: "client" | "project" | "deal" | "lead"; entityId: string; canUpload: boolean; userId: string; isAdmin: boolean;
}) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("documents")
    .select("id, name, size_bytes, mime_type, uploaded_by, created_at")
    .eq("entity", entity).eq("entity_id", entityId).is("archived_at", null)
    .order("created_at", { ascending: false });
  const docs = data ?? [];
  return (
    <Card>
      <CardHeader title="Documents" description="Private files. Access follows this record’s permissions." />
      {docs.length === 0 ? (
        <p className="px-5 py-4 text-sm text-text-3">No documents yet.</p>
      ) : (
        <ul className="divide-y divide-border">
          {docs.map((d) => (
            <li key={d.id} className="flex items-center gap-3 px-5 py-2.5">
              <FileText className="size-4 shrink-0 text-text-3" />
              <a href={`/app/documents/${d.id}`} className="min-w-0 flex-1 truncate text-sm hover:text-accent">{d.name}</a>
              <span className="hidden text-xs text-text-3 sm:inline">{size(d.size_bytes)} · {formatDate(d.created_at)}</span>
              {(d.uploaded_by === userId || isAdmin) && <RemoveDocument id={d.id} />}
            </li>
          ))}
        </ul>
      )}
      {canUpload && (
        <div className="border-t border-border p-4">
          <DocumentUpload entity={entity} entityId={entityId} />
        </div>
      )}
    </Card>
  );
}
