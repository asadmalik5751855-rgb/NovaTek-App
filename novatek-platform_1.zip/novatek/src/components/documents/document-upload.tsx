"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Trash2, Upload } from "lucide-react";
import { Alert, Button } from "@/components/ui/primitives";
import { archiveDocument, uploadDocument } from "@/app/app/documents/actions";

export function DocumentUpload({ entity, entityId }: { entity: string; entityId: string }) {
  const router = useRouter();
  const ref = useRef<HTMLFormElement>(null);
  const [pending, start] = useTransition();
  const [msg, setMsg] = useState<{ tone: "error" | "success"; text: string } | null>(null);
  return (
    <form
      ref={ref}
      className="space-y-2"
      action={(fd) => {
        setMsg(null);
        start(async () => {
          const r = await uploadDocument(fd);
          if (!r.ok) setMsg({ tone: "error", text: r.error });
          else {
            setMsg({ tone: "success", text: "Uploaded." });
            ref.current?.reset();
            router.refresh();
          }
        });
      }}
    >
      <input type="hidden" name="entity" value={entity} />
      <input type="hidden" name="entity_id" value={entityId} />
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <input
          type="file"
          name="file"
          required
          aria-label="File"
          accept=".pdf,.png,.jpg,.jpeg,.webp,.txt,.csv,.docx,.xlsx,.pptx,.zip"
          className="block w-full text-sm text-text-2 file:mr-3 file:rounded-md file:border file:border-border file:bg-surface-2 file:px-3 file:py-1.5 file:text-sm file:text-text"
        />
        <Button type="submit" size="sm" variant="secondary" disabled={pending}>
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />} Upload
        </Button>
      </div>
      <p className="text-xs text-text-3">PDF, images, Office files, CSV, TXT or ZIP · max 25 MB</p>
      {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
    </form>
  );
}

export function RemoveDocument({ id }: { id: string }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <button
      type="button"
      aria-label="Remove document"
      disabled={pending}
      onClick={() => start(async () => { const r = await archiveDocument(id); if (r.ok) router.refresh(); })}
      className="grid size-7 place-items-center rounded-md text-text-3 hover:bg-surface-2 hover:text-danger"
    >
      {pending ? <Loader2 className="size-3.5 animate-spin" /> : <Trash2 className="size-3.5" />}
    </button>
  );
}
