"use client";

import * as React from "react";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { FormProvider, useForm, useFormContext, type FieldValues } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2 } from "lucide-react";
import type { z } from "zod";
import { Alert, Button, Field, Input, Select, Textarea } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";

export type FormActionResult =
  | { ok: true; data?: unknown }
  | { ok: false; error: string; fieldErrors?: Record<string, string[] | undefined> };

type Props = {
  schema: z.ZodType;
  /** Server action. Receives the raw form values; the server re-validates with the same schema. */
  action: (values: Record<string, unknown>) => Promise<FormActionResult>;
  defaultValues?: Record<string, unknown>;
  submitLabel: string;
  /** Where to go after success. A function receives the action's data (e.g. a new id). */
  redirectTo?: string | ((data: unknown) => string);
  successMessage?: string;
  resetOnSuccess?: boolean;
  children: React.ReactNode;
  className?: string;
  secondary?: React.ReactNode;
};

/**
 * Generic form: React Hook Form + Zod on the client for instant feedback, then the server action
 * validates again (authoritative) and enforces permissions. Success is only shown after the server confirms.
 */
export function Form({ schema, action, defaultValues, submitLabel, redirectTo, successMessage, resetOnSuccess, children, className, secondary }: Props) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [message, setMessage] = useState<{ tone: "error" | "success"; text: string } | null>(null);
  const methods = useForm<FieldValues>({
    resolver: zodResolver(schema as never) as never,
    defaultValues: defaultValues as FieldValues,
    mode: "onTouched",
  });

  const onSubmit = methods.handleSubmit(() => {
    setMessage(null);
    const values = methods.getValues();
    start(async () => {
      const res = await action(values);
      if (!res.ok) {
        setMessage({ tone: "error", text: res.error });
        for (const [k, v] of Object.entries(res.fieldErrors ?? {})) if (v?.[0]) methods.setError(k, { message: v[0] });
        return;
      }
      if (redirectTo) {
        router.push(typeof redirectTo === "function" ? redirectTo(res.data) : redirectTo);
        router.refresh();
        return;
      }
      if (resetOnSuccess) methods.reset(defaultValues as FieldValues);
      setMessage({ tone: "success", text: successMessage ?? "Saved." });
      router.refresh();
    });
  });

  return (
    <FormProvider {...methods}>
      <form onSubmit={onSubmit} noValidate className={cn("space-y-5", className)}>
        {message && <Alert tone={message.tone}>{message.text}</Alert>}
        {children}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <Button type="submit" variant="brand" disabled={pending}>
            {pending && <Loader2 className="size-4 animate-spin" />} {submitLabel}
          </Button>
          {secondary}
        </div>
      </form>
    </FormProvider>
  );
}

function useFieldError(name: string) {
  const {
    formState: { errors },
  } = useFormContext();
  return errors[name]?.message as string | undefined;
}

type BaseProps = { name: string; label: string; hint?: string; required?: boolean; className?: string };

export function TextField({
  name,
  label,
  hint,
  required,
  className,
  ...rest
}: BaseProps & Omit<React.InputHTMLAttributes<HTMLInputElement>, "name">) {
  const { register } = useFormContext();
  const error = useFieldError(name);
  return (
    <Field label={label} htmlFor={name} error={error} hint={hint} required={required} className={className}>
      <Input id={name} aria-invalid={Boolean(error) || undefined} aria-describedby={error ? `${name}-error` : undefined} {...rest} {...register(name)} />
    </Field>
  );
}

export function TextAreaField({
  name,
  label,
  hint,
  required,
  className,
  ...rest
}: BaseProps & Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, "name">) {
  const { register } = useFormContext();
  const error = useFieldError(name);
  return (
    <Field label={label} htmlFor={name} error={error} hint={hint} required={required} className={className}>
      <Textarea id={name} aria-invalid={Boolean(error) || undefined} {...rest} {...register(name)} />
    </Field>
  );
}

export type Option = { value: string; label: string };

export function SelectField({
  name,
  label,
  hint,
  required,
  className,
  options,
  placeholder,
}: BaseProps & { options: readonly Option[]; placeholder?: string }) {
  const { register } = useFormContext();
  const error = useFieldError(name);
  return (
    <Field label={label} htmlFor={name} error={error} hint={hint} required={required} className={className}>
      <Select id={name} aria-invalid={Boolean(error) || undefined} {...register(name)}>
        {placeholder !== undefined && <option value="">{placeholder}</option>}
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </Select>
    </Field>
  );
}

export function CheckboxField({ name, label, hint, className }: BaseProps) {
  const { register } = useFormContext();
  const error = useFieldError(name);
  return (
    <div className={cn("space-y-1", className)}>
      <label className="flex cursor-pointer items-start gap-2.5 text-sm">
        <input type="checkbox" className="mt-0.5 size-4 accent-[var(--accent)]" {...register(name)} />
        <span>
          <span className="font-medium text-text">{label}</span>
          {hint && <span className="block text-xs text-text-3">{hint}</span>}
        </span>
      </label>
      {error && <p className="text-xs text-danger" role="alert">{error}</p>}
    </div>
  );
}

export function FormSection({ title, description, children, columns = 2 }: { title: string; description?: string; children: React.ReactNode; columns?: 1 | 2 | 3 }) {
  return (
    <section className="space-y-4">
      <div>
        <h2 className="text-sm font-semibold">{title}</h2>
        {description && <p className="mt-0.5 text-xs text-text-3">{description}</p>}
      </div>
      <div className={cn("grid gap-4", columns === 2 && "sm:grid-cols-2", columns === 3 && "sm:grid-cols-3")}>{children}</div>
    </section>
  );
}

function toLocalInput(iso: unknown) {
  if (typeof iso !== "string" || !iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}

/**
 * Date + time in the user's own timezone. The form value is stored as an ISO instant (with offset),
 * so the server never has to guess the browser's timezone.
 */
export function DateTimeField({ name, label, hint, required, className }: BaseProps) {
  const { setValue, getValues, formState: { errors } } = useFormContext();
  const ref = React.useRef<HTMLInputElement>(null);
  const error = errors[name]?.message as string | undefined;
  // Uncontrolled on purpose: anything typed before hydration is kept (and synced), and the initial value is
  // rendered in the browser's timezone after mount, so server and client HTML never disagree.
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (el.value) setValue(name, new Date(el.value).toISOString(), { shouldDirty: true });
    else el.value = toLocalInput(getValues(name));
  }, [name, setValue, getValues]);
  return (
    <Field label={label} htmlFor={name} error={error} hint={hint} required={required} className={className}>
      <Input
        ref={ref}
        id={name}
        type="datetime-local"
        aria-invalid={Boolean(error) || undefined}
        onChange={(e) => {
          const v = e.target.value;
          setValue(name, v ? new Date(v).toISOString() : "", { shouldValidate: true, shouldDirty: true });
        }}
      />
    </Field>
  );
}
