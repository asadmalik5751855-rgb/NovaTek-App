import Image from "next/image";
import { brand } from "@/lib/config/brand";
import { cn } from "@/lib/utils";

/**
 * The official horizontal NovaTek logo, rendered from the supplied file exactly as-is.
 * `plate` puts it on a white rounded plate for dark backgrounds (the file has an opaque white background).
 * Never replace this with text, never apply filters, recolouring or non-proportional sizing.
 */
export function BrandLogo({
  height = 28,
  plate = false,
  priority = false,
  className,
}: {
  height?: number;
  plate?: boolean;
  priority?: boolean;
  className?: string;
}) {
  const { src, width: w, height: h } = brand.logo.horizontal;
  // Intrinsic size = the real file; the browser scales by height with width:auto, so the aspect ratio is exact.
  // `unoptimized` serves the original bytes — no re-encoding or resampling by the image optimizer.
  const img = (
    <Image
      src={src}
      alt={brand.companyName}
      width={w}
      height={h}
      unoptimized
      priority={priority}
      style={{ height, width: "auto" }}
      className="block select-none"
      draggable={false}
    />
  );
  if (!plate) return <span className={cn("inline-block", className)}>{img}</span>;
  return (
    <span className={cn("inline-flex items-center rounded-lg bg-white px-2.5 py-1.5 shadow-sm", className)}>{img}</span>
  );
}

/** The official app icon / symbol, from the supplied file. Proportional sizing only. */
export function BrandMark({ size = 32, className, priority }: { size?: number; className?: string; priority?: boolean }) {
  return (
    <Image
      src={brand.logo.icon.src}
      alt={brand.companyName}
      width={brand.logo.icon.width}
      height={brand.logo.icon.height}
      unoptimized
      priority={priority}
      style={{ width: size, height: size }}
      className={cn("block select-none", className)}
      draggable={false}
    />
  );
}
