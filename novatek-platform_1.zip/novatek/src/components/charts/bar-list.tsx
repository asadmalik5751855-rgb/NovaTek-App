/** Horizontal bars with the value as text at the end (funnels, rankings). Label and value use text tokens. */
export function BarList({ rows, max, empty = "No data in this period" }: {
  rows: { label: string; value: number; display?: string; hint?: string }[]; max?: number; empty?: string;
}) {
  if (!rows.length) return <p className="py-6 text-center text-sm text-text-3">{empty}</p>;
  const m = Math.max(max ?? 0, ...rows.map((r) => r.value), 1);
  return (
    <ul className="space-y-3">
      {rows.map((r) => (
        <li key={r.label}>
          <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
            <span className="truncate text-text-2">{r.label}</span>
            <span className="shrink-0 tabular-nums text-text">{r.display ?? r.value.toLocaleString()}{r.hint && <span className="ml-1.5 text-xs text-text-3">{r.hint}</span>}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-surface-2">
            <div className="h-full rounded-full bg-accent" style={{ width: `${(r.value / m) * 100}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}
