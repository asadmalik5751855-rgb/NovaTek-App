"use client";

import { useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Button, Input } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";

const PRESETS = [["today", "Today"], ["7d", "7 days"], ["30d", "30 days"], ["90d", "90 days"], ["12m", "12 months"]] as const;

/** Date-range filter: presets plus a custom range, all in the URL so views are shareable. */
export function RangeFilter({ active, from, to }: { active: string; from: string; to: string }) {
  const router = useRouter();
  const path = usePathname();
  const sp = useSearchParams();
  const [custom, setCustom] = useState(active === "custom");
  const [f, setF] = useState(from);
  const [t, setT] = useState(to);
  const go = (params: Record<string, string>) => {
    const next = new URLSearchParams(sp.toString());
    for (const k of ["range", "from", "to"]) next.delete(k);
    for (const [k, v] of Object.entries(params)) next.set(k, v);
    router.push(`${path}?${next}`);
  };
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="flex flex-wrap rounded-lg border border-border p-0.5 text-sm" role="group" aria-label="Date range">
        {PRESETS.map(([k, l]) => (
          <button key={k} type="button" onClick={() => { setCustom(false); go({ range: k }); }} aria-pressed={active === k}
            className={cn("rounded-md px-2.5 py-1.5", active === k ? "bg-surface-2 font-medium" : "text-text-3 hover:text-text")}>{l}</button>
        ))}
        <button type="button" onClick={() => setCustom(true)} aria-pressed={active === "custom"}
          className={cn("rounded-md px-2.5 py-1.5", active === "custom" || custom ? "bg-surface-2 font-medium" : "text-text-3 hover:text-text")}>Custom</button>
      </div>
      {custom && (
        <div className="flex flex-wrap items-center gap-2">
          <Input type="date" value={f} onChange={(e) => setF(e.target.value)} aria-label="From" className="h-9 w-40" />
          <span className="text-text-3">–</span>
          <Input type="date" value={t} onChange={(e) => setT(e.target.value)} aria-label="To" className="h-9 w-40" />
          <Button size="sm" variant="secondary" disabled={!f || !t || f > t} onClick={() => go({ range: "custom", from: f, to: t })}>Apply</Button>
        </div>
      )}
    </div>
  );
}
