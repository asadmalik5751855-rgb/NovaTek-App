"use client";

import { useState } from "react";

export type Point = { label: string; value: number; display?: string; detail?: string };

function niceMax(v: number) {
  if (v <= 0) return 1;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  const m = v / p;
  return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 5 ? 5 : 10) * p;
}
const compact = (v: number) => new Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 }).format(v);

/**
 * Single-series column chart (SVG). Spec: bars ≤24px, 4px rounded data-end and square baseline, hairline grid,
 * one axis, per-bar hover tooltip, and a visually hidden data table for screen readers.
 */
export function ColumnChart({ data, title, height = 170, valueLabel }: { data: Point[]; title: string; height?: number; valueLabel: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 480, padL = 34, padB = 22, padT = 10;
  const plotH = height - padB - padT;
  const max = niceMax(Math.max(...data.map((d) => d.value), 0));
  const ticks = [0, max / 2, max];
  const band = (W - padL) / Math.max(data.length, 1);
  const barW = Math.min(24, Math.max(2, band * 0.6));
  const labelEvery = Math.ceil(data.length / 6);
  const y = (v: number) => padT + plotH - (v / max) * plotH;
  const allZero = data.every((d) => d.value === 0);

  return (
    <figure className="relative" aria-label={title}>
      <svg viewBox={`0 0 ${W} ${height}`} className="h-auto w-full overflow-visible" role="img" aria-hidden onMouseLeave={() => setHover(null)}>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={padL} x2={W} y1={y(t)} y2={y(t)} stroke="var(--border)" strokeWidth={1} />
            <text x={padL - 6} y={y(t)} dy="0.32em" textAnchor="end" fontSize={11} fill="var(--text-3)">{compact(t)}</text>
          </g>
        ))}
        {data.map((d, i) => {
          const x = padL + band * i + (band - barW) / 2;
          const h = Math.max(0, (d.value / max) * plotH);
          const r = Math.min(4, h, barW / 2);
          const top = padT + plotH - h;
          return (
            <g key={d.label + i} onMouseEnter={() => setHover(i)} onFocus={() => setHover(i)}>
              <rect x={padL + band * i} y={padT} width={band} height={plotH} fill="transparent" />
              {h > 0 && (
                <path
                  d={`M${x},${padT + plotH} L${x},${top + r} Q${x},${top} ${x + r},${top} L${x + barW - r},${top} Q${x + barW},${top} ${x + barW},${top + r} L${x + barW},${padT + plotH} Z`}
                  fill="var(--accent)"
                  opacity={hover === null || hover === i ? 1 : 0.45}
                />
              )}
              {i % labelEvery === 0 && (
                <text x={padL + band * i + band / 2} y={height - 6} textAnchor="middle" fontSize={11} fill="var(--text-3)">{d.label}</text>
              )}
            </g>
          );
        })}
      </svg>
      {allZero && <p className="absolute inset-0 grid place-items-center text-sm text-text-3">No {valueLabel.toLowerCase()} in this period</p>}
      {hover !== null && data[hover] && (
        <div
          className="pointer-events-none absolute top-0 z-10 -translate-x-1/2 rounded-lg border border-border bg-surface px-3 py-2 text-xs shadow-card"
          style={{ left: `${((padL + band * hover + band / 2) / W) * 100}%` }}
        >
          <p className="text-text-3">{data[hover].detail ?? data[hover].label}</p>
          <p className="font-semibold tabular-nums text-text">{data[hover].display ?? data[hover].value.toLocaleString()} <span className="font-normal text-text-3">{valueLabel.toLowerCase()}</span></p>
        </div>
      )}
      <table className="sr-only">
        <caption>{title}</caption>
        <thead><tr><th>Period</th><th>{valueLabel}</th></tr></thead>
        <tbody>{data.map((d, i) => <tr key={i}><td>{d.detail ?? d.label}</td><td>{d.display ?? d.value}</td></tr>)}</tbody>
      </table>
    </figure>
  );
}
