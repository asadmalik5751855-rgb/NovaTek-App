"use client";

import { useFormContext } from "react-hook-form";
import { Form, FormSection, SelectField, TextAreaField, TextField, type Option } from "@/components/forms/form";
import { CURRENCIES } from "@/lib/validation/common";
import { dealSchema, dealUpdateSchema } from "@/lib/validation/sales";
import { createDeal, updateDeal } from "@/app/app/deals/actions";

type Props = {
  mode: "create" | "edit";
  dealId?: string;
  defaults: Record<string, unknown>;
  stages: { id: string; name: string; default_probability: number }[];
  leads: Option[];
  clients: Option[];
  people: Option[];
  services: Option[];
  canAssign: boolean;
};

function StageProbability({ stages }: { stages: Props["stages"] }) {
  const { register, setValue } = useFormContext();
  const reg = register("stage_id");
  return (
    <div className="space-y-1.5">
      <label htmlFor="stage_id" className="block text-sm font-medium">Stage<span className="ml-0.5 text-danger">*</span></label>
      <select
        id="stage_id"
        className="h-10 w-full rounded-lg border border-border bg-surface px-3 text-sm"
        {...reg}
        onChange={(e) => {
          reg.onChange(e);
          const s = stages.find((x) => x.id === e.target.value);
          if (s) setValue("probability", String(s.default_probability));
        }}
      >
        {stages.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
      </select>
      <p className="text-xs text-text-3">Choosing a stage suggests its default probability.</p>
    </div>
  );
}

export function DealForm({ mode, dealId, defaults, stages, leads, clients, people, services, canAssign }: Props) {
  const action = mode === "create" ? createDeal : updateDeal.bind(null, dealId!);
  return (
    <Form
      schema={mode === "create" ? dealSchema : dealUpdateSchema}
      action={action}
      defaultValues={defaults}
      submitLabel={mode === "create" ? "Create deal" : "Save changes"}
      redirectTo={(data) => `/app/deals/${mode === "create" ? (data as { id: string }).id : dealId}`}
    >
      <FormSection title="Opportunity">
        <TextField name="name" label="Deal name" required placeholder="e.g. School admissions portal" className="sm:col-span-2" />
        {mode === "create" && <SelectField name="lead_id" label="Lead" options={leads} placeholder="—" hint="Deals are usually created from a qualified lead" />}
        <SelectField name="client_id" label="Client" options={clients} placeholder="—" hint={mode === "create" ? "For repeat business with an existing client" : undefined} />
        <SelectField name="service_id" label="Service" options={services} placeholder="—" hint="Used to pick the commission rule" />
        {canAssign ? (
          <SelectField name="owner_id" label="Salesperson" options={people} placeholder="Me" />
        ) : null}
      </FormSection>
      <FormSection title="Value & forecast" columns={3}>
        <TextField name="value" label="Estimated value" required inputMode="decimal" />
        <SelectField name="currency" label="Currency" options={CURRENCIES.map((c) => ({ value: c, label: c }))} />
        <TextField name="probability" label="Probability %" required inputMode="numeric" />
        <StageProbability stages={stages} />
        <TextField name="expected_close_date" label="Expected close" type="date" />
      </FormSection>
      <FormSection title="Notes" columns={1}>
        <TextAreaField name="notes" label="Notes" rows={4} />
      </FormSection>
    </Form>
  );
}
