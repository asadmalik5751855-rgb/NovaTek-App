"use client";

import { Form, FormSection, SelectField, TextAreaField, TextField, type Option } from "@/components/forms/form";
import { CURRENCIES } from "@/lib/validation/common";
import { commissionRuleSchema } from "@/lib/validation/sales";
import { createCommissionRule } from "@/app/app/commissions/actions";

export function CommissionRuleForm({ services, roles, people }: { services: Option[]; roles: Option[]; people: Option[] }) {
  const today = new Date().toISOString().slice(0, 10);
  return (
    <Form
      schema={commissionRuleSchema}
      action={createCommissionRule}
      defaultValues={{ name: "", service_id: "", eligible_role_id: "", eligible_user_id: "", percent: "0", fixed_amount: "", currency: "USD", effective_from: today, effective_to: "", notes: "" }}
      submitLabel="Create rule (pending approval)"
      successMessage="Rule created. Another manager must approve it before it applies."
      resetOnSuccess
    >
      <FormSection title="Rule">
        <TextField name="name" label="Name" required placeholder="e.g. Professional websites — 5%" className="sm:col-span-2" />
        <SelectField name="service_id" label="Service" options={services} placeholder="Any service" />
        <SelectField name="eligible_role_id" label="Eligible role" options={roles} placeholder="Any role" />
        <SelectField name="eligible_user_id" label="Specific person" options={people} placeholder="Anyone in the role" />
      </FormSection>
      <FormSection title="Amount" columns={3}>
        <TextField name="percent" label="Percent of deal value" inputMode="decimal" />
        <TextField name="fixed_amount" label="Fixed amount" inputMode="decimal" />
        <SelectField name="currency" label="Fixed amount currency" options={CURRENCIES.map((c) => ({ value: c, label: c }))} />
      </FormSection>
      <FormSection title="Validity">
        <TextField name="effective_from" label="Effective from" type="date" required />
        <TextField name="effective_to" label="Effective until" type="date" hint="Leave empty for open-ended" />
        <TextAreaField name="notes" label="Notes" rows={2} className="sm:col-span-2" />
      </FormSection>
    </Form>
  );
}
