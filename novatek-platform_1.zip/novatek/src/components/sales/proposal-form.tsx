"use client";

import { Form, FormSection, SelectField, TextAreaField, TextField, type Option } from "@/components/forms/form";
import { CURRENCIES } from "@/lib/validation/common";
import { proposalSchema } from "@/lib/validation/sales";
import { createProposal, updateProposal } from "@/app/app/deals/actions";

export function ProposalForm({ dealId, proposalId, defaults, services }: {
  dealId?: string; proposalId?: string; defaults: Record<string, unknown>; services: Option[];
}) {
  const action = proposalId ? updateProposal.bind(null, proposalId) : createProposal.bind(null, dealId!);
  return (
    <Form
      schema={proposalSchema}
      action={action}
      defaultValues={defaults}
      submitLabel={proposalId ? "Save draft" : "Create draft proposal"}
      redirectTo={(data) => `/app/proposals/${proposalId ?? (data as { id: string }).id}`}
    >
      <FormSection title="Proposal">
        <TextField name="title" label="Title" required className="sm:col-span-2" />
        <SelectField name="service_id" label="Service" options={services} placeholder="—" />
        <TextField name="expiry_date" label="Valid until" type="date" hint="After this date the client link can no longer accept it" />
      </FormSection>
      <FormSection title="Price" columns={2}>
        <TextField name="price" label="Price" required inputMode="decimal" />
        <SelectField name="currency" label="Currency" options={CURRENCIES.map((c) => ({ value: c, label: c }))} />
      </FormSection>
      <FormSection title="Content" columns={1}>
        <TextAreaField name="scope" label="Scope of work" rows={8} placeholder="What's included, deliverables, assumptions…" />
        <TextAreaField name="timeline" label="Timeline" rows={3} placeholder="e.g. 6 weeks from kickoff: design (2), build (3), launch (1)" />
        <TextAreaField name="terms" label="Terms" rows={5} placeholder="Payment schedule, revisions, ownership, support…" />
      </FormSection>
    </Form>
  );
}
