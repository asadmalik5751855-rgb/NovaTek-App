"use client";

import { useOptimistic, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Alert, Button, Input } from "@/components/ui/primitives";
import { cn, formatDate, formatMoney } from "@/lib/utils";
import { markDealLost, markDealWon, moveDealStage } from "@/app/app/deals/actions";

export type BoardDeal = {
  id: string; name: string; value: number; currency: string; probability: number; forecast_value: number;
  stage_id: string; owner_id: string | null; expected_close_date: string | null; company: string | null;
};
type Stage = { id: string; name: string; is_won: boolean; is_lost: boolean; default_probability: number };

function sum(deals: BoardDeal[], key: "value" | "forecast_value") {
  const by = new Map<string, number>();
  for (const d of deals) by.set(d.currency, (by.get(d.currency) ?? 0) + Number(d[key]));
  return [...by.entries()].map(([c, v]) => formatMoney(v, c)).join(" + ") || "—";
}

export function DealBoard({ stages, deals, people, canEdit }: {
  stages: Stage[]; deals: BoardDeal[]; people: Record<string, string>; canEdit: Record<string, boolean>;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [over, setOver] = useState<string | null>(null);
  const [closing, setClosing] = useState<{ deal: BoardDeal; stage: Stage } | null>(null);
  const [input, setInput] = useState("");
  const [optimistic, move] = useOptimistic(deals, (state, m: { id: string; stage: string }) =>
    state.map((d) => (d.id === m.id ? { ...d, stage_id: m.stage } : d)));
  const editable = (d: BoardDeal) => Boolean(canEdit[d.id]);

  const drop = (id: string, stage: Stage) => {
    const deal = optimistic.find((d) => d.id === id);
    if (!deal || deal.stage_id === stage.id || !editable(deal)) return;
    setError(null);
    if (stage.is_won || stage.is_lost) {
      setInput(stage.is_won ? String(deal.value) : "");
      setClosing({ deal, stage });
      return;
    }
    start(async () => {
      move({ id, stage: stage.id });
      const r = await moveDealStage(id, stage.id);
      if (!r.ok) setError(`${deal.name}: ${r.error}`);
      router.refresh();
    });
  };

  const confirmClose = () => {
    if (!closing) return;
    const { deal, stage } = closing;
    start(async () => {
      const r = stage.is_won ? await markDealWon(deal.id, input) : await markDealLost(deal.id, input);
      if (!r.ok) { setError(`${deal.name}: ${r.error}`); return; }
      setClosing(null);
      router.refresh();
    });
  };

  return (
    <div className="space-y-3">
      {error && <Alert tone="error">{error}</Alert>}
      {closing && (
        <div className="rounded-xl border border-accent/40 bg-surface p-4 shadow-card" role="dialog" aria-label={closing.stage.is_won ? "Mark deal won" : "Mark deal lost"}>
          <p className="text-sm font-semibold">{closing.stage.is_won ? "Mark as won" : "Mark as lost"}: {closing.deal.name}</p>
          <p className="mt-1 text-xs text-text-3">
            {closing.stage.is_won
              ? "Confirms the final value. The lead moves to Won, a client record is created or reused, and commission is calculated from approved rules."
              : "Record why it was lost. This is kept on the lead's timeline for future analysis."}
          </p>
          <div className="mt-3 flex flex-col gap-2 sm:flex-row">
            <Input
              aria-label={closing.stage.is_won ? "Final value" : "Reason lost"}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              inputMode={closing.stage.is_won ? "decimal" : "text"}
              placeholder={closing.stage.is_won ? "Final value" : "e.g. Chose a cheaper vendor"}
              className="sm:max-w-xs"
            />
            <Button variant={closing.stage.is_won ? "brand" : "danger"} onClick={confirmClose} disabled={pending}>
              {pending && <Loader2 className="size-4 animate-spin" />} Confirm
            </Button>
            <Button variant="ghost" onClick={() => setClosing(null)} disabled={pending}>Cancel</Button>
          </div>
        </div>
      )}
      <div className="-mx-4 overflow-x-auto px-4 pb-4 sm:-mx-6 sm:px-6 lg:mx-0 lg:px-0">
        <div className="flex gap-3" style={{ minWidth: stages.length * 272 }}>
          {stages.map((s) => {
            const col = optimistic.filter((d) => d.stage_id === s.id);
            return (
              <section
                key={s.id}
                aria-label={s.name}
                onDragOver={(e) => { e.preventDefault(); setOver(s.id); }}
                onDragLeave={() => setOver((o) => (o === s.id ? null : o))}
                onDrop={(e) => { e.preventDefault(); setOver(null); const id = e.dataTransfer.getData("text/deal-id"); if (id) drop(id, s); }}
                className={cn("flex w-64 shrink-0 flex-col rounded-xl border bg-surface-2/40 transition-colors",
                  over === s.id ? "border-accent bg-accent/5" : "border-border")}
              >
                <header className="border-b border-border px-3 py-2.5">
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-semibold">{s.name}</h2>
                    <span className="rounded bg-surface px-1.5 text-xs tabular-nums text-text-3">{col.length}</span>
                  </div>
                  <p className="mt-0.5 truncate text-xs text-text-3" title="Stage value">{sum(col, "value")}</p>
                  {!s.is_won && !s.is_lost && (
                    <p className="truncate text-[11px] text-text-3" title="Forecast = value × probability">Forecast {sum(col, "forecast_value")}</p>
                  )}
                </header>
                <ul className="flex min-h-24 flex-1 flex-col gap-2 p-2">
                  {col.map((d) => (
                    <li
                      key={d.id}
                      draggable={editable(d) && !s.is_won}
                      onDragStart={(e) => { e.dataTransfer.setData("text/deal-id", d.id); e.dataTransfer.effectAllowed = "move"; }}
                      className={cn("rounded-lg border border-border bg-surface p-3 shadow-card", editable(d) && !s.is_won && "cursor-grab active:cursor-grabbing")}
                    >
                      <Link href={`/app/deals/${d.id}`} className="block text-sm font-medium hover:text-accent">{d.name}</Link>
                      {d.company && <p className="truncate text-xs text-text-3">{d.company}</p>}
                      <div className="mt-2 flex items-center justify-between text-xs">
                        <span className="tabular-nums font-medium">{formatMoney(d.value, d.currency)}</span>
                        <span className="tabular-nums text-text-3">{d.probability}%</span>
                      </div>
                      <div className="mt-1 flex items-center justify-between text-[11px] text-text-3">
                        <span className="truncate">{d.owner_id ? people[d.owner_id] ?? "—" : "No owner"}</span>
                        {d.expected_close_date && <span>{formatDate(d.expected_close_date, { year: undefined })}</span>}
                      </div>
                      {editable(d) && !s.is_won && !s.is_lost && (
                        <select
                          aria-label={`Move ${d.name} to stage`}
                          className="mt-2 w-full rounded-md border border-border bg-surface px-2 py-1 text-xs text-text-2"
                          value={d.stage_id}
                          onChange={(e) => { const st = stages.find((x) => x.id === e.target.value); if (st) drop(d.id, st); }}
                        >
                          {stages.map((x) => <option key={x.id} value={x.id}>Move to: {x.name}</option>)}
                        </select>
                      )}
                    </li>
                  ))}
                  {col.length === 0 && <li className="grid flex-1 place-items-center py-6 text-xs text-text-3">No deals</li>}
                </ul>
              </section>
            );
          })}
        </div>
      </div>
    </div>
  );
}
