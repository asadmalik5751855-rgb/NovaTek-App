"use client";

import { Form, FormSection, SelectField, TextAreaField, TextField, type Option } from "@/components/forms/form";
import { clientSchema } from "@/lib/validation/sales";
import { createClientRecord, updateClientRecord } from "@/app/app/clients/actions";

export function ClientForm({ clientId, defaults, industries, countries, people, canAssign }: {
  clientId?: string; defaults: Record<string, unknown>; industries: Option[]; countries: Option[]; people: Option[]; canAssign: boolean;
}) {
  return (
    <Form
      schema={clientSchema}
      action={clientId ? updateClientRecord.bind(null, clientId) : createClientRecord}
      defaultValues={defaults}
      submitLabel={clientId ? "Save changes" : "Create client"}
      redirectTo={(data) => `/app/clients/${clientId ?? (data as { id: string }).id}`}
    >
      <FormSection title="Company">
        <TextField name="company_name" label="Company name" required />
        <TextField name="website" label="Website" placeholder="example.com" />
        <SelectField name="industry_id" label="Industry" options={industries} placeholder="—" />
        <SelectField name="country_code" label="Country" options={countries} placeholder="—" />
        <TextField name="city" label="City" />
        <SelectField name="status" label="Status" options={[{ value: "active", label: "Active" }, { value: "inactive", label: "Inactive" }]} />
      </FormSection>
      <FormSection title="Primary contact">
        <TextField name="contact_name" label="Contact name" />
        <TextField name="email" label="Email" type="email" />
        <TextField name="phone" label="Phone" type="tel" />
        {canAssign && <SelectField name="account_manager_id" label="Account manager" options={people} placeholder="—" />}
      </FormSection>
      <FormSection title="Notes" columns={1}>
        <TextAreaField name="notes" label="Notes" rows={4} />
      </FormSection>
    </Form>
  );
}
