import { Progress } from "@/components/ui/status";
import { TARGET_METRIC } from "@/lib/labels";
import type { Target } from "@/lib/data/performance";
import { cn, dayKey, formatDate, formatMoney } from "@/lib/utils";

export function TargetRow({ t, person }: { t: Target; person?: string }) {
  const actual = t.actual ?? 0;
  const pct = t.target_value > 0 ? Math.round((actual / t.target_value) * 100) : 0;
  const today = dayKey(new Date());
  const status = t.period_end < today ? (pct >= 100 ? "Achieved" : "Missed") : t.period_start > today ? "Upcoming" : pct >= 100 ? "Achieved" : "In progress";
  const fmt = (v: number) => (t.metric === "revenue_won" && t.currency ? formatMoney(v, t.currency) : v.toLocaleString());
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-baseline justify-between gap-2 text-sm">
        <span className="font-medium">{TARGET_METRIC[t.metric as keyof typeof TARGET_METRIC]}{person && <span className="font-normal text-text-3"> · {person}</span>}</span>
        <span className="tabular-nums">
          {t.actual === null ? "—" : fmt(actual)} <span className="text-text-3">/ {fmt(t.target_value)}</span>
        </span>
      </div>
      <Progress value={pct} />
      <div className="flex justify-between text-xs text-text-3">
        <span>{formatDate(t.period_start)} – {formatDate(t.period_end)}</span>
        <span className={cn(status === "Achieved" && "text-success", status === "Missed" && "text-danger")}>{status} · {pct}%</span>
      </div>
    </div>
  );
}
