"use client";

import { Form, SelectField, TextAreaField, TextField, type Option } from "@/components/forms/form";
import { TARGET_METRIC, options } from "@/lib/labels";
import { CURRENCIES } from "@/lib/validation/common";
import { targetSchema } from "@/lib/validation/people";
import { createTarget } from "@/app/app/targets/actions";

export function TargetForm({ people, defaults }: { people: Option[]; defaults: Record<string, unknown> }) {
  return (
    <Form schema={targetSchema} action={createTarget} defaultValues={defaults} submitLabel="Save target" successMessage="Target saved." resetOnSuccess>
      <SelectField name="user_id" label="Person" options={people} placeholder="Choose…" required />
      <SelectField name="metric" label="Metric" options={options(TARGET_METRIC)} />
      <div className="grid grid-cols-2 gap-3">
        <TextField name="period_start" label="From" type="date" required />
        <TextField name="period_end" label="To" type="date" required />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <TextField name="target_value" label="Target" inputMode="decimal" required />
        <SelectField name="currency" label="Currency (revenue only)" options={CURRENCIES.map((c) => ({ value: c, label: c }))} />
      </div>
      <TextAreaField name="notes" label="Notes" rows={2} />
    </Form>
  );
}
