"use client";

import { useState, useTransition } from "react";
import { Loader2, Sparkles } from "lucide-react";
import { Alert, Button } from "@/components/ui/primitives";
import { CopyButton } from "@/components/ui/copy-button";
import { runAiAssist } from "@/app/app/ai/actions";

export function AiAssist({ entityId, features }: { entityId: string; features: { key: string; label: string }[] }) {
  const [pending, start] = useTransition();
  const [active, setActive] = useState<string | null>(null);
  const [result, setResult] = useState<{ text: string; model: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {features.map((f) => (
          <Button
            key={f.key}
            size="sm"
            variant="secondary"
            disabled={pending}
            onClick={() => {
              setActive(f.key);
              setError(null);
              setResult(null);
              start(async () => {
                const r = await runAiAssist({ feature: f.key, entityId });
                if (r.ok) setResult(r.data);
                else setError(r.error);
              });
            }}
          >
            {pending && active === f.key ? <Loader2 className="size-3.5 animate-spin" /> : <Sparkles className="size-3.5" />} {f.label}
          </Button>
        ))}
      </div>
      {error && <Alert tone="info">{error}</Alert>}
      {result && (
        <div className="space-y-2 rounded-lg border border-violet-500/30 bg-violet-500/5 p-3">
          <p className="flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wide text-violet-600 dark:text-violet-300">
            <Sparkles className="size-3" /> AI-generated draft · {result.model} · review before using
          </p>
          <p className="whitespace-pre-wrap text-sm">{result.text}</p>
          <CopyButton value={result.text} label="Copy draft" />
        </div>
      )}
    </div>
  );
}
