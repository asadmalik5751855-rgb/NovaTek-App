"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { AlertTriangle, CheckCircle2, Loader2, Upload } from "lucide-react";
import { Alert, Badge, Button } from "@/components/ui/primitives";
import { parseCsv } from "@/lib/csv";
import { previewImport, runImport, type PreviewRow } from "@/app/app/leads/import/actions";

const REQUIRED = ["company_name"];

export function ImportWizard({ columns }: { columns: string[] }) {
  const [rows, setRows] = useState<Record<string, string>[] | null>(null);
  const [preview, setPreview] = useState<PreviewRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [skip, setSkip] = useState(false);
  const [done, setDone] = useState<{ inserted: number; possible_duplicates: number; skipped: number } | null>(null);
  const [pending, start] = useTransition();

  const onFile = async (file: File | undefined) => {
    setError(null); setPreview(null); setRows(null); setDone(null);
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { setError("Files must be 5 MB or smaller."); return; }
    const table = parseCsv(await file.text());
    if (table.length < 2) { setError("The file needs a header row and at least one data row."); return; }
    const headers = table[0].map((h) => h.trim().toLowerCase().replace(/\s+/g, "_"));
    const unknown = headers.filter((h) => h && !columns.includes(h));
    const missing = REQUIRED.filter((r) => !headers.includes(r));
    if (missing.length) { setError(`Missing required column: ${missing.join(", ")}. Expected headers: ${columns.join(", ")}.`); return; }
    if (unknown.length) { setError(`Unknown column(s): ${unknown.join(", ")}. Allowed: ${columns.join(", ")}.`); return; }
    const data = table.slice(1).map((r) => Object.fromEntries(headers.map((h, i) => [h, (r[i] ?? "").trim()])));
    if (data.length > 2000) { setError("Import at most 2,000 rows at a time."); return; }
    setRows(data);
    start(async () => {
      const r = await previewImport(data);
      if (!r.ok) setError(r.error);
      else setPreview(r.data);
    });
  };

  const invalid = preview?.filter((p) => p.errors.length).length ?? 0;
  const dups = preview?.filter((p) => p.duplicate && !p.errors.length).length ?? 0;
  const valid = (preview?.length ?? 0) - invalid;

  if (done) {
    return (
      <Alert tone="success">
        Imported {done.inserted} lead{done.inserted === 1 ? "" : "s"} with source “Import”.
        {done.possible_duplicates > 0 && ` ${done.possible_duplicates} flagged as possible duplicates (nothing was merged).`}
        {done.skipped > 0 && ` ${done.skipped} invalid row(s) skipped as you chose.`} <Link href="/app/leads" className="underline">View leads</Link>
      </Alert>
    );
  }

  return (
    <div className="space-y-5">
      <label className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border border-dashed border-border-strong px-6 py-10 text-center hover:bg-surface-2/40">
        <Upload className="size-6 text-text-3" />
        <span className="text-sm font-medium">Choose a CSV file</span>
        <span className="text-xs text-text-3">Headers: {columns.join(", ")}</span>
        <input type="file" accept=".csv,text/csv" className="sr-only" aria-label="CSV file" onChange={(e) => onFile(e.target.files?.[0])} />
      </label>
      {pending && !preview && <p className="flex items-center gap-2 text-sm text-text-3"><Loader2 className="size-4 animate-spin" /> Validating every row on the server…</p>}
      {error && <Alert tone="error">{error}</Alert>}
      {preview && rows && (
        <>
          <div className="flex flex-wrap gap-2 text-sm">
            <Badge color="emerald"><CheckCircle2 className="size-3" /> {valid} valid</Badge>
            {invalid > 0 && <Badge color="rose"><AlertTriangle className="size-3" /> {invalid} with errors</Badge>}
            {dups > 0 && <Badge color="amber">{dups} possible duplicates (will be flagged, not merged)</Badge>}
          </div>
          <div className="max-h-[420px] overflow-auto rounded-xl border border-border">
            <table className="w-full min-w-[720px] text-xs">
              <thead className="sticky top-0 bg-surface-2 text-left text-text-3">
                <tr><th className="px-3 py-2">Row</th><th className="px-3 py-2">Company</th><th className="px-3 py-2">Contact</th><th className="px-3 py-2">Email</th><th className="px-3 py-2">Country</th><th className="px-3 py-2">Result</th></tr>
              </thead>
              <tbody className="divide-y divide-border">
                {preview.map((p) => (
                  <tr key={p.index} className={p.errors.length ? "bg-danger/5" : undefined}>
                    <td className="px-3 py-1.5 tabular-nums text-text-3">{p.index + 2}</td>
                    <td className="px-3 py-1.5">{rows[p.index].company_name}</td>
                    <td className="px-3 py-1.5">{rows[p.index].contact_name}</td>
                    <td className="px-3 py-1.5">{rows[p.index].email}</td>
                    <td className="px-3 py-1.5">{rows[p.index].country}</td>
                    <td className="px-3 py-1.5">{p.errors.length ? <span className="text-danger">{p.errors.join("; ")}</span> : p.duplicate ? <span className="text-warning">Possible duplicate</span> : <span className="text-success">OK</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {invalid > 0 && (
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" className="size-4 accent-[var(--accent)]" checked={skip} onChange={(e) => setSkip(e.target.checked)} />
              Skip the {invalid} row(s) with errors and import only valid rows
            </label>
          )}
          <Button
            variant="brand"
            disabled={pending || valid === 0 || (invalid > 0 && !skip)}
            onClick={() => start(async () => {
              setError(null);
              const r = await runImport(rows, skip);
              if (!r.ok) setError(r.error);
              else setDone(r.data);
            })}
          >
            {pending && <Loader2 className="size-4 animate-spin" />} Import {valid} lead{valid === 1 ? "" : "s"}
          </Button>
        </>
      )}
    </div>
  );
}
