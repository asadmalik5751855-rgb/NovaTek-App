"use client";

import { useOptimistic, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AlertTriangle } from "lucide-react";
import { Alert } from "@/components/ui/primitives";
import { TemperatureBadge } from "@/components/leads/badges";
import type { LeadListItem, LeadStatus } from "@/lib/leads/types";
import { cn, formatMoney } from "@/lib/utils";
import { changeLeadStatus } from "@/app/app/leads/actions";

function columnValue(leads: LeadListItem[]) {
  const byCurrency = new Map<string, number>();
  for (const l of leads) if (l.estimated_value !== null) byCurrency.set(l.currency, (byCurrency.get(l.currency) ?? 0) + Number(l.estimated_value));
  return [...byCurrency.entries()].map(([c, v]) => formatMoney(v, c)).join(" + ") || "—";
}

export function PipelineBoard({
  statuses,
  leads,
  people,
  canEdit,
}: {
  statuses: LeadStatus[];
  leads: LeadListItem[];
  people: Record<string, string>;
  canEdit: boolean;
}) {
  const router = useRouter();
  const [, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [optimistic, move] = useOptimistic(leads, (state, m: { id: string; status: string }) =>
    state.map((l) => (l.id === m.id ? { ...l, status_id: m.status } : l)),
  );

  const moveLead = (id: string, status: string) => {
    const lead = optimistic.find((l) => l.id === id);
    if (!lead || lead.status_id === status) return;
    setError(null);
    start(async () => {
      move({ id, status });
      const res = await changeLeadStatus(id, status);
      if (!res.ok) setError(`${lead.company_name}: ${res.error}`); // optimistic state reverts automatically
      router.refresh();
    });
  };

  const won = optimistic.filter((l) => statuses.find((s) => s.id === l.status_id)?.is_won).length;
  const lost = optimistic.filter((l) => {
    const s = statuses.find((x) => x.id === l.status_id);
    return s?.is_closed && !s.is_won;
  }).length;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm text-text-3">
        <span><strong className="text-text">{optimistic.length}</strong> leads on board</span>
        <span>
          Win rate of closed:{" "}
          <strong className="text-text">{won + lost > 0 ? `${Math.round((won / (won + lost)) * 100)}%` : "—"}</strong>
          {won + lost > 0 && <span> ({won} won / {lost} lost)</span>}
        </span>
      </div>
      {error && <Alert tone="error">{error}</Alert>}

      <div className="-mx-4 overflow-x-auto px-4 pb-4 sm:-mx-6 sm:px-6 lg:mx-0 lg:px-0">
        <div className="flex gap-3" style={{ minWidth: statuses.length * 272 }}>
          {statuses.map((s) => {
            const col = optimistic.filter((l) => l.status_id === s.id);
            return (
              <section
                key={s.id}
                aria-label={s.name}
                onDragOver={(e) => {
                  if (!canEdit) return;
                  e.preventDefault();
                  setDragOver(s.id);
                }}
                onDragLeave={() => setDragOver((d) => (d === s.id ? null : d))}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragOver(null);
                  const id = e.dataTransfer.getData("text/lead-id");
                  if (id) moveLead(id, s.id);
                }}
                className={cn(
                  "flex w-64 shrink-0 flex-col rounded-xl border bg-surface-2/40 transition-colors",
                  dragOver === s.id ? "border-accent bg-accent/5" : "border-border",
                )}
              >
                <header className="border-b border-border px-3 py-2.5">
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-semibold">{s.name}</h2>
                    <span className="rounded bg-surface px-1.5 text-xs tabular-nums text-text-3">{col.length}</span>
                  </div>
                  <p className="mt-0.5 truncate text-xs text-text-3" title="Sum of estimated values">{columnValue(col)}</p>
                </header>
                <ul className="flex min-h-24 flex-1 flex-col gap-2 p-2">
                  {col.map((l) => (
                    <li
                      key={l.id}
                      draggable={canEdit}
                      onDragStart={(e) => {
                        e.dataTransfer.setData("text/lead-id", l.id);
                        e.dataTransfer.effectAllowed = "move";
                      }}
                      className={cn("rounded-lg border border-border bg-surface p-3 shadow-card", canEdit && "cursor-grab active:cursor-grabbing")}
                    >
                      <Link href={`/app/leads/${l.id}`} className="block text-sm font-medium hover:text-accent">
                        {l.company_name}
                      </Link>
                      <div className="mt-2 flex flex-wrap items-center gap-1.5">
                        <TemperatureBadge temperature={l.temperature} score={l.score} />
                        {l.possible_duplicate_of && <AlertTriangle className="size-3.5 text-warning" aria-label="Possible duplicate" />}
                      </div>
                      <div className="mt-2 flex items-center justify-between text-xs text-text-3">
                        <span className="truncate">{l.assigned_to ? people[l.assigned_to] ?? "—" : "Unassigned"}</span>
                        <span className="tabular-nums">{l.estimated_value !== null ? formatMoney(l.estimated_value, l.currency) : ""}</span>
                      </div>
                      {canEdit && (
                        <select
                          aria-label={`Move ${l.company_name} to stage`}
                          className="mt-2 w-full rounded-md border border-border bg-surface px-2 py-1 text-xs text-text-2"
                          value={l.status_id}
                          onChange={(e) => moveLead(l.id, e.target.value)}
                        >
                          {statuses.map((x) => <option key={x.id} value={x.id}>Move to: {x.name}</option>)}
                        </select>
                      )}
                    </li>
                  ))}
                  {col.length === 0 && <li className="grid flex-1 place-items-center py-6 text-xs text-text-3">No leads</li>}
                </ul>
              </section>
            );
          })}
        </div>
      </div>
    </div>
  );
}
