"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2 } from "lucide-react";
import { Alert, Button, Field, Input, Select, Textarea } from "@/components/ui/primitives";
import { createLeadSchema, leadFieldsSchema, type CreateLeadInput } from "@/lib/validation/leads";
import { BUDGET_RANGES, BUSINESS_SIZES, type Country, type DirectoryUser, type Lookup, type LeadStatus } from "@/lib/leads/types";
import { createLead, updateLead } from "@/app/app/leads/actions";

type Props = {
  mode: "create" | "edit";
  leadId?: string;
  defaults: Partial<Record<keyof CreateLeadInput, string>>;
  lookups: {
    statuses: LeadStatus[];
    sources: Lookup[];
    services: Lookup[];
    industries: Lookup[];
    countries: Country[];
    people: DirectoryUser[];
  };
  canAssign: boolean;
  currentUserId: string;
};

export function LeadForm({ mode, leadId, defaults, lookups, canAssign, currentUserId }: Props) {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const schema = mode === "create" ? createLeadSchema : leadFieldsSchema;
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
  } = useForm<Record<string, string>>({
    resolver: zodResolver(schema) as never,
    defaultValues: { currency: "USD", ...defaults } as Record<string, string>,
  });

  const onSubmit = handleSubmit((values) => {
    setServerError(null);
    startTransition(async () => {
      const res = mode === "create" ? await createLead(values) : await updateLead(leadId!, values);
      if (!res.ok) {
        setServerError(res.error);
        if (res.fieldErrors)
          for (const [k, v] of Object.entries(res.fieldErrors)) if (v?.[0]) setError(k, { message: v[0] });
        return;
      }
      const id = mode === "create" && res.data ? (res.data as { id: string }).id : leadId!;
      router.push(`/app/leads/${id}`);
      router.refresh();
    });
  });

  const err = (k: string) => errors[k]?.message as string | undefined;
  const reg = (k: string) => ({ ...register(k), "aria-invalid": Boolean(errors[k]) || undefined, id: k });

  return (
    <form onSubmit={onSubmit} className="space-y-8" noValidate>
      {serverError && <Alert tone="error">{serverError}</Alert>}

      <section className="grid gap-4 sm:grid-cols-2">
        <h2 className="text-sm font-semibold sm:col-span-2">Company</h2>
        <Field label="Company name" htmlFor="company_name" error={err("company_name")} required>
          <Input {...reg("company_name")} autoComplete="organization" />
        </Field>
        <Field label="Website" htmlFor="website" error={err("website")} hint="Used to detect duplicates">
          <Input {...reg("website")} placeholder="example.com" inputMode="url" />
        </Field>
        <Field label="Industry" htmlFor="industry_id" error={err("industry_id")}>
          <Select {...reg("industry_id")}>
            <option value="">—</option>
            {lookups.industries.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}
          </Select>
        </Field>
        <Field label="Business size" htmlFor="business_size" error={err("business_size")}>
          <Select {...reg("business_size")}>
            <option value="">—</option>
            {BUSINESS_SIZES.map((b) => <option key={b.value} value={b.value}>{b.label}</option>)}
          </Select>
        </Field>
        <Field label="Country" htmlFor="country_code" error={err("country_code")}>
          <Select {...reg("country_code")}>
            <option value="">—</option>
            {lookups.countries.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
          </Select>
        </Field>
        <Field label="City" htmlFor="city" error={err("city")}>
          <Input {...reg("city")} />
        </Field>
      </section>

      <section className="grid gap-4 sm:grid-cols-2">
        <h2 className="text-sm font-semibold sm:col-span-2">Contact</h2>
        <Field label="Contact name" htmlFor="contact_name" error={err("contact_name")}>
          <Input {...reg("contact_name")} autoComplete="off" />
        </Field>
        <Field label="Business email" htmlFor="email" error={err("email")}>
          <Input {...reg("email")} type="email" autoComplete="off" />
        </Field>
        <Field label="Business phone" htmlFor="phone" error={err("phone")}>
          <Input {...reg("phone")} type="tel" autoComplete="off" />
        </Field>
      </section>

      <section className="grid gap-4 sm:grid-cols-2">
        <h2 className="text-sm font-semibold sm:col-span-2">Opportunity</h2>
        <Field label="Service interest" htmlFor="service_id" error={err("service_id")}>
          <Select {...reg("service_id")}>
            <option value="">—</option>
            {lookups.services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
        </Field>
        <Field label="Stated budget" htmlFor="budget_range" error={err("budget_range")}>
          <Select {...reg("budget_range")}>
            <option value="">—</option>
            {BUDGET_RANGES.map((b) => <option key={b.value} value={b.value}>{b.label}</option>)}
          </Select>
        </Field>
        <div className="grid grid-cols-3 gap-2">
          <Field label="Estimated value" htmlFor="estimated_value" error={err("estimated_value")} className="col-span-2">
            <Input {...reg("estimated_value")} inputMode="decimal" placeholder="0" />
          </Field>
          <Field label="Currency" htmlFor="currency" error={err("currency")}>
            <Select {...reg("currency")}>
              {["USD", "PKR", "AED", "EUR", "GBP", "SAR"].map((c) => <option key={c}>{c}</option>)}
            </Select>
          </Field>
        </div>
        {mode === "create" && (
          <>
            <Field label="Source" htmlFor="source_id" error={err("source_id")} required>
              <Select {...reg("source_id")}>
                <option value="">Choose…</option>
                {lookups.sources.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </Select>
            </Field>
            <Field label="Status" htmlFor="status_id" error={err("status_id")} required>
              <Select {...reg("status_id")}>
                {lookups.statuses.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </Select>
            </Field>
            <Field label="Assign to" htmlFor="assigned_to" error={err("assigned_to")}>
              <Select {...reg("assigned_to")}>
                <option value="">Unassigned</option>
                {(canAssign ? lookups.people : lookups.people.filter((p) => p.id === currentUserId)).map((p) => (
                  <option key={p.id} value={p.id}>{p.id === currentUserId ? `Me (${p.full_name || "you"})` : p.full_name}</option>
                ))}
              </Select>
            </Field>
          </>
        )}
        <Field label="Source reference" htmlFor="source_reference" error={err("source_reference")} hint="Where this lead came from (URL, referrer name…)" className="sm:col-span-2">
          <Input {...reg("source_reference")} />
        </Field>
        <Field label="Notes / requirements" htmlFor="message" error={err("message")} className="sm:col-span-2">
          <Textarea {...reg("message")} rows={4} />
        </Field>
      </section>

      <div className="flex justify-end gap-2 border-t border-border pt-5">
        <Button variant="secondary" onClick={() => router.back()} disabled={pending}>Cancel</Button>
        <Button type="submit" variant="brand" disabled={pending}>
          {pending && <Loader2 className="size-4 animate-spin" />}
          {mode === "create" ? "Create lead" : "Save changes"}
        </Button>
      </div>
    </form>
  );
}
