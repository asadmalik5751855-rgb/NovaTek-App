"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Alert, Button, Input, Select, Textarea } from "@/components/ui/primitives";
import { updateQualification } from "@/app/app/leads/actions";

export type Question = { key: string; label: string; type: "text" | "longtext" | "yesno" | "choice"; options?: string[] };

export function QualificationForm({ leadId, questions, answers, canEdit }: {
  leadId: string; questions: Question[]; answers: Record<string, string>; canEdit: boolean;
}) {
  const router = useRouter();
  const [values, setValues] = useState<Record<string, string>>(() => Object.fromEntries(questions.map((q) => [q.key, answers[q.key] ?? ""])));
  const [editing, setEditing] = useState(false);
  const [pending, start] = useTransition();
  const [msg, setMsg] = useState<{ tone: "error" | "success"; text: string } | null>(null);
  const answered = questions.filter((q) => answers[q.key]).length;

  if (!editing) {
    return (
      <div className="space-y-3">
        <p className="text-xs text-text-3">{answered} of {questions.length} answered</p>
        {answered > 0 && (
          <dl className="space-y-2 text-sm">
            {questions.filter((q) => answers[q.key]).map((q) => (
              <div key={q.key}>
                <dt className="text-xs text-text-3">{q.label}</dt>
                <dd className="whitespace-pre-wrap">{answers[q.key]}</dd>
              </div>
            ))}
          </dl>
        )}
        {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
        {canEdit && <Button size="sm" variant="secondary" onClick={() => setEditing(true)}>{answered ? "Edit answers" : "Qualify this lead"}</Button>}
      </div>
    );
  }

  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        setMsg(null);
        start(async () => {
          const r = await updateQualification(leadId, values);
          if (!r.ok) { setMsg({ tone: "error", text: r.error }); return; }
          setEditing(false);
          setMsg({ tone: "success", text: "Saved to the lead and its timeline." });
          router.refresh();
        });
      }}
    >
      {questions.map((q) => {
        const id = `q-${q.key}`;
        const set = (v: string) => setValues((s) => ({ ...s, [q.key]: v }));
        return (
          <label key={q.key} htmlFor={id} className="block space-y-1">
            <span className="text-sm font-medium">{q.label}</span>
            {q.type === "longtext" ? (
              <Textarea id={id} value={values[q.key]} onChange={(e) => set(e.target.value)} maxLength={2000} />
            ) : q.type === "yesno" || q.type === "choice" ? (
              <Select id={id} value={values[q.key]} onChange={(e) => set(e.target.value)}>
                <option value="">—</option>
                {(q.type === "yesno" ? ["Yes", "No"] : q.options ?? []).map((o) => <option key={o}>{o}</option>)}
              </Select>
            ) : (
              <Input id={id} value={values[q.key]} onChange={(e) => set(e.target.value)} maxLength={2000} />
            )}
          </label>
        );
      })}
      {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
      <div className="flex gap-2">
        <Button type="submit" size="sm" variant="brand" disabled={pending}>{pending && <Loader2 className="size-4 animate-spin" />} Save</Button>
        <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>Cancel</Button>
      </div>
    </form>
  );
}
