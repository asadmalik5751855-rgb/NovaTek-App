import {
  Archive,
  ArchiveRestore,
  Building2,
  CalendarX,
  ClipboardCheck,
  FileText,
  Handshake,
  ListChecks,
  ThumbsDown,
  Trophy,
  ArrowRightLeft,
  CalendarClock,
  GitMerge,
  Mail,
  MessageSquare,
  Pencil,
  Phone,
  PlusCircle,
  StickyNote,
  UserCheck,
  UserMinus,
  Users,
  type LucideIcon,
} from "lucide-react";
import type { LeadActivity } from "@/lib/leads/types";
import { formatDateTime, timeAgo } from "@/lib/utils";

const ICON: Record<string, LucideIcon> = {
  created: PlusCircle,
  assigned: UserCheck,
  unassigned: UserMinus,
  status_change: ArrowRightLeft,
  note: StickyNote,
  call: Phone,
  email: Mail,
  message: MessageSquare,
  meeting: Users,
  follow_up: CalendarClock,
  archived: Archive,
  restored: ArchiveRestore,
  merged: GitMerge,
  updated: Pencil,
  deal: Handshake,
  deal_won: Trophy,
  deal_lost: ThumbsDown,
  proposal: FileText,
  converted: Building2,
  meeting_scheduled: CalendarClock,
  meeting_cancelled: CalendarX,
  task: ListChecks,
  qualification: ClipboardCheck,
};

function describe(a: LeadActivity, name: (id: unknown) => string) {
  const m = a.metadata as Record<string, unknown>;
  switch (a.type) {
    case "created":
      return `created the lead${m.source ? ` (source: ${m.source})` : ""}`;
    case "assigned":
      return `assigned it to ${name(m.to)}`;
    case "unassigned":
      return `removed the assignee (${name(m.from)})`;
    case "status_change":
      return `moved it from ${m.from ?? "—"} to ${m.to ?? "—"}`;
    case "note":
      return "added a note";
    case "call":
      return "logged a call";
    case "email":
      return "logged an email";
    case "message":
      return "logged a message";
    case "meeting":
      return "logged a meeting";
    case "archived":
      return "archived the lead";
    case "restored":
      return "restored the lead";
    case "merged":
      return m.merged_lead_id ? `merged “${m.merged_company ?? "a duplicate"}” into this lead` : "merged this lead into another";
    case "deal":
      return "created a deal";
    case "deal_won":
      return "marked the deal won";
    case "deal_lost":
      return "marked the deal lost";
    case "proposal":
      return "updated a proposal";
    case "converted":
      return m.new_client ? "converted the lead to a client" : "linked the lead to an existing client";
    case "meeting_scheduled":
      return `scheduled a meeting${m.starts_at ? ` for ${formatDateTime(String(m.starts_at))}` : ""}`;
    case "meeting_cancelled":
      return m.status === "no_show" ? "recorded a no-show" : "cancelled a meeting";
    case "task":
      return `created a task${m.assignee_id ? ` for ${name(m.assignee_id)}` : ""}`;
    case "qualification":
      return "updated qualification answers";
    case "updated":
      return `updated ${Array.isArray(m.fields) ? (m.fields as string[]).map((f) => f.replace(/_/g, " ")).join(", ") : "details"}`;
    default:
      return a.type.replace(/_/g, " ");
  }
}

export function Timeline({ activities, people }: { activities: LeadActivity[]; people: Map<string, string> }) {
  const name = (id: unknown) => (typeof id === "string" ? people.get(id) ?? "a former user" : "—");
  if (!activities.length) return <p className="px-5 py-6 text-sm text-text-3">No activity yet.</p>;
  return (
    <ol className="relative space-y-5 px-5 py-5">
      <span className="absolute bottom-5 left-[33px] top-5 w-px bg-border" aria-hidden />
      {activities.map((a) => {
        const Icon = ICON[a.type] ?? Pencil;
        const actor = a.actor_id
          ? people.get(a.actor_id) ?? "A former user"
          : a.type === "created" ? "Website form" : a.type === "proposal" ? "Client" : "System";
        return (
          <li key={a.id} className="relative flex gap-3">
            <span className="relative z-10 grid size-7 shrink-0 place-items-center rounded-full border border-border bg-surface text-text-2">
              <Icon className="size-3.5" />
            </span>
            <div className="min-w-0 flex-1 pt-0.5">
              <p className="text-sm">
                <span className="font-medium">{actor}</span> <span className="text-text-2">{describe(a, name)}</span>
              </p>
              <time dateTime={a.created_at} title={formatDateTime(a.created_at)} className="text-xs text-text-3">
                {timeAgo(a.created_at)}
              </time>
              {a.body && <p className="mt-2 whitespace-pre-wrap rounded-lg border border-border bg-surface-2/50 px-3 py-2 text-sm text-text-2">{a.body}</p>}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
