import { Flame } from "lucide-react";
import { Badge } from "@/components/ui/primitives";
import { TEMPERATURE_LABEL, type Temperature } from "@/lib/leads/normalize";
import { TEMPERATURE_COLOR, type LeadStatus } from "@/lib/leads/types";

export function StatusBadge({ status }: { status: LeadStatus | undefined }) {
  if (!status) return <Badge>Unknown</Badge>;
  return <Badge color={status.color}>{status.name}</Badge>;
}

export function TemperatureBadge({ temperature, score }: { temperature: Temperature; score: number }) {
  return (
    <Badge color={TEMPERATURE_COLOR[temperature]}>
      {(temperature === "hot" || temperature === "very_hot") && <Flame className="size-3" />}
      {TEMPERATURE_LABEL[temperature]} · {score}
    </Badge>
  );
}
