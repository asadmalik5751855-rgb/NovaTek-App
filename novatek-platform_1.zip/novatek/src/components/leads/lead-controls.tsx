"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Archive, ArchiveRestore, Loader2, Mail, MessageSquare, Phone, StickyNote, Users } from "lucide-react";
import { Alert, Button, Input, Select, Textarea } from "@/components/ui/primitives";
import type { DirectoryUser, LeadStatus } from "@/lib/leads/types";
import { cn } from "@/lib/utils";
import {
  addLeadActivity,
  assignLead,
  changeLeadStatus,
  dismissDuplicate,
  setFollowUp,
  setLeadArchived,
} from "@/app/app/leads/actions";

type Result = { ok: true } | { ok: false; error: string };

function useAction() {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const run = (fn: () => Promise<Result>, onOk?: () => void) => {
    setError(null);
    start(async () => {
      const r = await fn();
      if (!r.ok) setError(r.error);
      else {
        onOk?.();
        router.refresh();
      }
    });
  };
  return { pending, error, run };
}

export function StatusControl({ leadId, value, statuses, disabled }: { leadId: string; value: string; statuses: LeadStatus[]; disabled?: boolean }) {
  const { pending, error, run } = useAction();
  return (
    <div className="space-y-2">
      <Select
        aria-label="Lead status"
        defaultValue={value}
        disabled={disabled || pending}
        onChange={(e) => run(() => changeLeadStatus(leadId, e.target.value))}
      >
        {statuses.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
      </Select>
      {error && <Alert tone="error">{error}</Alert>}
    </div>
  );
}

export function AssignControl({ leadId, value, people }: { leadId: string; value: string | null; people: DirectoryUser[] }) {
  const { pending, error, run } = useAction();
  return (
    <div className="space-y-2">
      <Select
        aria-label="Assigned to"
        defaultValue={value ?? ""}
        disabled={pending}
        onChange={(e) => run(() => assignLead(leadId, e.target.value || null))}
      >
        <option value="">Unassigned</option>
        {people.map((p) => <option key={p.id} value={p.id}>{p.full_name || "Unnamed user"}</option>)}
      </Select>
      {error && <Alert tone="error">{error}</Alert>}
    </div>
  );
}

const ACTIVITY_TYPES = [
  { value: "note", label: "Note", icon: StickyNote },
  { value: "call", label: "Call", icon: Phone },
  { value: "email", label: "Email", icon: Mail },
  { value: "message", label: "Message", icon: MessageSquare },
  { value: "meeting", label: "Meeting", icon: Users },
] as const;

export function ActivityComposer({ leadId }: { leadId: string }) {
  const { pending, error, run } = useAction();
  const [type, setType] = useState<(typeof ACTIVITY_TYPES)[number]["value"]>("note");
  const [body, setBody] = useState("");
  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        run(() => addLeadActivity(leadId, { type, body }), () => setBody(""));
      }}
    >
      <div className="flex flex-wrap gap-1" role="radiogroup" aria-label="Activity type">
        {ACTIVITY_TYPES.map((t) => (
          <button
            key={t.value}
            type="button"
            role="radio"
            aria-checked={type === t.value}
            onClick={() => setType(t.value)}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs",
              type === t.value ? "border-accent bg-accent/10 text-text" : "border-border text-text-2 hover:bg-surface-2",
            )}
          >
            <t.icon className="size-3.5" /> {t.label}
          </button>
        ))}
      </div>
      <Textarea
        aria-label="Activity details"
        value={body}
        onChange={(e) => setBody(e.target.value)}
        placeholder={type === "note" ? "Add a note…" : `What happened on this ${type}?`}
        rows={3}
        maxLength={5000}
      />
      {error && <Alert tone="error">{error}</Alert>}
      <div className="flex justify-end">
        <Button type="submit" size="sm" disabled={pending || !body.trim()}>
          {pending && <Loader2 className="size-3.5 animate-spin" />} Log {type}
        </Button>
      </div>
    </form>
  );
}

function toLocalInput(iso: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function FollowUpForm({
  leadId,
  at,
  type,
  priority,
}: {
  leadId: string;
  at: string | null;
  type: string | null;
  priority: string | null;
}) {
  const { pending, error, run } = useAction();
  const [saved, setSaved] = useState(false);
  return (
    <form
      className="space-y-2"
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        const local = String(fd.get("at") ?? "");
        setSaved(false);
        run(
          () =>
            setFollowUp(leadId, {
              // Interpret the picker value in the user's local timezone.
              next_follow_up_at: local ? new Date(local).toISOString() : "",
              follow_up_type: fd.get("type"),
              follow_up_priority: fd.get("priority"),
            }),
          () => setSaved(true),
        );
      }}
    >
      <Input type="datetime-local" name="at" defaultValue={toLocalInput(at)} aria-label="Next follow-up" />
      <div className="grid grid-cols-2 gap-2">
        <Select name="type" defaultValue={type ?? ""} aria-label="Follow-up type">
          <option value="">Type</option>
          <option value="call">Call</option>
          <option value="email">Email</option>
          <option value="message">Message</option>
          <option value="meeting">Meeting</option>
          <option value="other">Other</option>
        </Select>
        <Select name="priority" defaultValue={priority ?? ""} aria-label="Priority">
          <option value="">Priority</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </Select>
      </div>
      {error && <Alert tone="error">{error}</Alert>}
      <div className="flex items-center justify-end gap-3">
        {saved && !pending && <span className="text-xs text-success">Saved</span>}
        <Button type="submit" size="sm" variant="secondary" disabled={pending}>
          {pending && <Loader2 className="size-3.5 animate-spin" />} Save follow-up
        </Button>
      </div>
    </form>
  );
}

export function ArchiveButton({ leadId, archived }: { leadId: string; archived: boolean }) {
  const { pending, error, run } = useAction();
  return (
    <div className="space-y-2">
      <Button
        variant={archived ? "secondary" : "ghost"}
        size="sm"
        className="w-full"
        disabled={pending}
        onClick={() => {
          if (!archived && !window.confirm("Archive this lead? It will be hidden from lists but its full history is kept and it can be restored.")) return;
          run(() => setLeadArchived(leadId, !archived));
        }}
      >
        {archived ? <ArchiveRestore className="size-4" /> : <Archive className="size-4" />}
        {archived ? "Restore lead" : "Archive lead"}
      </Button>
      {error && <Alert tone="error">{error}</Alert>}
    </div>
  );
}

export function DismissDuplicateButton({ leadId }: { leadId: string }) {
  const { pending, error, run } = useAction();
  return (
    <>
      <Button size="sm" variant="secondary" disabled={pending} onClick={() => run(() => dismissDuplicate(leadId))}>
        Not a duplicate
      </Button>
      {error && <span className="text-xs text-danger">{error}</span>}
    </>
  );
}
