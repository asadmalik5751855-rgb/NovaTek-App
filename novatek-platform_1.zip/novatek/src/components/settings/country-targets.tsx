"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/primitives";
import { setCountryTarget } from "@/app/app/settings/actions";

export function CountryTargets({ countries, canEdit }: { countries: { code: string; name: string; is_target: boolean }[]; canEdit: boolean }) {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const targets = countries.filter((c) => c.is_target);
  const list = useMemo(() => (q.trim().length < 1 ? [] : countries.filter((c) => c.name.toLowerCase().includes(q.toLowerCase()) && !c.is_target).slice(0, 8)), [q, countries]);
  const toggle = (code: string, v: boolean) => start(async () => {
    setError(null);
    const r = await setCountryTarget(code, v);
    if (!r.ok) setError(r.error);
    router.refresh();
  });
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {targets.length === 0 && <span className="text-sm text-text-3">No target countries.</span>}
        {targets.map((c) => (
          <span key={c.code} className="inline-flex items-center gap-1.5 rounded-md bg-surface-2 px-2 py-1 text-sm">
            {c.name}
            {canEdit && <button type="button" disabled={pending} onClick={() => toggle(c.code, false)} className="text-text-3 hover:text-danger" aria-label={`Remove ${c.name}`}>×</button>}
          </span>
        ))}
      </div>
      {canEdit && (
        <div>
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Add a country…" aria-label="Find a country" />
          {list.length > 0 && (
            <ul className="mt-1 rounded-lg border border-border">
              {list.map((c) => (
                <li key={c.code}><button type="button" disabled={pending} onClick={() => { toggle(c.code, true); setQ(""); }} className="w-full px-3 py-1.5 text-left text-sm hover:bg-surface-2">{c.name}</button></li>
              ))}
            </ul>
          )}
        </div>
      )}
      {error && <p className="text-sm text-danger">{error}</p>}
    </div>
  );
}
