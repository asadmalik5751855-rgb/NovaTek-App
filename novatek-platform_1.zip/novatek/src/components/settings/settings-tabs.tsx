import Link from "next/link";
import type { Session } from "@/lib/auth/session";
import { cn } from "@/lib/utils";

const TABS = [
  { href: "/app/settings", label: "Company & branding", check: "settings.manage" },
  { href: "/app/settings/crm", label: "CRM & sales", check: "crm.configure" },
  { href: "/app/settings/departments", label: "Departments", check: "employees.manage" },
  { href: "/app/settings/integrations", label: "Integrations", check: "settings.manage" },
  { href: "/app/settings/announcements", label: "Announcements", check: "settings.manage" },
  { href: "/app/settings/security", label: "Security", check: "settings.manage" },
] as const;

export function SettingsTabs({ session, active }: { session: Session; active: string }) {
  return (
    <nav aria-label="Settings sections" className="-mx-4 mb-6 flex gap-1 overflow-x-auto border-b border-border px-4 sm:mx-0 sm:px-0">
      {TABS.filter((t) => session.can(t.check)).map((t) => (
        <Link key={t.href} href={t.href} aria-current={active === t.href ? "page" : undefined}
          className={cn("-mb-px whitespace-nowrap border-b-2 px-3 py-2 text-sm", active === t.href ? "border-accent font-medium text-text" : "border-transparent text-text-3 hover:text-text")}>
          {t.label}
        </Link>
      ))}
    </nav>
  );
}
