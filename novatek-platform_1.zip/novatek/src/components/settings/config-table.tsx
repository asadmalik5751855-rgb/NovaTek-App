"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Check, Loader2, Plus } from "lucide-react";
import { Alert, Button, Input, Select } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";
import { saveConfigRow, type ConfigTable } from "@/app/app/settings/actions";

export type FieldSpec = {
  name: string;
  label: string;
  type: "text" | "number" | "checkbox" | "select";
  options?: { value: string; label: string }[];
  createOnly?: boolean;
  width?: string;
};

type Row = Record<string, unknown> & { __id: string };

function RowEditor({ table, fields, row, isNew, onDone }: { table: ConfigTable; fields: FieldSpec[]; row: Record<string, unknown>; isNew?: boolean; onDone?: () => void }) {
  const router = useRouter();
  const [values, setValues] = useState<Record<string, unknown>>(row);
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const dirty = fields.some((f) => values[f.name] !== row[f.name]);

  const save = () => {
    setError(null);
    setSaved(false);
    const payload = Object.fromEntries(fields.filter((f) => isNew || !f.createOnly).map((f) => [f.name, f.type === "checkbox" ? Boolean(values[f.name]) : String(values[f.name] ?? "")]));
    start(async () => {
      const r = await saveConfigRow(table, isNew ? null : String(row.__id), payload);
      if (!r.ok) {
        const fe = "fieldErrors" in r && r.fieldErrors ? Object.entries(r.fieldErrors).map(([k, v]) => `${fields.find((f) => f.name === k)?.label ?? k}: ${v?.[0]}`).join("; ") : "";
        setError(fe || r.error);
        return;
      }
      setSaved(true);
      onDone?.();
      router.refresh();
    });
  };

  return (
    <div className="space-y-1.5">
      <div className="flex flex-wrap items-end gap-2">
        {fields.map((f) => {
          if (f.createOnly && !isNew) {
            return (
              <div key={f.name} className={cn("min-w-0", f.width ?? (f.type === "checkbox" ? "w-12" : "w-32"))}>
                <span className="block text-[11px] text-text-3">{f.label}</span>
                <code className="block truncate py-2 text-xs text-text-2">{f.type === "checkbox" ? (row[f.name] ? "Yes" : "—") : String(row[f.name] ?? "")}</code>
              </div>
            );
          }
          const id = `${table}-${row.__id ?? "new"}-${f.name}`;
          if (f.type === "checkbox") {
            return (
              <label key={f.name} htmlFor={id} className="flex h-10 items-center gap-1.5 px-1 text-xs text-text-2">
                <input id={id} type="checkbox" className="size-4 accent-[var(--accent)]" checked={Boolean(values[f.name])}
                  onChange={(e) => setValues((v) => ({ ...v, [f.name]: e.target.checked }))} />
                {f.label}
              </label>
            );
          }
          return (
            <label key={f.name} htmlFor={id} className={cn("block min-w-0", f.width ?? "w-40")}>
              <span className="block text-[11px] text-text-3">{f.label}</span>
              {f.type === "select" ? (
                <Select id={id} value={String(values[f.name] ?? "")} onChange={(e) => setValues((v) => ({ ...v, [f.name]: e.target.value }))}>
                  {f.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </Select>
              ) : (
                <Input id={id} value={String(values[f.name] ?? "")} inputMode={f.type === "number" ? "numeric" : undefined}
                  onChange={(e) => setValues((v) => ({ ...v, [f.name]: e.target.value }))} />
              )}
            </label>
          );
        })}
        <Button size="sm" variant={isNew ? "brand" : "secondary"} onClick={save} disabled={pending || (!isNew && !dirty)} className="mb-1">
          {pending ? <Loader2 className="size-3.5 animate-spin" /> : isNew ? <Plus className="size-3.5" /> : saved && !dirty ? <Check className="size-3.5 text-success" /> : null}
          {isNew ? "Add" : "Save"}
        </Button>
      </div>
      {error && <Alert tone="error">{error}</Alert>}
    </div>
  );
}

export function ConfigTableEditor({ table, fields, rows, canEdit, canAdd = true, newDefaults }: {
  table: ConfigTable; fields: FieldSpec[]; rows: Row[]; canEdit: boolean; canAdd?: boolean; newDefaults: Record<string, unknown>;
}) {
  const [adding, setAdding] = useState(false);
  if (!canEdit) {
    return (
      <ul className="divide-y divide-border text-sm">
        {rows.map((r) => <li key={r.__id} className="px-5 py-2">{fields.filter((f) => f.type !== "checkbox").map((f) => String(r[f.name] ?? "")).join(" · ")}</li>)}
      </ul>
    );
  }
  return (
    <div className="divide-y divide-border">
      {rows.map((r) => (
        <div key={r.__id} className="px-5 py-3"><RowEditor table={table} fields={fields} row={r} /></div>
      ))}
      {canAdd && (
        <div className="px-5 py-3">
          {adding ? (
            <RowEditor table={table} fields={fields} row={{ __id: "new", ...newDefaults }} isNew onDone={() => setAdding(false)} />
          ) : (
            <Button size="sm" variant="ghost" onClick={() => setAdding(true)}><Plus className="size-3.5" /> Add</Button>
          )}
        </div>
      )}
    </div>
  );
}
