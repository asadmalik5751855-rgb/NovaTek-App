"use client";

import { useOptimistic, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { setRolePermission } from "@/app/app/settings/actions";

export function PermissionToggle({ roleId, permission, granted, disabled, label }: { roleId: string; permission: string; granted: boolean; disabled: boolean; label: string }) {
  const router = useRouter();
  const [, start] = useTransition();
  const [value, setValue] = useOptimistic(granted);
  const [error, setError] = useState<string | null>(null);
  return (
    <input
      type="checkbox"
      aria-label={label}
      title={error ?? label}
      checked={value}
      disabled={disabled}
      className={`size-4 accent-[var(--accent)] disabled:opacity-60 ${error ? "outline outline-2 outline-danger" : ""}`}
      onChange={(e) => {
        const next = e.target.checked;
        start(async () => {
          setValue(next);
          const r = await setRolePermission(roleId, permission, next);
          setError(r.ok ? null : r.error);
          router.refresh();
        });
      }}
    />
  );
}
