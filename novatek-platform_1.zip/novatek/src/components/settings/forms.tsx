"use client";

import { z } from "zod";
import { Form, SelectField, TextAreaField, TextField } from "@/components/forms/form";
import { saveBranding, saveQualificationQuestions, saveSecuritySettings, sendAnnouncement, createRole } from "@/app/app/settings/actions";

const any = z.object({}).passthrough();

export function BrandingForm({ defaults }: { defaults: Record<string, unknown> }) {
  return (
    <Form schema={any} action={saveBranding} defaultValues={defaults} submitLabel="Save branding" successMessage="Saved. The public website shows the new details.">
      <TextField name="tagline" label="Tagline" required />
      <div className="grid gap-4 sm:grid-cols-2">
        <TextField name="contact_email" label="Contact email" type="email" />
        <TextField name="contact_phone" label="Phone" type="tel" />
        <TextField name="whatsapp" label="WhatsApp number" placeholder="+92 …" />
        <TextField name="address" label="Address" />
        <TextField name="linkedin" label="LinkedIn URL" placeholder="https://…" />
        <TextField name="facebook" label="Facebook URL" placeholder="https://…" />
        <TextField name="instagram" label="Instagram URL" placeholder="https://…" />
        <TextField name="x" label="X / Twitter URL" placeholder="https://…" />
      </div>
      <TextField name="footer_note" label="Footer note" />
    </Form>
  );
}

export function QualificationQuestionsForm({ value }: { value: string }) {
  return (
    <Form schema={any} action={saveQualificationQuestions} defaultValues={{ questions: value }} submitLabel="Save questions" successMessage="Questions saved.">
      <TextAreaField name="questions" label="Questions" rows={9} className="font-mono"
        hint="One per line: key | label | type | options. Types: text, longtext, yesno, choice (options comma-separated)." />
    </Form>
  );
}

export function AnnouncementForm() {
  return (
    <Form schema={any} action={sendAnnouncement} defaultValues={{ title: "", body: "", priority: "normal" }} submitLabel="Send to everyone" successMessage="Sent to all active users." resetOnSuccess>
      <TextField name="title" label="Title" required />
      <TextAreaField name="body" label="Message" rows={4} />
      <SelectField name="priority" label="Priority" options={[{ value: "normal", label: "Normal" }, { value: "high", label: "High" }]} />
    </Form>
  );
}

export function SecurityForm({ minutes }: { minutes: number }) {
  return (
    <Form schema={any} action={saveSecuritySettings} defaultValues={{ reauth_minutes: String(minutes), password: "" }} submitLabel="Save" successMessage="Security settings saved.">
      <TextField name="reauth_minutes" label="Password re-confirmation window (minutes)" inputMode="numeric" hint="How recently a password must have been confirmed for exports" />
      <TextField name="password" label="Your password" type="password" autoComplete="current-password" required hint="Changing security settings requires re-authentication" />
    </Form>
  );
}

export function NewRoleForm() {
  return (
    <Form schema={any} action={createRole} defaultValues={{ key: "", name: "", description: "" }} submitLabel="Create role" successMessage="Role created. Grant it permissions below." resetOnSuccess>
      <div className="grid gap-4 sm:grid-cols-3">
        <TextField name="key" label="Key" placeholder="e.g. support_agent" required />
        <TextField name="name" label="Name" required />
        <TextField name="description" label="Description" />
      </div>
    </Form>
  );
}
