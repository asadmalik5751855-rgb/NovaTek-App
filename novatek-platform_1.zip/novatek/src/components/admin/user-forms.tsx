"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Alert, Button, Field, Input, Select } from "@/components/ui/primitives";
import { createUserAccount, setUserRoles, setUserStatus, updateEmployment } from "@/app/app/admin/users/actions";

type Role = { key: string; name: string; description: string | null; is_superuser: boolean };
type Dept = { id: string; name: string };

function useRun() {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [msg, setMsg] = useState<{ tone: "error" | "success" | "warning"; text: string } | null>(null);
  const run = (fn: () => Promise<{ ok: boolean; error?: string }>, success: string) => {
    setMsg(null);
    start(async () => {
      const r = await fn();
      setMsg(r.ok ? { tone: "success", text: success } : { tone: "error", text: r.error ?? "Failed" });
      if (r.ok) router.refresh();
    });
  };
  return { pending, msg, setMsg, run };
}

function RoleChecklist({ roles, selected, onToggle, canGrantSuper, disabled }: {
  roles: Role[]; selected: Set<string>; onToggle: (k: string) => void; canGrantSuper: boolean; disabled?: boolean;
}) {
  return (
    <fieldset className="grid gap-2 sm:grid-cols-2" disabled={disabled}>
      <legend className="sr-only">Roles</legend>
      {roles.map((r) => {
        const locked = r.is_superuser && !canGrantSuper;
        return (
          <label key={r.key} className={`flex gap-3 rounded-lg border border-border p-3 ${locked ? "opacity-50" : "cursor-pointer hover:bg-surface-2/50"}`}>
            <input type="checkbox" className="mt-0.5 accent-[var(--accent)]" checked={selected.has(r.key)} disabled={locked} onChange={() => onToggle(r.key)} />
            <span>
              <span className="block text-sm font-medium">{r.name}</span>
              {r.description && <span className="block text-xs text-text-3">{r.description}</span>}
            </span>
          </label>
        );
      })}
    </fieldset>
  );
}

export function RolesForm({ userId, roles, current, canGrantSuper, isSelf }: {
  userId: string; roles: Role[]; current: string[]; canGrantSuper: boolean; isSelf: boolean;
}) {
  const [selected, setSelected] = useState(new Set(current));
  const { pending, msg, run } = useRun();
  if (isSelf) return <Alert tone="info">You can’t change your own roles. Another administrator must do it.</Alert>;
  return (
    <div className="space-y-4">
      <RoleChecklist
        roles={roles}
        selected={selected}
        canGrantSuper={canGrantSuper}
        disabled={pending}
        onToggle={(k) => setSelected((s) => { const n = new Set(s); if (n.has(k)) n.delete(k); else n.add(k); return n; })}
      />
      {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
      <div className="flex justify-end">
        <Button
          variant="brand"
          disabled={pending}
          onClick={() => {
            if (!window.confirm("Update this user's roles? Their access changes immediately.")) return;
            run(() => setUserRoles(userId, [...selected]), "Roles updated.");
          }}
        >
          {pending && <Loader2 className="size-4 animate-spin" />} Save roles
        </Button>
      </div>
    </div>
  );
}

export function StatusForm({ userId, status, isSelf }: { userId: string; status: string; isSelf: boolean }) {
  const { pending, msg, run } = useRun();
  const disabled = status !== "active";
  if (isSelf) return <p className="text-sm text-text-3">You can’t disable your own account.</p>;
  return (
    <div className="space-y-3">
      <p className="text-sm text-text-2">
        {disabled ? "This account is disabled and cannot sign in or access any data." : "This account is active."}
      </p>
      {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
      <Button
        variant={disabled ? "brand" : "danger"}
        disabled={pending}
        onClick={() => {
          if (!disabled && !window.confirm("Disable this account? The user loses all access immediately. History is kept.")) return;
          run(() => setUserStatus(userId, disabled ? "active" : "disabled"), disabled ? "Account activated." : "Account disabled.");
        }}
      >
        {pending && <Loader2 className="size-4 animate-spin" />} {disabled ? "Activate account" : "Disable account"}
      </Button>
    </div>
  );
}

export function EmploymentForm({ userId, departments, values }: {
  userId: string; departments: Dept[]; values: { full_name: string; department_id: string; designation: string; joining_date: string; phone: string };
}) {
  const { pending, msg, run } = useRun();
  return (
    <form
      className="grid gap-4 sm:grid-cols-2"
      onSubmit={(e) => {
        e.preventDefault();
        const input = Object.fromEntries(new FormData(e.currentTarget));
        run(() => updateEmployment(userId, input), "Saved.");
      }}
    >
      <Field label="Full name" htmlFor="full_name" required><Input id="full_name" name="full_name" defaultValue={values.full_name} required /></Field>
      <Field label="Phone" htmlFor="phone"><Input id="phone" name="phone" type="tel" defaultValue={values.phone} /></Field>
      <Field label="Department" htmlFor="department_id">
        <Select id="department_id" name="department_id" defaultValue={values.department_id}>
          <option value="">—</option>
          {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </Select>
      </Field>
      <Field label="Designation" htmlFor="designation"><Input id="designation" name="designation" defaultValue={values.designation} /></Field>
      <Field label="Joining date" htmlFor="joining_date"><Input id="joining_date" name="joining_date" type="date" defaultValue={values.joining_date} /></Field>
      <div className="flex items-end justify-end gap-3 sm:col-span-2">
        {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
        <Button type="submit" variant="secondary" disabled={pending}>{pending && <Loader2 className="size-4 animate-spin" />} Save details</Button>
      </div>
    </form>
  );
}

export function CreateUserForm({ roles, departments, canGrantSuper }: { roles: Role[]; departments: Dept[]; canGrantSuper: boolean }) {
  const router = useRouter();
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[] | undefined>>({});
  return (
    <form
      className="space-y-6"
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        setError(null);
        setFieldErrors({});
        start(async () => {
          const r = await createUserAccount({ ...Object.fromEntries(fd), role_keys: [...selected] });
          if (!r.ok) {
            setError(r.error);
            setFieldErrors(r.fieldErrors ?? {});
            return;
          }
          if (r.data.warning) window.alert(r.data.warning);
          router.push(`/app/admin/users/${r.data.id}`);
        });
      }}
    >
      {error && <Alert tone="error">{error}</Alert>}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Full name" htmlFor="full_name" required error={fieldErrors.full_name?.[0]}><Input id="full_name" name="full_name" required /></Field>
        <Field label="Work email" htmlFor="email" required error={fieldErrors.email?.[0]}><Input id="email" name="email" type="email" required autoComplete="off" /></Field>
        <Field label="Initial password" htmlFor="password" required error={fieldErrors.password?.[0]} hint="12+ characters with upper, lower and a number. Share it securely; ask them to change it.">
          <Input id="password" name="password" type="password" required autoComplete="new-password" />
        </Field>
        <Field label="Department" htmlFor="department_id">
          <Select id="department_id" name="department_id" defaultValue="">
            <option value="">—</option>
            {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </Select>
        </Field>
        <Field label="Designation" htmlFor="designation"><Input id="designation" name="designation" /></Field>
      </div>
      <div>
        <h2 className="mb-3 text-sm font-semibold">Roles</h2>
        <RoleChecklist
          roles={roles}
          selected={selected}
          canGrantSuper={canGrantSuper}
          onToggle={(k) => setSelected((s) => { const n = new Set(s); if (n.has(k)) n.delete(k); else n.add(k); return n; })}
        />
      </div>
      <div className="flex justify-end border-t border-border pt-5">
        <Button type="submit" variant="brand" disabled={pending}>{pending && <Loader2 className="size-4 animate-spin" />} Create account</Button>
      </div>
    </form>
  );
}
