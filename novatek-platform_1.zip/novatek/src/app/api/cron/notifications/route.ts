import { timingSafeEqual } from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";
import { integrationEnv, isServiceRoleConfigured } from "@/lib/env.server";
import { createAdminClient } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

/**
 * Scheduled reminders (task due/overdue, meetings in the next hour, overdue follow-ups, proposal expiry).
 * Called by Vercel Cron (see vercel.json) with `Authorization: Bearer $CRON_SECRET`. Idempotent: each reminder is sent once.
 */
export async function GET(req: NextRequest) {
  const secret = integrationEnv.cronSecret;
  const given = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!secret || given.length !== secret.length || !timingSafeEqual(Buffer.from(given), Buffer.from(secret))) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  if (!isServiceRoleConfigured()) return NextResponse.json({ error: "service role not configured" }, { status: 503 });
  const { data, error } = await createAdminClient().rpc("run_scheduled_notifications");
  if (error) {
    console.error("[cron:notifications]", error);
    return NextResponse.json({ error: "failed" }, { status: 500 });
  }
  return NextResponse.json({ ok: true, sent: data });
}
