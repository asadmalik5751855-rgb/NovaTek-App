import { NextResponse } from "next/server";
import { isSupabaseConfigured } from "@/lib/env";
import { isServiceRoleConfigured } from "@/lib/env.server";

export const dynamic = "force-dynamic";

/** Liveness + configuration check for monitoring. Reveals no secrets. */
export async function GET() {
  let database = "not_configured";
  if (isSupabaseConfigured()) {
    try {
      const { createAdminClient } = await import("@/lib/supabase/admin");
      const { error } = isServiceRoleConfigured() ? await createAdminClient().from("settings").select("key").limit(1) : { error: null };
      database = error ? "error" : "ok";
    } catch {
      database = "error";
    }
  }
  return NextResponse.json({ status: database === "ok" ? "ok" : "degraded", database, time: new Date().toISOString() }, { status: database === "error" ? 503 : 200 });
}
