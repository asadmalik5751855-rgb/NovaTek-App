import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Check } from "lucide-react";
import { BrandLogo } from "@/components/brand/brand-logo";
import { EnquiryForm } from "@/components/public/enquiry-form";
import { brand } from "@/lib/config/brand";
import { isSupabaseConfigured } from "@/lib/env";
import { createClient } from "@/lib/supabase/server";

type Page = {
  slug: string; headline: string; subheadline: string | null; hero_image_url: string | null; benefits: string[]; cta_label: string;
  testimonials: { quote: string; author: string; role: string }[]; faq: { q: string; a: string }[]; services: { key: string } | null;
};

async function load(slug: string) {
  if (!isSupabaseConfigured() || !/^[a-z0-9][a-z0-9-]{1,79}$/.test(slug)) return null;
  const supabase = await createClient();
  const [page, services, countries] = await Promise.all([
    supabase.from("landing_pages").select("slug, headline, subheadline, hero_image_url, benefits, cta_label, testimonials, faq, services(key)")
      .eq("slug", slug).eq("status", "published").maybeSingle(),
    supabase.from("services").select("key, name").eq("active", true).order("position"),
    supabase.from("countries").select("code, name").eq("active", true).order("name"),
  ]);
  if (!page.data) return null;
  return { page: page.data as unknown as Page, services: (services.data ?? []) as { key: string; name: string }[], countries: (countries.data ?? []) as { code: string; name: string }[] };
}

export async function generateMetadata({ params }: PageProps<"/l/[slug]">): Promise<Metadata> {
  const d = await load((await params).slug);
  return d ? { title: d.page.headline, description: d.page.subheadline ?? undefined } : { title: "Not found" };
}

/** Published campaign landing page. Its form creates a real lead with source "Landing Page" and this page's campaign. */
export default async function LandingPage({ params }: PageProps<"/l/[slug]">) {
  const d = await load((await params).slug);
  if (!d) notFound();
  const p = d.page;
  return (
    <div className="dark min-h-dvh bg-bg text-text">
      <header className="border-b border-border/70">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Link href="/" aria-label={`${brand.companyName} home`}><BrandLogo height={26} plate priority /></Link>
          <a href="#enquire" className="text-sm text-text-2 hover:text-text">{p.cta_label}</a>
        </div>
      </header>
      <main>
        <section className="relative overflow-hidden">
          <div className="grid-bg absolute inset-0 opacity-60" aria-hidden />
          <div className="relative mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 md:py-24 lg:grid-cols-[1.1fr_1fr] lg:items-start">
            <div>
              <h1 className="text-[clamp(2.2rem,5vw,3.75rem)] font-semibold leading-[1.03] tracking-[-0.035em]">{p.headline}</h1>
              {p.subheadline && <p className="mt-5 max-w-xl text-lg leading-relaxed text-text-2">{p.subheadline}</p>}
              {p.benefits.length > 0 && (
                <ul className="mt-8 space-y-3">
                  {p.benefits.map((b) => <li key={b} className="flex gap-3"><Check className="mt-1 size-4 shrink-0 text-accent" /> <span>{b}</span></li>)}
                </ul>
              )}
              {p.hero_image_url && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={p.hero_image_url} alt="" className="mt-10 w-full rounded-2xl border border-border object-cover" />
              )}
            </div>
            <div id="enquire" className="scroll-mt-24 rounded-2xl border border-border bg-surface p-5 sm:p-7">
              <h2 className="mb-5 text-lg font-semibold">{p.cta_label}</h2>
              <EnquiryForm services={d.services} countries={d.countries} defaultService={p.services?.key} landingPage={p.slug} submitLabel={p.cta_label} />
            </div>
          </div>
        </section>
        {p.testimonials.length > 0 && (
          <section className="border-t border-border">
            <div className="mx-auto grid max-w-6xl gap-5 px-4 py-16 sm:px-6 md:grid-cols-2">
              {p.testimonials.map((t) => (
                <figure key={t.quote} className="rounded-2xl border border-border bg-surface p-6">
                  <blockquote className="text-text-2">“{t.quote}”</blockquote>
                  <figcaption className="mt-4 text-sm"><span className="font-medium">{t.author}</span>{t.role && <span className="text-text-3"> · {t.role}</span>}</figcaption>
                </figure>
              ))}
            </div>
          </section>
        )}
        {p.faq.length > 0 && (
          <section className="border-t border-border">
            <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
              <h2 className="text-2xl font-semibold tracking-[-0.02em]">Questions</h2>
              <div className="mt-6 divide-y divide-border border-y border-border">
                {p.faq.map((f) => (
                  <details key={f.q} className="group py-4">
                    <summary className="cursor-pointer list-none font-medium">{f.q}</summary>
                    <p className="mt-2 text-sm leading-relaxed text-text-2">{f.a}</p>
                  </details>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>
      <footer className="border-t border-border">
        <p className="mx-auto max-w-6xl px-4 py-6 text-xs text-text-3 sm:px-6">© {new Date().getFullYear()} {brand.companyName} · <Link href="/" className="hover:text-text">{brand.companyName} website</Link></p>
      </footer>
    </div>
  );
}
