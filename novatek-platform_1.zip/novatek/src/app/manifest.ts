import type { MetadataRoute } from "next";
import { brand } from "@/lib/config/brand";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: `${brand.companyName} Platform`,
    short_name: brand.companyName,
    id: "/app",
    start_url: "/app",
    scope: "/",
    description: "NovaTek CRM, sales and operations platform",
    display: "standalone",
    background_color: brand.colors.base,
    theme_color: brand.colors.base,
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    shortcuts: [
      { name: "Leads", url: "/app/leads" },
      { name: "Tasks", url: "/app/tasks" },
      { name: "Add lead", url: "/app/leads/new" },
    ],
  };
}
