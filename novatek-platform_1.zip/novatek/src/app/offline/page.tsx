import type { Metadata } from "next";
import { BrandMark } from "@/components/brand/brand-logo";

export const metadata: Metadata = { title: "Offline", robots: { index: false } };
export const dynamic = "force-static";

export default function OfflinePage() {
  return (
    <main className="dark grid min-h-dvh place-items-center bg-bg px-6 text-center text-text">
      <div className="max-w-sm space-y-4">
        <div className="flex justify-center"><BrandMark size={56} /></div>
        <h1 className="text-xl font-semibold">You’re offline</h1>
        <p className="text-sm text-text-2">The NovaTek platform needs a connection to show live data. Nothing private is stored on this device. Reconnect and try again.</p>
        <a href="/app" className="inline-block rounded-lg border border-border px-4 py-2 text-sm hover:bg-surface-2">Try again</a>
      </div>
    </main>
  );
}
