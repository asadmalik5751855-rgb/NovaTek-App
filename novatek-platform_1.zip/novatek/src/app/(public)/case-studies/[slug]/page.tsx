import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArrowUpRight } from "lucide-react";
import { ButtonLink } from "@/components/ui/primitives";
import { getPublishedEntries } from "@/lib/data/site";

async function find(slug: string) {
  return (await getPublishedEntries()).find((e) => e.kind === "case_study" && e.slug === slug) ?? null;
}

export async function generateMetadata({ params }: PageProps<"/case-studies/[slug]">): Promise<Metadata> {
  const e = await find((await params).slug);
  return e ? { title: e.title, description: e.summary } : { title: "Case study" };
}

export default async function CaseStudyPage({ params }: PageProps<"/case-studies/[slug]">) {
  const e = await find((await params).slug);
  if (!e) notFound();
  return (
    <article className="mx-auto max-w-3xl px-4 py-16 sm:px-6 md:py-24">
      <p className="text-sm text-text-3">{[e.client_name, e.industry, e.service].filter(Boolean).join(" · ")}</p>
      <h1 className="mt-2 text-[clamp(2rem,4vw,3rem)] font-semibold leading-[1.1] tracking-[-0.03em]">{e.title}</h1>
      <p className="mt-5 text-lg text-text-2">{e.summary}</p>
      {e.image_url && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={e.image_url} alt="" className="mt-10 w-full rounded-2xl border border-border object-cover" />
      )}
      {[["The challenge", e.challenge], ["What we built", e.solution], ["Results", e.results]].map(([h, v]) =>
        v ? (
          <section key={h} className="mt-10">
            <h2 className="text-lg font-semibold">{h}</h2>
            <p className="mt-3 whitespace-pre-wrap leading-relaxed text-text-2">{v}</p>
          </section>
        ) : null,
      )}
      <div className="mt-12 flex flex-wrap gap-3">
        <ButtonLink href="/contact" variant="brand">Start a similar project</ButtonLink>
        {e.project_url && <a href={e.project_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 px-2 text-sm text-text-2 hover:text-text">View live <ArrowUpRight className="size-4" /></a>}
      </div>
    </article>
  );
}
