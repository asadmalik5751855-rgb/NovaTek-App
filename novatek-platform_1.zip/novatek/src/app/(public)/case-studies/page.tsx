import type { Metadata } from "next";
import Link from "next/link";
import { ButtonLink } from "@/components/ui/primitives";
import { getPublishedEntries } from "@/lib/data/site";

export const metadata: Metadata = { title: "Case studies", description: "How NovaTek approached real client problems." };

export default async function CaseStudiesPage() {
  const entries = (await getPublishedEntries()).filter((e) => e.kind === "case_study");
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-24">
      <h1 className="text-[clamp(2.2rem,4.5vw,3.5rem)] font-semibold leading-[1.05] tracking-[-0.03em]">Case studies</h1>
      <p className="mt-5 max-w-2xl text-lg text-text-2">The problem, what we built, and what changed — with measured results only.</p>
      {entries.length === 0 ? (
        <div className="mt-14 rounded-2xl border border-border bg-surface p-8">
          <h2 className="text-lg font-semibold">Case studies are being prepared</h2>
          <p className="mt-2 max-w-xl text-text-2">We publish case studies only with client permission and verified results. Ask us for references relevant to your project.</p>
          <div className="mt-6"><ButtonLink href="/contact" variant="brand">Request references</ButtonLink></div>
        </div>
      ) : (
        <div className="mt-14 divide-y divide-border border-y border-border">
          {entries.map((e) => (
            <Link key={e.id} href={`/case-studies/${e.slug}`} className="group grid gap-3 py-8 md:grid-cols-[1fr_1.6fr] md:gap-10">
              <div>
                <p className="text-xs text-text-3">{[e.industry, e.service].filter(Boolean).join(" · ")}</p>
                <h2 className="mt-1 text-xl font-semibold group-hover:text-accent">{e.title}</h2>
              </div>
              <p className="text-text-2">{e.summary}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
