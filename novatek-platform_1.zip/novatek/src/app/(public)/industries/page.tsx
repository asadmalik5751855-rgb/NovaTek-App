import type { Metadata } from "next";
import { ButtonLink } from "@/components/ui/primitives";
import { INDUSTRY_DETAILS } from "@/lib/content/site";

export const metadata: Metadata = {
  title: "Industries",
  description: "Digital solutions for schools, e-commerce brands, restaurants, retail, professional services, startups and growing businesses.",
};

export default function IndustriesPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-24">
      <h1 className="max-w-3xl text-[clamp(2.2rem,4.5vw,3.5rem)] font-semibold leading-[1.05] tracking-[-0.03em]">Industries we work with</h1>
      <p className="mt-5 max-w-2xl text-lg text-text-2">Different sectors, the same standard: clear scope, honest timelines and software you own. Working in Pakistan, the UAE and internationally.</p>
      <div className="mt-14 divide-y divide-border border-y border-border">
        {INDUSTRY_DETAILS.map((i) => (
          <section key={i.name} className="grid gap-3 py-8 md:grid-cols-[1fr_1.6fr] md:gap-10">
            <h2 className="text-xl font-semibold tracking-[-0.01em]">{i.name}</h2>
            <p className="text-text-2">{i.text}</p>
          </section>
        ))}
      </div>
      <div className="mt-12"><ButtonLink href="/contact" variant="brand" size="lg">Get a free consultation</ButtonLink></div>
    </div>
  );
}
