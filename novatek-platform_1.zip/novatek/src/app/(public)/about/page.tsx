import type { Metadata } from "next";
import { BrandMark } from "@/components/brand/brand-logo";
import { ButtonLink } from "@/components/ui/primitives";
import { PROCESS } from "@/lib/content/site";

export const metadata: Metadata = { title: "About", description: "NovaTek is a digital solutions and software services company." };

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-24">
      <div className="grid gap-12 md:grid-cols-[1.5fr_1fr] md:items-start">
        <div>
          <h1 className="text-[clamp(2.2rem,4.5vw,3.5rem)] font-semibold leading-[1.05] tracking-[-0.03em]">
            We build digital products for businesses that are growing.
          </h1>
          <div className="mt-8 max-w-[38rem] space-y-5 text-lg leading-relaxed text-text-2">
            <p>
              NovaTek is a digital solutions and software services company. We design and develop websites, e-commerce
              stores, SaaS products and custom business applications, and we automate the repetitive work that slows
              teams down.
            </p>
            <p>
              We work with startups, schools, retailers, restaurants and professional services firms in Pakistan, the UAE
              and further afield. Our approach is simple: agree a clear scope, build in the open, and hand over work you
              fully own.
            </p>
          </div>
        </div>
        <div className="hidden justify-end md:flex">
          <BrandMark size={220} />
        </div>
      </div>

      <section className="mt-20 border-t border-border pt-14">
        <h2 className="text-2xl font-semibold tracking-[-0.02em]">How we work</h2>
        <ol className="mt-8 grid gap-8 md:grid-cols-2">
          {PROCESS.map((p, i) => (
            <li key={p.name} className="flex gap-4">
              <span className="grid size-8 shrink-0 place-items-center rounded-full border border-border text-sm tabular-nums text-text-2">{i + 1}</span>
              <div>
                <h3 className="font-medium">{p.name}</h3>
                <p className="mt-1 text-sm leading-relaxed text-text-2">{p.text}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <div className="mt-16">
        <ButtonLink href="/contact" variant="brand" size="lg">Talk to NovaTek</ButtonLink>
      </div>
    </div>
  );
}
