import type { Metadata } from "next";
import { ButtonLink } from "@/components/ui/primitives";
import { SERVICES } from "@/lib/content/site";

export const metadata: Metadata = {
  title: "Services",
  description: "Web development, e-commerce, custom software, UI/UX design, SaaS products and AI automation.",
};

export default function ServicesPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-24">
      <h1 className="max-w-3xl text-[clamp(2.2rem,4.5vw,3.5rem)] font-semibold leading-[1.05] tracking-[-0.03em]">
        Services
      </h1>
      <p className="mt-5 max-w-2xl text-lg text-text-2">
        Pick the service closest to what you need. If you’re not sure, describe the problem — we’ll suggest the right approach.
      </p>

      <div className="mt-14 divide-y divide-border border-y border-border">
        {SERVICES.map((s) => (
          <section key={s.key} id={s.key} className="grid scroll-mt-24 gap-6 py-10 md:grid-cols-[1fr_1.6fr_auto] md:items-start md:gap-10">
            <h2 className="text-2xl font-semibold tracking-[-0.02em]">{s.name}</h2>
            <div className="max-w-xl space-y-3">
              <p className="text-text">{s.summary}</p>
              <p className="text-sm leading-relaxed text-text-2">{s.detail}</p>
            </div>
            <ButtonLink href={`/contact?service=${s.key}`} variant="secondary">Request a quote</ButtonLink>
          </section>
        ))}
      </div>
    </div>
  );
}
