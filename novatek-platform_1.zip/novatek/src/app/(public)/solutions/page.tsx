import type { Metadata } from "next";
import { Check } from "lucide-react";
import { ButtonLink } from "@/components/ui/primitives";
import { SOLUTIONS } from "@/lib/content/site";

export const metadata: Metadata = {
  title: "Solutions",
  description: "Websites, online stores, operations systems, automation and SaaS products — scoped around the outcome you need.",
};

export default function SolutionsPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-24">
      <h1 className="max-w-3xl text-[clamp(2.2rem,4.5vw,3.5rem)] font-semibold leading-[1.05] tracking-[-0.03em]">Solutions</h1>
      <p className="mt-5 max-w-2xl text-lg text-text-2">Start from the outcome. Each solution combines the services needed to get there, scoped in writing before work begins.</p>
      <div className="mt-14 grid gap-5 md:grid-cols-2">
        {SOLUTIONS.map((s) => (
          <section key={s.key} id={s.key} className="flex scroll-mt-24 flex-col rounded-2xl border border-border bg-surface p-6">
            <h2 className="text-xl font-semibold tracking-[-0.01em]">{s.name}</h2>
            <p className="mt-2 text-sm text-text-2">{s.for}</p>
            <ul className="mt-5 flex-1 space-y-2 text-sm">
              {s.includes.map((i) => (
                <li key={i} className="flex gap-2"><Check className="mt-0.5 size-4 shrink-0 text-accent" /> {i}</li>
              ))}
            </ul>
            <div className="mt-6"><ButtonLink href={`/contact?service=${s.service}`} variant="secondary">Talk to NovaTek</ButtonLink></div>
          </section>
        ))}
      </div>
    </div>
  );
}
