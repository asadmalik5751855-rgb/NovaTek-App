import type { Metadata } from "next";
import { Mail, MessageCircle } from "lucide-react";
import { EnquiryForm } from "@/components/public/enquiry-form";
import { brand } from "@/lib/config/brand";
import { SERVICES } from "@/lib/content/site";
import { isSupabaseConfigured } from "@/lib/env";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = {
  title: "Contact",
  description: "Tell NovaTek about your project and request a free consultation.",
};

async function loadCatalogue() {
  if (!isSupabaseConfigured()) return { services: [...SERVICES], countries: [] };
  try {
    const supabase = await createClient();
    const [s, c] = await Promise.all([
      supabase.from("services").select("key, name").eq("active", true).order("position"),
      supabase.from("countries").select("code, name").eq("active", true).order("name"),
    ]);
    return {
      services: s.data?.length ? (s.data as { key: string; name: string }[]) : [...SERVICES],
      countries: (c.data ?? []) as { code: string; name: string }[],
    };
  } catch {
    return { services: [...SERVICES], countries: [] };
  }
}

export default async function ContactPage({ searchParams }: PageProps<"/contact">) {
  const sp = await searchParams;
  const { services, countries } = await loadCatalogue();
  const requested = typeof sp.service === "string" ? sp.service : undefined;
  const defaultService = services.some((s) => s.key === requested) ? requested : undefined;

  return (
    <div className="mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 md:py-24 lg:grid-cols-[1fr_1.7fr]">
      <div>
        <h1 className="text-[clamp(2.2rem,4.5vw,3.25rem)] font-semibold leading-[1.05] tracking-[-0.03em]">Start your project</h1>
        <p className="mt-5 max-w-sm text-lg leading-relaxed text-text-2">
          Tell us what you need. The more context you share, the more useful our first conversation will be.
        </p>
        <ul className="mt-10 space-y-4 text-sm">
          <li>
            <a href={`mailto:${brand.contact.email}`} className="flex items-center gap-3 text-text-2 hover:text-text">
              <Mail className="size-4 text-text-3" /> {brand.contact.email}
            </a>
          </li>
          <li>
            <a href={brand.contact.whatsappLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-text-2 hover:text-text">
              <MessageCircle className="size-4 text-text-3" /> WhatsApp {brand.contact.whatsapp}
            </a>
          </li>
        </ul>
        <p className="mt-10 max-w-sm text-xs leading-relaxed text-text-3">
          Your details are used to respond to this enquiry.
        </p>
      </div>

      <div className="chamfer-frame">
        <div className="bg-surface p-6 sm:p-8">
          <EnquiryForm services={services} countries={countries} defaultService={defaultService} />
        </div>
      </div>
    </div>
  );
}
