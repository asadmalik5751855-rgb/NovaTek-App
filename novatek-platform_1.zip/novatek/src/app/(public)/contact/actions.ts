"use server";

import { createHash } from "node:crypto";
import { headers } from "next/headers";
import { z } from "zod";
import { brand } from "@/lib/config/brand";
import { isSupabaseConfigured } from "@/lib/env";
import { isServiceRoleConfigured, serverEnv } from "@/lib/env.server";
import { createAdminClient } from "@/lib/supabase/admin";
import { publicLeadSchema } from "@/lib/validation/public-lead";

export type EnquiryResult =
  | { ok: true }
  | { ok: false; error: string; fieldErrors?: Record<string, string[] | undefined> };

const FALLBACK = `Please email ${brand.contact.email} or message us on WhatsApp at ${brand.contact.whatsapp}.`;

export async function submitEnquiry(input: unknown): Promise<EnquiryResult> {
  if (!isSupabaseConfigured() || !isServiceRoleConfigured()) {
    // Never pretend an enquiry was received when it can't be stored.
    return { ok: false, error: `Online enquiries aren't connected yet. ${FALLBACK}` };
  }

  const parsed = publicLeadSchema.safeParse(input);
  if (!parsed.success) {
    const fe = z.flattenError(parsed.error).fieldErrors;
    if (fe.company_website || fe.started_at) return { ok: false, error: `We couldn't send your enquiry. ${FALLBACK}` };
    return { ok: false, error: "Please check the highlighted fields.", fieldErrors: fe };
  }
  const d = parsed.data;

  // Humans take more than a few seconds to fill the form; scripts usually don't.
  const elapsed = Date.now() - d.started_at;
  if (elapsed < 3000 || elapsed > 1000 * 60 * 60 * 6) {
    return { ok: false, error: "Please review your details and send again." };
  }

  const h = await headers();
  const ip = (h.get("x-forwarded-for")?.split(",")[0] ?? h.get("x-real-ip") ?? "unknown").trim();
  const ipHash = createHash("sha256").update(`${serverEnv.leadIpHashSalt}:${ip}`).digest("hex");

  try {
    const { data, error } = await createAdminClient().rpc("submit_public_lead", {
      p: {
        name: d.name,
        company: d.company,
        email: d.email,
        phone: d.phone,
        country: d.country,
        service: d.service,
        budget: d.budget,
        website: d.website,
        message: d.message,
        consent: d.consent,
        utm_source: d.utm_source,
        utm_medium: d.utm_medium,
        utm_campaign: d.utm_campaign,
        utm_content: d.utm_content,
        utm_term: d.utm_term,
        landing_page: d.landing_page,
        page_path: d.page_path,
        ip_hash: ipHash,
        user_agent: h.get("user-agent") ?? "",
      },
    });
    if (error) throw error;
    const r = data as { ok: boolean; error?: string };
    if (r.ok) return { ok: true };
    switch (r.error) {
      case "rate_limited":
        return { ok: false, error: `Too many enquiries were sent from this connection recently. Try again later. ${FALLBACK}` };
      case "duplicate_submission":
        return { ok: false, error: "We've just received an enquiry from this email address. There's no need to send it again." };
      case "invalid_email":
        return { ok: false, error: "Please check your email address.", fieldErrors: { email: ["Enter a valid email address"] } };
      default:
        return { ok: false, error: "Please check the highlighted fields." };
    }
  } catch (e) {
    console.error("[submitEnquiry]", e);
    return { ok: false, error: `We couldn't send your enquiry because of a problem on our side. ${FALLBACK}` };
  }
}
