import type { Metadata } from "next";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { ButtonLink } from "@/components/ui/primitives";
import { getPublishedEntries } from "@/lib/data/site";

export const metadata: Metadata = { title: "Portfolio", description: "Selected NovaTek projects." };

export default async function PortfolioPage() {
  const entries = await getPublishedEntries();
  return (
    <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 md:py-24">
      <h1 className="text-[clamp(2.2rem,4.5vw,3.5rem)] font-semibold leading-[1.05] tracking-[-0.03em]">Portfolio</h1>
      <p className="mt-5 max-w-2xl text-lg text-text-2">Work we can show. Some clients prefer to stay anonymous — we respect that.</p>
      {entries.length === 0 ? (
        <div className="mt-14 rounded-2xl border border-border bg-surface p-8">
          <h2 className="text-lg font-semibold">Our portfolio is being prepared</h2>
          <p className="mt-2 max-w-xl text-text-2">We publish projects only with our clients’ permission. In the meantime we’re happy to walk you through relevant work on a call.</p>
          <div className="mt-6"><ButtonLink href="/contact" variant="brand">Talk to NovaTek</ButtonLink></div>
        </div>
      ) : (
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {entries.map((e) => (
            <article key={e.id} className="flex flex-col overflow-hidden rounded-2xl border border-border bg-surface">
              {e.image_url && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={e.image_url} alt="" className="aspect-[16/10] w-full object-cover" loading="lazy" />
              )}
              <div className="flex flex-1 flex-col p-5">
                <p className="text-xs text-text-3">{[e.service, e.industry].filter(Boolean).join(" · ")}</p>
                <h2 className="mt-1 font-semibold">{e.title}</h2>
                <p className="mt-2 flex-1 text-sm text-text-2">{e.summary}</p>
                <div className="mt-4 flex gap-4 text-sm">
                  {e.kind === "case_study" && <Link href={`/case-studies/${e.slug}`} className="text-accent hover:underline">Read case study</Link>}
                  {e.project_url && <a href={e.project_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-text-2 hover:text-text">Live site <ArrowUpRight className="size-3.5" /></a>}
                </div>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
