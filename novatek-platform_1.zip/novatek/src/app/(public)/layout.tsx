import Link from "next/link";
import { BrandLogo } from "@/components/brand/brand-logo";
import { ButtonLink } from "@/components/ui/primitives";
import { brand } from "@/lib/config/brand";
import { getPublicBranding } from "@/lib/data/branding";

const NAV = [
  { href: "/services", label: "Services" },
  { href: "/solutions", label: "Solutions" },
  { href: "/industries", label: "Industries" },
  { href: "/portfolio", label: "Work" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export default async function PublicLayout({ children }: LayoutProps<"/">) {
  const b = await getPublicBranding();
  return (
    // The public site is always dark: it's the brand's primary presentation.
    <div className="dark flex min-h-dvh flex-col bg-bg text-text">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-surface focus:px-3 focus:py-2">
        Skip to content
      </a>
      <header className="sticky top-0 z-40 border-b border-border/70 bg-bg/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
          <Link href="/" aria-label={`${brand.companyName} home`} className="shrink-0">
            <BrandLogo height={26} plate priority />
          </Link>
          <nav aria-label="Main" className="hidden items-center gap-7 text-sm text-text-2 md:flex">
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} className="hover:text-text">{n.label}</Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link href="/login" className="hidden px-2 text-sm text-text-3 hover:text-text sm:block">Team sign in</Link>
            <ButtonLink href="/contact" variant="brand" size="sm">Talk to NovaTek</ButtonLink>
          </div>
        </div>
        <nav aria-label="Main mobile" className="flex gap-6 overflow-x-auto border-t border-border/70 px-4 py-2 text-sm text-text-2 md:hidden">
          {NAV.map((n) => <Link key={n.href} href={n.href}>{n.label}</Link>)}
        </nav>
      </header>

      <main id="main" className="flex-1">{children}</main>

      <footer className="border-t border-border">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
          <div className="space-y-4">
            <BrandLogo height={24} plate />
            <p className="max-w-sm text-sm text-text-3">{b.tagline}</p>
            {b.address && <p className="max-w-sm text-sm text-text-3">{b.address}</p>}
          </div>
          <div>
            <h2 className="mb-3 text-sm font-medium">Company</h2>
            <ul className="space-y-2 text-sm text-text-3">
              {NAV.map((n) => <li key={n.href}><Link href={n.href} className="hover:text-text">{n.label}</Link></li>)}
              <li><Link href="/case-studies" className="hover:text-text">Case studies</Link></li>
            </ul>
          </div>
          <div>
            <h2 className="mb-3 text-sm font-medium">Get in touch</h2>
            <ul className="space-y-2 text-sm text-text-3">
              <li><a href={`mailto:${b.email}`} className="hover:text-text">{b.email}</a></li>
              {b.phone && <li><a href={`tel:${b.phone.replace(/[^\d+]/g, "")}`} className="hover:text-text">{b.phone}</a></li>}
              <li><a href={b.whatsappLink} className="hover:text-text" rel="noopener noreferrer" target="_blank">WhatsApp {b.whatsapp}</a></li>
              {b.social.map((x) => <li key={x.href}><a href={x.href} className="hover:text-text" rel="noopener noreferrer" target="_blank">{x.label}</a></li>)}
            </ul>
          </div>
        </div>
        <div className="border-t border-border">
          <p className="mx-auto max-w-6xl px-4 py-5 text-xs text-text-3 sm:px-6">© {new Date().getFullYear()} {brand.companyName}. All rights reserved.{b.footerNote && ` ${b.footerNote}`}</p>
        </div>
      </footer>
    </div>
  );
}
