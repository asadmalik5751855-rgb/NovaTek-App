import Link from "next/link";
import { ArrowUpRight, Check } from "lucide-react";
import { ButtonLink } from "@/components/ui/primitives";
import { INDUSTRIES, PROCESS, SERVICES } from "@/lib/content/site";
import { brand } from "@/lib/config/brand";

export default function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="grid-bg pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_30%_20%,black,transparent_70%)]" aria-hidden />
        <div
          className="pointer-events-none absolute -right-40 -top-40 size-[520px] rounded-full opacity-25 blur-3xl"
          style={{ background: "radial-gradient(circle, var(--brand-violet), transparent 65%)" }}
          aria-hidden
        />
        <div className="relative mx-auto grid max-w-6xl gap-12 px-4 py-20 sm:px-6 md:py-28 lg:grid-cols-[1.35fr_1fr] lg:items-center">
          <div className="hero-rise">
            <h1 className="text-[clamp(2.4rem,5.6vw,4.4rem)] font-semibold leading-[1.02] tracking-[-0.035em]">
              Software that moves your business forward.
            </h1>
            <p className="mt-6 max-w-[34rem] text-lg leading-relaxed text-text-2">
              NovaTek designs and builds websites, online stores, custom business software and automation for
              companies that need it done properly — clear scope, honest timelines, and code you own.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <ButtonLink href="/contact" variant="brand" size="lg">Get a free consultation</ButtonLink>
              <ButtonLink href="/services" variant="secondary" size="lg">See what we build</ButtonLink>
            </div>
          </div>

          <div className="chamfer-frame chamfer-frame-brand">
            <div className="bg-surface p-6 sm:p-7">
              <h2 className="text-base font-semibold">What do you need?</h2>
              <p className="mt-1 text-sm text-text-3">Pick one to start a request — it takes about a minute.</p>
              <ul className="mt-5 space-y-1">
                {SERVICES.map((s) => (
                  <li key={s.key}>
                    <Link
                      href={`/contact?service=${s.key}`}
                      className="group flex items-center justify-between rounded-lg px-3 py-2.5 text-sm text-text-2 transition-colors hover:bg-surface-2 hover:text-text"
                    >
                      {s.name}
                      <ArrowUpRight className="size-4 text-text-3 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-text" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6 md:py-24">
        <div className="max-w-2xl">
          <h2 className="text-3xl font-semibold tracking-[-0.025em] md:text-4xl">Six things we do well.</h2>
          <p className="mt-4 text-text-2">
            Every project starts with a written scope, and you can follow progress on a live preview as it’s built.
          </p>
        </div>
        <dl className="mt-12 grid border-t border-border md:grid-cols-2">
          {SERVICES.map((s, i) => (
            <div
              key={s.key}
              className={`border-b border-border py-7 md:py-8 ${i % 2 === 0 ? "md:border-r md:pr-10" : "md:pl-10"}`}
            >
              <dt className="text-lg font-medium">{s.name}</dt>
              <dd className="mt-2 max-w-md text-sm leading-relaxed text-text-2">{s.summary}</dd>
            </div>
          ))}
        </dl>
        <Link href="/services" className="mt-8 inline-flex items-center gap-1.5 text-sm text-text-2 hover:text-text">
          Read about each service <ArrowUpRight className="size-4" />
        </Link>
      </section>

      {/* Process */}
      <section className="border-y border-border bg-surface/50">
        <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 md:py-24">
          <h2 className="text-3xl font-semibold tracking-[-0.025em] md:text-4xl">How a project runs.</h2>
          <ol className="mt-12 grid gap-10 md:grid-cols-4 md:gap-6">
            {PROCESS.map((p, i) => (
              <li key={p.name} className="relative">
                <span className="brand-gradient-text text-sm font-semibold tabular-nums">Step {i + 1}</span>
                <h3 className="mt-2 font-medium">{p.name}</h3>
                <p className="mt-2 text-sm leading-relaxed text-text-2">{p.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Industries + principles */}
      <section className="mx-auto grid max-w-6xl gap-16 px-4 py-20 sm:px-6 md:grid-cols-2 md:py-24">
        <div>
          <h2 className="text-2xl font-semibold tracking-[-0.02em]">Who we work with</h2>
          <ul className="mt-6 flex flex-wrap gap-2">
            {INDUSTRIES.map((i) => (
              <li key={i} className="rounded-full border border-border px-3.5 py-1.5 text-sm text-text-2">{i}</li>
            ))}
          </ul>
          <p className="mt-6 text-sm text-text-3">Based in Pakistan, working with clients locally, in the UAE and internationally.</p>
        </div>
        <div>
          <h2 className="text-2xl font-semibold tracking-[-0.02em]">What you can expect</h2>
          <ul className="mt-6 space-y-4">
            {[
              "A fixed, written scope and price before any work starts",
              "Regular progress you can see on a live preview",
              "Full ownership of your code, designs and accounts",
              "Plain answers about what is and isn't worth building",
            ].map((t) => (
              <li key={t} className="flex gap-3 text-text-2">
                <Check className="mt-0.5 size-5 shrink-0 text-brand-blue" /> {t}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-4 pb-24 sm:px-6">
        <div className="chamfer-frame" style={{ ["--cut" as string]: "40px" }}>
          <div className="flex flex-col gap-6 bg-surface p-8 md:flex-row md:items-center md:justify-between md:p-12">
            <div className="max-w-xl">
              <h2 className="text-2xl font-semibold tracking-[-0.02em] md:text-3xl">Have a project in mind?</h2>
              <p className="mt-3 text-text-2">
                Tell us what you’re trying to achieve and a member of the team will get back to you personally.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <ButtonLink href="/contact" variant="brand" size="lg">Start your project</ButtonLink>
              <a href={brand.contact.whatsappLink} target="_blank" rel="noopener noreferrer" className="inline-flex h-12 items-center rounded-lg border border-border px-6 text-text-2 hover:bg-surface-2 hover:text-text">
                WhatsApp us
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
