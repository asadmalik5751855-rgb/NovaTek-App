import type { MetadataRoute } from "next";
import { getPublishedEntries } from "@/lib/data/site";
import { publicEnv } from "@/lib/env";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = publicEnv.siteUrl.replace(/\/$/, "");
  const pages = ["", "/services", "/solutions", "/industries", "/portfolio", "/case-studies", "/about", "/contact"];
  const studies = (await getPublishedEntries()).filter((e) => e.kind === "case_study").map((e) => `/case-studies/${e.slug}`);
  return [...pages, ...studies].map((p) => ({ url: `${base}${p}` }));
}
