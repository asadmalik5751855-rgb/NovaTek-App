import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { BrandLogo } from "@/components/brand/brand-logo";
import { Alert, Button } from "@/components/ui/primitives";
import { isSupabaseConfigured } from "@/lib/env";
import { getSessionState } from "@/lib/auth/session";
import { LoginForm } from "./login-form";
import { signOut } from "./actions";

export const metadata: Metadata = { title: "Sign in", robots: { index: false } };

export default async function LoginPage({ searchParams }: PageProps<"/login">) {
  const sp = await searchParams;
  const next = typeof sp.next === "string" ? sp.next : undefined;
  const state = await getSessionState();
  if (state.kind === "active") redirect("/app");

  return (
    <main className="grid-bg relative grid min-h-dvh place-items-center bg-bg px-4 py-12">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex justify-center">
          <Link href="/" aria-label="NovaTek home">
            <BrandLogo height={30} plate priority />
          </Link>
        </div>
        <div className="rounded-2xl border border-border bg-surface p-6 shadow-card">
          <h1 className="text-lg font-semibold">Sign in to the platform</h1>
          <p className="mb-5 mt-1 text-sm text-text-3">Accounts are created by your administrator.</p>

          {!isSupabaseConfigured() ? (
            <Alert tone="warning">
              Supabase is not configured. Add the environment variables from <code>.env.example</code> — see
              docs/SETUP.md. Sign-in is disabled until then.
            </Alert>
          ) : state.kind === "disabled" ? (
            <div className="space-y-4">
              <Alert tone="error">The account {state.email} is disabled. Contact your administrator.</Alert>
              <form action={signOut}>
                <Button type="submit" variant="secondary" className="w-full">
                  Sign out
                </Button>
              </form>
            </div>
          ) : (
            <>
              {sp.error === "disabled" && <div className="mb-4"><Alert tone="error">Your account is disabled.</Alert></div>}
              <LoginForm next={next} />
            </>
          )}
        </div>
      </div>
    </main>
  );
}
