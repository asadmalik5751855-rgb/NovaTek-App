"use server";

import { redirect } from "next/navigation";
import { z } from "zod";
import { isSupabaseConfigured } from "@/lib/env";
import { createClient } from "@/lib/supabase/server";
import { auditEvent } from "@/lib/audit";

const signInSchema = z.object({
  email: z.email("Enter a valid email").max(254),
  password: z.string().min(1, "Enter your password").max(200),
  next: z.string().optional(),
});

export type SignInState = { error?: string } | undefined;

function safeNext(next: string | undefined) {
  // Only allow internal app paths (prevents open redirects).
  return next && /^\/app(\/[\w\-/]*)?$/.test(next) ? next : "/app";
}

export async function signIn(_prev: SignInState, formData: FormData): Promise<SignInState> {
  if (!isSupabaseConfigured()) return { error: "Authentication is not configured yet. See docs/SETUP.md." };
  const parsed = signInSchema.safeParse(Object.fromEntries(formData));
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Invalid input" };

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithPassword({
    email: parsed.data.email,
    password: parsed.data.password,
  });
  if (error || !data.user) {
    // Same message for unknown email and wrong password (no account enumeration).
    return { error: error?.status === 429 ? "Too many attempts. Wait a minute and try again." : "Incorrect email or password." };
  }

  const { data: profile } = await supabase.from("profiles").select("status").eq("id", data.user.id).maybeSingle();
  if (profile?.status !== "active") {
    await supabase.auth.signOut();
    return { error: "This account is disabled. Contact your administrator." };
  }

  await auditEvent(data.user.id, "auth.login", "user", data.user.id);
  redirect(safeNext(parsed.data.next));
}

export async function signOut() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (user) await auditEvent(user.id, "auth.logout", "user", user.id);
  await supabase.auth.signOut();
  redirect("/login");
}
