"use server";

import { z } from "zod";
import { isServiceRoleConfigured } from "@/lib/env.server";
import { visitorIpHash } from "@/lib/request";
import { createAdminClient } from "@/lib/supabase/admin";

const schema = z.object({
  token: z.string().regex(/^[0-9a-f]{64}$/),
  accept: z.boolean(),
  name: z.string().trim().min(2, "Enter your full name").max(120),
  confirm: z.literal(true, { message: "Please confirm you are authorised to respond" }),
});

/** The client's own response on the proposal link — the strongest evidence of acceptance. */
export async function respondToProposal(input: unknown): Promise<{ ok: true } | { ok: false; error: string }> {
  if (!isServiceRoleConfigured()) return { ok: false, error: "Responses can’t be recorded right now. Please reply by email." };
  const parsed = schema.safeParse(input);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? "Please check your details." };
  try {
    const { data, error } = await createAdminClient().rpc("respond_public_proposal", {
      p_token: parsed.data.token, p_accept: parsed.data.accept, p_name: parsed.data.name, p_ip_hash: await visitorIpHash(),
    });
    if (error) throw error;
    const r = data as { ok: boolean; error?: string };
    if (r.ok) return { ok: true };
    return {
      ok: false,
      error: r.error === "expired" ? "This proposal has expired." : r.error === "closed" ? "This proposal has already been answered." : "This link is no longer valid.",
    };
  } catch (e) {
    console.error("[respondToProposal]", e);
    return { ok: false, error: "Your response could not be recorded. Please try again or reply by email." };
  }
}
