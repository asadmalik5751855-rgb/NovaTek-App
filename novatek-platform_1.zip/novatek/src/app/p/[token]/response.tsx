"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { Alert, Button, Field, Input } from "@/components/ui/primitives";
import { respondToProposal } from "./actions";

export function ProposalResponse({ token }: { token: string }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const send = (accept: boolean) => {
    setError(null);
    start(async () => {
      const r = await respondToProposal({ token, accept, name, confirm });
      if (!r.ok) setError(r.error);
      else router.refresh();
    });
  };

  return (
    <div className="space-y-4 rounded-xl border border-border bg-surface p-5">
      <h2 className="text-sm font-semibold">Your response</h2>
      <Field label="Your full name" htmlFor="respondent">
        <Input id="respondent" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
      </Field>
      <label className="flex items-start gap-2.5 text-sm text-text-2">
        <input type="checkbox" className="mt-0.5 size-4 accent-[var(--accent)]" checked={confirm} onChange={(e) => setConfirm(e.target.checked)} />
        I’m authorised to respond to this proposal on behalf of my organisation.
      </label>
      {error && <Alert tone="error">{error}</Alert>}
      <div className="flex flex-wrap gap-2">
        <Button variant="brand" onClick={() => send(true)} disabled={pending}>{pending && <Loader2 className="size-4 animate-spin" />} Accept proposal</Button>
        <Button variant="secondary" onClick={() => send(false)} disabled={pending}>Decline</Button>
      </div>
    </div>
  );
}
