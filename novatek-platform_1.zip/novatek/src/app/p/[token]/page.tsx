import type { Metadata } from "next";
import { BrandLogo } from "@/components/brand/brand-logo";
import { Alert, Card } from "@/components/ui/primitives";
import { brand } from "@/lib/config/brand";
import { isSupabaseConfigured } from "@/lib/env";
import { isServiceRoleConfigured } from "@/lib/env.server";
import { isAutomatedOrPrefetch } from "@/lib/request";
import { createAdminClient } from "@/lib/supabase/admin";
import { formatDate, formatMoney } from "@/lib/utils";
import { ProposalResponse } from "./response";

export const metadata: Metadata = { title: "Proposal", robots: { index: false, follow: false } };

type PublicProposal = {
  title: string; scope: string | null; price: number; currency: string; timeline: string | null; terms: string | null;
  expiry_date: string | null; status: string; service: string | null; sent_at: string | null; responded_at: string | null;
  response_name: string | null; client: string | null;
};

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="dark min-h-dvh bg-bg text-text">
      <header className="border-b border-border">
        <div className="mx-auto flex h-16 max-w-3xl items-center px-4 sm:px-6"><BrandLogo height={24} plate /></div>
      </header>
      <main className="mx-auto max-w-3xl px-4 py-10 sm:px-6">{children}</main>
    </div>
  );
}

/**
 * Private proposal link. Opening it records a real view (link-preview bots and prefetches are ignored).
 * The client can accept or decline here; that response is the evidence shown to NovaTek staff.
 */
export default async function PublicProposalPage({ params }: PageProps<"/p/[token]">) {
  const { token } = await params;
  if (!/^[0-9a-f]{64}$/.test(token) || !isSupabaseConfigured() || !isServiceRoleConfigured()) {
    return <Shell><Alert tone="info">This proposal link is not valid.</Alert></Shell>;
  }
  if (await isAutomatedOrPrefetch()) {
    return <Shell><p className="text-sm text-text-3">A private proposal from {brand.companyName}. Open the link in your browser to view it.</p></Shell>;
  }
  const { data, error } = await createAdminClient().rpc("view_public_proposal", { p_token: token });
  if (error) {
    console.error("[proposal view]", error);
    return <Shell><Alert tone="error">This proposal can’t be shown right now. Please try again later.</Alert></Shell>;
  }
  const p = data as PublicProposal | null;
  if (!p) return <Shell><Alert tone="info">This proposal link is not valid or is no longer available.</Alert></Shell>;

  const open = p.status === "sent" || p.status === "viewed";
  return (
    <Shell>
      <p className="text-sm text-text-3">Proposal{p.client ? ` for ${p.client}` : ""}</p>
      <h1 className="mt-1 text-3xl font-semibold tracking-tight">{p.title}</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <Card className="p-4"><p className="text-xs text-text-3">Investment</p><p className="mt-1 text-xl font-semibold tabular-nums">{formatMoney(p.price, p.currency)}</p></Card>
        <Card className="p-4"><p className="text-xs text-text-3">Service</p><p className="mt-1 text-sm font-medium">{p.service ?? "—"}</p></Card>
        <Card className="p-4"><p className="text-xs text-text-3">Valid until</p><p className="mt-1 text-sm font-medium">{p.expiry_date ? formatDate(p.expiry_date) : "—"}</p></Card>
      </div>
      {[["Scope of work", p.scope], ["Timeline", p.timeline], ["Terms", p.terms]].map(([h, v]) =>
        v ? (
          <section key={h} className="mt-8">
            <h2 className="text-sm font-semibold">{h}</h2>
            <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-text-2">{v}</p>
          </section>
        ) : null,
      )}
      <div className="mt-10">
        {open ? (
          <ProposalResponse token={token} />
        ) : p.status === "accepted" ? (
          <Alert tone="success">Accepted{p.response_name ? ` by ${p.response_name}` : ""}{p.responded_at ? ` on ${formatDate(p.responded_at)}` : ""}. Thank you — we’ll be in touch.</Alert>
        ) : p.status === "rejected" ? (
          <Alert tone="info">This proposal was declined{p.responded_at ? ` on ${formatDate(p.responded_at)}` : ""}.</Alert>
        ) : (
          <Alert tone="warning">This proposal has expired. Contact {brand.contact.email} for an updated one.</Alert>
        )}
      </div>
    </Shell>
  );
}
