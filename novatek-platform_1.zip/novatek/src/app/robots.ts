import type { MetadataRoute } from "next";
import { publicEnv } from "@/lib/env";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/app", "/login", "/p/"] }],
    sitemap: `${publicEnv.siteUrl}/sitemap.xml`,
  };
}
