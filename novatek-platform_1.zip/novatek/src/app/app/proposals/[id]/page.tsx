import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CheckCircle2, Copy, Eye, Pencil, Send, XCircle } from "lucide-react";
import { Alert, ButtonLink, Card, CardHeader } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { CopyButton } from "@/components/ui/copy-button";
import { DescRow, MapBadge, SectionTitle } from "@/components/ui/status";
import { requirePermission } from "@/lib/auth/session";
import { canViewSales } from "@/lib/auth/permissions";
import { getPeopleMap, getServices } from "@/lib/data/lookups";
import { publicEnv } from "@/lib/env";
import { PROPOSAL_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";
import { formatDate, formatDateTime, formatMoney } from "@/lib/utils";
import { dayKey } from "@/lib/utils";
import { deleteDraftProposal, duplicateProposal, expireProposal, recordProposalResponse, sendProposal } from "@/app/app/deals/actions";

export default async function ProposalPage({ params }: PageProps<"/app/proposals/[id]">) {
  const session = await requirePermission(canViewSales);
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const [{ data: p }, people, services] = await Promise.all([
    supabase.from("proposals").select("*, deals(id, name, owner_id, created_by, won_at)").eq("id", id).maybeSingle(),
    getPeopleMap(), getServices(),
  ]);
  if (!p) notFound();
  const deal = p.deals as { id: string; name: string; owner_id: string | null; created_by: string | null; won_at: string | null };
  const canEdit = session.can("sales.manage") || deal.owner_id === session.userId || deal.created_by === session.userId;
  const link = `${publicEnv.siteUrl.replace(/\/$/, "")}/p/${p.public_token}`;
  const open = p.status === "sent" || p.status === "viewed";
  const expiredByDate = open && p.expiry_date && new Date(p.expiry_date) < new Date(dayKey(new Date()));

  return (
    <>
      <Link href={`/app/deals/${deal.id}`} className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> {deal.name}</Link>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{p.title}</h1>
          <div className="mt-2 flex items-center gap-2">
            <MapBadge map={PROPOSAL_STATUS} value={p.status} />
            <span className="text-sm text-text-3">{formatMoney(p.price, p.currency)}</span>
          </div>
        </div>
        {canEdit && p.status === "draft" && <ButtonLink href={`/app/proposals/${p.id}/edit`} variant="secondary"><Pencil className="size-4" /> Edit draft</ButtonLink>}
      </div>
      {expiredByDate && <div className="mb-6"><Alert tone="warning">The validity date has passed. The client link will show it as expired.</Alert></div>}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader title="Proposal" />
            <dl className="divide-y divide-border px-5 py-2">
              <DescRow label="Service">{services.find((s) => s.id === p.service_id)?.name}</DescRow>
              <DescRow label="Price">{formatMoney(p.price, p.currency)}</DescRow>
              <DescRow label="Valid until">{p.expiry_date ? formatDate(p.expiry_date) : null}</DescRow>
              <DescRow label="Scope">{p.scope ? <span className="whitespace-pre-wrap">{p.scope}</span> : null}</DescRow>
              <DescRow label="Timeline">{p.timeline ? <span className="whitespace-pre-wrap">{p.timeline}</span> : null}</DescRow>
              <DescRow label="Terms">{p.terms ? <span className="whitespace-pre-wrap">{p.terms}</span> : null}</DescRow>
            </dl>
          </Card>
        </div>

        <div className="space-y-6">
          {p.status !== "draft" && (
            <Card className="space-y-3 p-5">
              <SectionTitle>Client link</SectionTitle>
              <p className="break-all rounded-lg bg-surface-2 px-3 py-2 font-mono text-xs">{link}</p>
              <CopyButton value={link} label="Copy link" />
              <p className="text-xs text-text-3">Send this private link to the client. Opening it is recorded as a view; they can accept or decline on the page.</p>
            </Card>
          )}

          <Card className="p-5">
            <SectionTitle>Tracking</SectionTitle>
            <dl className="space-y-1.5 text-sm">
              <div className="flex justify-between gap-3"><dt className="text-text-3">Sent</dt><dd>{p.sent_at ? formatDateTime(p.sent_at) : "—"}</dd></div>
              <div className="flex justify-between gap-3"><dt className="flex items-center gap-1 text-text-3"><Eye className="size-3.5" /> Link opened</dt><dd>{p.view_count > 0 ? `${p.view_count}×` : "Not yet"}</dd></div>
              {p.first_viewed_at && <div className="flex justify-between gap-3"><dt className="text-text-3">First opened</dt><dd>{formatDateTime(p.first_viewed_at)}</dd></div>}
              {p.last_viewed_at && <div className="flex justify-between gap-3"><dt className="text-text-3">Last opened</dt><dd>{formatDateTime(p.last_viewed_at)}</dd></div>}
              {p.responded_at && (
                <div className="flex justify-between gap-3"><dt className="text-text-3">Response</dt>
                  <dd className="text-right">{formatDateTime(p.responded_at)}<br />
                    <span className="text-xs text-text-3">{p.response_source === "client_link" ? `by ${p.response_name} on the link` : "recorded by staff"}</span>
                  </dd>
                </div>
              )}
            </dl>
            {p.response_evidence && <p className="mt-3 rounded-lg bg-surface-2 p-3 text-xs text-text-2">Evidence: {p.response_evidence}</p>}
          </Card>

          {canEdit && (
            <Card className="space-y-3 p-5">
              <SectionTitle>Actions</SectionTitle>
              {p.status === "draft" && (
                <>
                  <ActionButton action={sendProposal.bind(null, p.id)} variant="brand" confirm="Mark as sent? The content is then locked and the client link becomes active." confirmLabel="Mark as sent">
                    <Send className="size-4" /> Mark as sent
                  </ActionButton>
                  <ActionButton action={deleteDraftProposal.bind(null, p.id)} variant="ghost" confirm="Delete this draft?" redirectTo={`/app/deals/${deal.id}`}>Delete draft</ActionButton>
                </>
              )}
              {open && (
                <>
                  <ActionButton
                    action={recordProposalResponse.bind(null, p.id, "accepted")}
                    variant="secondary"
                    prompt={{ label: "Evidence of acceptance", multiline: true, minLength: 10, placeholder: "e.g. Signed PDF received by email from the client on 14 Oct" }}
                    confirmLabel="Record accepted"
                  >
                    <CheckCircle2 className="size-4" /> Record accepted
                  </ActionButton>
                  <ActionButton
                    action={recordProposalResponse.bind(null, p.id, "rejected")}
                    variant="secondary"
                    prompt={{ label: "Evidence of rejection", multiline: true, minLength: 10, placeholder: "e.g. Client replied by email declining on 14 Oct" }}
                    confirmLabel="Record rejected"
                  >
                    <XCircle className="size-4" /> Record rejected
                  </ActionButton>
                  <ActionButton action={expireProposal.bind(null, p.id)} variant="ghost" confirm="Mark this proposal as expired? The client link will stop accepting responses.">Mark expired</ActionButton>
                </>
              )}
              {!deal.won_at && (
                <ActionButton action={duplicateProposal.bind(null, p.id)} variant="ghost" redirectTo="/app/proposals/{id}/edit">
                  <Copy className="size-4" /> New version
                </ActionButton>
              )}
            </Card>
          )}
          <p className="text-center text-xs text-text-3">Created {formatDate(p.created_at)}{p.created_by ? ` by ${people.get(p.created_by) ?? "a former user"}` : ""}</p>
        </div>
      </div>
    </>
  );
}
