import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { ProposalForm } from "@/components/sales/proposal-form";
import { requirePermission } from "@/lib/auth/session";
import { canViewSales } from "@/lib/auth/permissions";
import { getServices, opts } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";

export const metadata = { title: "Edit proposal" };

export default async function EditProposalPage({ params }: PageProps<"/app/proposals/[id]/edit">) {
  await requirePermission(canViewSales);
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const [{ data: p }, services] = await Promise.all([supabase.from("proposals").select("*").eq("id", id).maybeSingle(), getServices()]);
  if (!p) notFound();
  if (p.status !== "draft") redirect(`/app/proposals/${id}`);
  const s = (v: unknown) => (v === null || v === undefined ? "" : String(v));
  return (
    <>
      <Link href={`/app/proposals/${id}`} className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> {p.title}</Link>
      <PageHeader title="Edit proposal" description="Drafts can be edited freely. Once marked as sent, the content is locked." />
      <Card className="max-w-3xl p-5 sm:p-6">
        <ProposalForm
          proposalId={id}
          services={opts(services)}
          defaults={{ title: p.title, service_id: s(p.service_id), price: s(p.price), currency: p.currency, scope: s(p.scope),
            timeline: s(p.timeline), terms: s(p.terms), expiry_date: s(p.expiry_date) }}
        />
      </Card>
    </>
  );
}
