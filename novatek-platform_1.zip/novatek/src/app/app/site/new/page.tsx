import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { SiteEntryForm } from "@/components/marketing/forms";
import { requirePermission } from "@/lib/auth/session";
import { getServices, opts } from "@/lib/data/lookups";
import { getLookups } from "@/lib/leads/queries";

export const metadata = { title: "New website entry" };

export default async function NewSiteEntryPage() {
  await requirePermission("site.manage");
  const [lookups, services] = await Promise.all([getLookups(), getServices()]);
  return (
    <>
      <Link href="/app/site" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Website content</Link>
      <PageHeader title="New portfolio item or case study" />
      <Card className="max-w-3xl p-5 sm:p-6">
        <SiteEntryForm
          defaults={{ kind: "case_study", slug: "", title: "", client_name: "", client_permission: false, industry_id: "", service_id: "", summary: "", challenge: "",
            solution: "", results: "", image_url: "", project_url: "", status: "draft", position: "0" }}
          industries={opts(lookups.industries)} services={opts(services)}
        />
      </Card>
    </>
  );
}
