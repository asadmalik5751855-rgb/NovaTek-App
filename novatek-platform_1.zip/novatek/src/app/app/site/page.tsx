import Link from "next/link";
import { ExternalLink, Globe, Plus } from "lucide-react";
import { ButtonLink, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { MapBadge } from "@/components/ui/status";
import { requirePermission } from "@/lib/auth/session";
import { PUBLISH_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";

export const metadata = { title: "Website content" };

export default async function SiteContentPage() {
  await requirePermission("site.manage");
  const supabase = await createClient();
  const { data, error } = await supabase.from("site_entries").select("id, kind, slug, title, client_name, status, position").order("kind").order("position").order("created_at");
  if (error) throw error;
  const rows = data ?? [];
  return (
    <>
      <PageHeader
        title="Website content"
        description="Portfolio items and case studies shown on the public site. Publish only real work; a client can be named only with their permission."
        actions={<ButtonLink href="/app/site/new" variant="brand"><Plus className="size-4" /> New entry</ButtonLink>}
      />
      <Card className="overflow-hidden">
        {rows.length === 0 ? (
          <EmptyState icon={<Globe className="size-5" />} title="Nothing published yet" description="Until you publish entries, the public Portfolio and Case Studies pages say that case studies are being prepared — nothing is invented."
            action={<ButtonLink href="/app/site/new" variant="brand">Add your first case study</ButtonLink>} />
        ) : (
          <ul className="divide-y divide-border">
            {rows.map((r) => (
              <li key={r.id} className="flex items-center gap-3 px-5 py-3">
                <Link href={`/app/site/${r.id}`} className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium hover:text-accent">{r.title}</span>
                  <span className="block text-xs text-text-3">{r.kind === "case_study" ? "Case study" : "Portfolio"} · {r.client_name ?? "Anonymous client"}</span>
                </Link>
                <MapBadge map={PUBLISH_STATUS} value={r.status} />
                {r.status === "published" && (
                  <a href={r.kind === "case_study" ? `/case-studies/${r.slug}` : "/portfolio"} target="_blank" rel="noopener noreferrer" aria-label="View on site" className="text-text-3 hover:text-text"><ExternalLink className="size-4" /></a>
                )}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </>
  );
}
