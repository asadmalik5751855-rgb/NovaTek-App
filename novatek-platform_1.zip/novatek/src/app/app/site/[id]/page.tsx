import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { SiteEntryForm } from "@/components/marketing/forms";
import { requirePermission } from "@/lib/auth/session";
import { getServices, opts } from "@/lib/data/lookups";
import { getLookups } from "@/lib/leads/queries";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";

export const metadata = { title: "Edit website entry" };

export default async function EditSiteEntryPage({ params }: PageProps<"/app/site/[id]">) {
  await requirePermission("site.manage");
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const [{ data: e }, lookups, services] = await Promise.all([supabase.from("site_entries").select("*").eq("id", id).maybeSingle(), getLookups(), getServices()]);
  if (!e) notFound();
  const s = (v: unknown) => (v === null || v === undefined ? "" : String(v));
  return (
    <>
      <Link href="/app/site" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Website content</Link>
      <PageHeader title={e.title} />
      <Card className="max-w-3xl p-5 sm:p-6">
        <SiteEntryForm
          id={id}
          defaults={{ kind: e.kind, slug: e.slug, title: e.title, client_name: s(e.client_name), client_permission: e.client_permission, industry_id: s(e.industry_id),
            service_id: s(e.service_id), summary: e.summary, challenge: s(e.challenge), solution: s(e.solution), results: s(e.results), image_url: s(e.image_url),
            project_url: s(e.project_url), status: e.status, position: String(e.position) }}
          industries={opts(lookups.industries)} services={opts(services)}
        />
      </Card>
    </>
  );
}
