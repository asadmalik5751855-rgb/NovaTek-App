import { NextResponse, type NextRequest } from "next/server";
import { auditEvent } from "@/lib/audit";
import { recentlyReauthenticated } from "@/lib/auth/reauth";
import { getSession } from "@/lib/auth/session";
import { toCsv } from "@/lib/csv";
import { EXPORTS } from "@/lib/export";
import { createClient } from "@/lib/supabase/server";

const SELECT: Record<string, { table: string; columns: string; order: string; limit?: number }> = {
  leads: { table: "leads", order: "created_at", columns: "id, company_name, contact_name, email, phone, website, city, country_code, business_size, budget_range, estimated_value, currency, score, temperature, status:lead_statuses(name), source:lead_sources(name), service:services(name), industry:industries(name), assigned_to, utm_source, utm_medium, utm_campaign, consent_status, last_contacted_at, next_follow_up_at, created_at, archived_at" },
  clients: { table: "clients", order: "created_at", columns: "id, company_name, website, contact_name, email, phone, city, country_code, status, account_manager_id, created_at, archived_at" },
  deals: { table: "deals", order: "created_at", columns: "id, name, value, currency, probability, forecast_value, stage:deal_stages(name), owner_id, expected_close_date, won_at, lost_at, lost_reason, created_at" },
  commissions: { table: "commissions", order: "created_at", columns: "id, deal_id, user_id, base_amount, percent, fixed_amount, amount, currency, status, approved_at, paid_at, paid_reference, created_at" },
  audit: { table: "audit_logs", order: "created_at", columns: "id, created_at, actor_id, action, entity, entity_id, metadata", limit: 10000 },
};

const flat = (v: unknown) => (v && typeof v === "object" && !Array.isArray(v) && "name" in (v as object) ? (v as { name: string }).name : v);

export async function GET(_req: NextRequest, ctx: RouteContext<"/app/export/[kind]">) {
  const { kind } = await ctx.params;
  const spec = EXPORTS[kind];
  const sel = SELECT[kind];
  const session = await getSession();
  if (!session) return new NextResponse("Unauthorized", { status: 401 });
  if (!spec || !sel) return new NextResponse("Not found", { status: 404 });
  if (!session.can(spec.check)) return new NextResponse("Forbidden", { status: 403 });

  const supabase = await createClient();
  const { data: win } = await supabase.from("settings").select("value").eq("key", "security.reauth_minutes").maybeSingle();
  if (!(await recentlyReauthenticated(session.userId, Number(win?.value ?? 10)))) {
    return new NextResponse("Please confirm your password on the export page first.", { status: 403 });
  }

  const rows: Record<string, unknown>[] = [];
  const page = 1000;
  for (let from = 0; from < (sel.limit ?? 50000); from += page) {
    const { data, error } = await supabase.from(sel.table).select(sel.columns).order(sel.order, { ascending: false }).range(from, from + page - 1);
    if (error) {
      console.error("[export]", error);
      return new NextResponse("Export failed", { status: 500 });
    }
    rows.push(...((data ?? []) as unknown as Record<string, unknown>[]));
    if (!data || data.length < page) break;
  }
  const headers = sel.columns.split(",").map((c) => c.trim().split(":")[0].split("(")[0]);
  const csv = toCsv(headers, rows.map((r) => headers.map((h) => flat(r[h]))));
  await auditEvent(session.userId, "data.exported", kind, null, { rows: rows.length });
  const stamp = new Date().toISOString().slice(0, 10);
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="novatek-${kind}-${stamp}.csv"`,
      "Cache-Control": "private, no-store",
    },
  });
}
