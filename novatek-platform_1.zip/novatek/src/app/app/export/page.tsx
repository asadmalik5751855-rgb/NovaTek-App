import { Download, Lock } from "lucide-react";
import { Card, CardHeader, PageHeader, buttonClass } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { recentlyReauthenticated } from "@/lib/auth/reauth";
import { requirePermission } from "@/lib/auth/session";
import { getSetting } from "@/lib/data/lookups";
import { EXPORTS } from "@/lib/export";
import { confirmForExport } from "./actions";

export const metadata = { title: "Export data" };

export default async function ExportPage() {
  const session = await requirePermission({ anyOf: ["leads.export", "sales.manage", "reports.view", "commissions.manage", "audit.view"] });
  const minutes = await getSetting<number>("security.reauth_minutes", 10);
  const unlocked = await recentlyReauthenticated(session.userId, minutes);
  const allowed = Object.entries(EXPORTS).filter(([, e]) => session.can(e.check));
  return (
    <>
      <PageHeader title="Export data" description="Exports contain only records you can access. Every export is recorded in the audit log." />
      <Card className="max-w-3xl">
        <CardHeader title={unlocked ? "Downloads unlocked" : "Confirm your password"} description={unlocked ? `For ${minutes} minutes after confirming` : "Exports require re-authentication"} />
        {!unlocked ? (
          <div className="p-5">
            <ActionButton action={confirmForExport} variant="brand" prompt={{ label: "Password", type: "password", minLength: 1 }} confirmLabel="Confirm">
              <Lock className="size-4" /> Unlock exports
            </ActionButton>
          </div>
        ) : (
          <ul className="divide-y divide-border">
            {allowed.map(([k, e]) => (
              <li key={k} className="flex flex-col gap-2 px-5 py-3 sm:flex-row sm:items-center">
                <div className="flex-1"><p className="text-sm font-medium">{e.label}</p><p className="text-xs text-text-3">{e.description}</p></div>
                <a href={`/app/export/${k}`} className={buttonClass("secondary", "sm")} download><Download className="size-4" /> CSV</a>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </>
  );
}
