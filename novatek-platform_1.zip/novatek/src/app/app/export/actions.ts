"use server";

import { z } from "zod";
import { authorize } from "@/lib/auth/session";
import { confirmPassword, markReauthenticated } from "@/lib/auth/reauth";
import { toActionError, type ActionResult } from "@/lib/errors";

/** Re-authentication before downloading data. */
export async function confirmForExport(password?: string): Promise<ActionResult> {
  try {
    const session = await authorize({ anyOf: ["leads.export", "sales.manage", "reports.view", "commissions.manage", "audit.view"] });
    const p = z.string().min(1).max(200).safeParse(password);
    if (!p.success || !(await confirmPassword(session.profile.email, p.data))) return { ok: false, error: "Password is incorrect." };
    await markReauthenticated(session.userId);
    return { ok: true, data: undefined };
  } catch (e) {
    return toActionError(e, "confirmForExport");
  }
}
