import type { Metadata } from "next";
import Link from "next/link";
import { LogOut, Search } from "lucide-react";
import { BrandLogo, BrandMark } from "@/components/brand/brand-logo";
import { MobileNav, SidebarNav } from "@/components/app/app-nav";
import { GlobalSearch } from "@/components/app/global-search";
import { navFor } from "@/components/app/nav";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { InstallPrompt } from "@/components/pwa/install-prompt";
import { requireUser } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";
import { initials } from "@/lib/utils";
import { signOut } from "@/app/login/actions";

export const metadata: Metadata = { title: { default: "Platform", template: "%s · NovaTek Platform" }, robots: { index: false } };

export default async function AppLayout({ children }: LayoutProps<"/app">) {
  const session = await requireUser();
  const supabase = await createClient();
  const { count } = await supabase
    .from("notifications")
    .select("id", { count: "exact", head: true })
    .is("read_at", null);
  const groups = navFor(session.permissions);
  const unread = count ?? 0;
  const roleNames = session.roles.map((r) => r.name).join(", ") || "No role assigned";

  return (
    <div className="min-h-dvh bg-bg">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-border bg-surface lg:flex">
        <div className="flex h-16 shrink-0 items-center px-5">
          <Link href="/app" aria-label="NovaTek platform home">
            <BrandLogo height={24} plate />
          </Link>
        </div>
        <div className="flex-1 overflow-y-auto px-3 py-2">
          <SidebarNav groups={groups} unread={unread} />
        </div>
        <div className="border-t border-border p-3">
          <div className="flex items-center gap-3 rounded-lg px-2 py-2">
            <Link href={`/app/people/${session.userId}`} className="grid size-8 shrink-0 place-items-center rounded-full bg-surface-2 text-xs font-semibold text-text-2" aria-label="My profile">
              {initials(session.profile.full_name || session.profile.email)}
            </Link>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{session.profile.full_name || session.profile.email}</p>
              <p className="truncate text-xs text-text-3">{roleNames}</p>
            </div>
            <ThemeToggle />
          </div>
          <form action={signOut}>
            <button
              type="submit"
              className="mt-1 flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm text-text-2 hover:bg-surface-2 hover:text-text"
            >
              <LogOut className="size-4 text-text-3" /> Sign out
            </button>
          </form>
        </div>
      </aside>

      {/* Desktop top bar */}
      <header className="sticky top-0 z-20 hidden h-16 items-center border-b border-border bg-bg/85 px-8 backdrop-blur lg:ml-64 lg:flex">
        <GlobalSearch />
      </header>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-border bg-surface/95 px-4 backdrop-blur lg:hidden">
        <Link href="/app" aria-label="NovaTek platform home">
          <BrandMark size={30} />
        </Link>
        <div className="flex items-center gap-1">
          <Link href="/app/search" aria-label="Search" className="grid size-9 place-items-center rounded-lg text-text-2 hover:bg-surface-2">
            <Search className="size-4" />
          </Link>
          <ThemeToggle />
          <form action={signOut}>
            <button type="submit" aria-label="Sign out" className="grid size-9 place-items-center rounded-lg text-text-2 hover:bg-surface-2">
              <LogOut className="size-4" />
            </button>
          </form>
        </div>
      </header>

      <main className="px-4 pb-24 pt-6 sm:px-6 lg:ml-64 lg:px-8 lg:pb-10 lg:pt-8">
        <div className="mx-auto max-w-7xl">{children}</div>
      </main>
      <MobileNav groups={groups} unread={unread} />
      <InstallPrompt />
    </div>
  );
}
