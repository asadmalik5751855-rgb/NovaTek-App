import { GlobalSearch } from "@/components/app/global-search";
import { PageHeader } from "@/components/ui/primitives";
import { requireUser } from "@/lib/auth/session";

export const metadata = { title: "Search" };

export default async function SearchPage() {
  await requireUser();
  return (
    <>
      <PageHeader title="Search" description="Leads, clients, deals, projects, tasks and people you have access to." />
      <GlobalSearch />
    </>
  );
}
