"use server";

import { z } from "zod";
import { authorize } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";

export type SearchHit = { kind: string; id: string; title: string; subtitle: string | null; href: string };

/** Global search. Runs as the user: every result is filtered by that table's row-level security. */
export async function searchAll(q: string): Promise<SearchHit[]> {
  try {
    await authorize();
    const parsed = z.string().trim().min(2).max(80).safeParse(q);
    if (!parsed.success) return [];
    const supabase = await createClient();
    const { data, error } = await supabase.rpc("global_search", { p_q: parsed.data, p_limit: 5 });
    if (error) throw error;
    return (data ?? []) as SearchHit[];
  } catch (e) {
    console.error("[search]", e);
    return [];
  }
}
