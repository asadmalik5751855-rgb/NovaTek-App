import Link from "next/link";
import { CalendarDays, Plus, Video } from "lucide-react";
import { ButtonLink, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { MapBadge } from "@/components/ui/status";
import { requireUser } from "@/lib/auth/session";
import { MEETING_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { cn, dayKey, formatDay, formatTime } from "@/lib/utils";

export const metadata = { title: "Meetings" };

type M = { id: string; title: string; starts_at: string; duration_minutes: number; status: string; meeting_link: string | null;
  leads: { company_name: string } | null; clients: { company_name: string } | null };

export default async function MeetingsPage({ searchParams }: PageProps<"/app/meetings">) {
  await requireUser();
  const sp = await searchParams;
  const past = sp.past === "1";
  const supabase = await createClient();
  const now = new Date().toISOString();
  let q = supabase.from("meetings").select("id, title, starts_at, duration_minutes, status, meeting_link, leads(company_name), clients(company_name)").limit(200);
  q = past ? q.or(`starts_at.lt.${now},status.neq.scheduled`).order("starts_at", { ascending: false })
           : q.eq("status", "scheduled").gte("starts_at", new Date(new Date().getTime() - 3 * 3600e3).toISOString()).order("starts_at");
  const { data, error } = await q;
  if (error) throw error;
  const meetings = (data ?? []) as unknown as M[];
  const byDay = new Map<string, M[]>();
  for (const m of meetings) {
    const k = dayKey(m.starts_at);
    byDay.set(k, [...(byDay.get(k) ?? []), m]);
  }

  return (
    <>
      <PageHeader
        title="Meetings"
        description="Meetings you organise or attend, and meetings on leads you can access."
        actions={<ButtonLink href="/app/meetings/new" variant="brand"><Plus className="size-4" /> Schedule</ButtonLink>}
      />
      <div className="mb-4 inline-flex rounded-lg border border-border p-0.5 text-sm">
        <Link href="/app/meetings" className={cn("rounded-md px-3 py-1.5", !past ? "bg-surface-2 font-medium" : "text-text-3")}>Upcoming</Link>
        <Link href="/app/meetings?past=1" className={cn("rounded-md px-3 py-1.5", past ? "bg-surface-2 font-medium" : "text-text-3")}>Past & closed</Link>
      </div>
      {meetings.length === 0 ? (
        <Card><EmptyState icon={<CalendarDays className="size-5" />} title={past ? "No past meetings" : "Nothing scheduled"} description="Schedule a meeting from a lead, deal or client, or here." /></Card>
      ) : (
        <div className="space-y-5">
          {[...byDay.entries()].map(([day, items]) => (
            <Card key={day} className="overflow-hidden">
              <p className="border-b border-border px-5 py-2.5 text-sm font-semibold">
                <time>{formatDay(items[0].starts_at)}</time>
              </p>
              <ul className="divide-y divide-border">
                {items.map((m) => (
                  <li key={m.id} className="flex items-center gap-3 px-5 py-3">
                    <time className="w-14 shrink-0 text-sm tabular-nums text-text-2">{formatTime(m.starts_at)}</time>
                    <Link href={`/app/meetings/${m.id}`} className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-medium hover:text-accent">{m.title}</span>
                      <span className="block truncate text-xs text-text-3">{m.clients?.company_name ?? m.leads?.company_name ?? "Internal"} · {m.duration_minutes} min</span>
                    </Link>
                    {m.meeting_link && m.status === "scheduled" && (
                      <a href={m.meeting_link} target="_blank" rel="noopener noreferrer" aria-label="Join meeting" className="grid size-8 place-items-center rounded-md border border-border hover:bg-surface-2"><Video className="size-4" /></a>
                    )}
                    <MapBadge map={MEETING_STATUS} value={m.status} />
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}
