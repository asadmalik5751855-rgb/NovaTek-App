import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CheckCircle2, Video } from "lucide-react";
import { Card, CardHeader } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { DescRow, MapBadge, SectionTitle } from "@/components/ui/status";
import { AiAssist } from "@/components/ai/ai-assist";
import { MeetingNotes } from "@/components/work/meeting-notes";
import { requireUser } from "@/lib/auth/session";
import { getPeopleMap } from "@/lib/data/lookups";
import { AI_FEATURES } from "@/lib/integrations/ai";
import { MEETING_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";
import { formatDateTime } from "@/lib/utils";
import { setMeetingStatus } from "../actions";

export default async function MeetingPage({ params }: PageProps<"/app/meetings/[id]">) {
  const session = await requireUser();
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const { data: m } = await supabase.from("meetings").select("*, leads(id, company_name), clients(id, company_name), deals(id, name), projects(id, name)").eq("id", id).maybeSingle();
  if (!m) notFound();
  const [{ data: parts }, people] = await Promise.all([
    supabase.from("meeting_participants").select("user_id").eq("meeting_id", id), getPeopleMap(),
  ]);
  const canEdit = m.organizer_id === session.userId || session.can("sales.manage");
  const started = new Date(m.starts_at) <= new Date();
  const scheduled = m.status === "scheduled";

  return (
    <>
      <Link href="/app/meetings" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Meetings</Link>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">{m.title}</h1>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <MapBadge map={MEETING_STATUS} value={m.status} />
          <span className="text-sm text-text-3" suppressHydrationWarning>{formatDateTime(m.starts_at)} · {m.duration_minutes} min</span>
        </div>
      </div>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader title="Notes" description={canEdit ? "Agenda before, notes after. Only the organiser can edit." : undefined} />
            <div className="p-5"><MeetingNotes id={m.id} notes={m.notes ?? ""} canEdit={canEdit} /></div>
          </Card>
          {m.outcome && (
            <Card>
              <CardHeader title="Outcome" />
              <p className="whitespace-pre-wrap px-5 py-4 text-sm">{m.outcome}</p>
            </Card>
          )}
          {session.can("ai.use") && (m.notes || m.outcome) && (
            <Card className="p-5">
              <SectionTitle>AI assist</SectionTitle>
              <AiAssist entityId={m.id} features={[{ key: "meeting_summary", label: AI_FEATURES.meeting_summary.label }]} />
            </Card>
          )}
        </div>
        <div className="space-y-6">
          {canEdit && scheduled && (
            <Card className="space-y-3 p-5">
              <SectionTitle>Update</SectionTitle>
              {started ? (
                <>
                  <ActionButton action={setMeetingStatus.bind(null, m.id, "completed")} variant="brand"
                    prompt={{ label: "Outcome", multiline: true, placeholder: "What was agreed? Next steps?" }} confirmLabel="Mark completed">
                    <CheckCircle2 className="size-4" /> Mark completed
                  </ActionButton>
                  <ActionButton action={setMeetingStatus.bind(null, m.id, "no_show")} variant="secondary" confirm="Record that the other side didn’t attend?">No show</ActionButton>
                </>
              ) : (
                <p className="text-xs text-text-3">You can mark it completed once it has started.</p>
              )}
              <ActionButton action={setMeetingStatus.bind(null, m.id, "cancelled")} variant="ghost" confirm="Cancel this meeting? Participants are notified.">Cancel meeting</ActionButton>
            </Card>
          )}
          <Card>
            <dl className="divide-y divide-border px-5 py-2">
              <DescRow label="Join">{m.meeting_link ? <a href={m.meeting_link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-accent hover:underline"><Video className="size-3.5" /> Open link</a> : null}</DescRow>
              <DescRow label="Location">{m.location}</DescRow>
              <DescRow label="Organiser">{m.organizer_id ? people.get(m.organizer_id) ?? "A former user" : null}</DescRow>
              <DescRow label="Participants">{(parts ?? []).map((p) => people.get(p.user_id) ?? "—").join(", ") || null}</DescRow>
              <DescRow label="Client side">{m.external_attendees}</DescRow>
              <DescRow label="Lead">{m.leads ? <Link className="text-accent hover:underline" href={`/app/leads/${m.leads.id}`}>{m.leads.company_name}</Link> : null}</DescRow>
              <DescRow label="Client">{m.clients ? <Link className="text-accent hover:underline" href={`/app/clients/${m.clients.id}`}>{m.clients.company_name}</Link> : null}</DescRow>
              <DescRow label="Deal">{m.deals ? <Link className="text-accent hover:underline" href={`/app/deals/${m.deals.id}`}>{m.deals.name}</Link> : null}</DescRow>
              <DescRow label="Project">{m.projects ? <Link className="text-accent hover:underline" href={`/app/projects/${m.projects.id}`}>{m.projects.name}</Link> : null}</DescRow>
            </dl>
          </Card>
        </div>
      </div>
    </>
  );
}
