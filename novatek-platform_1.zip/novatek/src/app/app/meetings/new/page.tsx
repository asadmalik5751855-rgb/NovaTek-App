import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { MeetingForm } from "@/components/work/meeting-form";
import { requireUser } from "@/lib/auth/session";
import { getPeople } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";

export const metadata = { title: "Schedule meeting" };

export default async function NewMeetingPage({ searchParams }: PageProps<"/app/meetings/new">) {
  const session = await requireUser();
  const sp = await searchParams;
  const pick = (k: string) => (typeof sp[k] === "string" && validId(sp[k]) ? (sp[k] as string) : "");
  const leadId = pick("lead"), clientId = pick("client"), dealId = pick("deal"), projectId = pick("project");
  const supabase = await createClient();
  const [people, lead, client, deal] = await Promise.all([
    getPeople(),
    leadId ? supabase.from("leads").select("company_name").eq("id", leadId).maybeSingle() : Promise.resolve({ data: null }),
    clientId ? supabase.from("clients").select("company_name").eq("id", clientId).maybeSingle() : Promise.resolve({ data: null }),
    dealId ? supabase.from("deals").select("name").eq("id", dealId).maybeSingle() : Promise.resolve({ data: null }),
  ]);
  const links = [
    lead.data && { label: "Lead", value: lead.data.company_name as string },
    client.data && { label: "Client", value: client.data.company_name as string },
    deal.data && { label: "Deal", value: deal.data.name as string },
  ].filter(Boolean) as { label: string; value: string }[];
  const subject = (client.data?.company_name ?? lead.data?.company_name) as string | undefined;
  return (
    <>
      <Link href="/app/meetings" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Meetings</Link>
      <PageHeader title="Schedule a meeting" description="Scheduling with a lead adds it to the lead’s timeline and its ‘meeting booked’ score. It only counts as contact once marked completed." />
      <Card className="max-w-3xl p-5 sm:p-6">
        <MeetingForm
          defaults={{ title: subject ? `Call with ${subject}` : "", starts_at: "", duration_minutes: "30", meeting_link: "", location: "", external_attendees: "",
            notes: "", lead_id: lead.data ? leadId : "", client_id: client.data ? clientId : "", deal_id: deal.data ? dealId : "", project_id: projectId, participant_ids: [] }}
          people={people.filter((p) => p.id !== session.userId).map((p) => ({ value: p.id, label: p.full_name || "Unnamed user" }))}
          links={links}
        />
      </Card>
    </>
  );
}
