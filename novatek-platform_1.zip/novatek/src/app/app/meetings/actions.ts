"use server";

import { z } from "zod";
import { NOT_FOUND, ok, refresh, runAction, validId } from "@/lib/actions";
import { check, checkRow, type ActionResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { meetingNotesSchema, meetingSchema } from "@/lib/validation/work";

function linked(m: { lead_id?: string | null; client_id?: string | null; deal_id?: string | null }) {
  return [
    ...(m.lead_id ? [`/app/leads/${m.lead_id}`] : []),
    ...(m.client_id ? [`/app/clients/${m.client_id}`] : []),
    ...(m.deal_id ? [`/app/deals/${m.deal_id}`] : []),
  ];
}

export async function createMeeting(input: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction("createMeeting", null, meetingSchema, input, async ({ participant_ids, ...d }, session) => {
    const supabase = await createClient();
    const row = checkRow(await supabase.from("meetings").insert({ ...d, status: "scheduled" }).select("id").single());
    const others = [...new Set(participant_ids)].filter((u) => u !== session.userId);
    if (others.length) {
      const r = await supabase.from("meeting_participants").insert(others.map((user_id) => ({ meeting_id: row.id, user_id })));
      if (r.error) throw r.error;
    }
    refresh("/app/meetings", "/app", ...linked(d));
    return ok({ id: row.id as string });
  });
}

export async function updateMeetingNotes(id: string, input: unknown): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("updateMeetingNotes", null, meetingNotesSchema, input, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("meetings").update(d).eq("id", id).select("id"));
    if (!rows?.length) return { ok: false, error: "Only the organiser can edit notes." };
    refresh(`/app/meetings/${id}`);
    return ok();
  });
}

export async function setMeetingStatus(id: string, status: "completed" | "cancelled" | "no_show", outcome?: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  const schema = z.object({ status: z.enum(["completed", "cancelled", "no_show"]), outcome: z.string().trim().max(5000).optional() });
  return runAction("setMeetingStatus", null, schema, { status, outcome }, async (d) => {
    const supabase = await createClient();
    const patch: Record<string, unknown> = { status: d.status };
    if (d.outcome) patch.outcome = d.outcome;
    const rows = check(await supabase.from("meetings").update(patch).eq("id", id).select("id, lead_id, client_id, deal_id"));
    if (!rows?.length) return { ok: false, error: "Only the organiser can update this meeting." };
    refresh("/app/meetings", `/app/meetings/${id}`, ...linked(rows[0]));
    return ok();
  });
}

export async function rescheduleMeeting(id: string, startsAtIso?: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  const schema = z.object({ starts_at: z.iso.datetime({ offset: true, message: "Choose a valid date and time" }) });
  return runAction("rescheduleMeeting", null, schema, { starts_at: startsAtIso }, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("meetings").update({ starts_at: d.starts_at }).eq("id", id).eq("status", "scheduled").select("id"));
    if (!rows?.length) return { ok: false, error: "Only scheduled meetings can be moved, by their organiser." };
    refresh("/app/meetings", `/app/meetings/${id}`);
    return ok();
  });
}
