import { PageHeader } from "@/components/ui/primitives";
import { RangeFilter } from "@/components/charts/range-filter";
import { BreakdownTable, FunnelCard, LeadsTrend, RevenueTrend, SalesKpis } from "@/components/insights/blocks";
import { requirePermission } from "@/lib/auth/session";
import { getBreakdown, getSeries, getSummary, resolveRange } from "@/lib/data/analytics";
import { getSetting } from "@/lib/data/lookups";
import { formatDate } from "@/lib/utils";

export const metadata = { title: "Analytics" };

export default async function AnalyticsPage({ searchParams }: PageProps<"/app/analytics">) {
  await requirePermission("reports.view");
  const r = resolveRange(await searchParams);
  const [summary, series, source, industry, country, service, owner, campaign, base] = await Promise.all([
    getSummary(r.from, r.to), getSeries(r.from, r.to, r.bucket),
    getBreakdown("source", r.from, r.to), getBreakdown("industry", r.from, r.to), getBreakdown("country", r.from, r.to),
    getBreakdown("service", r.from, r.to), getBreakdown("owner", r.from, r.to), getBreakdown("campaign", r.from, r.to),
    getSetting<string>("finance.base_currency", "USD"),
  ]);
  return (
    <>
      <PageHeader
        title="Analytics"
        description={`${formatDate(r.fromDate)} – ${formatDate(r.toDate)}. Every number is computed live from the database and limited to records you can access.`}
        actions={<RangeFilter active={r.key} from={r.fromDate} to={r.toDate} />}
      />
      <div className="space-y-6">
        <SalesKpis s={summary} />
        <div className="grid gap-6 xl:grid-cols-2">
          <LeadsTrend series={series} bucket={r.bucket} />
          <RevenueTrend series={series} bucket={r.bucket} currency={base} />
        </div>
        <FunnelCard s={summary} />
        <div className="grid gap-6 xl:grid-cols-2">
          <BreakdownTable title="Lead sources" description="Which source actually produces business" rows={source} nameLabel="Source" />
          <BreakdownTable title="Campaigns" description="By utm_campaign" rows={campaign} nameLabel="Campaign" />
          <BreakdownTable title="Services" rows={service} nameLabel="Service" />
          <BreakdownTable title="Industries" rows={industry} nameLabel="Industry" />
          <BreakdownTable title="Countries" rows={country} nameLabel="Country" />
          <BreakdownTable title="Salespeople" description="By current lead owner" rows={owner} nameLabel="Owner" />
        </div>
      </div>
    </>
  );
}
