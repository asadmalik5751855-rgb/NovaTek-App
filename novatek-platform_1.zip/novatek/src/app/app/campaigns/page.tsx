import Link from "next/link";
import { Megaphone, Plus } from "lucide-react";
import { ButtonLink, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { MapBadge, MoneyList } from "@/components/ui/status";
import { requirePermission } from "@/lib/auth/session";
import { canViewCampaigns } from "@/lib/auth/permissions";
import { campaignStats } from "@/lib/data/campaigns";
import { CAMPAIGN_CHANNEL, CAMPAIGN_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { formatDate, formatMoney } from "@/lib/utils";

export const metadata = { title: "Campaigns" };

export default async function CampaignsPage() {
  const session = await requirePermission(canViewCampaigns);
  const supabase = await createClient();
  const { data, error } = await supabase.from("campaigns").select("id, name, utm_campaign, channel, status, start_date, end_date, spend, currency").order("created_at", { ascending: false });
  if (error) throw error;
  const campaigns = data ?? [];
  const stats = await campaignStats(campaigns.map((c) => c.id));

  return (
    <>
      <PageHeader
        title="Campaigns"
        description="Results come from leads actually attributed to each campaign (utm_campaign or its landing page). Cost per lead uses the spend you record."
        actions={session.can("campaigns.manage") && <ButtonLink href="/app/campaigns/new" variant="brand"><Plus className="size-4" /> New campaign</ButtonLink>}
      />
      <Card className="overflow-hidden">
        {campaigns.length === 0 ? (
          <EmptyState icon={<Megaphone className="size-5" />} title="No campaigns" description="Create a campaign and use its utm_campaign value in your links and ads."
            action={session.can("campaigns.manage") ? <ButtonLink href="/app/campaigns/new" variant="brand">New campaign</ButtonLink> : undefined} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead className="border-b border-border bg-surface-2/50 text-left text-xs font-medium uppercase tracking-wide text-text-3">
                <tr>
                  <th className="px-4 py-2.5">Campaign</th><th className="px-4 py-2.5">Status</th><th className="px-4 py-2.5 text-right">Leads</th>
                  <th className="px-4 py-2.5 text-right">Qualified</th><th className="px-4 py-2.5 text-right">Won</th><th className="px-4 py-2.5">Revenue</th>
                  <th className="px-4 py-2.5 text-right">Cost / lead</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {campaigns.map((c) => {
                  const s = stats.get(c.id)!;
                  return (
                    <tr key={c.id} className="hover:bg-surface-2/40">
                      <td className="px-4 py-3">
                        <Link href={`/app/campaigns/${c.id}`} className="font-medium hover:text-accent">{c.name}</Link>
                        <div className="text-xs text-text-3">{CAMPAIGN_CHANNEL[c.channel as keyof typeof CAMPAIGN_CHANNEL]} · <code>{c.utm_campaign}</code>{c.start_date && ` · ${formatDate(c.start_date)}`}</div>
                      </td>
                      <td className="px-4 py-3"><MapBadge map={CAMPAIGN_STATUS} value={c.status} /></td>
                      <td className="px-4 py-3 text-right tabular-nums">{s.leads}</td>
                      <td className="px-4 py-3 text-right tabular-nums">{s.qualified}</td>
                      <td className="px-4 py-3 text-right tabular-nums">{s.won}</td>
                      <td className="px-4 py-3"><MoneyList items={s.revenue} /></td>
                      <td className="px-4 py-3 text-right tabular-nums">{s.leads && Number(c.spend) > 0 ? formatMoney(Number(c.spend) / s.leads, c.currency) : "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}
