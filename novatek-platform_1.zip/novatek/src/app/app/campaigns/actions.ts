"use server";

import { NOT_FOUND, ok, refresh, runAction, validId } from "@/lib/actions";
import { check, checkRow, type ActionResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { campaignSchema, landingPageSchema, siteEntrySchema } from "@/lib/validation/marketing";

export async function createCampaign(input: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction("createCampaign", "campaigns.manage", campaignSchema, input, async (d) => {
    const supabase = await createClient();
    const row = checkRow(await supabase.from("campaigns").insert(d).select("id").single());
    refresh("/app/campaigns");
    return ok({ id: row.id as string });
  });
}

export async function updateCampaign(id: string, input: unknown): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("updateCampaign", "campaigns.manage", campaignSchema, input, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("campaigns").update(d).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh("/app/campaigns", `/app/campaigns/${id}`);
    return ok();
  });
}

export async function saveLandingPage(id: string | null, input: unknown): Promise<ActionResult<{ id: string }>> {
  if (id !== null && !validId(id)) return NOT_FOUND;
  return runAction("saveLandingPage", "campaigns.manage", landingPageSchema, input, async ({ testimonials_confirmed: _ok, ...d }) => {
    void _ok;
    const supabase = await createClient();
    if (id) {
      const rows = check(await supabase.from("landing_pages").update(d).eq("id", id).select("id, slug"));
      if (!rows?.length) return NOT_FOUND;
      refresh("/app/landing-pages", `/app/landing-pages/${id}`, `/l/${rows[0].slug}`);
      return ok({ id });
    }
    const row = checkRow(await supabase.from("landing_pages").insert(d).select("id").single());
    refresh("/app/landing-pages");
    return ok({ id: row.id as string });
  });
}

export async function saveSiteEntry(id: string | null, input: unknown): Promise<ActionResult<{ id: string }>> {
  if (id !== null && !validId(id)) return NOT_FOUND;
  return runAction("saveSiteEntry", "site.manage", siteEntrySchema, input, async (d) => {
    const supabase = await createClient();
    let newId = id;
    if (id) {
      const rows = check(await supabase.from("site_entries").update(d).eq("id", id).select("id"));
      if (!rows?.length) return NOT_FOUND;
    } else {
      newId = checkRow(await supabase.from("site_entries").insert(d).select("id").single()).id as string;
    }
    refresh("/app/site", "/portfolio", "/case-studies", `/case-studies/${d.slug}`);
    return ok({ id: newId! });
  });
}

