import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { CampaignForm } from "@/components/marketing/forms";
import { requirePermission } from "@/lib/auth/session";
import { getPeople, getServices, opts } from "@/lib/data/lookups";
import { getLookups } from "@/lib/leads/queries";

export const metadata = { title: "New campaign" };

export default async function NewCampaignPage() {
  await requirePermission("campaigns.manage");
  const [lookups, services, people] = await Promise.all([getLookups(), getServices(), getPeople()]);
  return (
    <>
      <Link href="/app/campaigns" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Campaigns</Link>
      <PageHeader title="New campaign" />
      <Card className="max-w-3xl p-5 sm:p-6">
        <CampaignForm
          defaults={{ name: "", utm_campaign: "", channel: "social", status: "draft", description: "", start_date: "", end_date: "", budget: "", spend: "0", currency: "USD",
            target_industry_id: "", target_country_code: "", service_id: "", owner_id: "" }}
          industries={opts(lookups.industries)} countries={lookups.countries.map((c) => ({ value: c.code, label: c.name }))}
          services={opts(services)} people={opts(people)}
        />
      </Card>
    </>
  );
}
