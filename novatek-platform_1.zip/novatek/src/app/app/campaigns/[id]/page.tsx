import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Card, CardHeader } from "@/components/ui/primitives";
import { CopyButton } from "@/components/ui/copy-button";
import { MapBadge, MoneyList, StatCard } from "@/components/ui/status";
import { TemperatureBadge } from "@/components/leads/badges";
import { CampaignForm } from "@/components/marketing/forms";
import { requirePermission } from "@/lib/auth/session";
import { canViewCampaigns } from "@/lib/auth/permissions";
import { campaignStats } from "@/lib/data/campaigns";
import { getPeople, getServices, opts } from "@/lib/data/lookups";
import { publicEnv } from "@/lib/env";
import { getLookups } from "@/lib/leads/queries";
import { CAMPAIGN_CHANNEL, CAMPAIGN_STATUS } from "@/lib/labels";
import type { Temperature } from "@/lib/leads/normalize";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";
import { formatDate, formatMoney } from "@/lib/utils";

export default async function CampaignPage({ params }: PageProps<"/app/campaigns/[id]">) {
  const session = await requirePermission(canViewCampaigns);
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const { data: c } = await supabase.from("campaigns").select("*").eq("id", id).maybeSingle();
  if (!c) notFound();
  const [stats, leads, pages, lookups, services, people] = await Promise.all([
    campaignStats([id]),
    supabase.from("campaign_leads").select("added_at, leads(id, company_name, score, temperature, created_at)").eq("campaign_id", id).order("added_at", { ascending: false }).limit(50),
    supabase.from("landing_pages").select("id, slug, headline, status").eq("campaign_id", id),
    getLookups(), getServices(), getPeople(),
  ]);
  const s = stats.get(id)!;
  const spend = Number(c.spend);
  const link = `${publicEnv.siteUrl.replace(/\/$/, "")}/contact?utm_source=${c.channel}&utm_medium=${c.channel}&utm_campaign=${c.utm_campaign}`;
  const str = (v: unknown) => (v === null || v === undefined ? "" : String(v));
  const rows = (leads.data ?? []) as unknown as { added_at: string; leads: { id: string; company_name: string; score: number; temperature: Temperature; created_at: string } | null }[];

  return (
    <>
      <Link href="/app/campaigns" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Campaigns</Link>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">{c.name}</h1>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <MapBadge map={CAMPAIGN_STATUS} value={c.status} />
          <span className="text-sm text-text-3">{CAMPAIGN_CHANNEL[c.channel as keyof typeof CAMPAIGN_CHANNEL]} · utm_campaign=<code>{c.utm_campaign}</code></span>
        </div>
      </div>
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <StatCard label="Leads" value={s.leads} />
        <StatCard label="Qualified" value={s.qualified} hint={s.leads ? `${Math.round((s.qualified / s.leads) * 100)}% of leads` : undefined} />
        <StatCard label="Won" value={s.won} hint={s.leads ? `${Math.round((s.won / s.leads) * 100)}% conversion` : undefined} />
        <StatCard label="Revenue" value={<MoneyList items={s.revenue} />} />
        <StatCard label="Cost per lead" value={s.leads && spend > 0 ? formatMoney(spend / s.leads, c.currency) : "—"} hint={spend > 0 ? `${formatMoney(spend, c.currency)} spent` : "Record spend to calculate"} />
      </div>
      <div className="grid gap-6 lg:grid-cols-5">
        <div className="space-y-6 lg:col-span-2">
          <Card className="space-y-2 p-5">
            <h2 className="text-sm font-semibold">Tracking link</h2>
            <p className="break-all rounded-lg bg-surface-2 px-3 py-2 font-mono text-xs">{link}</p>
            <CopyButton value={link} label="Copy link" />
            <p className="text-xs text-text-3">Any link carrying <code>utm_campaign={c.utm_campaign}</code> is attributed here.</p>
          </Card>
          <Card>
            <CardHeader title="Landing pages" />
            {(pages.data ?? []).length === 0 ? <p className="px-5 py-4 text-sm text-text-3">None linked. <Link href="/app/landing-pages/new" className="text-accent hover:underline">Create one</Link></p> : (
              <ul className="divide-y divide-border">
                {(pages.data ?? []).map((p) => (
                  <li key={p.id}><Link href={`/app/landing-pages/${p.id}`} className="flex items-center justify-between gap-2 px-5 py-2.5 text-sm hover:bg-surface-2/50"><span className="truncate">/l/{p.slug}</span><span className="text-xs text-text-3">{p.status}</span></Link></li>
                ))}
              </ul>
            )}
          </Card>
          <Card>
            <CardHeader title="Latest attributed leads" description="Only leads you have access to are listed" />
            {rows.length === 0 ? <p className="px-5 py-4 text-sm text-text-3">No leads yet.</p> : (
              <ul className="divide-y divide-border">
                {rows.filter((r) => r.leads).map((r) => (
                  <li key={r.leads!.id}><Link href={`/app/leads/${r.leads!.id}`} className="flex items-center gap-2 px-5 py-2.5 hover:bg-surface-2/50">
                    <span className="flex-1 truncate text-sm">{r.leads!.company_name}</span>
                    <span className="text-xs text-text-3">{formatDate(r.leads!.created_at)}</span>
                    <TemperatureBadge temperature={r.leads!.temperature} score={r.leads!.score} />
                  </Link></li>
                ))}
              </ul>
            )}
          </Card>
        </div>
        {session.can("campaigns.manage") && (
          <Card className="p-5 sm:p-6 lg:col-span-3">
            <h2 className="mb-4 text-sm font-semibold">Edit campaign</h2>
            <CampaignForm
              id={id}
              defaults={{ name: c.name, utm_campaign: c.utm_campaign, channel: c.channel, status: c.status, description: str(c.description), start_date: str(c.start_date),
                end_date: str(c.end_date), budget: str(c.budget), spend: str(c.spend), currency: c.currency, target_industry_id: str(c.target_industry_id),
                target_country_code: str(c.target_country_code), service_id: str(c.service_id), owner_id: str(c.owner_id) }}
              industries={opts(lookups.industries)} countries={lookups.countries.map((x) => ({ value: x.code, label: x.name }))}
              services={opts(services)} people={opts(people)}
            />
          </Card>
        )}
      </div>
    </>
  );
}
