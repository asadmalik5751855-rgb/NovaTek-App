"use server";

import { z } from "zod";
import { NOT_FOUND, ok, refresh, runAction, validId } from "@/lib/actions";
import { canViewSales } from "@/lib/auth/permissions";
import { check, checkRow, type ActionResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { idSchema } from "@/lib/validation/common";
import { dealSchema, dealUpdateSchema, proposalSchema } from "@/lib/validation/sales";

const paths = (id?: string) => ["/app/deals", "/app", ...(id ? [`/app/deals/${id}`] : [])];

export async function createDeal(input: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction("createDeal", canViewSales, dealSchema, input, async (d) => {
    const supabase = await createClient();
    const row = checkRow(await supabase.from("deals").insert(d).select("id").single());
    refresh(...paths(), ...(d.lead_id ? [`/app/leads/${d.lead_id}`] : []));
    return ok({ id: row.id as string });
  });
}

export async function updateDeal(id: string, input: unknown): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("updateDeal", canViewSales, dealUpdateSchema, input, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("deals").update(d).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(...paths(id));
    return ok();
  });
}

export async function moveDealStage(id: string, stageId: string): Promise<ActionResult> {
  if (!validId(id) || !validId(stageId)) return NOT_FOUND;
  return runAction("moveDealStage", canViewSales, z.object({}), {}, async () => {
    const supabase = await createClient();
    const { data: stage } = await supabase.from("deal_stages").select("default_probability, is_won, is_lost").eq("id", stageId).maybeSingle();
    if (!stage) return NOT_FOUND;
    if (stage.is_won || stage.is_lost) return { ok: false, error: "Use “Mark won” or “Mark lost” to close a deal." };
    const rows = check(await supabase.from("deals").update({ stage_id: stageId, probability: stage.default_probability }).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(...paths(id));
    return ok();
  });
}

export async function markDealWon(id: string, finalValue?: string): Promise<ActionResult<{ client_id: string | null }>> {
  if (!validId(id)) return NOT_FOUND;
  const schema = z.object({ value: z.union([z.literal(""), z.coerce.number().min(0).max(1_000_000_000)]).optional() });
  return runAction("markDealWon", canViewSales, schema, { value: finalValue ?? "" }, async (d) => {
    const supabase = await createClient();
    const res = check(await supabase.rpc("mark_deal_won", { p_deal: id, p_value: d.value === "" || d.value === undefined ? null : d.value }));
    refresh(...paths(id), "/app/clients", "/app/commissions", "/app/leads", "/app/pipeline");
    return ok({ client_id: (res as { client_id: string | null }).client_id });
  });
}

export async function markDealLost(id: string, reason?: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  const schema = z.object({ reason: z.string().trim().min(3, "Give a reason").max(1000) });
  return runAction("markDealLost", canViewSales, schema, { reason: reason ?? "" }, async (d) => {
    const supabase = await createClient();
    check(await supabase.rpc("mark_deal_lost", { p_deal: id, p_reason: d.reason }));
    refresh(...paths(id), "/app/leads", "/app/pipeline");
    return ok();
  });
}

export async function setDealArchived(id: string, archived: boolean): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("setDealArchived", "sales.manage", z.object({}), {}, async () => {
    const supabase = await createClient();
    const rows = check(await supabase.from("deals").update({ archived_at: archived ? new Date().toISOString() : null }).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(...paths(id));
    return ok();
  });
}

// ----------------------------------------------------------------------------- proposals

export async function createProposal(dealId: string, input: unknown): Promise<ActionResult<{ id: string }>> {
  if (!validId(dealId)) return NOT_FOUND;
  return runAction("createProposal", canViewSales, proposalSchema, input, async (d) => {
    const supabase = await createClient();
    const row = checkRow(await supabase.from("proposals").insert({ ...d, deal_id: dealId }).select("id").single());
    refresh(`/app/deals/${dealId}`);
    return ok({ id: row.id as string });
  });
}

export async function updateProposal(id: string, input: unknown): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("updateProposal", canViewSales, proposalSchema, input, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("proposals").update(d).eq("id", id).select("id, deal_id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(`/app/proposals/${id}`, `/app/deals/${rows[0].deal_id}`);
    return ok();
  });
}

async function setProposalStatus(id: string, status: string, extra: Record<string, unknown> = {}) {
  const supabase = await createClient();
  const rows = check(await supabase.from("proposals").update({ status, ...extra }).eq("id", id).select("id, deal_id"));
  if (!rows?.length) return NOT_FOUND;
  refresh(`/app/proposals/${id}`, `/app/deals/${rows[0].deal_id}`, "/app/deals");
  return ok();
}

export async function sendProposal(id: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("sendProposal", canViewSales, z.object({}), {}, () => setProposalStatus(id, "sent"));
}

export async function recordProposalResponse(id: string, status: "accepted" | "rejected", evidence?: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  const schema = z.object({
    status: z.enum(["accepted", "rejected"]),
    evidence: z.string().trim().min(10, "Describe the evidence (at least 10 characters)").max(2000),
  });
  return runAction("recordProposalResponse", canViewSales, schema, { status, evidence: evidence ?? "" }, (d) =>
    setProposalStatus(id, d.status, { response_evidence: d.evidence }));
}

export async function expireProposal(id: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("expireProposal", canViewSales, z.object({}), {}, () => setProposalStatus(id, "expired"));
}

export async function deleteDraftProposal(id: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("deleteDraftProposal", canViewSales, z.object({}), {}, async () => {
    const supabase = await createClient();
    const rows = check(await supabase.from("proposals").delete().eq("id", id).eq("status", "draft").select("deal_id"));
    if (!rows?.length) return { ok: false, error: "Only drafts can be deleted." };
    refresh(`/app/deals/${rows[0].deal_id}`);
    return ok();
  });
}

export async function duplicateProposal(id: string): Promise<ActionResult<{ id: string }>> {
  if (!idSchema.safeParse(id).success) return NOT_FOUND;
  return runAction("duplicateProposal", canViewSales, z.object({}), {}, async () => {
    const supabase = await createClient();
    const { data: p } = await supabase.from("proposals").select("deal_id, title, service_id, scope, price, currency, timeline, terms, expiry_date").eq("id", id).maybeSingle();
    if (!p) return NOT_FOUND;
    const row = checkRow(await supabase.from("proposals").insert({ ...p, title: `${p.title} (v2)`.slice(0, 200), expiry_date: null }).select("id").single());
    refresh(`/app/deals/${p.deal_id}`);
    return ok({ id: row.id as string });
  });
}
