import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { DealForm } from "@/components/sales/deal-form";
import { requirePermission } from "@/lib/auth/session";
import { canViewSales } from "@/lib/auth/permissions";
import { getClientOptions, getDealStages, getPeople, getServices, opts } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";

export const metadata = { title: "Edit deal" };

export default async function EditDealPage({ params }: PageProps<"/app/deals/[id]/edit">) {
  const session = await requirePermission(canViewSales);
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const [{ data: d }, stages, people, services, clients] = await Promise.all([
    supabase.from("deals").select("*").eq("id", id).maybeSingle(), getDealStages(), getPeople(), getServices(), getClientOptions(),
  ]);
  if (!d) notFound();
  const canEdit = session.can("sales.manage") || d.owner_id === session.userId || d.created_by === session.userId;
  if (!canEdit || d.won_at) redirect(`/app/deals/${id}`);
  const current = stages.find((s) => s.id === d.stage_id);
  const open = stages.filter((s) => (!s.is_won && !s.is_lost) || s.id === current?.id);
  const s = (v: unknown) => (v === null || v === undefined ? "" : String(v));
  return (
    <>
      <Link href={`/app/deals/${id}`} className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> {d.name}</Link>
      <PageHeader title="Edit deal" />
      <Card className="max-w-3xl p-5 sm:p-6">
        <DealForm
          mode="edit"
          dealId={id}
          defaults={{ name: d.name, client_id: s(d.client_id), stage_id: d.stage_id, value: s(d.value), currency: d.currency, probability: s(d.probability),
            expected_close_date: s(d.expected_close_date), owner_id: s(d.owner_id), service_id: s(d.service_id), notes: s(d.notes) }}
          stages={open}
          leads={[]}
          clients={opts(clients)}
          people={opts(people)}
          services={opts(services)}
          canAssign={session.can("sales.manage")}
        />
      </Card>
    </>
  );
}
