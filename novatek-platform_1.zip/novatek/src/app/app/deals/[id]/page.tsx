import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CalendarPlus, FileText, Pencil, Trophy, XCircle } from "lucide-react";
import { Alert, Badge, ButtonLink, Card, CardHeader, EmptyState } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { DescRow, MapBadge, SectionTitle } from "@/components/ui/status";
import { DocumentsCard } from "@/components/documents/documents-card";
import { ProposalForm } from "@/components/sales/proposal-form";
import { requirePermission } from "@/lib/auth/session";
import { canViewSales } from "@/lib/auth/permissions";
import { getDealStages, getPeopleMap, getServices, opts } from "@/lib/data/lookups";
import { COMMISSION_STATUS, MEETING_STATUS, PROPOSAL_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";
import { formatDate, formatDateTime, formatMoney } from "@/lib/utils";
import { markDealLost, markDealWon, setDealArchived } from "../actions";

export default async function DealPage({ params }: PageProps<"/app/deals/[id]">) {
  const session = await requirePermission(canViewSales);
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const [{ data: d }, stages, people, services] = await Promise.all([
    supabase.from("deals").select("*, leads(id, company_name), clients(id, company_name)").eq("id", id).maybeSingle(),
    getDealStages(), getPeopleMap(), getServices(),
  ]);
  if (!d) notFound();
  const [proposals, meetings, commissions] = await Promise.all([
    supabase.from("proposals").select("id, title, status, price, currency, sent_at, view_count, expiry_date, created_at").eq("deal_id", id).order("created_at", { ascending: false }),
    supabase.from("meetings").select("id, title, starts_at, status").eq("deal_id", id).order("starts_at", { ascending: false }).limit(20),
    supabase.from("commissions").select("id, user_id, amount, currency, status").eq("deal_id", id),
  ]);
  const stage = stages.find((s) => s.id === d.stage_id);
  const closed = Boolean(d.won_at || d.lost_at);
  const canEdit = session.can("sales.manage") || d.owner_id === session.userId || d.created_by === session.userId;
  const service = services.find((s) => s.id === d.service_id)?.name;
  const company = d.clients?.company_name ?? d.leads?.company_name;

  return (
    <>
      <Link href="/app/deals" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Deals</Link>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{d.name}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            {stage && <Badge color={stage.color}>{stage.name}</Badge>}
            {company && <span className="text-sm text-text-3">{company}</span>}
            {d.archived_at && <Badge color="zinc">Archived</Badge>}
          </div>
        </div>
        {canEdit && !d.won_at && (
          <ButtonLink href={`/app/deals/${d.id}/edit`} variant="secondary"><Pencil className="size-4" /> Edit</ButtonLink>
        )}
      </div>

      {d.won_at && (
        <div className="mb-6"><Alert tone="success">Won on {formatDateTime(d.won_at)}{d.closed_by ? ` by ${people.get(d.closed_by) ?? "a former user"}` : ""}. Won deals are closed and can’t be edited.</Alert></div>
      )}
      {d.lost_at && (
        <div className="mb-6"><Alert tone="warning">Lost on {formatDateTime(d.lost_at)}: {d.lost_reason}</Alert></div>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader title="Details" />
            <dl className="divide-y divide-border px-5 py-2">
              <DescRow label="Value">{formatMoney(d.value, d.currency)}</DescRow>
              <DescRow label="Probability">{d.probability}%</DescRow>
              <DescRow label="Forecast">{closed ? "—" : <span>{formatMoney(d.forecast_value, d.currency)} <span className="text-xs text-text-3">(projection, not revenue)</span></span>}</DescRow>
              <DescRow label="Expected close">{d.expected_close_date ? formatDate(d.expected_close_date) : null}</DescRow>
              <DescRow label="Salesperson">{d.owner_id ? people.get(d.owner_id) ?? "A former user" : null}</DescRow>
              <DescRow label="Service">{service}</DescRow>
              <DescRow label="Lead">{d.leads ? <Link className="text-accent hover:underline" href={`/app/leads/${d.leads.id}`}>{d.leads.company_name}</Link> : null}</DescRow>
              <DescRow label="Client">{d.clients ? <Link className="text-accent hover:underline" href={`/app/clients/${d.clients.id}`}>{d.clients.company_name}</Link> : null}</DescRow>
              <DescRow label="Created">{formatDateTime(d.created_at)}{d.created_by ? ` by ${people.get(d.created_by) ?? "a former user"}` : ""}</DescRow>
              {d.notes && <DescRow label="Notes"><span className="whitespace-pre-wrap">{d.notes}</span></DescRow>}
            </dl>
          </Card>

          <Card>
            <CardHeader title="Proposals" description="Viewed and accepted are only shown with real evidence: the client opening or answering the link, or staff recording proof." />
            {(proposals.data ?? []).length === 0 ? (
              <EmptyState icon={<FileText className="size-5" />} title="No proposals yet" description="Draft a proposal, then send the client its private link." />
            ) : (
              <ul className="divide-y divide-border">
                {(proposals.data ?? []).map((p) => (
                  <li key={p.id}>
                    <Link href={`/app/proposals/${p.id}`} className="flex flex-wrap items-center gap-3 px-5 py-3 hover:bg-surface-2/50">
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium">{p.title}</span>
                        <span className="block text-xs text-text-3">
                          {formatMoney(p.price, p.currency)} · {p.sent_at ? `sent ${formatDate(p.sent_at)}` : `created ${formatDate(p.created_at)}`}
                          {p.view_count > 0 && ` · opened ${p.view_count}×`}
                        </span>
                      </span>
                      <MapBadge map={PROPOSAL_STATUS} value={p.status} />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
            {canEdit && !closed && (
              <details className="border-t border-border">
                <summary className="cursor-pointer px-5 py-3 text-sm font-medium text-accent">New proposal</summary>
                <div className="px-5 pb-5">
                  <ProposalForm
                    dealId={d.id}
                    services={opts(services)}
                    defaults={{ title: `Proposal — ${d.name}`.slice(0, 200), service_id: d.service_id ?? "", price: String(d.value), currency: d.currency,
                      scope: "", timeline: "", terms: "", expiry_date: "" }}
                  />
                </div>
              </details>
            )}
          </Card>

          <Card>
            <CardHeader
              title="Meetings"
              action={<Link href={`/app/meetings/new?deal=${d.id}${d.lead_id ? `&lead=${d.lead_id}` : ""}`} className="inline-flex items-center gap-1 text-xs text-accent hover:underline"><CalendarPlus className="size-3.5" /> Schedule</Link>}
            />
            {(meetings.data ?? []).length === 0 ? (
              <p className="px-5 py-4 text-sm text-text-3">No meetings linked to this deal.</p>
            ) : (
              <ul className="divide-y divide-border">
                {(meetings.data ?? []).map((m) => (
                  <li key={m.id}>
                    <Link href={`/app/meetings/${m.id}`} className="flex items-center gap-3 px-5 py-2.5 hover:bg-surface-2/50">
                      <span className="flex-1 truncate text-sm">{m.title}</span>
                      <span className="text-xs text-text-3">{formatDateTime(m.starts_at)}</span>
                      <MapBadge map={MEETING_STATUS} value={m.status} />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <DocumentsCard entity="deal" entityId={d.id} canUpload={canEdit} userId={session.userId} isAdmin={session.can("settings.manage")} />
        </div>

        <div className="space-y-6">
          {canEdit && !closed && !d.archived_at && (
            <Card className="space-y-3 p-5">
              <SectionTitle>Close this deal</SectionTitle>
              <ActionButton
                action={markDealWon.bind(null, d.id)}
                variant="brand"
                prompt={{ label: "Final value", placeholder: String(d.value), hint: `Leave as is to keep ${formatMoney(d.value, d.currency)}. The lead moves to Won, a client is created or reused, and commission is calculated.` }}
                confirmLabel="Mark won"
              >
                <Trophy className="size-4" /> Mark won
              </ActionButton>
              <ActionButton
                action={markDealLost.bind(null, d.id)}
                variant="secondary"
                prompt={{ label: "Why was it lost?", minLength: 3, multiline: true, placeholder: "e.g. Budget moved to next year" }}
                confirmLabel="Mark lost"
              >
                <XCircle className="size-4" /> Mark lost
              </ActionButton>
            </Card>
          )}

          {(commissions.data ?? []).length > 0 && (
            <Card className="p-5">
              <SectionTitle>Commission</SectionTitle>
              <ul className="space-y-2 text-sm">
                {(commissions.data ?? []).map((c) => (
                  <li key={c.id} className="flex items-center justify-between gap-2">
                    <span>{people.get(c.user_id) ?? "—"}</span>
                    <span className="flex items-center gap-2 tabular-nums">{formatMoney(c.amount, c.currency)} <MapBadge map={COMMISSION_STATUS} value={c.status} /></span>
                  </li>
                ))}
              </ul>
            </Card>
          )}
          {d.won_at && (commissions.data ?? []).length === 0 && (
            <Card className="p-5 text-sm text-text-3">No commission: no approved rule matched this salesperson and service on the close date.</Card>
          )}

          {session.can("sales.manage") && (
            <ActionButton
              action={setDealArchived.bind(null, d.id, !d.archived_at)}
              variant="ghost"
              confirm={d.archived_at ? "Restore this deal?" : "Archive this deal? It disappears from boards but its history is kept."}
            >
              {d.archived_at ? "Restore deal" : "Archive deal"}
            </ActionButton>
          )}
          <p className="text-center text-xs text-text-3">Updated {formatDate(d.updated_at)}</p>
        </div>
      </div>
    </>
  );
}
