import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { DealForm } from "@/components/sales/deal-form";
import { requirePermission } from "@/lib/auth/session";
import { canViewSales } from "@/lib/auth/permissions";
import { getClientOptions, getDealStages, getPeople, getServices, opts } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";

export const metadata = { title: "New deal" };

export default async function NewDealPage({ searchParams }: PageProps<"/app/deals/new">) {
  const session = await requirePermission(canViewSales);
  const sp = await searchParams;
  const supabase = await createClient();
  const [stages, people, services, clients, leadsRes] = await Promise.all([
    getDealStages(), getPeople(), getServices(), getClientOptions(),
    supabase.from("leads").select("id, company_name").is("archived_at", null).order("created_at", { ascending: false }).limit(500),
  ]);
  const open = stages.filter((s) => !s.is_won && !s.is_lost);
  const leadId = typeof sp.lead === "string" && validId(sp.lead) ? sp.lead : undefined;
  const clientId = typeof sp.client === "string" && validId(sp.client) ? sp.client : undefined;
  let defaults: Record<string, unknown> = {
    name: "", lead_id: leadId ?? "", client_id: clientId ?? "", stage_id: open[0]?.id, value: "", currency: "USD",
    probability: String(open[0]?.default_probability ?? 10), expected_close_date: "", owner_id: "", service_id: "", notes: "",
  };
  if (leadId) {
    const { data: l } = await supabase.from("leads").select("company_name, estimated_value, currency, service_id, client_id").eq("id", leadId).maybeSingle();
    if (l) {
      const svc = services.find((s) => s.id === l.service_id)?.name;
      defaults = { ...defaults, name: `${l.company_name}${svc ? ` — ${svc}` : ""}`.slice(0, 200), value: l.estimated_value ?? "",
        currency: l.currency ?? "USD", service_id: l.service_id ?? "", client_id: l.client_id ?? "" };
    }
  }

  return (
    <>
      <Link href="/app/deals" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Deals</Link>
      <PageHeader title="New deal" description="Track a qualified opportunity: value, probability, proposals and the close." />
      <Card className="max-w-3xl p-5 sm:p-6">
        <DealForm
          mode="create"
          defaults={defaults}
          stages={open}
          leads={(leadsRes.data ?? []).map((l) => ({ value: l.id as string, label: l.company_name as string }))}
          clients={opts(clients)}
          people={opts(people)}
          services={opts(services)}
          canAssign={session.can("sales.manage")}
        />
      </Card>
    </>
  );
}
