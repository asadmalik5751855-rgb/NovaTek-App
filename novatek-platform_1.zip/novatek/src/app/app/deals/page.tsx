import Link from "next/link";
import { Handshake, Plus } from "lucide-react";
import { ButtonLink, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { MoneyList, StatCard } from "@/components/ui/status";
import { DealBoard, type BoardDeal } from "@/components/sales/deal-board";
import { requirePermission } from "@/lib/auth/session";
import { canViewSales } from "@/lib/auth/permissions";
import { getDealStages, getPeopleMap } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { cn } from "@/lib/utils";

export const metadata = { title: "Deals" };

type Row = BoardDeal & { created_by: string | null; won_at: string | null; lost_at: string | null; leads: { company_name: string } | null; clients: { company_name: string } | null };

export default async function DealsPage({ searchParams }: PageProps<"/app/deals">) {
  const session = await requirePermission(canViewSales);
  const sp = await searchParams;
  const mine = sp.mine === "1";
  const [stages, people] = await Promise.all([getDealStages(), getPeopleMap()]);
  const supabase = await createClient();
  const since = new Date(new Date().getTime() - 30 * 864e5).toISOString();
  let q = supabase
    .from("deals")
    .select("id, name, value, currency, probability, forecast_value, stage_id, owner_id, created_by, expected_close_date, won_at, lost_at, leads(company_name), clients(company_name)")
    .is("archived_at", null)
    .or(`and(won_at.is.null,lost_at.is.null),won_at.gte.${since},lost_at.gte.${since}`)
    .order("value", { ascending: false })
    .limit(600);
  if (mine) q = q.eq("owner_id", session.userId);
  const { data, error } = await q;
  if (error) throw error;
  const rows = (data ?? []) as unknown as Row[];
  const deals: BoardDeal[] = rows.map((r) => ({
    id: r.id, name: r.name, value: Number(r.value), currency: r.currency, probability: r.probability, forecast_value: Number(r.forecast_value),
    stage_id: r.stage_id, owner_id: r.owner_id, expected_close_date: r.expected_close_date,
    company: r.clients?.company_name ?? r.leads?.company_name ?? null,
  }));
  const canEdit = Object.fromEntries(rows.map((r) => [r.id, session.can("sales.manage") || r.owner_id === session.userId || r.created_by === session.userId]));
  const open = rows.filter((r) => !r.won_at && !r.lost_at);
  const won = rows.filter((r) => r.won_at);

  return (
    <>
      <PageHeader
        title="Deals"
        description="Qualified opportunities. Forecast = value × probability — it is a projection, not revenue."
        actions={
          <>
            <div className="flex rounded-lg border border-border p-0.5 text-sm">
              <Link href="/app/deals" className={cn("rounded-md px-3 py-1.5", !mine ? "bg-surface-2 font-medium" : "text-text-3")}>All visible</Link>
              <Link href="/app/deals?mine=1" className={cn("rounded-md px-3 py-1.5", mine ? "bg-surface-2 font-medium" : "text-text-3")}>Mine</Link>
            </div>
            <ButtonLink href="/app/deals/new" variant="brand"><Plus className="size-4" /> New deal</ButtonLink>
          </>
        }
      />
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Open deals" value={open.length} />
        <StatCard label="Pipeline value" value={<MoneyList items={open.map((d) => ({ currency: d.currency, amount: d.value }))} />} />
        <StatCard label="Forecast" value={<MoneyList items={open.map((d) => ({ currency: d.currency, amount: d.forecast_value }))} />} hint="Projection, not revenue" />
        <StatCard label="Won · 30 days" value={<MoneyList items={won.map((d) => ({ currency: d.currency, amount: d.value }))} />} hint={`${won.length} deal${won.length === 1 ? "" : "s"}`} tone="success" />
      </div>
      {deals.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Handshake className="size-5" />}
            title={mine ? "You have no deals" : "No deals yet"}
            description="Create a deal from a qualified lead to track its value, probability and proposals."
            action={<ButtonLink href="/app/deals/new" variant="brand"><Plus className="size-4" /> New deal</ButtonLink>}
          />
        </Card>
      ) : (
        <DealBoard stages={stages} deals={deals} people={Object.fromEntries(people)} canEdit={canEdit} />
      )}
    </>
  );
}
