"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth/session";
import { toActionError, type ActionResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";

const MAX_BYTES = 25 * 1024 * 1024;
const ALLOWED: Record<string, string[]> = {
  "application/pdf": ["pdf"],
  "image/png": ["png"],
  "image/jpeg": ["jpg", "jpeg"],
  "image/webp": ["webp"],
  "text/plain": ["txt"],
  "text/csv": ["csv"],
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ["docx"],
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ["xlsx"],
  "application/vnd.openxmlformats-officedocument.presentationml.presentation": ["pptx"],
  "application/zip": ["zip"],
};
const ENTITY_PATH: Record<string, (id: string) => string> = {
  client: (id) => `/app/clients/${id}`,
  project: (id) => `/app/projects/${id}`,
  deal: (id) => `/app/deals/${id}`,
  lead: (id) => `/app/leads/${id}`,
};

// File signatures: refuse files whose content doesn't match the declared type.
function sniff(bytes: Uint8Array): string | null {
  const h = (n: number) => Array.from(bytes.slice(0, n)).map((b) => b.toString(16).padStart(2, "0")).join("");
  if (h(4) === "25504446") return "application/pdf";
  if (h(8) === "89504e470d0a1a0a") return "image/png";
  if (h(3) === "ffd8ff") return "image/jpeg";
  if (h(4) === "52494646" && String.fromCharCode(...bytes.slice(8, 12)) === "WEBP") return "image/webp";
  if (h(4) === "504b0304") return "zip"; // docx/xlsx/pptx/zip are all zip containers
  return null;
}

export async function uploadDocument(formData: FormData): Promise<ActionResult> {
  try {
    await authorize();
    const meta = z
      .object({ entity: z.enum(["client", "project", "deal", "lead"]), entity_id: z.uuid() })
      .safeParse({ entity: formData.get("entity"), entity_id: formData.get("entity_id") });
    if (!meta.success) return { ok: false, error: "Invalid upload target." };
    const file = formData.get("file");
    if (!(file instanceof File) || file.size === 0) return { ok: false, error: "Choose a file to upload." };
    if (file.size > MAX_BYTES) return { ok: false, error: "Files must be 25 MB or smaller." };
    const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
    const allowedExt = ALLOWED[file.type];
    if (!allowedExt || !allowedExt.includes(ext)) return { ok: false, error: "This file type isn't allowed. Use PDF, images, Office documents, CSV, TXT or ZIP." };
    const bytes = new Uint8Array(await file.arrayBuffer());
    const sig = sniff(bytes);
    const textual = file.type === "text/plain" || file.type === "text/csv";
    const okSig = textual ? !bytes.slice(0, 1024).includes(0) : sig === file.type || (sig === "zip" && (file.type.includes("openxmlformats") || file.type === "application/zip"));
    if (!okSig) return { ok: false, error: "The file contents don't match its type." };

    const supabase = await createClient();
    // The parent must be visible to this user (RLS) before anything is stored.
    const table = { client: "clients", project: "projects", deal: "deals", lead: "leads" }[meta.data.entity];
    const { data: parent } = await supabase.from(table).select("id").eq("id", meta.data.entity_id).maybeSingle();
    if (!parent) return { ok: false, error: "Not found, or you don't have access to it." };

    const safeName = file.name.replace(/[^\w.\- ]+/g, "_").slice(-120) || `file.${ext}`;
    const path = `${meta.data.entity}/${meta.data.entity_id}/${crypto.randomUUID()}-${safeName}`;
    const up = await supabase.storage.from("documents").upload(path, bytes, { contentType: file.type, upsert: false });
    if (up.error) {
      console.error("[uploadDocument] storage", up.error);
      return { ok: false, error: "File storage isn't available right now. The file was not saved." };
    }
    const ins = await supabase.from("documents").insert({
      entity: meta.data.entity, entity_id: meta.data.entity_id, name: safeName, storage_path: path, size_bytes: file.size, mime_type: file.type,
    });
    if (ins.error) {
      await supabase.storage.from("documents").remove([path]);
      throw ins.error;
    }
    revalidatePath(ENTITY_PATH[meta.data.entity](meta.data.entity_id));
    return { ok: true, data: undefined };
  } catch (e) {
    return toActionError(e, "uploadDocument");
  }
}

export async function archiveDocument(id: string): Promise<ActionResult> {
  try {
    await authorize();
    if (!z.uuid().safeParse(id).success) return { ok: false, error: "Not found." };
    const supabase = await createClient();
    const { data, error } = await supabase.from("documents").update({ archived_at: new Date().toISOString() }).eq("id", id).select("entity, entity_id");
    if (error) throw error;
    if (!data?.length) return { ok: false, error: "Only the uploader or an administrator can remove this file." };
    revalidatePath(ENTITY_PATH[data[0].entity](data[0].entity_id));
    return { ok: true, data: undefined };
  } catch (e) {
    return toActionError(e, "archiveDocument");
  }
}
