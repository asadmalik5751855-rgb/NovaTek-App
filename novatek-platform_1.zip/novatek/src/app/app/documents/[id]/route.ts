import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { getSession } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";

/** Download: checks access through RLS, then redirects to a 60-second signed URL. */
export async function GET(_req: NextRequest, ctx: RouteContext<"/app/documents/[id]">) {
  const { id } = await ctx.params;
  const session = await getSession();
  if (!session) return new NextResponse("Unauthorized", { status: 401 });
  if (!z.uuid().safeParse(id).success) return new NextResponse("Not found", { status: 404 });
  const supabase = await createClient();
  const { data: doc } = await supabase.from("documents").select("storage_path, name").eq("id", id).is("archived_at", null).maybeSingle();
  if (!doc) return new NextResponse("Not found", { status: 404 });
  const { data, error } = await supabase.storage.from("documents").createSignedUrl(doc.storage_path, 60, { download: doc.name });
  if (error || !data?.signedUrl) return new NextResponse("File storage unavailable", { status: 503 });
  return NextResponse.redirect(data.signedUrl, { headers: { "Cache-Control": "private, no-store" } });
}
