import Link from "next/link";
import { ExternalLink, PanelsTopLeft, Plus } from "lucide-react";
import { ButtonLink, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { MapBadge } from "@/components/ui/status";
import { requirePermission } from "@/lib/auth/session";
import { canViewCampaigns } from "@/lib/auth/permissions";
import { PUBLISH_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { formatDate } from "@/lib/utils";

export const metadata = { title: "Landing pages" };

export default async function LandingPagesPage() {
  const session = await requirePermission(canViewCampaigns);
  const supabase = await createClient();
  const { data, error } = await supabase.from("landing_pages").select("id, slug, headline, status, published_at, campaigns(name)").order("created_at", { ascending: false });
  if (error) throw error;
  const pages = (data ?? []) as unknown as { id: string; slug: string; headline: string; status: string; published_at: string | null; campaigns: { name: string } | null }[];
  return (
    <>
      <PageHeader
        title="Landing pages"
        description="Campaign pages at /l/your-slug. Their form creates real CRM leads with source “Landing Page” and the page’s campaign."
        actions={session.can("campaigns.manage") && <ButtonLink href="/app/landing-pages/new" variant="brand"><Plus className="size-4" /> New page</ButtonLink>}
      />
      <Card className="overflow-hidden">
        {pages.length === 0 ? (
          <EmptyState icon={<PanelsTopLeft className="size-5" />} title="No landing pages" description="Build a focused page for a service or campaign."
            action={session.can("campaigns.manage") ? <ButtonLink href="/app/landing-pages/new" variant="brand">New page</ButtonLink> : undefined} />
        ) : (
          <ul className="divide-y divide-border">
            {pages.map((p) => (
              <li key={p.id} className="flex flex-wrap items-center gap-3 px-5 py-3">
                <Link href={`/app/landing-pages/${p.id}`} className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium hover:text-accent">{p.headline}</span>
                  <span className="block text-xs text-text-3">/l/{p.slug}{p.campaigns?.name && ` · ${p.campaigns.name}`}{p.published_at && ` · published ${formatDate(p.published_at)}`}</span>
                </Link>
                <MapBadge map={PUBLISH_STATUS} value={p.status} />
                {p.status === "published" && <a href={`/l/${p.slug}`} target="_blank" rel="noopener noreferrer" className="text-text-3 hover:text-text" aria-label="Open page"><ExternalLink className="size-4" /></a>}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </>
  );
}
