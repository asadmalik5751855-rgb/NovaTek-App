import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { LandingPageForm } from "@/components/marketing/forms";
import { requirePermission } from "@/lib/auth/session";
import { canViewCampaigns } from "@/lib/auth/permissions";
import { getServices, opts } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";

export const metadata = { title: "Landing page" };

export default async function LandingPageEditor({ params }: PageProps<"/app/landing-pages/[id]">) {
  const session = await requirePermission(canViewCampaigns);
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const [{ data: p }, { data: campaigns }, services] = await Promise.all([
    supabase.from("landing_pages").select("*").eq("id", id).maybeSingle(),
    supabase.from("campaigns").select("id, name").order("name"),
    getServices(),
  ]);
  if (!p) notFound();
  const { count: leadCount } = await supabase.from("leads").select("id", { count: "exact", head: true }).eq("source_reference", `/l/${p.slug}`);
  const benefits = (p.benefits as string[]).join("\n");
  const testimonials = (p.testimonials as { quote: string; author: string; role: string }[]).map((t) => [t.quote, t.author, t.role].join(" | ")).join("\n");
  const faq = (p.faq as { q: string; a: string }[]).map((f) => `${f.q} | ${f.a}`).join("\n");
  const s = (v: unknown) => (v === null || v === undefined ? "" : String(v));
  return (
    <>
      <Link href="/app/landing-pages" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Landing pages</Link>
      <PageHeader
        title={p.headline}
        description={`/l/${p.slug} · ${leadCount ?? 0} lead${leadCount === 1 ? "" : "s"} you can see came from this page`}
        actions={p.status === "published" ? <a href={`/l/${p.slug}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-sm text-accent hover:underline">Open live page <ExternalLink className="size-4" /></a> : undefined}
      />
      {session.can("campaigns.manage") ? (
        <Card className="max-w-3xl p-5 sm:p-6">
          <LandingPageForm
            id={id}
            defaults={{ slug: p.slug, campaign_id: s(p.campaign_id), service_id: s(p.service_id), headline: p.headline, subheadline: s(p.subheadline),
              hero_image_url: s(p.hero_image_url), benefits, cta_label: p.cta_label, testimonials, testimonials_confirmed: testimonials.length > 0, faq, status: p.status }}
            campaigns={opts(campaigns ?? [])} services={opts(services)}
          />
        </Card>
      ) : (
        <Card className="p-5 text-sm text-text-3">You can view campaign results but not edit pages.</Card>
      )}
    </>
  );
}
