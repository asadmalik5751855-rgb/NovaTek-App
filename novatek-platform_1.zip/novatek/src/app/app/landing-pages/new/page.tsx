import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { LandingPageForm } from "@/components/marketing/forms";
import { requirePermission } from "@/lib/auth/session";
import { getServices, opts } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";

export const metadata = { title: "New landing page" };

export default async function NewLandingPage() {
  await requirePermission("campaigns.manage");
  const supabase = await createClient();
  const [{ data: campaigns }, services] = await Promise.all([supabase.from("campaigns").select("id, name").order("name"), getServices()]);
  return (
    <>
      <Link href="/app/landing-pages" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Landing pages</Link>
      <PageHeader title="New landing page" />
      <Card className="max-w-3xl p-5 sm:p-6">
        <LandingPageForm
          defaults={{ slug: "", campaign_id: "", service_id: "", headline: "", subheadline: "", hero_image_url: "", benefits: "", cta_label: "Get a free consultation",
            testimonials: "", testimonials_confirmed: false, faq: "", status: "draft" }}
          campaigns={opts(campaigns ?? [])} services={opts(services)}
        />
      </Card>
    </>
  );
}
