import { notFound } from "next/navigation";
import { PageHeader } from "@/components/ui/primitives";
import { RangeFilter } from "@/components/charts/range-filter";
import { CeoPortal, CmoPortal, CooPortal, CtoPortal } from "@/components/portals/portals";
import { CommandCenter } from "@/components/portals/command-center";
import { requirePermission } from "@/lib/auth/session";
import { resolveRange } from "@/lib/data/analytics";
import { formatDate } from "@/lib/utils";

const PORTALS = {
  ceo: { title: "CEO portal", description: "Company performance: revenue, growth, pipeline, people and markets.", perm: "portal.ceo" },
  coo: { title: "COO portal", description: "Daily operations: follow-ups, assignments, workload, meetings and approvals.", perm: "portal.coo" },
  cto: { title: "CTO portal", description: "Technical delivery: projects, engineering workload and bugs.", perm: "portal.cto" },
  cmo: { title: "CMO portal", description: "Marketing performance: sources, campaigns, lead quality and markets.", perm: "portal.cmo" },
} as const;

export async function generateMetadata({ params }: PageProps<"/app/portals/[role]">) {
  const p = PORTALS[(await params).role as keyof typeof PORTALS];
  return { title: p?.title ?? "Portal" };
}

export default async function PortalPage({ params, searchParams }: PageProps<"/app/portals/[role]">) {
  const role = (await params).role as keyof typeof PORTALS;
  const p = PORTALS[role];
  if (!p) notFound();
  const session = await requirePermission(p.perm);
  const r = resolveRange(await searchParams);
  return (
    <>
      <PageHeader title={p.title} description={`${p.description} ${formatDate(r.fromDate)} – ${formatDate(r.toDate)}.`}
        actions={role !== "cto" ? <RangeFilter active={r.key} from={r.fromDate} to={r.toDate} /> : undefined} />
      <div className="mb-8"><CommandCenter session={session} /></div>
      {role === "ceo" && <CeoPortal r={r} />}
      {role === "coo" && <CooPortal session={session} r={r} />}
      {role === "cto" && <CtoPortal r={r} />}
      {role === "cmo" && <CmoPortal r={r} />}
    </>
  );
}
