import Link from "next/link";
import { Bell, CheckCheck } from "lucide-react";
import { Badge, Button, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { requireUser } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";
import { cn, formatDateTime, timeAgo } from "@/lib/utils";
import { markNotificationsRead } from "./actions";

export const metadata = { title: "Notifications" };

type Notification = { id: string; type: string; title: string; body: string | null; link: string | null; priority: string; read_at: string | null; created_at: string };

async function markAll() {
  "use server";
  await markNotificationsRead("all");
}

async function markOne(formData: FormData) {
  "use server";
  await markNotificationsRead([String(formData.get("id"))]);
}

export default async function NotificationsPage() {
  await requireUser();
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("notifications")
    .select("id, type, title, body, link, priority, read_at, created_at")
    .order("created_at", { ascending: false })
    .limit(100);
  if (error) throw error;
  const items = (data ?? []) as Notification[];
  const unread = items.filter((n) => !n.read_at).length;

  return (
    <>
      <PageHeader
        title="Notifications"
        description={unread ? `${unread} unread` : "You're all caught up"}
        actions={
          unread > 0 && (
            <form action={markAll}>
              <Button type="submit" variant="secondary"><CheckCheck className="size-4" /> Mark all read</Button>
            </form>
          )
        }
      />
      <Card>
        {items.length === 0 ? (
          <EmptyState icon={<Bell className="size-5" />} title="No notifications yet" description="You'll be notified here when leads are assigned to you or new enquiries arrive." />
        ) : (
          <ul className="divide-y divide-border">
            {items.map((n) => (
              <li key={n.id} className={cn("flex items-start gap-3 px-5 py-4", !n.read_at && "bg-accent/[0.04]")}>
                <span className={cn("mt-1.5 size-2 shrink-0 rounded-full", n.read_at ? "bg-transparent" : "bg-accent")} aria-hidden />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    {n.link ? (
                      <Link href={n.link} className="text-sm font-medium hover:text-accent">{n.title}</Link>
                    ) : (
                      <span className="text-sm font-medium">{n.title}</span>
                    )}
                    {n.priority === "high" && <Badge color="rose">High</Badge>}
                  </div>
                  {n.body && <p className="mt-0.5 text-sm text-text-2">{n.body}</p>}
                  <time className="text-xs text-text-3" dateTime={n.created_at} title={formatDateTime(n.created_at)}>{timeAgo(n.created_at)}</time>
                </div>
                {!n.read_at && (
                  <form action={markOne}>
                    <input type="hidden" name="id" value={n.id} />
                    <button type="submit" className="text-xs text-text-3 hover:text-text">Mark read</button>
                  </form>
                )}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </>
  );
}
