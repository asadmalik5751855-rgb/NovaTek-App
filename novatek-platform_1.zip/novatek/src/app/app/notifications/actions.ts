"use server";

import { revalidatePath } from "next/cache";
import { authorize } from "@/lib/auth/session";
import { check, toActionError, type ActionResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { idSchema } from "@/lib/validation/leads";

export async function markNotificationsRead(ids: string[] | "all"): Promise<ActionResult> {
  try {
    const session = await authorize();
    const supabase = await createClient();
    // RLS + column grant restrict this to read_at on the caller's own notifications.
    let q = supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("user_id", session.userId).is("read_at", null);
    if (ids !== "all") {
      const valid = ids.filter((i) => idSchema.safeParse(i).success).slice(0, 200);
      if (!valid.length) return { ok: true, data: undefined };
      q = q.in("id", valid);
    }
    check(await q);
    revalidatePath("/app", "layout");
    return { ok: true, data: undefined };
  } catch (e) {
    return toActionError(e, "markNotificationsRead");
  }
}
