import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { TaskForm } from "@/components/work/task-form";
import { requireUser } from "@/lib/auth/session";
import { getDepartments, getPeople, getProjectOptions, opts } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";

export const metadata = { title: "New task" };

export default async function NewTaskPage({ searchParams }: PageProps<"/app/tasks/new">) {
  const session = await requireUser();
  const sp = await searchParams;
  const pick = (k: string) => (typeof sp[k] === "string" && validId(sp[k]) ? (sp[k] as string) : "");
  const leadId = pick("lead"), clientId = pick("client"), projectId = pick("project");
  const supabase = await createClient();
  const [people, departments, projects, lead, client] = await Promise.all([
    getPeople(), getDepartments(), getProjectOptions(),
    leadId ? supabase.from("leads").select("company_name").eq("id", leadId).maybeSingle() : Promise.resolve({ data: null }),
    clientId ? supabase.from("clients").select("company_name").eq("id", clientId).maybeSingle() : Promise.resolve({ data: null }),
  ]);
  const canAssign = session.can({ anyOf: ["tasks.assign", "projects.manage"] });
  return (
    <>
      <Link href="/app/tasks" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Tasks</Link>
      <PageHeader title="New task" />
      <Card className="max-w-3xl p-5 sm:p-6">
        <TaskForm
          defaults={{ title: "", description: "", kind: lead.data ? "sales" : "general", assignee_id: "", priority: "medium", due_at: "", status: "todo",
            department_id: "", lead_id: lead.data ? leadId : "", client_id: client.data ? clientId : "", project_id: projectId }}
          people={opts(people)}
          departments={opts(departments)}
          projects={opts(projects)}
          canAssign={canAssign}
          links={{ lead: lead.data?.company_name, client: client.data?.company_name }}
        />
      </Card>
    </>
  );
}
