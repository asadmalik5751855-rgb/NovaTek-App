import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Card, CardHeader } from "@/components/ui/primitives";
import { DescRow, MapBadge, SectionTitle } from "@/components/ui/status";
import { TaskForm } from "@/components/work/task-form";
import { TaskStatusSelect } from "@/components/work/task-status";
import { requireUser } from "@/lib/auth/session";
import { getDepartments, getPeople, getPeopleMap, getProjectOptions, opts } from "@/lib/data/lookups";
import { PRIORITY, TASK_KIND, TASK_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";
import { formatDateTime } from "@/lib/utils";

export default async function TaskPage({ params }: PageProps<"/app/tasks/[id]">) {
  const session = await requireUser();
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const { data: t } = await supabase.from("tasks").select("*, projects(id, name), leads(id, company_name), clients(id, company_name), departments(name)").eq("id", id).maybeSingle();
  if (!t) notFound();
  const [peopleMap, people, departments, projects] = await Promise.all([getPeopleMap(), getPeople(), getDepartments(), getProjectOptions()]);
  const canAssign = session.can({ anyOf: ["tasks.assign", "projects.manage"] });
  const canEdit = canAssign || t.assignee_id === session.userId || t.created_by === session.userId;
  const s = (v: unknown) => (v === null || v === undefined ? "" : String(v));

  return (
    <>
      <Link href="/app/tasks" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Tasks</Link>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">{t.title}</h1>
        <div className="mt-2 flex flex-wrap gap-2">
          <MapBadge map={TASK_STATUS} value={t.status} />
          <MapBadge map={PRIORITY} value={t.priority} />
        </div>
      </div>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          {canEdit ? (
            <Card className="p-5 sm:p-6">
              <TaskForm
                taskId={id}
                defaults={{ title: t.title, description: s(t.description), kind: t.kind, assignee_id: s(t.assignee_id), priority: t.priority, due_at: s(t.due_at),
                  status: t.status, department_id: s(t.department_id), lead_id: s(t.lead_id), client_id: s(t.client_id), project_id: s(t.project_id) }}
                people={opts(people)}
                departments={opts(departments)}
                projects={opts(projects)}
                canAssign={canAssign}
                links={{ lead: t.leads?.company_name, client: t.clients?.company_name }}
              />
            </Card>
          ) : (
            <Card>
              <CardHeader title="Details" />
              <p className="whitespace-pre-wrap px-5 py-4 text-sm">{t.description || "No description."}</p>
            </Card>
          )}
        </div>
        <div className="space-y-6">
          {canEdit && (
            <Card className="p-5">
              <SectionTitle>Status</SectionTitle>
              <TaskStatusSelect id={t.id} value={t.status} />
            </Card>
          )}
          <Card>
            <dl className="divide-y divide-border px-5 py-2">
              <DescRow label="Type">{TASK_KIND[t.kind as keyof typeof TASK_KIND]}</DescRow>
              <DescRow label="Assignee">{t.assignee_id ? peopleMap.get(t.assignee_id) ?? "A former user" : "Unassigned"}</DescRow>
              <DescRow label="Created by">{t.created_by ? peopleMap.get(t.created_by) ?? "A former user" : null}</DescRow>
              <DescRow label="Due">{t.due_at ? formatDateTime(t.due_at) : null}</DescRow>
              <DescRow label="Department">{t.departments?.name}</DescRow>
              <DescRow label="Project">{t.projects ? <Link className="text-accent hover:underline" href={`/app/projects/${t.projects.id}`}>{t.projects.name}</Link> : null}</DescRow>
              <DescRow label="Lead">{t.leads ? <Link className="text-accent hover:underline" href={`/app/leads/${t.leads.id}`}>{t.leads.company_name}</Link> : null}</DescRow>
              <DescRow label="Client">{t.clients ? <Link className="text-accent hover:underline" href={`/app/clients/${t.clients.id}`}>{t.clients.company_name}</Link> : null}</DescRow>
              <DescRow label="Completed">{t.completed_at ? formatDateTime(t.completed_at) : null}</DescRow>
              <DescRow label="Created">{formatDateTime(t.created_at)}</DescRow>
            </dl>
          </Card>
        </div>
      </div>
    </>
  );
}
