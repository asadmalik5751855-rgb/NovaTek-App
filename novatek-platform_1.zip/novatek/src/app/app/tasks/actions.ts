"use server";

import { z } from "zod";
import { NOT_FOUND, ok, refresh, runAction, validId } from "@/lib/actions";
import { check, checkRow, type ActionResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { TASK_STATUSES, taskSchema } from "@/lib/validation/work";

function paths(t: { id?: string; lead_id?: string | null; project_id?: string | null }) {
  return ["/app/tasks", "/app", ...(t.id ? [`/app/tasks/${t.id}`] : []), ...(t.lead_id ? [`/app/leads/${t.lead_id}`] : []), ...(t.project_id ? [`/app/projects/${t.project_id}`] : [])];
}

export async function createTask(input: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction("createTask", null, taskSchema, input, async (d) => {
    const supabase = await createClient();
    const row = checkRow(await supabase.from("tasks").insert(d).select("id").single());
    refresh(...paths(d));
    return ok({ id: row.id as string });
  });
}

export async function updateTask(id: string, input: unknown): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("updateTask", null, taskSchema, input, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("tasks").update(d).eq("id", id).select("id, lead_id, project_id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(...paths(rows[0]));
    return ok();
  });
}

export async function setTaskStatus(id: string, status: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("setTaskStatus", null, z.object({ status: z.enum(TASK_STATUSES) }), { status }, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("tasks").update({ status: d.status }).eq("id", id).select("id, lead_id, project_id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(...paths(rows[0]));
    return ok();
  });
}
