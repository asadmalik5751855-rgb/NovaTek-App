import Link from "next/link";
import { ListChecks, Plus } from "lucide-react";
import { Badge, ButtonLink, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { MapBadge, StatCard } from "@/components/ui/status";
import { TaskStatusSelect } from "@/components/work/task-status";
import { requireUser } from "@/lib/auth/session";
import { getPeopleMap } from "@/lib/data/lookups";
import { PRIORITY, TASK_KIND } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { cn, formatDateTime } from "@/lib/utils";

export const metadata = { title: "Tasks" };

type Task = {
  id: string; title: string; status: string; priority: string; kind: keyof typeof TASK_KIND; due_at: string | null; assignee_id: string | null;
  created_by: string | null; project_id: string | null; lead_id: string | null; projects: { name: string } | null; leads: { company_name: string } | null;
};

export default async function TasksPage({ searchParams }: PageProps<"/app/tasks">) {
  const session = await requireUser();
  const sp = await searchParams;
  const canTeam = session.can({ anyOf: ["tasks.assign", "projects.view", "projects.manage"] });
  const view = sp.view === "created" ? "created" : sp.view === "team" && canTeam ? "team" : "mine";
  const done = sp.done === "1";
  const supabase = await createClient();
  let q = supabase.from("tasks")
    .select("id, title, status, priority, kind, due_at, assignee_id, created_by, project_id, lead_id, projects(name), leads(company_name)")
    .order("due_at", { ascending: true, nullsFirst: false }).order("created_at", { ascending: false }).limit(300);
  if (view === "mine") q = q.eq("assignee_id", session.userId);
  if (view === "created") q = q.eq("created_by", session.userId);
  q = done ? q.in("status", ["completed", "cancelled"]) : q.not("status", "in", "(completed,cancelled)");
  const [{ data, error }, people] = await Promise.all([q, getPeopleMap()]);
  if (error) throw error;
  const tasks = (data ?? []) as unknown as Task[];
  const now = new Date();
  const eod = new Date(now); eod.setHours(23, 59, 59, 999);
  const groups = done
    ? [{ key: "done", label: "Closed", items: tasks }]
    : [
        { key: "overdue", label: "Overdue", items: tasks.filter((t) => t.due_at && new Date(t.due_at) < now) },
        { key: "today", label: "Due today", items: tasks.filter((t) => t.due_at && new Date(t.due_at) >= now && new Date(t.due_at) <= eod) },
        { key: "upcoming", label: "Upcoming", items: tasks.filter((t) => t.due_at && new Date(t.due_at) > eod) },
        { key: "none", label: "No due date", items: tasks.filter((t) => !t.due_at) },
      ];
  const link = (v: string, d = done) => `/app/tasks?${new URLSearchParams({ ...(v !== "mine" ? { view: v } : {}), ...(d ? { done: "1" } : {}) })}`;

  return (
    <>
      <PageHeader
        title="Tasks"
        description="Everything assigned to you, what you’ve delegated, and your team’s work."
        actions={<ButtonLink href="/app/tasks/new" variant="brand"><Plus className="size-4" /> New task</ButtonLink>}
      />
      {!done && (
        <div className="mb-5 grid grid-cols-3 gap-3">
          <StatCard label="Overdue" value={groups[0].items.length} tone={groups[0].items.length ? "danger" : undefined} />
          <StatCard label="Due today" value={groups[1].items.length} />
          <StatCard label="Open" value={tasks.length} />
        </div>
      )}
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="flex rounded-lg border border-border p-0.5 text-sm">
          {[["mine", "Assigned to me"], ["created", "Created by me"], ...(canTeam ? [["team", "Team"]] : [])].map(([k, l]) => (
            <Link key={k} href={link(k)} className={cn("rounded-md px-3 py-1.5", view === k ? "bg-surface-2 font-medium" : "text-text-3")}>{l}</Link>
          ))}
        </div>
        <Link href={link(view, !done)} className="text-sm text-accent hover:underline">{done ? "Show open tasks" : "Show completed & cancelled"}</Link>
      </div>

      {tasks.length === 0 ? (
        <Card>
          <EmptyState icon={<ListChecks className="size-5" />} title={done ? "Nothing closed yet" : "No open tasks"} description="Create a task, or link one to a lead, client or project." action={<ButtonLink href="/app/tasks/new" variant="brand">New task</ButtonLink>} />
        </Card>
      ) : (
        <div className="space-y-6">
          {groups.filter((g) => g.items.length).map((g) => (
            <Card key={g.key} className="overflow-hidden">
              <div className="flex items-center justify-between border-b border-border px-5 py-2.5">
                <h2 className={cn("text-sm font-semibold", g.key === "overdue" && "text-danger")}>{g.label}</h2>
                <span className="text-xs text-text-3">{g.items.length}</span>
              </div>
              <ul className="divide-y divide-border">
                {g.items.map((t) => (
                  <li key={t.id} className="flex flex-col gap-2 px-5 py-3 sm:flex-row sm:items-center">
                    <div className="min-w-0 flex-1">
                      <Link href={`/app/tasks/${t.id}`} className="block truncate text-sm font-medium hover:text-accent">{t.title}</Link>
                      <p className="truncate text-xs text-text-3">
                        {TASK_KIND[t.kind]}
                        {t.projects?.name && ` · ${t.projects.name}`}
                        {t.leads?.company_name && ` · ${t.leads.company_name}`}
                        {view !== "mine" && ` · ${t.assignee_id ? people.get(t.assignee_id) ?? "—" : "Unassigned"}`}
                        {t.due_at && ` · due ${formatDateTime(t.due_at)}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {t.priority !== "medium" && <MapBadge map={PRIORITY} value={t.priority} />}
                      {t.kind === "bug" && <Badge color="rose">Bug</Badge>}
                      <TaskStatusSelect id={t.id} value={t.status} compact />
                    </div>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}
