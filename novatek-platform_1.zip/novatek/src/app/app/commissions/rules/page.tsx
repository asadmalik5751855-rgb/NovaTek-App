import Link from "next/link";
import { ArrowLeft, Scale } from "lucide-react";
import { Card, CardHeader, EmptyState, PageHeader } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { MapBadge } from "@/components/ui/status";
import { CommissionRuleForm } from "@/components/sales/commission-rule-form";
import { requireUser } from "@/lib/auth/session";
import { getPeople, getPeopleMap, getRoles, getServices, opts } from "@/lib/data/lookups";
import { RULE_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { formatDate, formatMoney } from "@/lib/utils";
import { approveCommissionRule, retireCommissionRule } from "../actions";

export const metadata = { title: "Commission rules" };

export default async function CommissionRulesPage() {
  const session = await requireUser();
  const canManage = session.can("commissions.manage");
  const supabase = await createClient();
  const [{ data, error }, services, roles, people, peopleMap] = await Promise.all([
    supabase.from("commission_rules").select("*").order("status").order("effective_from", { ascending: false }),
    getServices(), getRoles(), getPeople(), getPeopleMap(),
  ]);
  if (error) throw error;
  const rules = data ?? [];
  const isSuper = session.roles.some((r) => r.key === "super_admin");

  return (
    <>
      <Link href="/app/commissions" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Commissions</Link>
      <PageHeader
        title="Commission rules"
        description="Nothing is hardcoded. A rule applies only after a second person approves it; approved rules are never edited — retire and replace them."
      />
      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="overflow-hidden lg:col-span-3">
          <CardHeader title={canManage ? "All rules" : "Rules that apply"} description="The most specific rule wins: person › service › role, then the newest." />
          {rules.length === 0 ? (
            <EmptyState icon={<Scale className="size-5" />} title="No commission rules" description={canManage ? "Create the first rule. Until one is approved, won deals carry no commission." : "No approved commission rules yet."} />
          ) : (
            <ul className="divide-y divide-border">
              {rules.map((r) => (
                <li key={r.id} className="space-y-2 px-5 py-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="flex-1 text-sm font-medium">{r.name}</span>
                    <MapBadge map={RULE_STATUS} value={r.status} />
                  </div>
                  <p className="text-xs text-text-3">
                    {[Number(r.percent) > 0 && `${r.percent}%`, Number(r.fixed_amount) > 0 && `${formatMoney(r.fixed_amount, r.currency)} fixed`].filter(Boolean).join(" + ")}
                    {" · "}{services.find((s) => s.id === r.service_id)?.name ?? "Any service"}
                    {" · "}{r.eligible_user_id ? peopleMap.get(r.eligible_user_id) ?? "A person" : roles.find((x) => x.id === r.eligible_role_id)?.name ?? "Any role"}
                    {" · "}{formatDate(r.effective_from)} → {r.effective_to ? formatDate(r.effective_to) : "open"}
                    {r.approved_by && ` · approved by ${peopleMap.get(r.approved_by) ?? "—"}`}
                  </p>
                  {canManage && (
                    <div className="flex flex-wrap gap-2">
                      {r.status === "pending" && (r.created_by !== session.userId || isSuper) && (
                        <ActionButton action={approveCommissionRule.bind(null, r.id)} size="sm" variant="brand" confirm="Approve this rule? It will apply to deals won from its start date.">Approve</ActionButton>
                      )}
                      {r.status === "pending" && r.created_by === session.userId && !isSuper && (
                        <span className="text-xs text-text-3">Waiting for another manager to approve</span>
                      )}
                      {r.status === "approved" && (
                        <ActionButton action={retireCommissionRule.bind(null, r.id)} size="sm" variant="ghost" confirm="Retire this rule from today? Existing commissions are unchanged.">Retire</ActionButton>
                      )}
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Card>
        {canManage && (
          <Card className="p-5 lg:col-span-2">
            <h2 className="mb-4 text-sm font-semibold">New rule</h2>
            <CommissionRuleForm services={opts(services)} roles={roles.filter((r) => !r.is_superuser).map((r) => ({ value: r.id, label: r.name }))} people={opts(people)} />
          </Card>
        )}
      </div>
    </>
  );
}
