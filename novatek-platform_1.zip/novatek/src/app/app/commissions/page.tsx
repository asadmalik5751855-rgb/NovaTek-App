import Link from "next/link";
import { Settings2, Wallet } from "lucide-react";
import { ButtonLink, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { MapBadge, MoneyList, StatCard } from "@/components/ui/status";
import { requireUser } from "@/lib/auth/session";
import { getPeopleMap } from "@/lib/data/lookups";
import { COMMISSION_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { cn, formatDate, formatMoney } from "@/lib/utils";
import { setCommissionStatus } from "./actions";

export const metadata = { title: "Commissions" };

type Row = {
  id: string; deal_id: string; user_id: string; amount: number; currency: string; percent: number; fixed_amount: number; base_amount: number;
  status: keyof typeof COMMISSION_STATUS; created_at: string; approved_at: string | null; paid_at: string | null; paid_reference: string | null;
  deals: { name: string; won_at: string | null } | null;
};

export default async function CommissionsPage({ searchParams }: PageProps<"/app/commissions">) {
  const session = await requireUser();
  const sp = await searchParams;
  const canManage = session.can("commissions.manage");
  const canSeeAll = canManage || session.can("reports.view");
  const scope = canSeeAll && sp.scope === "all" ? "all" : "mine";
  const status = typeof sp.status === "string" && sp.status in COMMISSION_STATUS ? sp.status : "";
  const supabase = await createClient();
  let q = supabase.from("commissions")
    .select("id, deal_id, user_id, amount, currency, percent, fixed_amount, base_amount, status, created_at, approved_at, paid_at, paid_reference, deals(name, won_at)")
    .order("created_at", { ascending: false }).limit(300);
  if (scope === "mine") q = q.eq("user_id", session.userId);
  if (status) q = q.eq("status", status);
  const [{ data, error }, people] = await Promise.all([q, getPeopleMap()]);
  if (error) throw error;
  const rows = (data ?? []) as unknown as Row[];
  const by = (s: string) => rows.filter((r) => r.status === s).map((r) => ({ currency: r.currency, amount: r.amount }));
  const tab = (key: string, label: string) => {
    const params = new URLSearchParams({ ...(scope === "all" ? { scope: "all" } : {}), ...(key ? { status: key } : {}) });
    return (
      <Link key={key} href={`/app/commissions?${params}`} className={cn("rounded-md px-3 py-1.5 text-sm", status === key ? "bg-surface-2 font-medium" : "text-text-3 hover:text-text")}>
        {label}
      </Link>
    );
  };

  return (
    <>
      <PageHeader
        title="Commissions"
        description="Calculated only from approved rules when a deal is won. Estimated → approved by a manager → paid with a reference."
        actions={
          <>
            {canSeeAll && (
              <div className="flex rounded-lg border border-border p-0.5 text-sm">
                <Link href="/app/commissions" className={cn("rounded-md px-3 py-1.5", scope === "mine" ? "bg-surface-2 font-medium" : "text-text-3")}>Mine</Link>
                <Link href="/app/commissions?scope=all" className={cn("rounded-md px-3 py-1.5", scope === "all" ? "bg-surface-2 font-medium" : "text-text-3")}>Everyone</Link>
              </div>
            )}
            <ButtonLink href="/app/commissions/rules" variant="secondary"><Settings2 className="size-4" /> Rules</ButtonLink>
          </>
        }
      />
      <div className="mb-6 grid grid-cols-3 gap-3">
        <StatCard label="Estimated" value={<MoneyList items={by("estimated")} empty="0" />} hint="Awaiting approval" />
        <StatCard label="Approved" value={<MoneyList items={by("approved")} empty="0" />} hint="Awaiting payment" />
        <StatCard label="Paid" value={<MoneyList items={by("paid")} empty="0" />} tone="success" />
      </div>
      <div className="mb-3 flex flex-wrap gap-1">
        {tab("", "All")}{tab("estimated", "Estimated")}{tab("approved", "Approved")}{tab("paid", "Paid")}{tab("void", "Void")}
      </div>
      <Card className="overflow-hidden">
        {rows.length === 0 ? (
          <EmptyState icon={<Wallet className="size-5" />} title="No commissions" description="When you win a deal covered by an approved commission rule, the estimate appears here." />
        ) : (
          <ul className="divide-y divide-border">
            {rows.map((r) => (
              <li key={r.id} className="flex flex-col gap-3 px-5 py-3 lg:flex-row lg:items-center">
                <div className="min-w-0 flex-1">
                  <Link href={`/app/deals/${r.deal_id}`} className="block truncate text-sm font-medium hover:text-accent">{r.deals?.name ?? "Deal"}</Link>
                  <p className="text-xs text-text-3">
                    {scope === "all" && `${people.get(r.user_id) ?? "—"} · `}
                    {Number(r.percent) > 0 && `${r.percent}% of ${formatMoney(r.base_amount, r.currency)}`}
                    {Number(r.fixed_amount) > 0 && ` + ${formatMoney(r.fixed_amount, r.currency)} fixed`}
                    {r.deals?.won_at && ` · won ${formatDate(r.deals.won_at)}`}
                    {r.paid_reference && ` · ref ${r.paid_reference}`}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold tabular-nums">{formatMoney(r.amount, r.currency)}</span>
                  <MapBadge map={COMMISSION_STATUS} value={r.status} />
                </div>
                {canManage && r.user_id !== session.userId && (r.status === "estimated" || r.status === "approved") && (
                  <div className="flex flex-wrap gap-2 lg:w-64 lg:justify-end">
                    {r.status === "estimated" && (
                      <ActionButton action={setCommissionStatus.bind(null, r.id, "approved")} size="sm" confirm="Approve this commission?" confirmLabel="Approve">Approve</ActionButton>
                    )}
                    {r.status === "approved" && (
                      <ActionButton action={setCommissionStatus.bind(null, r.id, "paid")} size="sm" variant="brand"
                        prompt={{ label: "Payment reference", minLength: 3, placeholder: "e.g. Bank transfer ID" }} confirmLabel="Mark paid">Mark paid</ActionButton>
                    )}
                    <ActionButton action={setCommissionStatus.bind(null, r.id, "void")} size="sm" variant="ghost"
                      prompt={{ label: "Reason", minLength: 3 }} confirmLabel="Void">Void</ActionButton>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </>
  );
}
