"use server";

import { z } from "zod";
import { NOT_FOUND, ok, refresh, runAction, validId } from "@/lib/actions";
import { check, checkRow, type ActionResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { commissionRuleSchema } from "@/lib/validation/sales";

export async function createCommissionRule(input: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction("createCommissionRule", "commissions.manage", commissionRuleSchema, input, async (d) => {
    const supabase = await createClient();
    const row = checkRow(await supabase.from("commission_rules").insert(d).select("id").single());
    refresh("/app/commissions/rules");
    return ok({ id: row.id as string });
  });
}

export async function approveCommissionRule(id: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("approveCommissionRule", "commissions.manage", z.object({}), {}, async () => {
    const supabase = await createClient();
    const rows = check(await supabase.from("commission_rules").update({ status: "approved" }).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh("/app/commissions/rules");
    return ok();
  });
}

export async function retireCommissionRule(id: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("retireCommissionRule", "commissions.manage", z.object({}), {}, async () => {
    const supabase = await createClient();
    const today = new Date().toISOString().slice(0, 10);
    const rows = check(await supabase.from("commission_rules").update({ status: "retired", effective_to: today }).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh("/app/commissions/rules");
    return ok();
  });
}

export async function setCommissionStatus(id: string, status: "approved" | "paid" | "void", reference?: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  const schema = z.object({ status: z.enum(["approved", "paid", "void"]), reference: z.string().trim().max(200).optional() });
  return runAction("setCommissionStatus", "commissions.manage", schema, { status, reference }, async (d) => {
    const supabase = await createClient();
    check(await supabase.rpc("set_commission_status", { p_id: id, p_status: d.status, p_reference: d.reference ?? null }));
    refresh("/app/commissions");
    return ok();
  });
}
