"use client";

import { AlertTriangle } from "lucide-react";
import { Button, Card, EmptyState } from "@/components/ui/primitives";

export default function AppError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  // Details are logged server-side; users see a safe message with a retry.
  return (
    <Card>
      <EmptyState
        icon={<AlertTriangle className="size-5" />}
        title="This page couldn't load"
        description="Something went wrong while loading data. Try again; if it keeps happening, contact your administrator."
        action={<Button variant="secondary" onClick={reset}>Try again</Button>}
      />
    </Card>
  );
}
