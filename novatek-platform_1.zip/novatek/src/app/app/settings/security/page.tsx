import { ShieldCheck } from "lucide-react";
import { Card, CardHeader, PageHeader } from "@/components/ui/primitives";
import { SecurityForm } from "@/components/settings/forms";
import { SettingsTabs } from "@/components/settings/settings-tabs";
import { requirePermission } from "@/lib/auth/session";
import { getSetting } from "@/lib/data/lookups";

export const metadata = { title: "Security" };

const POSTURE = [
  "Row-level security on every table: the database itself decides what each user may read or change.",
  "Permissions are checked again in every server action; the interface only hides what you can’t use.",
  "Users cannot change their own roles or status; only a Super Admin can grant Super Admin.",
  "Every login, logout, role change, export, merge and configuration change is written to the audit log.",
  "Leads, clients and deals are archived, never hard-deleted, so history is preserved.",
  "Exports and security changes require your password again.",
  "Public forms use server validation, a honeypot, timing checks and rate limits; visitor IPs are stored only as salted hashes.",
  "The service-role key and integration secrets live only in server environment variables.",
];

export default async function SecurityPage() {
  const session = await requirePermission("settings.manage");
  const minutes = await getSetting<number>("security.reauth_minutes", 10);
  const isSuper = session.roles.some((r) => r.key === "super_admin");
  return (
    <>
      <PageHeader title="Settings" />
      <SettingsTabs session={session} active="/app/settings/security" />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="Re-authentication" description={isSuper ? undefined : "Only a Super Admin can change security settings"} />
          <div className="p-5">{isSuper ? <SecurityForm minutes={minutes} /> : <p className="text-sm">Window: {minutes} minutes</p>}</div>
        </Card>
        <Card>
          <CardHeader title="How the platform is protected" />
          <ul className="space-y-2.5 p-5 text-sm">
            {POSTURE.map((p) => <li key={p} className="flex gap-2"><ShieldCheck className="mt-0.5 size-4 shrink-0 text-success" /> {p}</li>)}
          </ul>
        </Card>
      </div>
    </>
  );
}
