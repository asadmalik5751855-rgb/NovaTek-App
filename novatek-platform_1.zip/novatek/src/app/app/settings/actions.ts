"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { NOT_FOUND, ok, refresh, runAction, validId } from "@/lib/actions";
import { auditEvent } from "@/lib/audit";
import { confirmPassword, markReauthenticated } from "@/lib/auth/reauth";
import { check, type ActionResult } from "@/lib/errors";
import { isServiceRoleConfigured } from "@/lib/env.server";
import { checkIntegration } from "@/lib/integrations/adapters";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import { checkbox, optionalText } from "@/lib/validation/common";

const key = z.string().trim().toLowerCase().regex(/^[a-z][a-z0-9_]{1,40}$/, "Lowercase letters, numbers and _ (2–41 chars)");
const color = z.enum(["slate", "zinc", "blue", "sky", "indigo", "violet", "purple", "fuchsia", "amber", "emerald", "rose"]);
const name = (max = 80) => z.string().trim().min(1, "Required").max(max);
const int = (min: number, max: number) => z.coerce.number({ message: "Enter a number" }).int().min(min).max(max);

/** Per-table schemas: only these tables and fields can be edited from Settings. RLS + audit triggers apply. */
const TABLES = {
  lead_statuses: {
    perm: "crm.configure" as const,
    create: z.object({ key, name: name(), position: int(0, 10000), color, show_in_pipeline: checkbox, is_closed: checkbox, is_won: checkbox, active: checkbox,
      funnel_rank: z.union([int(1, 20), z.literal("")]).transform((v) => (v === "" ? null : v)).nullable().optional() }),
    update: z.object({ name: name(), position: int(0, 10000), color, show_in_pipeline: checkbox, is_closed: checkbox, is_won: checkbox, active: checkbox,
      funnel_rank: z.union([int(1, 20), z.literal("")]).transform((v) => (v === "" ? null : v)).nullable().optional() }),
  },
  lead_sources: {
    perm: "crm.configure" as const,
    create: z.object({ key, name: name(), active: checkbox }),
    update: z.object({ name: name(), active: checkbox }),
  },
  services: {
    perm: "crm.configure" as const,
    create: z.object({ key, name: name(), position: int(0, 10000), active: checkbox, description: optionalText(500) }),
    update: z.object({ name: name(), position: int(0, 10000), active: checkbox, description: optionalText(500) }),
  },
  industries: {
    perm: "crm.configure" as const,
    create: z.object({ name: name(), is_target: checkbox, active: checkbox }),
    update: z.object({ name: name(), is_target: checkbox, active: checkbox }),
  },
  deal_stages: {
    perm: "crm.configure" as const,
    create: z.object({ key, name: name(60), position: int(0, 10000), default_probability: int(0, 100), color, is_won: checkbox, is_lost: checkbox, active: checkbox }),
    update: z.object({ name: name(60), position: int(0, 10000), default_probability: int(0, 100), color, active: checkbox }),
  },
  departments: {
    perm: "employees.manage" as const,
    create: z.object({ name: name() }),
    update: z.object({ name: name() }),
  },
  scoring_rules: {
    perm: "crm.configure" as const,
    create: null,
    update: z.object({ label: name(120), points: int(-100, 100), active: checkbox }),
  },
} as const;
export type ConfigTable = keyof typeof TABLES;

export async function saveConfigRow(table: ConfigTable, id: string | null, input: unknown): Promise<ActionResult> {
  const spec = TABLES[table];
  if (!spec) return NOT_FOUND;
  const schema = id ? spec.update : spec.create;
  if (!schema) return { ok: false, error: "Rows can’t be added to this table." };
  const idCol = table === "scoring_rules" ? "signal" : "id";
  if (id && idCol === "id" && !validId(id)) return NOT_FOUND;
  return runAction(`saveConfigRow:${table}`, spec.perm, schema as z.ZodType, input, async (d) => {
    const supabase = await createClient();
    if (id) {
      const rows = check(await supabase.from(table).update(d as Record<string, unknown>).eq(idCol, id).select(idCol));
      if (!rows?.length) return NOT_FOUND;
    } else {
      check(await supabase.from(table).insert(d as Record<string, unknown>));
    }
    refresh("/app/settings", "/app/settings/crm", "/app/settings/departments");
    return ok();
  });
}

export async function deleteDepartment(id: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("deleteDepartment", "employees.manage", z.object({}), {}, async () => {
    const supabase = await createClient();
    const rows = check(await supabase.from("departments").delete().eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh("/app/settings/departments");
    return ok();
  });
}

export async function rescoreLeads(): Promise<ActionResult<{ count: number }>> {
  return runAction("rescoreLeads", "crm.configure", z.object({}), {}, async () => {
    const supabase = await createClient();
    const n = check(await supabase.rpc("rescore_all_leads")) as number;
    refresh("/app/leads", "/app/pipeline");
    return ok({ count: n });
  });
}

export async function setCountryTarget(code: string, isTarget: boolean): Promise<ActionResult> {
  return runAction("setCountryTarget", "crm.configure", z.object({ code: z.string().regex(/^[A-Z]{2}$/), t: z.boolean() }), { code, t: isTarget }, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("countries").update({ is_target: d.t }).eq("code", d.code).select("code"));
    if (!rows?.length) return NOT_FOUND;
    refresh("/app/settings/crm");
    return ok();
  });
}

const questionsSchema = z
  .string()
  .transform((v) => v.split("\n").map((x) => x.trim()).filter(Boolean))
  .pipe(z.array(z.string().max(600)).min(1, "Add at least one question").max(25, "At most 25 questions"))
  .transform((rows, ctx) =>
    rows.map((r, i) => {
      const [k, label, type, opts] = r.split("|").map((x) => x.trim());
      if (!/^[a-z][a-z0-9_]{1,40}$/.test(k ?? "") || !label || !["text", "longtext", "yesno", "choice"].includes(type ?? "")) {
        ctx.addIssue({ code: "custom", message: `Line ${i + 1}: use key | label | text/longtext/yesno/choice | option1, option2` });
      }
      return { key: k, label, type, ...(type === "choice" ? { options: (opts ?? "").split(",").map((o) => o.trim()).filter(Boolean) } : {}) };
    }),
  );

export async function saveQualificationQuestions(input: unknown): Promise<ActionResult> {
  return runAction("saveQualificationQuestions", "crm.configure", z.object({ questions: questionsSchema }), input, async (d) => {
    const supabase = await createClient();
    check(await supabase.from("settings").update({ value: d.questions }).eq("key", "crm.qualification_questions"));
    refresh("/app/settings/crm");
    return ok();
  });
}

const brandingSchema = z.object({
  tagline: z.string().trim().min(3).max(200),
  contact_email: z.union([z.email("Enter a valid email"), z.literal("")]),
  contact_phone: z.string().trim().max(40),
  whatsapp: z.string().trim().max(40).refine((v) => v === "" || /^\+?[\d\s()-]{6,40}$/.test(v), "Enter a valid number"),
  address: z.string().trim().max(300),
  footer_note: z.string().trim().max(300),
  linkedin: z.union([z.url({ protocol: /^https$/ }), z.literal("")]),
  facebook: z.union([z.url({ protocol: /^https$/ }), z.literal("")]),
  instagram: z.union([z.url({ protocol: /^https$/ }), z.literal("")]),
  x: z.union([z.url({ protocol: /^https$/ }), z.literal("")]),
});

/** Branding TEXT only. The logo and the name's font are locked (see tests/brand/brand-lock.test.ts). */
export async function saveBranding(input: unknown): Promise<ActionResult> {
  return runAction("saveBranding", "settings.manage", brandingSchema, input, async ({ linkedin, facebook, instagram, x, ...rest }) => {
    const supabase = await createClient();
    check(await supabase.from("settings").upsert({ key: "branding", value: { ...rest, social: { linkedin, facebook, instagram, x } } }));
    refresh("/", "/contact", "/app/settings");
    revalidatePath("/", "layout");
    return ok();
  });
}

export async function sendAnnouncement(input: unknown): Promise<ActionResult> {
  const schema = z.object({ title: z.string().trim().min(3, "Add a title").max(160), body: z.string().trim().max(4000), priority: z.enum(["normal", "high"]) });
  return runAction("sendAnnouncement", "settings.manage", schema, input, async (d) => {
    const supabase = await createClient();
    check(await supabase.rpc("send_announcement", { p_title: d.title, p_body: d.body, p_priority: d.priority }));
    refresh("/app/settings/announcements", "/app/notifications");
    return ok();
  });
}

export async function runIntegrationCheck(key: string): Promise<ActionResult<{ status: string; message: string }>> {
  return runAction("runIntegrationCheck", "settings.manage", z.object({ key: z.string().regex(/^[a-z][a-z0-9_]{1,40}$/) }), { key }, async (d, session) => {
    if (!isServiceRoleConfigured()) return { ok: false, error: "SUPABASE_SERVICE_ROLE_KEY is required to record checks." };
    const supabase = await createClient();
    const { data: row } = await supabase.from("integrations").select("required_env").eq("key", d.key).maybeSingle();
    if (!row) return NOT_FOUND;
    const result = await checkIntegration(d.key, row.required_env as string[]);
    check(await createAdminClient().rpc("record_integration_check", { p_key: d.key, p_status: result.status, p_error: result.status === "ok" ? null : result.message, p_actor: session.userId }));
    refresh("/app/settings/integrations");
    return ok(result);
  });
}

export async function setIntegrationEnabled(key: string, enabled: boolean): Promise<ActionResult> {
  return runAction("setIntegrationEnabled", "settings.manage", z.object({ key: z.string().regex(/^[a-z][a-z0-9_]{1,40}$/), enabled: z.boolean() }), { key, enabled }, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("integrations").update({ enabled: d.enabled }).eq("key", d.key).select("key"));
    if (!rows?.length) return NOT_FOUND;
    refresh("/app/settings/integrations");
    return ok();
  });
}

export async function saveSecuritySettings(input: unknown): Promise<ActionResult> {
  const schema = z.object({ reauth_minutes: int(1, 120), password: z.string().min(1, "Confirm your password") });
  return runAction("saveSecuritySettings", "settings.manage", schema, input, async (d, session) => {
    if (!(await confirmPassword(session.profile.email, d.password))) return { ok: false, error: "Password is incorrect.", fieldErrors: { password: ["Password is incorrect"] } };
    await markReauthenticated(session.userId);
    const supabase = await createClient();
    check(await supabase.from("settings").upsert({ key: "security.reauth_minutes", value: d.reauth_minutes }));
    await auditEvent(session.userId, "security.settings_changed", "settings", "security.reauth_minutes", { value: d.reauth_minutes });
    refresh("/app/settings/security");
    return ok();
  });
}

export async function setRolePermission(roleId: string, permission: string, granted: boolean): Promise<ActionResult> {
  if (!validId(roleId)) return NOT_FOUND;
  const schema = z.object({ permission: z.string().regex(/^[a-z]+\.[a-z_]+$/), granted: z.boolean() });
  return runAction("setRolePermission", "users.manage_roles", schema, { permission, granted }, async (d) => {
    const supabase = await createClient();
    if (d.granted) check(await supabase.from("role_permissions").insert({ role_id: roleId, permission_key: d.permission }));
    else {
      const rows = check(await supabase.from("role_permissions").delete().eq("role_id", roleId).eq("permission_key", d.permission).select("role_id"));
      if (!rows?.length) return NOT_FOUND;
    }
    refresh("/app/admin/roles");
    return ok();
  });
}

export async function createRole(input: unknown): Promise<ActionResult> {
  const schema = z.object({ key, name: name(), description: optionalText(300) });
  return runAction("createRole", "users.manage_roles", schema, input, async (d) => {
    const supabase = await createClient();
    check(await supabase.from("roles").insert({ ...d, is_system: false, is_superuser: false }));
    refresh("/app/admin/roles", "/app/admin/users");
    return ok();
  });
}
