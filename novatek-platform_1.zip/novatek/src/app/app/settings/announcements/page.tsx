import { Card, CardHeader, PageHeader } from "@/components/ui/primitives";
import { AnnouncementForm } from "@/components/settings/forms";
import { SettingsTabs } from "@/components/settings/settings-tabs";
import { requirePermission } from "@/lib/auth/session";
import { getPeopleMap } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { formatDateTime } from "@/lib/utils";

export const metadata = { title: "Announcements" };

export default async function AnnouncementsPage() {
  const session = await requirePermission("settings.manage");
  const supabase = await createClient();
  const [{ data }, people] = await Promise.all([supabase.from("announcements").select("*").order("created_at", { ascending: false }).limit(30), getPeopleMap()]);
  return (
    <>
      <PageHeader title="Settings" />
      <SettingsTabs session={session} active="/app/settings/announcements" />
      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-2">
          <CardHeader title="New announcement" description="Delivered as a notification to every active user" />
          <div className="p-5"><AnnouncementForm /></div>
        </Card>
        <Card className="lg:col-span-3">
          <CardHeader title="Sent" />
          {(data ?? []).length === 0 ? <p className="px-5 py-4 text-sm text-text-3">No announcements yet.</p> : (
            <ul className="divide-y divide-border">
              {(data ?? []).map((a) => (
                <li key={a.id} className="px-5 py-3">
                  <p className="text-sm font-medium">{a.title}</p>
                  {a.body && <p className="mt-1 whitespace-pre-wrap text-sm text-text-2">{a.body}</p>}
                  <p className="mt-1 text-xs text-text-3">{formatDateTime(a.created_at)} · {a.sent_by ? people.get(a.sent_by) ?? "—" : "—"} · {a.recipient_count} recipients{a.priority === "high" ? " · high priority" : ""}</p>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  );
}
