import { redirect } from "next/navigation";
import { Lock } from "lucide-react";
import { Card, CardHeader, PageHeader } from "@/components/ui/primitives";
import { BrandLogo, BrandMark } from "@/components/brand/brand-logo";
import { SettingsTabs } from "@/components/settings/settings-tabs";
import { BrandingForm } from "@/components/settings/forms";
import { requirePermission } from "@/lib/auth/session";
import { canConfigure } from "@/lib/auth/permissions";
import { brand } from "@/lib/config/brand";
import { getSetting } from "@/lib/data/lookups";

export const metadata = { title: "Settings" };

type Branding = { tagline?: string; contact_email?: string; contact_phone?: string; whatsapp?: string; address?: string; footer_note?: string;
  social?: { linkedin?: string; facebook?: string; instagram?: string; x?: string } };

export default async function SettingsPage() {
  const session = await requirePermission(canConfigure);
  if (!session.can("settings.manage")) redirect("/app/settings/crm");
  const b = await getSetting<Branding>("branding", {});
  return (
    <>
      <PageHeader title="Settings" description="Central configuration. Every change is recorded in the audit log." />
      <SettingsTabs session={session} active="/app/settings" />
      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader title="Branding & contact details" description="Shown on the public website" />
          <div className="p-5">
            <BrandingForm defaults={{
              tagline: b.tagline ?? brand.tagline, contact_email: b.contact_email ?? brand.contact.email, contact_phone: b.contact_phone ?? "",
              whatsapp: b.whatsapp ?? brand.contact.whatsapp, address: b.address ?? "", footer_note: b.footer_note ?? "",
              linkedin: b.social?.linkedin ?? "", facebook: b.social?.facebook ?? "", instagram: b.social?.instagram ?? "", x: b.social?.x ?? "",
            }} />
          </div>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader title="Logo & name" description="Locked by owner instruction" />
          <div className="space-y-4 p-5">
            <BrandLogo height={32} plate />
            <BrandMark size={48} />
            <p className="flex gap-2 text-sm text-text-2"><Lock className="mt-0.5 size-4 shrink-0 text-text-3" />
              The official logo, app icon, company name and its lettering are fixed. They are served from the original files and can’t be changed, recoloured or restyled from Settings.</p>
          </div>
        </Card>
      </div>
    </>
  );
}
