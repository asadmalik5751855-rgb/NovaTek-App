import { Card, CardHeader, PageHeader } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { ConfigTableEditor, type FieldSpec } from "@/components/settings/config-table";
import { CountryTargets } from "@/components/settings/country-targets";
import { QualificationQuestionsForm } from "@/components/settings/forms";
import { SettingsTabs } from "@/components/settings/settings-tabs";
import { requirePermission } from "@/lib/auth/session";
import { canConfigure } from "@/lib/auth/permissions";
import { createClient } from "@/lib/supabase/server";
import { rescoreLeads } from "../actions";

export const metadata = { title: "CRM settings" };

const COLORS = ["slate", "zinc", "blue", "sky", "indigo", "violet", "purple", "fuchsia", "amber", "emerald", "rose"].map((c) => ({ value: c, label: c }));

export default async function CrmSettingsPage() {
  const session = await requirePermission(canConfigure);
  const can = session.can("crm.configure");
  const supabase = await createClient();
  const [statuses, sources, services, industries, stages, rules, countries, questions] = await Promise.all([
    supabase.from("lead_statuses").select("*").order("position"),
    supabase.from("lead_sources").select("*").order("name"),
    supabase.from("services").select("*").order("position"),
    supabase.from("industries").select("*").order("name"),
    supabase.from("deal_stages").select("*").order("position"),
    supabase.from("scoring_rules").select("*").order("signal"),
    supabase.from("countries").select("code, name, is_target").eq("active", true).order("name"),
    supabase.from("settings").select("value").eq("key", "crm.qualification_questions").maybeSingle(),
  ]);
  const rows = (d: { data: Record<string, unknown>[] | null }, idKey = "id") => (d.data ?? []).map((r) => ({ ...r, __id: String(r[idKey]) }));
  const qText = ((questions.data?.value as { key: string; label: string; type: string; options?: string[] }[]) ?? [])
    .map((q) => [q.key, q.label, q.type, q.options?.join(", ")].filter((x) => x !== undefined).join(" | ")).join("\n");

  const statusFields: FieldSpec[] = [
    { name: "key", label: "Key", type: "text", createOnly: true, width: "w-36" },
    { name: "name", label: "Name", type: "text" },
    { name: "position", label: "Order", type: "number", width: "w-20" },
    { name: "color", label: "Colour", type: "select", options: COLORS, width: "w-28" },
    { name: "funnel_rank", label: "Funnel stage #", type: "number", width: "w-28" },
    { name: "show_in_pipeline", label: "On board", type: "checkbox" },
    { name: "is_closed", label: "Closed", type: "checkbox" },
    { name: "is_won", label: "Won", type: "checkbox" },
    { name: "active", label: "Active", type: "checkbox" },
  ];

  return (
    <>
      <PageHeader title="Settings" description="Lead statuses, sources, services, industries, markets, deal stages, scoring and qualification." />
      <SettingsTabs session={session} active="/app/settings/crm" />
      <div className="space-y-6">
        <Card>
          <CardHeader title="Lead statuses" description="Funnel stage # (1 qualified → 7 won) powers conversion analytics. Statuses are never deleted — deactivate instead." />
          <ConfigTableEditor table="lead_statuses" canEdit={can} rows={rows(statuses)} fields={statusFields}
            newDefaults={{ key: "", name: "", position: "200", color: "slate", funnel_rank: "", show_in_pipeline: false, is_closed: false, is_won: false, active: true }} />
        </Card>

        <Card>
          <CardHeader title="Deal stages" description="Won/lost stages are fixed once created; deals reach them only through Mark won / Mark lost." />
          <ConfigTableEditor table="deal_stages" canEdit={can} rows={rows(stages)} newDefaults={{ key: "", name: "", position: "35", default_probability: "40", color: "blue", is_won: false, is_lost: false, active: true }}
            fields={[
              { name: "key", label: "Key", type: "text", createOnly: true, width: "w-32" },
              { name: "name", label: "Name", type: "text" },
              { name: "position", label: "Order", type: "number", width: "w-20" },
              { name: "default_probability", label: "Default %", type: "number", width: "w-24" },
              { name: "color", label: "Colour", type: "select", options: COLORS, width: "w-28" },
              { name: "is_won", label: "Won", type: "checkbox", createOnly: true },
              { name: "is_lost", label: "Lost", type: "checkbox", createOnly: true },
              { name: "active", label: "Active", type: "checkbox" },
            ]} />
        </Card>

        <Card>
          <CardHeader title="Lead scoring" description="Points per proven signal; total is capped 0–100. Cold ≤30 · Warm ≤60 · Hot ≤80 · Very hot >80."
            action={can ? <ActionButton action={rescoreLeads} size="sm" confirm="Recalculate the score of every active lead with the current rules?" successMessage="All active leads rescored.">Rescore all leads</ActionButton> : undefined} />
          <ConfigTableEditor table="scoring_rules" canEdit={can} canAdd={false} rows={rows(rules, "signal")} newDefaults={{}}
            fields={[
              { name: "signal", label: "Signal", type: "text", createOnly: true, width: "w-40" },
              { name: "label", label: "Label", type: "text", width: "w-56" },
              { name: "points", label: "Points", type: "number", width: "w-20" },
              { name: "active", label: "Active", type: "checkbox" },
            ]} />
        </Card>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader title="Services" />
            <ConfigTableEditor table="services" canEdit={can} rows={rows(services)} newDefaults={{ key: "", name: "", position: "100", active: true, description: "" }}
              fields={[
                { name: "key", label: "Key", type: "text", createOnly: true, width: "w-32" },
                { name: "name", label: "Name", type: "text", width: "w-48" },
                { name: "position", label: "Order", type: "number", width: "w-16" },
                { name: "active", label: "Active", type: "checkbox" },
              ]} />
          </Card>
          <Card>
            <CardHeader title="Lead sources" />
            <ConfigTableEditor table="lead_sources" canEdit={can} rows={rows(sources)} newDefaults={{ key: "", name: "", active: true }}
              fields={[
                { name: "key", label: "Key", type: "text", createOnly: true, width: "w-32" },
                { name: "name", label: "Name", type: "text", width: "w-48" },
                { name: "active", label: "Active", type: "checkbox" },
              ]} />
          </Card>
          <Card>
            <CardHeader title="Industries" description="Target industries earn scoring points" />
            <ConfigTableEditor table="industries" canEdit={can} rows={rows(industries)} newDefaults={{ name: "", is_target: false, active: true }}
              fields={[
                { name: "name", label: "Name", type: "text", width: "w-52" },
                { name: "is_target", label: "Target", type: "checkbox" },
                { name: "active", label: "Active", type: "checkbox" },
              ]} />
          </Card>
          <Card>
            <CardHeader title="Target countries" description="Target countries earn scoring points" />
            <div className="p-5"><CountryTargets countries={(countries.data ?? []) as { code: string; name: string; is_target: boolean }[]} canEdit={can} /></div>
          </Card>
        </div>

        <Card>
          <CardHeader title="Qualification questions" description="Shown on every lead. Answers are stored on the lead and recorded on its timeline." />
          <div className="p-5">{can ? <QualificationQuestionsForm value={qText} /> : <pre className="whitespace-pre-wrap text-sm">{qText}</pre>}</div>
        </Card>
      </div>
    </>
  );
}
