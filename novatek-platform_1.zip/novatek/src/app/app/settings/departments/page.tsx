import { Card, CardHeader, PageHeader } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { ConfigTableEditor } from "@/components/settings/config-table";
import { SettingsTabs } from "@/components/settings/settings-tabs";
import { requirePermission } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";
import { deleteDepartment } from "../actions";

export const metadata = { title: "Departments" };

export default async function DepartmentsPage() {
  const session = await requirePermission("employees.manage");
  const supabase = await createClient();
  const [{ data: depts }, { data: people }] = await Promise.all([
    supabase.from("departments").select("id, name").order("name"),
    supabase.from("directory").select("department_id").eq("status", "active"),
  ]);
  const count = new Map<string, number>();
  for (const p of people ?? []) if (p.department_id) count.set(p.department_id, (count.get(p.department_id) ?? 0) + 1);
  return (
    <>
      <PageHeader title="Settings" />
      <SettingsTabs session={session} active="/app/settings/departments" />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader title="Departments" description="Rename or add. A department can only be removed when no one is in it." />
          <ConfigTableEditor table="departments" canEdit rows={(depts ?? []).map((d) => ({ ...d, __id: d.id }))} newDefaults={{ name: "" }}
            fields={[{ name: "name", label: "Name", type: "text", width: "w-64" }]} />
        </Card>
        <Card>
          <CardHeader title="Headcount" />
          <ul className="divide-y divide-border">
            {(depts ?? []).map((d) => (
              <li key={d.id} className="flex items-center gap-3 px-5 py-2.5 text-sm">
                <span className="flex-1">{d.name}</span>
                <span className="tabular-nums text-text-3">{count.get(d.id) ?? 0}</span>
                {!count.get(d.id) && <ActionButton action={deleteDepartment.bind(null, d.id)} size="sm" variant="ghost" confirm={`Delete “${d.name}”?`}>Delete</ActionButton>}
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </>
  );
}
