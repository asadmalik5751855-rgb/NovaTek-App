import { CheckCircle2, CircleDashed, XCircle } from "lucide-react";
import { Badge, Card, PageHeader } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { SettingsTabs } from "@/components/settings/settings-tabs";
import { requirePermission } from "@/lib/auth/session";
import { envPresent } from "@/lib/env.server";
import { hasAdapter } from "@/lib/integrations/adapters";
import { createClient } from "@/lib/supabase/server";
import { formatDateTime } from "@/lib/utils";
import { runIntegrationCheck, setIntegrationEnabled } from "../actions";

export const metadata = { title: "Integrations" };

export default async function IntegrationsPage() {
  const session = await requirePermission("settings.manage");
  const supabase = await createClient();
  const { data, error } = await supabase.from("integrations").select("*").order("category").order("name");
  if (error) throw error;
  return (
    <>
      <PageHeader title="Settings" description="Integrations stay off until their credentials are set on the server and a live check succeeds. Nothing is simulated." />
      <SettingsTabs session={session} active="/app/settings/integrations" />
      <div className="grid gap-4 lg:grid-cols-2">
        {(data ?? []).map((i) => {
          const configured = envPresent(i.required_env as string[]);
          const adapter = hasAdapter(i.key);
          return (
            <Card key={i.key} className="space-y-3 p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs text-text-3">{i.category}</p>
                  <h2 className="font-semibold">{i.name}</h2>
                </div>
                {i.enabled ? <Badge color="emerald">Enabled</Badge> : <Badge>Off</Badge>}
              </div>
              <p className="text-sm text-text-2">{i.description}</p>
              <ul className="space-y-1 text-xs">
                {(i.required_env as string[]).map((v) => {
                  const ok = envPresent([v]);
                  return <li key={v} className="flex items-center gap-1.5">{ok ? <CheckCircle2 className="size-3.5 text-success" /> : <CircleDashed className="size-3.5 text-text-3" />}<code>{v}</code>{!ok && <span className="text-text-3">not set</span>}</li>;
                })}
              </ul>
              {!adapter && <p className="text-xs text-text-3">Connector not built yet — it will stay disabled even with credentials.</p>}
              {i.last_checked_at && (
                <p className="flex items-center gap-1.5 text-xs">
                  {i.last_status === "ok" ? <CheckCircle2 className="size-3.5 text-success" /> : <XCircle className="size-3.5 text-danger" />}
                  Last check {formatDateTime(i.last_checked_at)}: {i.last_status === "ok" ? "succeeded" : i.last_error ?? i.last_status}
                </p>
              )}
              <div className="flex flex-wrap gap-2">
                <ActionButton action={runIntegrationCheck.bind(null, i.key)} size="sm" disabled={!configured} successMessage="Check finished — see the result above.">Run live check</ActionButton>
                {i.enabled ? (
                  <ActionButton action={setIntegrationEnabled.bind(null, i.key, false)} size="sm" variant="ghost" confirm="Turn this integration off?">Turn off</ActionButton>
                ) : (
                  <ActionButton action={setIntegrationEnabled.bind(null, i.key, true)} size="sm" variant="brand" disabled={i.last_status !== "ok"}>Enable</ActionButton>
                )}
              </div>
            </Card>
          );
        })}
      </div>
    </>
  );
}
