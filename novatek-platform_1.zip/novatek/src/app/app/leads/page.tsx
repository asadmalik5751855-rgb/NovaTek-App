import Link from "next/link";
import { AlertTriangle, ChevronLeft, ChevronRight, Download, Plus, Search, Target, Upload } from "lucide-react";
import { Badge, ButtonLink, Card, EmptyState, Input, PageHeader, Select, buttonClass } from "@/components/ui/primitives";
import { StatusBadge, TemperatureBadge } from "@/components/leads/badges";
import { requirePermission } from "@/lib/auth/session";
import { canViewLeads } from "@/lib/auth/permissions";
import { PAGE_SIZE, getLookups, listLeads } from "@/lib/leads/queries";
import { formatDate, formatMoney } from "@/lib/utils";

export const metadata = { title: "Leads" };

const str = (v: string | string[] | undefined) => (typeof v === "string" && v ? v : undefined);

export default async function LeadsPage({ searchParams }: PageProps<"/app/leads">) {
  const session = await requirePermission(canViewLeads);
  const sp = await searchParams;
  const filters = {
    q: str(sp.q),
    status: str(sp.status),
    temperature: str(sp.temperature),
    assigned: str(sp.assigned),
    source: str(sp.source),
    archived: sp.archived === "1",
    page: Number(str(sp.page) ?? 1) || 1,
  };
  const [lookups, { leads, total, page }] = await Promise.all([getLookups(), listLeads(filters, session.userId)]);
  const people = new Map(lookups.people.map((p) => [p.id, p.full_name]));
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const hasFilters = Boolean(filters.q || filters.status || filters.temperature || filters.assigned || filters.source || filters.archived);

  const pageHref = (p: number) => {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(sp)) if (typeof v === "string" && v && k !== "page") params.set(k, v);
    params.set("page", String(p));
    return `/app/leads?${params}`;
  };

  return (
    <>
      <PageHeader
        title="Leads"
        description={`${total.toLocaleString()} ${filters.archived ? "archived" : "active"} lead${total === 1 ? "" : "s"}${session.can("leads.view_all") ? "" : " assigned to or created by you"}`}
        actions={
          <>
            {session.can("leads.import") && <ButtonLink href="/app/leads/import" variant="secondary"><Upload className="size-4" /> Import</ButtonLink>}
            {session.can("leads.export") && <ButtonLink href="/app/export" variant="secondary"><Download className="size-4" /> Export</ButtonLink>}
            {session.can("leads.create") && (
              <ButtonLink href="/app/leads/new" variant="brand">
                <Plus className="size-4" /> Add lead
              </ButtonLink>
            )}
          </>
        }
      />

      <form className="mb-4 grid grid-cols-2 gap-2 md:grid-cols-6" role="search">
        <div className="relative col-span-2">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-text-3" />
          <Input name="q" defaultValue={filters.q} placeholder="Search company, contact, email" className="pl-9" aria-label="Search leads" />
        </div>
        <Select name="status" defaultValue={filters.status ?? ""} aria-label="Status">
          <option value="">All statuses</option>
          {lookups.statuses.map((s) => (
            <option key={s.id} value={s.id}>{s.name}</option>
          ))}
        </Select>
        <Select name="temperature" defaultValue={filters.temperature ?? ""} aria-label="Temperature">
          <option value="">Any temperature</option>
          <option value="hot_plus">Hot or Very Hot</option>
          <option value="very_hot">Very Hot</option>
          <option value="hot">Hot</option>
          <option value="warm">Warm</option>
          <option value="cold">Cold</option>
        </Select>
        <Select name="assigned" defaultValue={filters.assigned ?? ""} aria-label="Assignee">
          <option value="">Anyone</option>
          <option value="me">Assigned to me</option>
          {session.can("leads.view_all") && <option value="unassigned">Unassigned</option>}
          {session.can("leads.view_all") &&
            lookups.people.map((p) => (
              <option key={p.id} value={p.id}>{p.full_name || "Unnamed user"}</option>
            ))}
        </Select>
        <div className="flex gap-2">
          <Select name="source" defaultValue={filters.source ?? ""} aria-label="Source">
            <option value="">All sources</option>
            {lookups.sources.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </Select>
          <button type="submit" className={buttonClass("secondary", "md")}>Filter</button>
        </div>
        {session.can("leads.delete") && (
          <label className="col-span-2 flex items-center gap-2 text-sm text-text-2 md:col-span-6">
            <input type="checkbox" name="archived" value="1" defaultChecked={filters.archived} className="accent-[var(--accent)]" />
            Show archived leads
          </label>
        )}
      </form>

      <Card className="overflow-hidden">
        {leads.length === 0 ? (
          <EmptyState
            icon={<Target className="size-5" />}
            title={hasFilters ? "No leads match these filters" : "No leads yet"}
            description={
              hasFilters
                ? "Try clearing a filter or searching for something else."
                : "Leads from the website contact form appear here automatically. You can also add one manually."
            }
            action={
              hasFilters ? (
                <ButtonLink href="/app/leads" variant="secondary">Clear filters</ButtonLink>
              ) : session.can("leads.create") ? (
                <ButtonLink href="/app/leads/new" variant="brand"><Plus className="size-4" /> Add your first lead</ButtonLink>
              ) : undefined
            }
          />
        ) : (
          <>
            {/* Desktop table */}
            <table className="hidden w-full text-sm md:table">
              <thead className="border-b border-border bg-surface-2/50 text-left text-xs font-medium uppercase tracking-wide text-text-3">
                <tr>
                  <th className="px-4 py-2.5">Company</th>
                  <th className="px-4 py-2.5">Status</th>
                  <th className="px-4 py-2.5">Score</th>
                  <th className="px-4 py-2.5">Owner</th>
                  <th className="px-4 py-2.5">Value</th>
                  <th className="px-4 py-2.5">Follow-up</th>
                  <th className="px-4 py-2.5">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {leads.map((l) => (
                  <tr key={l.id} className="hover:bg-surface-2/40">
                    <td className="max-w-72 px-4 py-3">
                      <Link href={`/app/leads/${l.id}`} className="font-medium text-text hover:text-accent">
                        {l.company_name}
                      </Link>
                      <div className="flex items-center gap-2 truncate text-xs text-text-3">
                        {l.contact_name ?? l.email ?? "—"}
                        {l.possible_duplicate_of && (
                          <Badge color="amber"><AlertTriangle className="size-3" /> Possible duplicate</Badge>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3"><StatusBadge status={lookups.statusById.get(l.status_id)} /></td>
                    <td className="px-4 py-3"><TemperatureBadge temperature={l.temperature} score={l.score} /></td>
                    <td className="px-4 py-3 text-text-2">{l.assigned_to ? people.get(l.assigned_to) ?? "—" : <span className="text-text-3">Unassigned</span>}</td>
                    <td className="px-4 py-3 tabular-nums text-text-2">{formatMoney(l.estimated_value, l.currency)}</td>
                    <td className={`px-4 py-3 ${l.next_follow_up_at && new Date(l.next_follow_up_at) < new Date() ? "text-danger" : "text-text-2"}`}>
                      {formatDate(l.next_follow_up_at)}
                    </td>
                    <td className="px-4 py-3 text-text-3">{formatDate(l.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Mobile cards */}
            <ul className="divide-y divide-border md:hidden">
              {leads.map((l) => (
                <li key={l.id}>
                  <Link href={`/app/leads/${l.id}`} className="block space-y-2 px-4 py-3">
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-medium">{l.company_name}</span>
                      <TemperatureBadge temperature={l.temperature} score={l.score} />
                    </div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-text-3">
                      <StatusBadge status={lookups.statusById.get(l.status_id)} />
                      {l.contact_name && <span>{l.contact_name}</span>}
                      {l.possible_duplicate_of && <Badge color="amber">Possible duplicate</Badge>}
                    </div>
                  </Link>
                </li>
              ))}
            </ul>

            {pages > 1 && (
              <div className="flex items-center justify-between border-t border-border px-4 py-3 text-sm text-text-3">
                <span>Page {page} of {pages}</span>
                <div className="flex gap-2">
                  {page > 1 && <Link className={buttonClass("secondary", "sm")} href={pageHref(page - 1)}><ChevronLeft className="size-4" /> Prev</Link>}
                  {page < pages && <Link className={buttonClass("secondary", "sm")} href={pageHref(page + 1)}>Next <ChevronRight className="size-4" /></Link>}
                </div>
              </div>
            )}
          </>
        )}
      </Card>
    </>
  );
}
