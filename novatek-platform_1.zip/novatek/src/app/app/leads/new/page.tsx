import { Card, PageHeader } from "@/components/ui/primitives";
import { LeadForm } from "@/components/leads/lead-form";
import { requirePermission } from "@/lib/auth/session";
import { getLookups } from "@/lib/leads/queries";

export const metadata = { title: "New lead" };

export default async function NewLeadPage() {
  const session = await requirePermission("leads.create");
  const lookups = await getLookups();
  const manual = lookups.sources.find((s) => s.key === "manual");
  return (
    <>
      <PageHeader title="New lead" description="Only record business information obtained legitimately. Duplicates are flagged automatically." />
      <Card className="p-5 sm:p-6">
        <LeadForm
          mode="create"
          defaults={{
            source_id: manual?.id ?? "",
            status_id: lookups.statuses[0]?.id ?? "",
            assigned_to: session.can("leads.assign") ? "" : session.userId,
          }}
          lookups={lookups}
          canAssign={session.can("leads.assign")}
          currentUserId={session.userId}
        />
      </Card>
    </>
  );
}
