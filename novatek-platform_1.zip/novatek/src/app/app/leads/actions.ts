"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorize } from "@/lib/auth/session";
import { check, toActionError, type ActionResult } from "@/lib/errors";
import { friendlyDbError } from "@/lib/actions";
import { createClient } from "@/lib/supabase/server";
import {
  activitySchema,
  createLeadSchema,
  followUpSchema,
  idSchema,
  leadFieldsSchema,
} from "@/lib/validation/leads";

const NOT_FOUND = { ok: false as const, error: "Lead not found, or you don't have access to it." };

function fieldErrors(err: z.ZodError) {
  return { ok: false as const, error: "Please fix the highlighted fields.", fieldErrors: z.flattenError(err).fieldErrors };
}

function refresh(id?: string) {
  revalidatePath("/app/leads");
  revalidatePath("/app/pipeline");
  revalidatePath("/app");
  if (id) revalidatePath(`/app/leads/${id}`);
}

export async function createLead(input: unknown): Promise<ActionResult<{ id: string; possibleDuplicate: boolean }>> {
  try {
    await authorize("leads.create");
    const parsed = createLeadSchema.safeParse(input);
    if (!parsed.success) return fieldErrors(parsed.error);
    const supabase = await createClient();
    const row = check(
      await supabase.from("leads").insert(parsed.data).select("id, possible_duplicate_of").single(),
    );
    if (!row) return { ok: false, error: "The lead could not be saved." };
    refresh();
    return { ok: true, data: { id: row.id, possibleDuplicate: Boolean(row.possible_duplicate_of) } };
  } catch (e) {
    return friendlyDbError(e, "createLead");
  }
}

export async function updateLead(id: string, input: unknown): Promise<ActionResult> {
  try {
    await authorize("leads.edit");
    if (!idSchema.safeParse(id).success) return NOT_FOUND;
    const parsed = leadFieldsSchema.safeParse(input);
    if (!parsed.success) return fieldErrors(parsed.error);
    const supabase = await createClient();
    const rows = check(await supabase.from("leads").update(parsed.data).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(id);
    return { ok: true, data: undefined };
  } catch (e) {
    return friendlyDbError(e, "updateLead");
  }
}

export async function changeLeadStatus(id: string, statusId: string): Promise<ActionResult> {
  try {
    await authorize("leads.edit");
    if (!idSchema.safeParse(id).success || !idSchema.safeParse(statusId).success) return NOT_FOUND;
    const supabase = await createClient();
    const rows = check(await supabase.from("leads").update({ status_id: statusId }).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(id);
    return { ok: true, data: undefined };
  } catch (e) {
    return friendlyDbError(e, "changeLeadStatus");
  }
}

export async function assignLead(id: string, userId: string | null): Promise<ActionResult> {
  try {
    await authorize("leads.assign");
    if (!idSchema.safeParse(id).success || (userId !== null && !idSchema.safeParse(userId).success)) return NOT_FOUND;
    const supabase = await createClient();
    const rows = check(await supabase.from("leads").update({ assigned_to: userId }).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(id);
    return { ok: true, data: undefined };
  } catch (e) {
    return friendlyDbError(e, "assignLead");
  }
}

export async function addLeadActivity(id: string, input: unknown): Promise<ActionResult> {
  try {
    await authorize("leads.edit");
    if (!idSchema.safeParse(id).success) return NOT_FOUND;
    const parsed = activitySchema.safeParse(input);
    if (!parsed.success) return fieldErrors(parsed.error);
    const supabase = await createClient();
    check(await supabase.from("lead_activities").insert({ lead_id: id, ...parsed.data }));
    refresh(id);
    return { ok: true, data: undefined };
  } catch (e) {
    return toActionError(e, "addLeadActivity");
  }
}

export async function setFollowUp(id: string, input: unknown): Promise<ActionResult> {
  try {
    await authorize("leads.edit");
    if (!idSchema.safeParse(id).success) return NOT_FOUND;
    const parsed = followUpSchema.safeParse(input);
    if (!parsed.success) return fieldErrors(parsed.error);
    const supabase = await createClient();
    const rows = check(await supabase.from("leads").update(parsed.data).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(id);
    return { ok: true, data: undefined };
  } catch (e) {
    return toActionError(e, "setFollowUp");
  }
}

export async function setLeadArchived(id: string, archived: boolean): Promise<ActionResult> {
  try {
    await authorize("leads.delete");
    if (!idSchema.safeParse(id).success) return NOT_FOUND;
    const supabase = await createClient();
    const rows = check(
      await supabase.from("leads").update({ archived_at: archived ? new Date().toISOString() : null }).eq("id", id).select("id"),
    );
    if (!rows?.length) return NOT_FOUND;
    refresh(id);
    return { ok: true, data: undefined };
  } catch (e) {
    return friendlyDbError(e, "setLeadArchived");
  }
}

export async function dismissDuplicate(id: string): Promise<ActionResult> {
  try {
    await authorize("leads.merge");
    if (!idSchema.safeParse(id).success) return NOT_FOUND;
    const supabase = await createClient();
    const rows = check(await supabase.from("leads").update({ possible_duplicate_of: null }).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(id);
    return { ok: true, data: undefined };
  } catch (e) {
    return toActionError(e, "dismissDuplicate");
  }
}

export async function convertLeadToClient(id: string): Promise<ActionResult<{ client_id: string }>> {
  try {
    await authorize("sales.manage");
    if (!idSchema.safeParse(id).success) return NOT_FOUND;
    const supabase = await createClient();
    const clientId = check(await supabase.rpc("convert_lead_to_client", { p_lead: id })) as string;
    refresh(id);
    revalidatePath("/app/clients");
    return { ok: true, data: { client_id: clientId } };
  } catch (e) {
    return friendlyDbError(e, "convertLeadToClient");
  }
}

/** Merge `duplicateId` into `survivorId` (atomic in the database; history is preserved). */
export async function mergeLeads(survivorId: string, duplicateId: string): Promise<ActionResult> {
  try {
    await authorize("leads.merge");
    if (!idSchema.safeParse(survivorId).success || !idSchema.safeParse(duplicateId).success) return NOT_FOUND;
    const supabase = await createClient();
    check(await supabase.rpc("merge_leads", { p_survivor: survivorId, p_duplicate: duplicateId }));
    refresh(survivorId);
    refresh(duplicateId);
    return { ok: true, data: undefined };
  } catch (e) {
    return friendlyDbError(e, "mergeLeads");
  }
}

const qualificationSchema = z.record(z.string().regex(/^[a-z][a-z0-9_]{1,40}$/), z.string().trim().max(2000)).refine(
  (o) => Object.keys(o).length <= 30, "Too many answers",
);

export async function updateQualification(id: string, input: unknown): Promise<ActionResult> {
  try {
    await authorize("leads.edit");
    if (!idSchema.safeParse(id).success) return NOT_FOUND;
    const parsed = qualificationSchema.safeParse(input);
    if (!parsed.success) return fieldErrors(parsed.error);
    const answers = Object.fromEntries(Object.entries(parsed.data).filter(([, v]) => v !== ""));
    const supabase = await createClient();
    const rows = check(await supabase.from("leads").update({ qualification: answers }).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(id);
    return { ok: true, data: undefined };
  } catch (e) {
    return friendlyDbError(e, "updateQualification");
  }
}
