import Link from "next/link";
import { notFound } from "next/navigation";
import { AlertTriangle, ArrowLeft, Building2, CalendarPlus, ExternalLink, Handshake, ListPlus, Mail, Pencil, Phone } from "lucide-react";
import { Alert, Badge, ButtonLink, Card, CardHeader } from "@/components/ui/primitives";
import { StatusBadge, TemperatureBadge } from "@/components/leads/badges";
import { Timeline } from "@/components/leads/timeline";
import {
  ActivityComposer,
  ArchiveButton,
  AssignControl,
  DismissDuplicateButton,
  FollowUpForm,
  StatusControl,
} from "@/components/leads/lead-controls";
import { requirePermission } from "@/lib/auth/session";
import { canViewLeads } from "@/lib/auth/permissions";
import { getLead, getLookups } from "@/lib/leads/queries";
import { BUDGET_RANGES, BUSINESS_SIZES } from "@/lib/leads/types";
import { idSchema } from "@/lib/validation/leads";
import { formatDate, formatDateTime, formatMoney } from "@/lib/utils";
import { ActionButton } from "@/components/ui/action-button";
import { MapBadge } from "@/components/ui/status";
import { AiAssist } from "@/components/ai/ai-assist";
import { DocumentsCard } from "@/components/documents/documents-card";
import { QualificationForm, type Question } from "@/components/leads/qualification-form";
import { getDealStages, getSetting } from "@/lib/data/lookups";
import { AI_FEATURES } from "@/lib/integrations/ai";
import { MEETING_STATUS, TASK_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { convertLeadToClient, mergeLeads } from "@/app/app/leads/actions";

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-3 gap-3 py-2 text-sm">
      <dt className="text-text-3">{label}</dt>
      <dd className="col-span-2 break-words text-text">{children ?? "—"}</dd>
    </div>
  );
}

export default async function LeadPage({ params }: PageProps<"/app/leads/[id]">) {
  const session = await requirePermission(canViewLeads);
  const { id } = await params;
  if (!idSchema.safeParse(id).success) notFound();
  const [result, lookups] = await Promise.all([getLead(id), getLookups()]);
  if (!result) notFound(); // RLS: not visible to this user is indistinguishable from not existing.

  const { lead: l, activities, tags, duplicate } = result;
  const supabase = await createClient();
  const [deals, meetings, tasks, questions, stages] = await Promise.all([
    session.can({ anyOf: ["sales.view", "sales.manage"] })
      ? supabase.from("deals").select("id, name, value, currency, stage_id").eq("lead_id", id).is("archived_at", null).order("created_at", { ascending: false })
      : Promise.resolve({ data: [] as { id: string; name: string; value: number; currency: string; stage_id: string }[] }),
    supabase.from("meetings").select("id, title, starts_at, status").eq("lead_id", id).order("starts_at", { ascending: false }).limit(10),
    supabase.from("tasks").select("id, title, status, due_at").eq("lead_id", id).order("created_at", { ascending: false }).limit(10),
    getSetting<Question[]>("crm.qualification_questions", []),
    getDealStages(),
  ]);
  const leadClientId = (l as unknown as { client_id: string | null }).client_id;
  const people = new Map(lookups.people.map((p) => [p.id, p.full_name || "Unnamed user"]));
  const canEdit = session.can("leads.edit");
  const status = lookups.statusById.get(l.status_id);
  const service = lookups.services.find((s) => s.id === l.service_id)?.name;
  const industry = lookups.industries.find((s) => s.id === l.industry_id)?.name;
  const country = lookups.countries.find((c) => c.code === l.country_code)?.name;
  const source = lookups.sources.find((s) => s.id === l.source_id)?.name;
  const utm = [
    ["source", l.utm_source], ["medium", l.utm_medium], ["campaign", l.utm_campaign], ["content", l.utm_content], ["term", l.utm_term],
  ].filter(([, v]) => v);

  return (
    <>
      <Link href="/app/leads" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text">
        <ArrowLeft className="size-4" /> Leads
      </Link>

      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{l.company_name}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <StatusBadge status={status} />
            <TemperatureBadge temperature={l.temperature} score={l.score} />
            {source && <Badge>{source}</Badge>}
            {tags.map((t) => <Badge key={t.id} color={t.color}>{t.name}</Badge>)}
            {l.archived_at && <Badge color="zinc">Archived</Badge>}
          </div>
        </div>
        <div className="flex gap-2">
          {l.email && (
            <a href={`mailto:${l.email}`} className="inline-flex size-10 items-center justify-center rounded-lg border border-border hover:bg-surface-2" aria-label="Email contact">
              <Mail className="size-4" />
            </a>
          )}
          {l.phone && (
            <a href={`tel:${l.phone.replace(/[^\d+]/g, "")}`} className="inline-flex size-10 items-center justify-center rounded-lg border border-border hover:bg-surface-2" aria-label="Call contact">
              <Phone className="size-4" />
            </a>
          )}
          {canEdit && (
            <ButtonLink href={`/app/leads/${l.id}/edit`} variant="secondary">
              <Pencil className="size-4" /> Edit
            </ButtonLink>
          )}
        </div>
      </div>

      {l.possible_duplicate_of && (
        <div className="mb-6">
          <Alert tone="warning">
            <span className="flex flex-wrap items-center gap-3">
              <AlertTriangle className="size-4" />
              <span className="flex-1">
                <strong>Possible duplicate</strong> of{" "}
                {duplicate ? (
                  <Link href={`/app/leads/${duplicate.id}`} className="underline">{duplicate.company_name}</Link>
                ) : (
                  "a lead you don't have access to"
                )}
                . Matched on domain, email, phone or company name. Nothing has been merged.
              </span>
              {session.can("leads.merge") && duplicate && (
                <ActionButton
                  action={mergeLeads.bind(null, duplicate.id, l.id)}
                  size="sm"
                  confirm={`Merge this lead into “${duplicate.company_name}”? Its timeline, notes, tags and deals move there; this record is archived. This cannot be undone automatically.`}
                  confirmLabel="Merge"
                  redirectTo={`/app/leads/${duplicate.id}`}
                >
                  Merge into original
                </ActionButton>
              )}
              {session.can("leads.merge") && <DismissDuplicateButton leadId={l.id} />}
            </span>
          </Alert>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader title="Details" />
            <dl className="divide-y divide-border px-5 py-2">
              <Row label="Contact">{l.contact_name}</Row>
              <Row label="Email">{l.email}</Row>
              <Row label="Phone">{l.phone}</Row>
              <Row label="Website">
                {l.website_domain ? (
                  <a href={`https://${l.website_domain}`} target="_blank" rel="noopener noreferrer nofollow" className="inline-flex items-center gap-1 text-accent hover:underline">
                    {l.website_domain} <ExternalLink className="size-3" />
                  </a>
                ) : l.website}
              </Row>
              <Row label="Industry">{industry}</Row>
              <Row label="Location">{[l.city, country].filter(Boolean).join(", ") || null}</Row>
              <Row label="Business size">{BUSINESS_SIZES.find((b) => b.value === l.business_size)?.label}</Row>
              <Row label="Service">{service}</Row>
              <Row label="Stated budget">{BUDGET_RANGES.find((b) => b.value === l.budget_range)?.label}</Row>
              <Row label="Estimated value">{l.estimated_value !== null ? formatMoney(l.estimated_value, l.currency) : null}</Row>
              <Row label="Consent">{l.consent_status === "granted" ? "Granted via form" : l.consent_status === "withdrawn" ? "Withdrawn" : "Not recorded"}</Row>
              <Row label="Last contacted">{l.last_contacted_at ? formatDateTime(l.last_contacted_at) : null}</Row>
              <Row label="Created">{formatDateTime(l.created_at)}{l.created_by ? ` by ${people.get(l.created_by) ?? "a former user"}` : ""}</Row>
              {l.message && <Row label="Message"><span className="whitespace-pre-wrap">{l.message}</span></Row>}
            </dl>
          </Card>

          <Card>
            <CardHeader title="Activity" description="Every change is recorded with who did it and when" />
            {canEdit && !l.archived_at && (
              <div className="border-b border-border p-5">
                <ActivityComposer leadId={l.id} />
              </div>
            )}
            <Timeline activities={activities} people={people} />
          </Card>

          {(deals.data ?? []).length > 0 && (
            <Card>
              <CardHeader title="Deals" />
              <ul className="divide-y divide-border">
                {(deals.data ?? []).map((d) => {
                  const st = stages.find((x) => x.id === d.stage_id);
                  return (
                    <li key={d.id}>
                      <Link href={`/app/deals/${d.id}`} className="flex items-center gap-3 px-5 py-2.5 hover:bg-surface-2/50">
                        <span className="flex-1 truncate text-sm">{d.name}</span>
                        <span className="text-sm tabular-nums">{formatMoney(d.value, d.currency)}</span>
                        {st && <Badge color={st.color}>{st.name}</Badge>}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </Card>
          )}

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader title="Meetings" action={canEdit ? <Link href={`/app/meetings/new?lead=${l.id}`} className="inline-flex items-center gap-1 text-xs text-accent hover:underline"><CalendarPlus className="size-3.5" /> Schedule</Link> : undefined} />
              {(meetings.data ?? []).length === 0 ? <p className="px-5 py-4 text-sm text-text-3">None scheduled.</p> : (
                <ul className="divide-y divide-border">
                  {(meetings.data ?? []).map((m) => (
                    <li key={m.id}><Link href={`/app/meetings/${m.id}`} className="flex items-center gap-2 px-5 py-2.5 hover:bg-surface-2/50">
                      <span className="flex-1 truncate text-sm">{m.title}</span><MapBadge map={MEETING_STATUS} value={m.status} />
                    </Link></li>
                  ))}
                </ul>
              )}
            </Card>
            <Card>
              <CardHeader title="Tasks" action={<Link href={`/app/tasks/new?lead=${l.id}`} className="inline-flex items-center gap-1 text-xs text-accent hover:underline"><ListPlus className="size-3.5" /> Add</Link>} />
              {(tasks.data ?? []).length === 0 ? <p className="px-5 py-4 text-sm text-text-3">No tasks.</p> : (
                <ul className="divide-y divide-border">
                  {(tasks.data ?? []).map((t) => (
                    <li key={t.id}><Link href={`/app/tasks/${t.id}`} className="flex items-center gap-2 px-5 py-2.5 hover:bg-surface-2/50">
                      <span className="flex-1 truncate text-sm">{t.title}</span><MapBadge map={TASK_STATUS} value={t.status} />
                    </Link></li>
                  ))}
                </ul>
              )}
            </Card>
          </div>

          <DocumentsCard entity="lead" entityId={l.id} canUpload={canEdit && !l.archived_at} userId={session.userId} isAdmin={session.can("settings.manage")} />
        </div>

        <div className="space-y-6">
          <Card className="space-y-4 p-5">
            <div>
              <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-text-3">Status</h2>
              {canEdit ? <StatusControl leadId={l.id} value={l.status_id} statuses={lookups.statuses} disabled={Boolean(l.archived_at)} /> : <StatusBadge status={status} />}
            </div>
            <div>
              <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-text-3">Owner</h2>
              {session.can("leads.assign") ? (
                <AssignControl leadId={l.id} value={l.assigned_to} people={lookups.people} />
              ) : (
                <p className="text-sm">{l.assigned_to ? people.get(l.assigned_to) : "Unassigned"}</p>
              )}
            </div>
          </Card>

          {(session.can({ anyOf: ["sales.view", "sales.manage"] }) || leadClientId) && !l.archived_at && (
            <Card className="space-y-3 p-5">
              <h2 className="text-xs font-medium uppercase tracking-wide text-text-3">Sales</h2>
              {leadClientId && (
                <Link href={`/app/clients/${leadClientId}`} className="flex items-center gap-2 text-sm text-accent hover:underline"><Building2 className="size-4" /> View client record</Link>
              )}
              {session.can({ anyOf: ["sales.view", "sales.manage"] }) && canEdit && (
                <ButtonLink href={`/app/deals/new?lead=${l.id}`} variant="secondary" className="w-full"><Handshake className="size-4" /> Create deal</ButtonLink>
              )}
              {session.can("sales.manage") && status?.is_won && !leadClientId && (
                <ActionButton
                  action={convertLeadToClient.bind(null, l.id)}
                  variant="brand"
                  confirm="Create a client from this won lead? If a client with the same website or email exists, it is linked instead of duplicated."
                  redirectTo="/app/clients/{client_id}"
                >
                  <Building2 className="size-4" /> Convert to client
                </ActionButton>
              )}
            </Card>
          )}

          {questions.length > 0 && (
            <Card className="p-5">
              <h2 className="mb-3 text-xs font-medium uppercase tracking-wide text-text-3">Qualification</h2>
              <QualificationForm leadId={l.id} questions={questions} answers={(l as unknown as { qualification: Record<string, string> }).qualification ?? {}} canEdit={canEdit && !l.archived_at} />
            </Card>
          )}

          {session.can("ai.use") && (
            <Card className="p-5">
              <h2 className="mb-3 text-xs font-medium uppercase tracking-wide text-text-3">AI assist</h2>
              <AiAssist entityId={l.id} features={(["lead_summary", "outreach_draft", "next_best_action"] as const).map((k) => ({ key: k, label: AI_FEATURES[k].label }))} />
            </Card>
          )}

          <Card className="p-5">
            <h2 className="mb-3 text-xs font-medium uppercase tracking-wide text-text-3">Next follow-up</h2>
            {canEdit ? (
              <FollowUpForm leadId={l.id} at={l.next_follow_up_at} type={l.follow_up_type} priority={l.follow_up_priority} />
            ) : (
              <p className="text-sm">{formatDateTime(l.next_follow_up_at)}</p>
            )}
          </Card>

          <Card className="p-5">
            <h2 className="text-xs font-medium uppercase tracking-wide text-text-3">Lead score</h2>
            <p className="mt-2 text-3xl font-semibold tabular-nums">{l.score}<span className="text-base text-text-3">/100</span></p>
            {l.score_breakdown.length ? (
              <ul className="mt-3 space-y-1.5 text-sm">
                {l.score_breakdown.map((b) => (
                  <li key={b.signal} className="flex justify-between">
                    <span className="text-text-2">{b.label}</span>
                    <span className="tabular-nums text-text-3">{b.points > 0 ? "+" : ""}{b.points}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-2 text-sm text-text-3">No scoring signals are proven by this lead’s data yet.</p>
            )}
          </Card>

          {(utm.length > 0 || l.source_reference) && (
            <Card className="p-5">
              <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-text-3">Attribution</h2>
              <dl className="space-y-1 text-sm">
                {l.source_reference && <div className="flex justify-between gap-3"><dt className="text-text-3">Reference</dt><dd className="truncate">{l.source_reference}</dd></div>}
                {utm.map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-3"><dt className="text-text-3">utm_{k}</dt><dd className="truncate">{v}</dd></div>
                ))}
              </dl>
            </Card>
          )}

          {session.can("leads.delete") && <ArchiveButton leadId={l.id} archived={Boolean(l.archived_at)} />}
          <p className="text-center text-xs text-text-3">Updated {formatDate(l.updated_at)}</p>
        </div>
      </div>
    </>
  );
}
