import { notFound } from "next/navigation";
import { Card, PageHeader } from "@/components/ui/primitives";
import { LeadForm } from "@/components/leads/lead-form";
import { requirePermission } from "@/lib/auth/session";
import { getLead, getLookups } from "@/lib/leads/queries";
import { idSchema } from "@/lib/validation/leads";

export const metadata = { title: "Edit lead" };

export default async function EditLeadPage({ params }: PageProps<"/app/leads/[id]/edit">) {
  const session = await requirePermission("leads.edit");
  const { id } = await params;
  if (!idSchema.safeParse(id).success) notFound();
  const [result, lookups] = await Promise.all([getLead(id), getLookups()]);
  if (!result) notFound();
  const l = result.lead;
  const s = (v: unknown) => (v === null || v === undefined ? "" : String(v));
  return (
    <>
      <PageHeader title={`Edit ${l.company_name}`} />
      <Card className="p-5 sm:p-6">
        <LeadForm
          mode="edit"
          leadId={l.id}
          defaults={{
            company_name: l.company_name, website: s(l.website), industry_id: s(l.industry_id), business_size: s(l.business_size),
            country_code: s(l.country_code), city: s(l.city), contact_name: s(l.contact_name), email: s(l.email), phone: s(l.phone),
            service_id: s(l.service_id), budget_range: s(l.budget_range), estimated_value: s(l.estimated_value), currency: l.currency,
            source_reference: s(l.source_reference), message: s(l.message),
          }}
          lookups={lookups}
          canAssign={session.can("leads.assign")}
          currentUserId={session.userId}
        />
      </Card>
    </>
  );
}
