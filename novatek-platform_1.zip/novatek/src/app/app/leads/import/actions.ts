"use server";

import { z } from "zod";
import { authorize } from "@/lib/auth/session";
import { friendlyDbError } from "@/lib/actions";
import { check, type ActionResult } from "@/lib/errors";
import { refresh } from "@/lib/actions";
import { createClient } from "@/lib/supabase/server";
import { CURRENCIES } from "@/lib/validation/common";

const rowSchema = z.object({
  company_name: z.string().trim().min(1, "company_name is required").max(200),
  contact_name: z.string().trim().max(120).optional().default(""),
  email: z.union([z.literal(""), z.email("invalid email").max(254)]).optional().default(""),
  phone: z.string().trim().max(40).refine((v) => v === "" || /^[+()\-.\s\d]{5,40}$/.test(v), "invalid phone").optional().default(""),
  website: z.string().trim().max(300).optional().default(""),
  city: z.string().trim().max(120).optional().default(""),
  country: z.string().trim().max(80).optional().default(""),
  industry: z.string().trim().max(80).optional().default(""),
  service: z.string().trim().max(80).optional().default(""),
  estimated_value: z.string().trim().refine((v) => v === "" || (/^\d+(\.\d{1,2})?$/.test(v.replace(/,/g, "")) && Number(v.replace(/,/g, "")) <= 1e9), "invalid value").optional().default(""),
  currency: z.string().trim().toUpperCase().refine((v) => v === "" || (CURRENCIES as readonly string[]).includes(v), "unsupported currency").optional().default(""),
  notes: z.string().trim().max(5000).optional().default(""),
});

export type PreviewRow = { index: number; data: Record<string, string>; errors: string[]; duplicate: boolean };

async function resolve(rows: Record<string, string>[]) {
  const supabase = await createClient();
  const [countries, industries, services] = await Promise.all([
    supabase.from("countries").select("code, name"),
    supabase.from("industries").select("id, name").eq("active", true),
    supabase.from("services").select("id, key, name").eq("active", true),
  ]);
  const byCountry = new Map<string, string>();
  for (const c of countries.data ?? []) { byCountry.set(c.code.toLowerCase(), c.code); byCountry.set(c.name.toLowerCase(), c.code); }
  const byIndustry = new Map((industries.data ?? []).map((i) => [i.name.toLowerCase(), i.id as string]));
  const byService = new Map<string, string>();
  for (const s of services.data ?? []) { byService.set(s.key.toLowerCase(), s.id); byService.set(s.name.toLowerCase(), s.id); }

  const seen = new Map<string, number>();
  return rows.map((raw, index) => {
    const errors: string[] = [];
    const parsed = rowSchema.safeParse(raw);
    if (!parsed.success) errors.push(...parsed.error.issues.map((i) => i.message));
    const d = parsed.success ? parsed.data : null;
    const out: Record<string, string> = {};
    if (d) {
      const country = d.country ? byCountry.get(d.country.toLowerCase()) : "";
      if (d.country && !country) errors.push(`unknown country “${d.country}”`);
      const industry = d.industry ? byIndustry.get(d.industry.toLowerCase()) : "";
      if (d.industry && !industry) errors.push(`unknown industry “${d.industry}”`);
      const service = d.service ? byService.get(d.service.toLowerCase()) : "";
      if (d.service && !service) errors.push(`unknown service “${d.service}”`);
      Object.assign(out, {
        company_name: d.company_name, contact_name: d.contact_name, email: d.email, phone: d.phone, website: d.website, city: d.city,
        country_code: country ?? "", industry_id: industry ?? "", service_id: service ?? "",
        estimated_value: d.estimated_value.replace(/,/g, ""), currency: d.currency || "USD", notes: d.notes,
      });
      // Duplicates inside the file itself
      const k = (d.email || d.website || d.company_name).toLowerCase();
      if (seen.has(k)) errors.push(`same as row ${seen.get(k)! + 2} in this file`);
      else seen.set(k, index);
    }
    return { index, data: out, errors };
  });
}

const inputSchema = z.array(z.record(z.string(), z.string().max(6000))).min(1, "The file has no data rows").max(2000, "Import at most 2,000 rows at a time");

/** Validates every row on the server and checks each against existing leads. Nothing is written. */
export async function previewImport(rows: unknown): Promise<ActionResult<PreviewRow[]>> {
  try {
    await authorize("leads.import");
    const parsed = inputSchema.safeParse(rows);
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid file" };
    const resolved = await resolve(parsed.data);
    const supabase = await createClient();
    const dupRows = check(await supabase.rpc("preview_duplicates", { p_rows: resolved.map((r) => r.data) })) as { row: number }[];
    const dups = new Set(dupRows.map((d) => d.row));
    return { ok: true, data: resolved.map((r) => ({ ...r, duplicate: dups.has(r.index) })) };
  } catch (e) {
    return friendlyDbError(e, "previewImport");
  }
}

/** Imports atomically. Invalid rows are only skipped when the user explicitly chose to skip them. */
export async function runImport(rows: unknown, skipInvalid: boolean): Promise<ActionResult<{ inserted: number; possible_duplicates: number; skipped: number }>> {
  try {
    await authorize("leads.import");
    const parsed = inputSchema.safeParse(rows);
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid file" };
    const resolved = await resolve(parsed.data);
    const invalid = resolved.filter((r) => r.errors.length);
    if (invalid.length && !skipInvalid) return { ok: false, error: `${invalid.length} row(s) have errors. Fix them or choose to skip them.` };
    const valid = resolved.filter((r) => !r.errors.length).map((r) => r.data);
    if (!valid.length) return { ok: false, error: "No valid rows to import." };
    const supabase = await createClient();
    const res = check(await supabase.rpc("import_leads", { p_rows: valid })) as { inserted: number; possible_duplicates: number };
    refresh("/app/leads", "/app/pipeline", "/app");
    return { ok: true, data: { ...res, skipped: invalid.length } };
  } catch (e) {
    return friendlyDbError(e, "runImport");
  }
}
