import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { ImportWizard } from "@/components/leads/import-wizard";
import { requirePermission } from "@/lib/auth/session";
import { IMPORT_COLUMNS } from "@/lib/csv/import-columns";

export const metadata = { title: "Import leads" };

export default async function ImportLeadsPage() {
  await requirePermission("leads.import");
  return (
    <>
      <Link href="/app/leads" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Leads</Link>
      <PageHeader title="Import leads from CSV" description="Every row is validated on the server and checked against existing leads before anything is saved. The import is all-or-nothing." />
      <Card className="max-w-5xl p-5 sm:p-6">
        <ImportWizard columns={IMPORT_COLUMNS} />
        <div className="mt-6 rounded-lg bg-surface-2/60 p-4 text-xs text-text-3">
          <p className="font-medium text-text-2">Format</p>
          <p className="mt-1">First row = headers. Only <code>company_name</code> is required. <code>country</code> accepts a code (PK) or name; <code>industry</code> and <code>service</code> must match names in Settings. Imported leads get source “Import”, start in the first pipeline status, are scored automatically, and are attributed to you. Only import business contacts you are permitted to use.</p>
        </div>
      </Card>
    </>
  );
}
