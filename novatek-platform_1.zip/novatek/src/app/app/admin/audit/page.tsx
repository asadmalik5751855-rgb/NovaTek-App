import Link from "next/link";
import { ChevronLeft, ChevronRight, ShieldCheck } from "lucide-react";
import { Card, EmptyState, Input, PageHeader, buttonClass } from "@/components/ui/primitives";
import { requirePermission } from "@/lib/auth/session";
import { getLookups } from "@/lib/leads/queries";
import { createClient } from "@/lib/supabase/server";
import { formatDateTime } from "@/lib/utils";

export const metadata = { title: "Audit Log" };
const PAGE = 50;

type Entry = { id: number; actor_id: string | null; action: string; entity: string; entity_id: string | null; metadata: Record<string, unknown>; created_at: string };

export default async function AuditPage({ searchParams }: PageProps<"/app/admin/audit">) {
  await requirePermission("audit.view");
  const sp = await searchParams;
  const action = typeof sp.action === "string" ? sp.action.replace(/[^a-z_.]/g, "").slice(0, 60) : "";
  const page = Math.max(1, Number(sp.page) || 1);
  const supabase = await createClient();
  let q = supabase.from("audit_logs").select("id, actor_id, action, entity, entity_id, metadata, created_at", { count: "exact" });
  if (action) q = q.ilike("action", `${action}%`);
  const [{ data, count, error }, lookups] = await Promise.all([
    q.order("created_at", { ascending: false }).range((page - 1) * PAGE, page * PAGE - 1),
    getLookups(),
  ]);
  if (error) throw error;
  const entries = (data ?? []) as Entry[];
  const people = new Map(lookups.people.map((p) => [p.id, p.full_name || "Unnamed user"]));
  const pages = Math.max(1, Math.ceil((count ?? 0) / PAGE));
  const href = (p: number) => `/app/admin/audit?${new URLSearchParams({ ...(action ? { action } : {}), page: String(p) })}`;

  return (
    <>
      <PageHeader title="Audit Log" description="Append-only record of security-relevant and business-critical actions." />
      <form className="mb-4 flex max-w-md gap-2" role="search">
        <Input name="action" defaultValue={action} placeholder="Filter by action prefix, e.g. role. or lead.status" aria-label="Action filter" />
        <button className={buttonClass("secondary")} type="submit">Filter</button>
      </form>
      <Card className="overflow-x-auto">
        {entries.length === 0 ? (
          <EmptyState icon={<ShieldCheck className="size-5" />} title="No audit entries" description="Entries appear as people sign in and change data." />
        ) : (
          <table className="w-full min-w-[720px] text-sm">
            <thead className="border-b border-border bg-surface-2/50 text-left text-xs font-medium uppercase tracking-wide text-text-3">
              <tr><th className="px-4 py-2.5">When</th><th className="px-4 py-2.5">Actor</th><th className="px-4 py-2.5">Action</th><th className="px-4 py-2.5">Entity</th><th className="px-4 py-2.5">Details</th></tr>
            </thead>
            <tbody className="divide-y divide-border">
              {entries.map((e) => (
                <tr key={e.id} className="align-top">
                  <td className="whitespace-nowrap px-4 py-2.5 text-text-3">{formatDateTime(e.created_at)}</td>
                  <td className="px-4 py-2.5">{e.actor_id ? people.get(e.actor_id) ?? e.actor_id.slice(0, 8) : <span className="text-text-3">System / public</span>}</td>
                  <td className="px-4 py-2.5 font-mono text-xs">{e.action}</td>
                  <td className="px-4 py-2.5 text-text-2">
                    {e.entity === "lead" && e.entity_id ? <Link className="text-accent hover:underline" href={`/app/leads/${e.entity_id}`}>lead</Link>
                      : e.entity === "user" && e.entity_id ? <Link className="text-accent hover:underline" href={`/app/admin/users/${e.entity_id}`}>{people.get(e.entity_id) ?? "user"}</Link>
                      : e.entity}
                  </td>
                  <td className="max-w-md px-4 py-2.5">
                    {Object.keys(e.metadata ?? {}).length > 0 && (
                      <details>
                        <summary className="cursor-pointer text-xs text-text-3">View</summary>
                        <pre className="mt-1 max-h-48 overflow-auto rounded bg-surface-2 p-2 text-[11px]">{JSON.stringify(e.metadata, null, 2)}</pre>
                      </details>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
      {pages > 1 && (
        <div className="mt-3 flex items-center justify-between text-sm text-text-3">
          <span>Page {page} of {pages}</span>
          <div className="flex gap-2">
            {page > 1 && <Link className={buttonClass("secondary", "sm")} href={href(page - 1)}><ChevronLeft className="size-4" /> Prev</Link>}
            {page < pages && <Link className={buttonClass("secondary", "sm")} href={href(page + 1)}>Next <ChevronRight className="size-4" /></Link>}
          </div>
        </div>
      )}
    </>
  );
}
