import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Badge, Card, CardHeader } from "@/components/ui/primitives";
import { EmploymentForm, RolesForm, StatusForm } from "@/components/admin/user-forms";
import { requirePermission } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";
import { formatDate, formatDateTime } from "@/lib/utils";
import { idSchema } from "@/lib/validation/leads";

export const metadata = { title: "User" };

export default async function UserPage({ params }: PageProps<"/app/admin/users/[id]">) {
  const session = await requirePermission({ anyOf: ["employees.view", "users.manage_roles"] });
  const { id } = await params;
  if (!idSchema.safeParse(id).success) notFound();
  const supabase = await createClient();
  const [profile, roles, userRoles, departments, isSuper, audit] = await Promise.all([
    supabase.from("profiles").select("id, email, full_name, phone, designation, department_id, joining_date, status, created_at").eq("id", id).maybeSingle(),
    supabase.from("roles").select("key, name, description, is_superuser").order("name"),
    supabase.from("user_roles").select("assigned_at, roles(key, name)").eq("user_id", id),
    supabase.from("departments").select("id, name").order("name"),
    supabase.rpc("is_superuser"),
    session.can("audit.view")
      ? supabase.from("audit_logs").select("id, action, entity, created_at").or(`actor_id.eq.${id},entity_id.eq.${id}`).order("created_at", { ascending: false }).limit(20)
      : Promise.resolve({ data: null }),
  ]);
  const p = profile.data;
  if (!p) notFound();
  const current = ((userRoles.data ?? []) as unknown as { roles: { key: string; name: string } }[]).map((r) => r.roles);
  const isSelf = id === session.userId;

  return (
    <>
      <Link href="/app/admin/users" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text">
        <ArrowLeft className="size-4" /> Users
      </Link>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight">{p.full_name || p.email}</h1>
        <p className="mt-1 flex flex-wrap items-center gap-2 text-sm text-text-3">
          {p.email}
          {p.status !== "active" && <Badge color="rose">Disabled</Badge>}
          {current.map((r) => <Badge key={r.key}>{r.name}</Badge>)}
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          {session.can("employees.manage") && (
            <Card>
              <CardHeader title="Employment" />
              <div className="p-5">
                <EmploymentForm
                  userId={p.id}
                  departments={departments.data ?? []}
                  values={{ full_name: p.full_name, department_id: p.department_id ?? "", designation: p.designation ?? "", joining_date: p.joining_date ?? "", phone: p.phone ?? "" }}
                />
              </div>
            </Card>
          )}
          {session.can("users.manage_roles") && (
            <Card>
              <CardHeader title="Roles" description="Permissions come from roles. Changes are audited." />
              <div className="p-5">
                <RolesForm userId={p.id} roles={roles.data ?? []} current={current.map((r) => r.key)} canGrantSuper={Boolean(isSuper.data)} isSelf={isSelf} />
              </div>
            </Card>
          )}
        </div>
        <div className="space-y-6">
          {session.can("employees.manage") && (
            <Card className="p-5">
              <h2 className="mb-3 text-xs font-medium uppercase tracking-wide text-text-3">Account status</h2>
              <StatusForm userId={p.id} status={p.status} isSelf={isSelf} />
            </Card>
          )}
          <Card className="p-5 text-sm">
            <dl className="space-y-2">
              <div className="flex justify-between"><dt className="text-text-3">Joined</dt><dd>{formatDate(p.joining_date)}</dd></div>
              <div className="flex justify-between"><dt className="text-text-3">Account created</dt><dd>{formatDate(p.created_at)}</dd></div>
            </dl>
          </Card>
          {audit.data && (
            <Card>
              <CardHeader title="Recent activity" />
              <ul className="divide-y divide-border text-sm">
                {audit.data.length === 0 && <li className="px-5 py-3 text-text-3">No recorded activity.</li>}
                {audit.data.map((a: { id: number; action: string; created_at: string }) => (
                  <li key={a.id} className="flex justify-between gap-3 px-5 py-2.5">
                    <span className="font-mono text-xs">{a.action}</span>
                    <span className="text-xs text-text-3">{formatDateTime(a.created_at)}</span>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}
