import { Alert, Card, PageHeader } from "@/components/ui/primitives";
import { CreateUserForm } from "@/components/admin/user-forms";
import { requirePermission } from "@/lib/auth/session";
import { isServiceRoleConfigured } from "@/lib/env.server";
import { createClient } from "@/lib/supabase/server";

export const metadata = { title: "Add user" };

export default async function NewUserPage() {
  await requirePermission("users.manage_roles");
  const supabase = await createClient();
  const [{ data: roles }, { data: departments }, { data: isSuper }] = await Promise.all([
    supabase.from("roles").select("key, name, description, is_superuser").order("name"),
    supabase.from("departments").select("id, name").order("name"),
    supabase.rpc("is_superuser"),
  ]);
  return (
    <>
      <PageHeader title="Add user" description="Creates a sign-in account. There is no public sign-up." />
      {!isServiceRoleConfigured() && (
        <div className="mb-4"><Alert tone="warning">SUPABASE_SERVICE_ROLE_KEY is not set on the server, so accounts can’t be created yet.</Alert></div>
      )}
      <Card className="p-5 sm:p-6">
        <CreateUserForm roles={roles ?? []} departments={departments ?? []} canGrantSuper={Boolean(isSuper)} />
      </Card>
    </>
  );
}
