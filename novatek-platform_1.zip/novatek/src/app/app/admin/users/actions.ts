"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { auditEvent } from "@/lib/audit";
import { authorize } from "@/lib/auth/session";
import { isServiceRoleConfigured } from "@/lib/env.server";
import { check, toActionError, type ActionResult } from "@/lib/errors";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";

const createUserSchema = z.object({
  email: z.email("Enter a valid email").max(254),
  full_name: z.string().trim().min(1, "Name is required").max(120),
  password: z
    .string()
    .min(12, "Use at least 12 characters")
    .max(128)
    .regex(/[a-z]/, "Include a lowercase letter")
    .regex(/[A-Z]/, "Include an uppercase letter")
    .regex(/\d/, "Include a number"),
  role_keys: z.array(z.string().regex(/^[a-z][a-z0-9_]{1,40}$/)).max(20).default([]),
  department_id: z.union([z.uuid(), z.literal("")]).optional(),
  designation: z.string().trim().max(120).optional(),
});

export async function createUserAccount(input: unknown): Promise<ActionResult<{ id: string; warning?: string }>> {
  try {
    const session = await authorize("users.manage_roles");
    if (!isServiceRoleConfigured()) return { ok: false, error: "User provisioning requires SUPABASE_SERVICE_ROLE_KEY on the server." };
    const parsed = createUserSchema.safeParse(input);
    if (!parsed.success) return { ok: false, error: "Please fix the highlighted fields.", fieldErrors: z.flattenError(parsed.error).fieldErrors };
    const d = parsed.data;

    const admin = createAdminClient();
    const { data, error } = await admin.auth.admin.createUser({
      email: d.email,
      password: d.password,
      email_confirm: true,
      user_metadata: { full_name: d.full_name },
    });
    if (error || !data.user) {
      return { ok: false, error: error?.message?.includes("already") ? "A user with this email already exists." : "Could not create the account." };
    }
    const userId = data.user.id;
    await auditEvent(session.userId, "user.created", "user", userId, { email: d.email });

    // Everything below runs as the admin's own session: RLS, escalation guards and audit apply.
    const supabase = await createClient();
    const problems: string[] = [];
    if (d.department_id || d.designation) {
      const r = await supabase.from("profiles").update({ department_id: d.department_id || null, designation: d.designation || null }).eq("id", userId);
      if (r.error) problems.push("employment details");
    }
    if (d.role_keys.length) {
      const { data: roles } = await supabase.from("roles").select("id, key").in("key", d.role_keys);
      const r = await supabase.from("user_roles").insert((roles ?? []).map((role) => ({ user_id: userId, role_id: role.id })));
      if (r.error) problems.push("roles");
    }
    revalidatePath("/app/admin/users");
    return {
      ok: true,
      data: {
        id: userId,
        warning: problems.length ? `Account created, but ${problems.join(" and ")} could not be saved. Set them on the user's page.` : undefined,
      },
    };
  } catch (e) {
    return toActionError(e, "createUserAccount");
  }
}

export async function setUserRoles(userId: string, roleKeys: string[]): Promise<ActionResult> {
  try {
    await authorize("users.manage_roles");
    if (!z.uuid().safeParse(userId).success) return { ok: false, error: "User not found." };
    const keys = z.array(z.string().regex(/^[a-z][a-z0-9_]{1,40}$/)).max(20).parse(roleKeys);
    const supabase = await createClient();
    const [{ data: allRoles }, { data: current }] = await Promise.all([
      supabase.from("roles").select("id, key"),
      supabase.from("user_roles").select("role_id").eq("user_id", userId),
    ]);
    const wanted = new Set((allRoles ?? []).filter((r) => keys.includes(r.key)).map((r) => r.id));
    const have = new Set((current ?? []).map((r) => r.role_id));
    const toAdd = [...wanted].filter((id) => !have.has(id));
    const toRemove = [...have].filter((id) => !wanted.has(id));
    if (toAdd.length) check(await supabase.from("user_roles").insert(toAdd.map((role_id) => ({ user_id: userId, role_id }))));
    if (toRemove.length) check(await supabase.from("user_roles").delete().eq("user_id", userId).in("role_id", toRemove));
    revalidatePath("/app/admin/users");
    revalidatePath(`/app/admin/users/${userId}`);
    return { ok: true, data: undefined };
  } catch (e) {
    return toActionError(e, "setUserRoles");
  }
}

export async function setUserStatus(userId: string, status: "active" | "disabled"): Promise<ActionResult> {
  try {
    const session = await authorize("employees.manage");
    if (!z.uuid().safeParse(userId).success || !["active", "disabled"].includes(status)) return { ok: false, error: "Invalid request." };
    if (userId === session.userId) return { ok: false, error: "You cannot change your own account status." };
    const supabase = await createClient();
    const rows = check(await supabase.from("profiles").update({ status }).eq("id", userId).select("id"));
    if (!rows?.length) return { ok: false, error: "User not found." };

    // Also block/unblock sign-in at the Auth layer so existing sessions can't refresh.
    if (isServiceRoleConfigured()) {
      const { error } = await createAdminClient().auth.admin.updateUserById(userId, {
        ban_duration: status === "disabled" ? "876000h" : "none",
      });
      if (error) console.error("[setUserStatus] auth ban update failed", error);
    }
    revalidatePath("/app/admin/users");
    revalidatePath(`/app/admin/users/${userId}`);
    // Even without the Auth-level ban, a disabled profile has zero permissions at the database level.
    return { ok: true, data: undefined };
  } catch (e) {
    return toActionError(e, "setUserStatus");
  }
}

const employmentSchema = z.object({
  full_name: z.string().trim().min(1).max(120),
  department_id: z.union([z.uuid(), z.literal("")]).transform((v) => v || null),
  designation: z.string().trim().max(120).transform((v) => v || null),
  joining_date: z.union([z.iso.date(), z.literal("")]).transform((v) => v || null),
  phone: z.string().trim().max(40).transform((v) => v || null),
});

export async function updateEmployment(userId: string, input: unknown): Promise<ActionResult> {
  try {
    await authorize("employees.manage");
    if (!z.uuid().safeParse(userId).success) return { ok: false, error: "User not found." };
    const parsed = employmentSchema.safeParse(input);
    if (!parsed.success) return { ok: false, error: "Please check the values.", fieldErrors: z.flattenError(parsed.error).fieldErrors };
    const supabase = await createClient();
    const rows = check(await supabase.from("profiles").update(parsed.data).eq("id", userId).select("id"));
    if (!rows?.length) return { ok: false, error: "User not found." };
    revalidatePath(`/app/admin/users/${userId}`);
    revalidatePath("/app/admin/users");
    return { ok: true, data: undefined };
  } catch (e) {
    return toActionError(e, "updateEmployment");
  }
}
