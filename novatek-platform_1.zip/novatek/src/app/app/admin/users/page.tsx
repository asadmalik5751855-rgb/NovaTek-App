import Link from "next/link";
import { UserPlus, Users } from "lucide-react";
import { Badge, ButtonLink, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { requirePermission } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";
import { formatDate, initials } from "@/lib/utils";

export const metadata = { title: "Users & Roles" };

type Row = {
  id: string;
  email: string;
  full_name: string;
  designation: string | null;
  status: string;
  joining_date: string | null;
  departments: { name: string } | null;
  user_roles: { roles: { key: string; name: string } | null }[];
};

export default async function UsersPage() {
  const session = await requirePermission({ anyOf: ["employees.view", "users.manage_roles"] });
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("profiles")
    .select("id, email, full_name, designation, status, joining_date, departments(name), user_roles(roles(key, name))")
    .order("full_name");
  if (error) throw error;
  const users = (data ?? []) as unknown as Row[];

  return (
    <>
      <PageHeader
        title="Users & Roles"
        description={`${users.length} account${users.length === 1 ? "" : "s"} · ${users.filter((u) => u.status === "active").length} active`}
        actions={
          session.can("users.manage_roles") && (
            <ButtonLink href="/app/admin/users/new" variant="brand"><UserPlus className="size-4" /> Add user</ButtonLink>
          )
        }
      />
      <Card className="overflow-hidden">
        {users.length === 0 ? (
          <EmptyState icon={<Users className="size-5" />} title="No users yet" description="Add your team so you can assign leads and roles." />
        ) : (
          <ul className="divide-y divide-border">
            {users.map((u) => (
              <li key={u.id}>
                <Link href={`/app/admin/users/${u.id}`} className="flex items-center gap-4 px-5 py-3.5 hover:bg-surface-2/40">
                  <span className="grid size-9 shrink-0 place-items-center rounded-full bg-surface-2 text-xs font-semibold text-text-2">
                    {initials(u.full_name || u.email)}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="truncate text-sm font-medium">{u.full_name || u.email}</span>
                      {u.status !== "active" && <Badge color="rose">Disabled</Badge>}
                    </span>
                    <span className="block truncate text-xs text-text-3">
                      {[u.designation, u.departments?.name, u.email].filter(Boolean).join(" · ")}
                    </span>
                  </span>
                  <span className="hidden flex-wrap justify-end gap-1 sm:flex">
                    {u.user_roles.map((r) => r.roles && <Badge key={r.roles.key} color={r.roles.key === "super_admin" ? "violet" : "slate"}>{r.roles.name}</Badge>)}
                    {u.user_roles.length === 0 && <span className="text-xs text-text-3">No role</span>}
                  </span>
                  <span className="hidden w-24 text-right text-xs text-text-3 md:block">{u.joining_date ? formatDate(u.joining_date) : ""}</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </>
  );
}
