import { Fragment } from "react";
import { Card, CardHeader, PageHeader } from "@/components/ui/primitives";
import { PermissionToggle } from "@/components/settings/permission-toggle";
import { NewRoleForm } from "@/components/settings/forms";
import { requirePermission } from "@/lib/auth/session";
import { createClient } from "@/lib/supabase/server";

export const metadata = { title: "Roles & permissions" };

export default async function RolesPage() {
  const session = await requirePermission({ anyOf: ["users.manage_roles", "settings.manage"] });
  const supabase = await createClient();
  const [{ data: roles }, { data: perms }, { data: grants }, { data: isSuper }] = await Promise.all([
    supabase.from("roles").select("id, key, name, is_superuser, is_system").order("is_superuser", { ascending: false }).order("name"),
    supabase.from("permissions").select("key, category, description").order("category").order("key"),
    supabase.from("role_permissions").select("role_id, permission_key"),
    supabase.rpc("is_superuser"),
  ]);
  const has = new Set((grants ?? []).map((g) => `${g.role_id}:${g.permission_key}`));
  const canEdit = Boolean(isSuper) && session.can("users.manage_roles");
  const categories = [...new Set((perms ?? []).map((p) => p.category))];
  return (
    <>
      <PageHeader
        title="Roles & permissions"
        description="Access is decided by granular permissions, enforced by the database. Roles are bundles of permissions; a person can have several."
      />
      {canEdit && (
        <Card className="mb-6">
          <CardHeader title="New role" description="E.g. Support Agent, Finance, Intern — then tick its permissions" />
          <div className="p-5"><NewRoleForm /></div>
        </Card>
      )}
      <Card className="overflow-hidden">
        <CardHeader title="Permission matrix" description={canEdit ? "Changes apply immediately and are audited. Super Admin always has every permission." : "Only a Super Admin can change permissions."} />
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-surface-2/80 backdrop-blur">
              <tr>
                <th className="sticky left-0 z-10 min-w-56 bg-surface-2 px-3 py-2 text-left font-medium text-text-3">Permission</th>
                {(roles ?? []).map((r) => (
                  <th key={r.id} className="min-w-20 px-2 py-2 text-center font-medium text-text-2"><span className="block whitespace-nowrap">{r.name}</span></th>
                ))}
              </tr>
            </thead>
            <tbody>
              {categories.map((c) => (
                <Fragment key={c}>
                  <tr><td colSpan={(roles ?? []).length + 1} className="bg-surface-2/40 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-text-3">{c}</td></tr>
                  {(perms ?? []).filter((p) => p.category === c).map((p) => (
                    <tr key={p.key} className="border-t border-border">
                      <td className="sticky left-0 bg-surface px-3 py-1.5">
                        <code className="text-[11px]">{p.key}</code>
                        <span className="block text-text-3">{p.description}</span>
                      </td>
                      {(roles ?? []).map((r) => (
                        <td key={r.id} className="px-2 py-1.5 text-center">
                          {r.is_superuser ? <span className="text-success" aria-label="Always">●</span> : (
                            <PermissionToggle roleId={r.id} permission={p.key} granted={has.has(`${r.id}:${p.key}`)} disabled={!canEdit} label={`${r.name}: ${p.key}`} />
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}
