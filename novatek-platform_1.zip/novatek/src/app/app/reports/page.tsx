import Link from "next/link";
import { FileBarChart } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { requirePermission } from "@/lib/auth/session";
import { REPORTS } from "@/lib/data/reports";

export const metadata = { title: "Reports" };

export default async function ReportsPage() {
  const session = await requirePermission("reports.view");
  const list = Object.entries(REPORTS).filter(([, r]) => session.can(r.check));
  return (
    <>
      <PageHeader title="Reports" description="Generated live from the database for any date range, and exportable as CSV. Only data you’re allowed to see is included." />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {list.map(([k, r]) => (
          <Link key={k} href={`/app/reports/${k}`}>
            <Card className="h-full space-y-2 p-5 transition-colors hover:border-border-strong">
              <FileBarChart className="size-5 text-accent" />
              <h2 className="font-semibold">{r.title}</h2>
              <p className="text-xs text-text-3">For {r.audience}</p>
              <p className="text-sm text-text-2">{r.description}</p>
            </Card>
          </Link>
        ))}
      </div>
    </>
  );
}
