import { NextResponse, type NextRequest } from "next/server";
import { auditEvent } from "@/lib/audit";
import { getSession } from "@/lib/auth/session";
import { toCsv } from "@/lib/csv";
import { resolveRange } from "@/lib/data/analytics";
import { REPORTS, buildReport } from "@/lib/data/reports";

export async function GET(req: NextRequest, ctx: RouteContext<"/app/reports/[kind]/csv">) {
  const { kind } = await ctx.params;
  const spec = REPORTS[kind];
  const session = await getSession();
  if (!session) return new NextResponse("Unauthorized", { status: 401 });
  if (!spec) return new NextResponse("Not found", { status: 404 });
  if (!session.can("reports.view") || !session.can(spec.check)) return new NextResponse("Forbidden", { status: 403 });
  const r = resolveRange(Object.fromEntries(req.nextUrl.searchParams));
  const sections = await buildReport(kind, r.from, r.to);
  const width = Math.max(...sections.map((s) => s.headers.length), 2);
  const rows: unknown[][] = [[spec.title, `${r.fromDate} to ${r.toDate}`], []];
  for (const s of sections) rows.push([s.title], s.headers, ...s.rows, []);
  const csv = toCsv(Array.from({ length: width }, (_, i) => (i === 0 ? "NovaTek report" : "")), rows);
  await auditEvent(session.userId, "report.exported", "report", kind, { from: r.fromDate, to: r.toDate });
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="novatek-${kind}-${r.fromDate}-${r.toDate}.csv"`,
      "Cache-Control": "private, no-store",
    },
  });
}
