import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft, Download } from "lucide-react";
import { Card, CardHeader, PageHeader, buttonClass } from "@/components/ui/primitives";
import { RangeFilter } from "@/components/charts/range-filter";
import { requirePermission } from "@/lib/auth/session";
import { resolveRange } from "@/lib/data/analytics";
import { REPORTS, buildReport } from "@/lib/data/reports";
import { formatDate } from "@/lib/utils";

export default async function ReportPage({ params, searchParams }: PageProps<"/app/reports/[kind]">) {
  const { kind } = await params;
  const spec = REPORTS[kind];
  if (!spec) notFound();
  const session = await requirePermission("reports.view");
  if (!session.can(spec.check)) redirect("/app/denied");
  const sp = await searchParams;
  const r = resolveRange(sp);
  const sections = await buildReport(kind, r.from, r.to);
  const qs = new URLSearchParams({ range: r.key, from: r.fromDate, to: r.toDate });
  return (
    <>
      <Link href="/app/reports" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Reports</Link>
      <PageHeader
        title={spec.title}
        description={`${formatDate(r.fromDate)} – ${formatDate(r.toDate)} · for ${spec.audience}`}
        actions={<>
          <RangeFilter active={r.key} from={r.fromDate} to={r.toDate} />
          <a href={`/app/reports/${kind}/csv?${qs}`} className={buttonClass("secondary")} download><Download className="size-4" /> CSV</a>
        </>}
      />
      <div className="space-y-6">
        {sections.map((s) => (
          <Card key={s.title} className="overflow-hidden">
            <CardHeader title={s.title} />
            {s.rows.length === 0 ? <p className="px-5 py-6 text-sm text-text-3">No data in this period.</p> : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b border-border text-left text-xs uppercase tracking-wide text-text-3">
                    <tr>{s.headers.map((h, i) => <th key={h} className={`px-4 py-2 ${i > 0 ? "text-right" : ""}`}>{h}</th>)}</tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {s.rows.map((row, i) => (
                      <tr key={i}>{row.map((c, j) => <td key={j} className={`px-4 py-2 ${j > 0 ? "text-right tabular-nums" : ""}`}>{c === null || c === "" ? "—" : typeof c === "number" ? c.toLocaleString("en-US") : c}</td>)}</tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        ))}
      </div>
    </>
  );
}
