import Link from "next/link";
import { UsersRound } from "lucide-react";
import { Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { requirePermission } from "@/lib/auth/session";
import { canViewPeople } from "@/lib/auth/permissions";
import { getDepartments, getPeople } from "@/lib/data/lookups";
import { initials } from "@/lib/utils";

export const metadata = { title: "People" };

export default async function PeoplePage() {
  await requirePermission(canViewPeople);
  const [people, departments] = await Promise.all([getPeople(), getDepartments()]);
  const dept = new Map(departments.map((d) => [d.id, d.name]));
  const groups = new Map<string, typeof people>();
  for (const p of people) {
    const k = (p.department_id && dept.get(p.department_id)) || "No department";
    groups.set(k, [...(groups.get(k) ?? []), p]);
  }
  return (
    <>
      <PageHeader title="People" description={`${people.length} active team member${people.length === 1 ? "" : "s"}`} />
      {people.length === 0 ? (
        <Card><EmptyState icon={<UsersRound className="size-5" />} title="No team members yet" description="Administrators add employees in Users." /></Card>
      ) : (
        <div className="space-y-6">
          {[...groups.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([g, list]) => (
            <section key={g}>
              <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-text-3">{g} · {list.length}</h2>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {list.map((p) => (
                  <Link key={p.id} href={`/app/people/${p.id}`}>
                    <Card className="flex items-center gap-3 p-4 transition-colors hover:border-border-strong">
                      <span className="grid size-10 shrink-0 place-items-center rounded-full bg-surface-2 text-sm font-semibold text-text-2">{initials(p.full_name)}</span>
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium">{p.full_name || "Unnamed user"}</span>
                        <span className="block truncate text-xs text-text-3">{p.designation ?? "—"}</span>
                      </span>
                    </Card>
                  </Link>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}
    </>
  );
}
