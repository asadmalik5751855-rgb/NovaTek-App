import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft, Settings } from "lucide-react";
import { ButtonLink, Card, CardHeader } from "@/components/ui/primitives";
import { MoneyList, StatCard } from "@/components/ui/status";
import { TargetRow } from "@/components/people/target-progress";
import { requireUser } from "@/lib/auth/session";
import { canViewPeople } from "@/lib/auth/permissions";
import { getDepartments } from "@/lib/data/lookups";
import { employeePerformance, targetsWithProgress } from "@/lib/data/performance";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";
import { initials, timeAgo } from "@/lib/utils";

export default async function PersonPage({ params }: PageProps<"/app/people/[id]">) {
  const session = await requireUser();
  const { id } = await params;
  if (!validId(id)) notFound();
  const self = id === session.userId;
  if (!self && !session.can(canViewPeople)) redirect("/app/denied");
  const supabase = await createClient();
  const { data: person } = await supabase.from("directory").select("id, full_name, designation, department_id").eq("id", id).maybeSingle();
  if (!person) notFound();
  const canSeeWork = self || session.can({ anyOf: ["reports.view", "employees.view", "targets.manage"] });
  const to = new Date();
  const from = new Date(to.getTime() - 30 * 864e5);
  const [departments, perf, targets, activity] = await Promise.all([
    getDepartments(),
    canSeeWork ? employeePerformance(from, to) : Promise.resolve([]),
    canSeeWork ? targetsWithProgress(id) : Promise.resolve([]),
    canSeeWork
      ? supabase.from("lead_activities").select("id, type, body, created_at, leads(id, company_name)").eq("actor_id", id).order("created_at", { ascending: false }).limit(15)
      : Promise.resolve({ data: [] }),
  ]);
  const p = perf.find((r) => r.user_id === id);
  const dept = departments.find((d) => d.id === person.department_id)?.name;
  const acts = (activity.data ?? []) as unknown as { id: string; type: string; body: string | null; created_at: string; leads: { id: string; company_name: string } | null }[];

  return (
    <>
      {session.can(canViewPeople) && <Link href="/app/people" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> People</Link>}
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <span className="grid size-14 place-items-center rounded-full bg-surface-2 text-lg font-semibold text-text-2">{initials(person.full_name)}</span>
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">{person.full_name || "Unnamed user"}</h1>
            <p className="text-sm text-text-3">{[person.designation, dept].filter(Boolean).join(" · ") || "—"}{self && " · You"}</p>
          </div>
        </div>
        {session.can({ anyOf: ["employees.view", "users.manage_roles"] }) && (
          <ButtonLink href={`/app/admin/users/${id}`} variant="secondary"><Settings className="size-4" /> Account & roles</ButtonLink>
        )}
      </div>

      {canSeeWork && p && (
        <>
          <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-text-3">Last 30 days</h2>
          <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-8">
            <StatCard label="Leads owned" value={p.leads_assigned} />
            <StatCard label="Qualified" value={p.leads_qualified} />
            <StatCard label="Contacts" value={p.contacts_logged} hint="Calls, emails, messages, meetings logged" />
            <StatCard label="Meetings" value={p.meetings_booked} />
            <StatCard label="Proposals" value={p.proposals_sent} />
            <StatCard label="Deals won" value={p.deals_won} />
            <StatCard label="Revenue" value={<MoneyList items={p.revenue} empty="0" className="text-base" />} />
            <StatCard label="Tasks done" value={p.tasks_completed} />
          </div>
          {p.overdue_followups > 0 && <p className="-mt-3 mb-6 text-sm text-danger">{p.overdue_followups} overdue follow-up{p.overdue_followups === 1 ? "" : "s"} right now</p>}
        </>
      )}

      {canSeeWork ? (
        <div className="grid gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader title="Targets" action={session.can("targets.manage") ? <Link href={`/app/targets?user=${id}`} className="text-xs text-accent hover:underline">Set targets</Link> : undefined} />
            {targets.length === 0 ? <p className="px-5 py-4 text-sm text-text-3">No targets set.</p> : (
              <div className="space-y-5 p-5">{targets.slice(0, 8).map((t) => <TargetRow key={t.id} t={t} />)}</div>
            )}
          </Card>
          <Card>
            <CardHeader title="Recent CRM activity" description="Only records you can access are shown" />
            {acts.length === 0 ? <p className="px-5 py-4 text-sm text-text-3">No recent activity.</p> : (
              <ul className="divide-y divide-border">
                {acts.map((a) => (
                  <li key={a.id} className="px-5 py-2.5 text-sm">
                    <span className="text-text-2">{a.type.replace(/_/g, " ")}</span>
                    {a.leads && <> on <Link href={`/app/leads/${a.leads.id}`} className="text-accent hover:underline">{a.leads.company_name}</Link></>}
                    <span className="ml-2 text-xs text-text-3">{timeAgo(a.created_at)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      ) : (
        <Card className="p-5 text-sm text-text-3">Work details are visible to the person, their managers and reporting roles.</Card>
      )}
    </>
  );
}
