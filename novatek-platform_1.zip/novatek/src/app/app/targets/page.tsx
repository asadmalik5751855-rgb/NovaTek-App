import { TrendingUp, Trash2 } from "lucide-react";
import { Card, CardHeader, EmptyState, PageHeader } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { TargetForm } from "@/components/people/target-form";
import { TargetRow } from "@/components/people/target-progress";
import { requireUser } from "@/lib/auth/session";
import { getPeople, getPeopleMap, opts } from "@/lib/data/lookups";
import { targetsWithProgress } from "@/lib/data/performance";
import { validId } from "@/lib/actions";
import { deleteTarget } from "./actions";

export const metadata = { title: "Targets" };

export default async function TargetsPage({ searchParams }: PageProps<"/app/targets">) {
  const session = await requireUser();
  const sp = await searchParams;
  const manage = session.can("targets.manage");
  const seeAll = manage || session.can("reports.view");
  const forUser = typeof sp.user === "string" && validId(sp.user) ? sp.user : undefined;
  const [targets, people, peopleMap] = await Promise.all([targetsWithProgress(seeAll ? forUser : session.userId), getPeople(), getPeopleMap()]);
  const now = new Date().toISOString().slice(0, 10);
  const current = targets.filter((t) => t.period_end >= now);
  const past = targets.filter((t) => t.period_end < now);
  const today = new Date();
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().slice(0, 10);
  const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().slice(0, 10);

  return (
    <>
      <PageHeader title="Targets" description="Progress is always calculated from real records — leads, meetings, proposals, won deals and completed tasks." />
      <div className="grid gap-6 lg:grid-cols-5">
        <div className="space-y-6 lg:col-span-3">
          <Card>
            <CardHeader title="Current & upcoming" description={seeAll ? (forUser ? peopleMap.get(forUser) : "Everyone") : "Your targets"} />
            {current.length === 0 ? (
              <EmptyState icon={<TrendingUp className="size-5" />} title="No active targets" description={manage ? "Set a monthly target for someone on your team." : "Your manager hasn’t set targets yet."} />
            ) : (
              <ul className="divide-y divide-border">
                {current.map((t) => (
                  <li key={t.id} className="flex items-start gap-3 px-5 py-4">
                    <div className="flex-1"><TargetRow t={t} person={seeAll ? peopleMap.get(t.user_id) : undefined} /></div>
                    {manage && <ActionButton action={deleteTarget.bind(null, t.id)} size="sm" variant="ghost" confirm="Delete this target?"><Trash2 className="size-3.5" /></ActionButton>}
                  </li>
                ))}
              </ul>
            )}
          </Card>
          {past.length > 0 && (
            <Card>
              <CardHeader title="Past periods" />
              <ul className="divide-y divide-border">
                {past.slice(0, 30).map((t) => <li key={t.id} className="px-5 py-4"><TargetRow t={t} person={seeAll ? peopleMap.get(t.user_id) : undefined} /></li>)}
              </ul>
            </Card>
          )}
        </div>
        {manage && (
          <Card className="p-5 lg:col-span-2">
            <h2 className="mb-4 text-sm font-semibold">Set a target</h2>
            <TargetForm people={opts(people)} defaults={{ user_id: forUser ?? "", metric: "deals_won", period_start: monthStart, period_end: monthEnd, target_value: "", currency: "USD", notes: "" }} />
          </Card>
        )}
      </div>
    </>
  );
}
