"use server";

import { z } from "zod";
import { NOT_FOUND, ok, refresh, runAction, validId } from "@/lib/actions";
import { check, checkRow, type ActionResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { targetSchema } from "@/lib/validation/people";

export async function createTarget(input: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction("createTarget", "targets.manage", targetSchema, input, async (d) => {
    const supabase = await createClient();
    const row = checkRow(await supabase.from("employee_targets").insert(d).select("id").single());
    refresh("/app/targets", `/app/people/${d.user_id}`);
    return ok({ id: row.id as string });
  });
}

export async function deleteTarget(id: string): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("deleteTarget", "targets.manage", z.object({}), {}, async () => {
    const supabase = await createClient();
    const rows = check(await supabase.from("employee_targets").delete().eq("id", id).select("user_id"));
    if (!rows?.length) return NOT_FOUND;
    refresh("/app/targets", `/app/people/${rows[0].user_id}`);
    return ok();
  });
}
