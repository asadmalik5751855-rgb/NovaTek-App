"use server";

import { z } from "zod";
import { authorize } from "@/lib/auth/session";
import { toActionError, type ActionResult } from "@/lib/errors";
import { isServiceRoleConfigured } from "@/lib/env.server";
import { AI_FEATURES, generate, isAiConfigured, type AiFeature } from "@/lib/integrations/ai";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";

const schema = z.object({
  feature: z.enum(Object.keys(AI_FEATURES) as [AiFeature, ...AiFeature[]]),
  entityId: z.uuid(),
});

/**
 * Runs an AI assist on ONE record the user can already see (fetched through RLS).
 * Output is returned as a labelled draft, logged in ai_generations, and never sent anywhere.
 */
export async function runAiAssist(input: unknown): Promise<ActionResult<{ text: string; model: string }>> {
  try {
    const session = await authorize("ai.use");
    const parsed = schema.safeParse(input);
    if (!parsed.success) return { ok: false, error: "Invalid request." };
    const { feature, entityId } = parsed.data;
    if (!isAiConfigured() || !isServiceRoleConfigured()) {
      return { ok: false, error: "AI assistance isn't configured. An administrator needs to set ANTHROPIC_API_KEY (Settings → Integrations)." };
    }
    const supabase = await createClient();
    const { data: integ } = await createAdminClient().from("integrations").select("enabled").eq("key", "anthropic_ai").maybeSingle();
    if (!integ?.enabled) return { ok: false, error: "AI assistance is turned off. An administrator can enable it in Settings → Integrations after a successful check." };

    const entity = AI_FEATURES[feature].entity;
    let record: Record<string, unknown> | null = null;
    if (entity === "lead") {
      const [{ data: lead }, { data: acts }] = await Promise.all([
        supabase.from("leads").select("company_name, contact_name, website, city, country_code, business_size, budget_range, estimated_value, currency, message, qualification, temperature, score, created_at, last_contacted_at, next_follow_up_at, lead_statuses(name), services(name), industries(name)").eq("id", entityId).maybeSingle(),
        supabase.from("lead_activities").select("type, body, created_at").eq("lead_id", entityId).order("created_at", { ascending: false }).limit(25),
      ]);
      if (lead) record = { ...lead, recent_activity: acts ?? [] };
    } else if (entity === "deal") {
      const { data: deal } = await supabase.from("deals").select("name, value, currency, probability, expected_close_date, notes, services(name), leads(company_name, message, qualification), clients(company_name)").eq("id", entityId).maybeSingle();
      record = deal;
    } else {
      const { data: m } = await supabase.from("meetings").select("title, starts_at, notes, outcome, external_attendees").eq("id", entityId).maybeSingle();
      record = m && (m.notes || m.outcome) ? m : null;
      if (m && !record) return { ok: false, error: "Add meeting notes first — there is nothing to summarise." };
    }
    if (!record) return { ok: false, error: "Not found, or you don't have access to it." };

    const out = await generate(feature, record);
    // Logged by the server (users can't write this table): who, what, which record, which model, the output.
    await createAdminClient().from("ai_generations").insert({
      user_id: session.userId, feature, entity, entity_id: entityId, model: out.model,
      input_summary: `${entity} ${entityId}`, output: out.text.slice(0, 20000), input_tokens: out.inputTokens ?? null, output_tokens: out.outputTokens ?? null,
    });
    return { ok: true, data: { text: out.text, model: out.model } };
  } catch (e) {
    if (e instanceof Error && e.message.startsWith("AI provider")) return { ok: false, error: `${e.message}. Nothing was generated.` };
    return toActionError(e, "runAiAssist");
  }
}
