import { KanbanSquare } from "lucide-react";
import { Alert, ButtonLink, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { PipelineBoard } from "@/components/leads/pipeline-board";
import { requirePermission } from "@/lib/auth/session";
import { canViewLeads } from "@/lib/auth/permissions";
import { LEAD_LIST_COLUMNS, getLookups } from "@/lib/leads/queries";
import type { LeadListItem } from "@/lib/leads/types";
import { createClient } from "@/lib/supabase/server";

export const metadata = { title: "Pipeline" };
const LIMIT = 500;

export default async function PipelinePage() {
  const session = await requirePermission(canViewLeads);
  const lookups = await getLookups();
  const columns = lookups.statuses.filter((s) => s.show_in_pipeline);
  const supabase = await createClient();
  const { data, count, error } = await supabase
    .from("leads")
    .select(LEAD_LIST_COLUMNS, { count: "exact" })
    .is("archived_at", null)
    .in("status_id", columns.map((c) => c.id))
    .order("score", { ascending: false })
    .limit(LIMIT);
  if (error) throw error;
  const leads = (data ?? []) as LeadListItem[];

  return (
    <>
      <PageHeader
        title="Pipeline"
        description="Drag a card to change its stage. Every move is saved and recorded on the lead's timeline."
      />
      {(count ?? 0) > LIMIT && (
        <div className="mb-3"><Alert tone="info">Showing the {LIMIT} highest-scoring of {count} leads. Use the leads list to filter.</Alert></div>
      )}
      {leads.length === 0 ? (
        <Card>
          <EmptyState
            icon={<KanbanSquare className="size-5" />}
            title="The pipeline is empty"
            description="Leads in pipeline stages appear here. New website enquiries start in “New”."
            action={session.can("leads.create") ? <ButtonLink href="/app/leads/new" variant="brand">Add a lead</ButtonLink> : undefined}
          />
        </Card>
      ) : (
        <PipelineBoard
          statuses={columns}
          leads={leads}
          people={Object.fromEntries(lookups.people.map((p) => [p.id, p.full_name || "Unnamed user"]))}
          canEdit={session.can("leads.edit")}
        />
      )}
    </>
  );
}
