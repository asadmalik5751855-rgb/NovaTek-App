import Link from "next/link";
import { FolderKanban, Plus } from "lucide-react";
import { ButtonLink, Card, EmptyState, PageHeader } from "@/components/ui/primitives";
import { MapBadge, Progress } from "@/components/ui/status";
import { requireUser } from "@/lib/auth/session";
import { getPeopleMap } from "@/lib/data/lookups";
import { PRIORITY, PROJECT_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { cn, formatDate } from "@/lib/utils";
import { dayKey } from "@/lib/utils";

export const metadata = { title: "Projects" };

export default async function ProjectsPage({ searchParams }: PageProps<"/app/projects">) {
  const session = await requireUser();
  const sp = await searchParams;
  const closed = sp.closed === "1";
  const supabase = await createClient();
  let q = supabase.from("projects").select("id, name, status, progress, priority, deadline, manager_id, clients(company_name)").is("archived_at", null);
  q = closed ? q.in("status", ["completed", "cancelled"]) : q.not("status", "in", "(completed,cancelled)");
  const [{ data, error }, people] = await Promise.all([q.order("deadline", { ascending: true, nullsFirst: false }).limit(300), getPeopleMap()]);
  if (error) throw error;
  const projects = (data ?? []) as unknown as {
    id: string; name: string; status: string; progress: number; priority: string; deadline: string | null; manager_id: string | null; clients: { company_name: string } | null;
  }[];
  const today = new Date(dayKey(new Date()));

  return (
    <>
      <PageHeader
        title="Projects"
        description={session.can({ anyOf: ["projects.view", "projects.manage"] }) ? "All company projects." : "Projects you manage or are a member of."}
        actions={session.can("projects.manage") && <ButtonLink href="/app/projects/new" variant="brand"><Plus className="size-4" /> New project</ButtonLink>}
      />
      <div className="mb-4 flex rounded-lg border border-border p-0.5 text-sm sm:inline-flex">
        <Link href="/app/projects" className={cn("rounded-md px-3 py-1.5", !closed ? "bg-surface-2 font-medium" : "text-text-3")}>In progress</Link>
        <Link href="/app/projects?closed=1" className={cn("rounded-md px-3 py-1.5", closed ? "bg-surface-2 font-medium" : "text-text-3")}>Completed & cancelled</Link>
      </div>
      {projects.length === 0 ? (
        <Card>
          <EmptyState icon={<FolderKanban className="size-5" />} title="No projects" description="Projects are created for clients, usually after a deal is won."
            action={session.can("projects.manage") ? <ButtonLink href="/app/projects/new" variant="brand">New project</ButtonLink> : undefined} />
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {projects.map((p) => {
            const late = p.deadline && new Date(p.deadline) < today && !["completed", "cancelled"].includes(p.status);
            return (
              <Link key={p.id} href={`/app/projects/${p.id}`}>
                <Card className="h-full space-y-3 p-5 transition-colors hover:border-border-strong">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h2 className="truncate font-medium">{p.name}</h2>
                      <p className="truncate text-xs text-text-3">{p.clients?.company_name ?? "Internal"}</p>
                    </div>
                    <MapBadge map={PROJECT_STATUS} value={p.status} />
                  </div>
                  <div>
                    <div className="mb-1 flex justify-between text-xs text-text-3"><span>Progress</span><span className="tabular-nums">{p.progress}%</span></div>
                    <Progress value={p.progress} />
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-text-3">{p.manager_id ? people.get(p.manager_id) ?? "—" : "No manager"}</span>
                    <span className={cn(late ? "font-medium text-danger" : "text-text-3")}>{p.deadline ? `${late ? "Overdue · " : "Due "}${formatDate(p.deadline)}` : "No deadline"}</span>
                  </div>
                  {p.priority !== "medium" && <MapBadge map={PRIORITY} value={p.priority} />}
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </>
  );
}
