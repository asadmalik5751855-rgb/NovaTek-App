import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { ProjectForm } from "@/components/work/project-form";
import { requirePermission } from "@/lib/auth/session";
import { getClientOptions, getDepartments, getPeople, getServices, opts } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";

export const metadata = { title: "New project" };

export default async function NewProjectPage({ searchParams }: PageProps<"/app/projects/new">) {
  const session = await requirePermission("projects.manage");
  const sp = await searchParams;
  const clientId = typeof sp.client === "string" && validId(sp.client) ? sp.client : "";
  const dealId = typeof sp.deal === "string" && validId(sp.deal) ? sp.deal : "";
  const [clients, services, people, departments] = await Promise.all([getClientOptions(), getServices(), getPeople(), getDepartments()]);
  let defaults: Record<string, unknown> = {
    name: "", client_id: clientId, deal_id: dealId, service_id: "", description: "", start_date: new Date().toISOString().slice(0, 10), deadline: "",
    status: "planning", budget: "", currency: "USD", priority: "medium", manager_id: session.userId, department_id: "",
  };
  if (dealId) {
    const supabase = await createClient();
    const { data: d } = await supabase.from("deals").select("name, client_id, service_id, value, currency").eq("id", dealId).maybeSingle();
    if (d) defaults = { ...defaults, name: d.name, client_id: d.client_id ?? clientId, service_id: d.service_id ?? "", budget: String(d.value), currency: d.currency };
  }
  return (
    <>
      <Link href="/app/projects" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Projects</Link>
      <PageHeader title="New project" />
      <Card className="max-w-3xl p-5 sm:p-6">
        <ProjectForm defaults={defaults} clients={opts(clients)} services={opts(services)} people={opts(people)} departments={opts(departments)} canManageAll />
      </Card>
    </>
  );
}
