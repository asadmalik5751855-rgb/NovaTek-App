import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ListPlus, Pencil, X } from "lucide-react";
import { ButtonLink, Card, CardHeader } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { DescRow, MapBadge, Progress, SectionTitle } from "@/components/ui/status";
import { DocumentsCard } from "@/components/documents/documents-card";
import { AddMemberForm } from "@/components/work/project-form";
import { TaskStatusSelect } from "@/components/work/task-status";
import { requireUser } from "@/lib/auth/session";
import { getPeople, getPeopleMap, getServices, opts } from "@/lib/data/lookups";
import { PRIORITY, PROJECT_STATUS, TASK_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";
import { formatDate, formatDateTime, formatMoney } from "@/lib/utils";
import { removeProjectMember } from "../actions";

export default async function ProjectPage({ params }: PageProps<"/app/projects/[id]">) {
  const session = await requireUser();
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const { data: p } = await supabase.from("projects").select("*, clients(id, company_name), deals(id, name)").eq("id", id).maybeSingle();
  if (!p) notFound();
  const [members, tasks, peopleMap, people, services] = await Promise.all([
    supabase.from("project_members").select("user_id, role, added_at").eq("project_id", id).order("added_at"),
    supabase.from("tasks").select("id, title, status, priority, assignee_id, due_at, kind").eq("project_id", id).order("created_at"),
    getPeopleMap(), getPeople(), getServices(),
  ]);
  const canManage = session.can("projects.manage") || p.manager_id === session.userId;
  const memberIds = new Set((members.data ?? []).map((m) => m.user_id));
  const byStatus = Object.keys(TASK_STATUS).map((k) => ({ key: k, items: (tasks.data ?? []).filter((t) => t.status === k) }));

  return (
    <>
      <Link href="/app/projects" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Projects</Link>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 flex-1">
          <h1 className="text-2xl font-semibold tracking-tight">{p.name}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <MapBadge map={PROJECT_STATUS} value={p.status} />
            <MapBadge map={PRIORITY} value={p.priority} />
            {p.clients && <Link href={`/app/clients/${p.clients.id}`} className="text-sm text-text-3 hover:text-accent">{p.clients.company_name}</Link>}
          </div>
          <div className="mt-4 max-w-md">
            <div className="mb-1 flex justify-between text-xs text-text-3"><span>Progress {(tasks.data ?? []).length ? "(from tasks)" : ""}</span><span className="tabular-nums">{p.progress}%</span></div>
            <Progress value={p.progress} />
          </div>
        </div>
        {canManage && <ButtonLink href={`/app/projects/${p.id}/edit`} variant="secondary"><Pencil className="size-4" /> Edit</ButtonLink>}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader title="Tasks" action={<Link href={`/app/tasks/new?project=${p.id}`} className="inline-flex items-center gap-1 text-xs text-accent hover:underline"><ListPlus className="size-3.5" /> Add task</Link>} />
            {(tasks.data ?? []).length === 0 ? (
              <p className="px-5 py-4 text-sm text-text-3">No tasks yet. Progress will follow task completion once tasks exist.</p>
            ) : (
              <div className="divide-y divide-border">
                {byStatus.filter((g) => g.items.length).map((g) => (
                  <div key={g.key}>
                    <p className="bg-surface-2/40 px-5 py-1.5 text-xs font-medium text-text-3">{TASK_STATUS[g.key as keyof typeof TASK_STATUS].label} · {g.items.length}</p>
                    <ul className="divide-y divide-border">
                      {g.items.map((t) => (
                        <li key={t.id} className="flex flex-wrap items-center gap-2 px-5 py-2.5">
                          <Link href={`/app/tasks/${t.id}`} className="min-w-0 flex-1 truncate text-sm hover:text-accent">{t.title}</Link>
                          <span className="text-xs text-text-3">{t.assignee_id ? peopleMap.get(t.assignee_id) ?? "—" : "Unassigned"}{t.due_at ? ` · ${formatDateTime(t.due_at)}` : ""}</span>
                          {(t.assignee_id === session.userId || canManage || session.can("tasks.assign")) && <TaskStatusSelect id={t.id} value={t.status} compact />}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </Card>
          <DocumentsCard entity="project" entityId={p.id} canUpload={canManage || memberIds.has(session.userId)} userId={session.userId} isAdmin={session.can("settings.manage")} />
        </div>

        <div className="space-y-6">
          <Card>
            <dl className="divide-y divide-border px-5 py-2">
              <DescRow label="Manager">{p.manager_id ? peopleMap.get(p.manager_id) ?? "A former user" : null}</DescRow>
              <DescRow label="Service">{services.find((s) => s.id === p.service_id)?.name}</DescRow>
              <DescRow label="Start">{p.start_date ? formatDate(p.start_date) : null}</DescRow>
              <DescRow label="Deadline">{p.deadline ? formatDate(p.deadline) : null}</DescRow>
              {(session.can("projects.manage") || session.can("sales.view")) && <DescRow label="Budget">{p.budget !== null ? formatMoney(p.budget, p.currency) : null}</DescRow>}
              <DescRow label="Deal">{p.deals ? <Link className="text-accent hover:underline" href={`/app/deals/${p.deals.id}`}>{p.deals.name}</Link> : null}</DescRow>
              {p.completed_at && <DescRow label="Completed">{formatDate(p.completed_at)}</DescRow>}
              {p.description && <DescRow label="Description"><span className="whitespace-pre-wrap">{p.description}</span></DescRow>}
            </dl>
          </Card>
          <Card className="p-5">
            <SectionTitle>Team</SectionTitle>
            {(members.data ?? []).length === 0 ? <p className="text-sm text-text-3">No members yet.</p> : (
              <ul className="space-y-2">
                {(members.data ?? []).map((m) => (
                  <li key={m.user_id} className="flex items-center gap-2 text-sm">
                    <span className="flex-1">{peopleMap.get(m.user_id) ?? "A former user"} <span className="text-xs text-text-3">· {m.role}</span></span>
                    {canManage && (
                      <ActionButton action={removeProjectMember.bind(null, p.id, m.user_id)} size="sm" variant="ghost" confirm="Remove from project?">
                        <X className="size-3.5" />
                      </ActionButton>
                    )}
                  </li>
                ))}
              </ul>
            )}
            {canManage && (
              <div className="mt-4 border-t border-border pt-4">
                <AddMemberForm projectId={p.id} people={opts(people.filter((x) => !memberIds.has(x.id)))} />
              </div>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
