import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { ProjectForm } from "@/components/work/project-form";
import { requireUser } from "@/lib/auth/session";
import { getClientOptions, getDepartments, getPeople, getServices, opts } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";

export const metadata = { title: "Edit project" };

export default async function EditProjectPage({ params }: PageProps<"/app/projects/[id]/edit">) {
  const session = await requireUser();
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const [{ data: p }, clients, services, people, departments] = await Promise.all([
    supabase.from("projects").select("*").eq("id", id).maybeSingle(), getClientOptions(), getServices(), getPeople(), getDepartments(),
  ]);
  if (!p) notFound();
  if (!(session.can("projects.manage") || p.manager_id === session.userId)) redirect(`/app/projects/${id}`);
  const s = (v: unknown) => (v === null || v === undefined ? "" : String(v));
  return (
    <>
      <Link href={`/app/projects/${id}`} className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> {p.name}</Link>
      <PageHeader title="Edit project" />
      <Card className="max-w-3xl p-5 sm:p-6">
        <ProjectForm
          projectId={id}
          defaults={{ name: p.name, client_id: s(p.client_id), deal_id: s(p.deal_id), service_id: s(p.service_id), description: s(p.description),
            start_date: s(p.start_date), deadline: s(p.deadline), status: p.status, budget: s(p.budget), currency: p.currency, priority: p.priority,
            manager_id: s(p.manager_id), department_id: s(p.department_id) }}
          clients={opts(clients)} services={opts(services)} people={opts(people)} departments={opts(departments)}
          canManageAll={session.can("projects.manage")}
        />
      </Card>
    </>
  );
}
