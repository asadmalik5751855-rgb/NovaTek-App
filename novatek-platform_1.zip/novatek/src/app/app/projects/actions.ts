"use server";

import { z } from "zod";
import { NOT_FOUND, ok, refresh, runAction, validId } from "@/lib/actions";
import { check, checkRow, type ActionResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { projectSchema } from "@/lib/validation/work";

export async function createProject(input: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction("createProject", "projects.manage", projectSchema, input, async (d) => {
    const supabase = await createClient();
    const row = checkRow(await supabase.from("projects").insert(d).select("id").single());
    refresh("/app/projects", ...(d.client_id ? [`/app/clients/${d.client_id}`] : []));
    return ok({ id: row.id as string });
  });
}

export async function updateProject(id: string, input: unknown): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("updateProject", null, projectSchema, input, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("projects").update(d).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh("/app/projects", `/app/projects/${id}`);
    return ok();
  });
}

export async function addProjectMember(projectId: string, input: unknown): Promise<ActionResult> {
  if (!validId(projectId)) return NOT_FOUND;
  const schema = z.object({ user_id: z.uuid("Choose a person"), role: z.string().trim().min(1, "Role is required").max(60) });
  return runAction("addProjectMember", null, schema, input, async (d) => {
    const supabase = await createClient();
    check(await supabase.from("project_members").insert({ project_id: projectId, ...d }));
    refresh(`/app/projects/${projectId}`);
    return ok();
  });
}

export async function removeProjectMember(projectId: string, userId: string): Promise<ActionResult> {
  if (!validId(projectId) || !validId(userId)) return NOT_FOUND;
  return runAction("removeProjectMember", null, z.object({}), {}, async () => {
    const supabase = await createClient();
    const rows = check(await supabase.from("project_members").delete().eq("project_id", projectId).eq("user_id", userId).select("user_id"));
    if (!rows?.length) return NOT_FOUND;
    refresh(`/app/projects/${projectId}`);
    return ok();
  });
}
