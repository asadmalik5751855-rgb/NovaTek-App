import { ShieldX } from "lucide-react";
import { ButtonLink, Card, EmptyState } from "@/components/ui/primitives";

export const metadata = { title: "Access denied" };

export default function DeniedPage() {
  return (
    <Card>
      <EmptyState
        icon={<ShieldX className="size-5" />}
        title="You don't have access to that page"
        description="Your role doesn't include the permission it requires. If you need it, ask an administrator to update your role."
        action={<ButtonLink href="/app" variant="secondary">Back to dashboard</ButtonLink>}
      />
    </Card>
  );
}
