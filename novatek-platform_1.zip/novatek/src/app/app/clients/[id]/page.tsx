import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ExternalLink, FolderPlus, Handshake, Mail, Pencil, Phone } from "lucide-react";
import { Badge, ButtonLink, Card, CardHeader } from "@/components/ui/primitives";
import { ActionButton } from "@/components/ui/action-button";
import { DescRow, MapBadge, MoneyList, StatCard } from "@/components/ui/status";
import { DocumentsCard } from "@/components/documents/documents-card";
import { requirePermission } from "@/lib/auth/session";
import { canViewClients } from "@/lib/auth/permissions";
import { getDealStages, getPeopleMap } from "@/lib/data/lookups";
import { getLookups } from "@/lib/leads/queries";
import { MEETING_STATUS, PROJECT_STATUS } from "@/lib/labels";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";
import { formatDate, formatDateTime, formatMoney } from "@/lib/utils";
import { setClientArchived } from "../actions";

export default async function ClientPage({ params }: PageProps<"/app/clients/[id]">) {
  const session = await requirePermission(canViewClients);
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const { data: c } = await supabase.from("clients").select("*").eq("id", id).maybeSingle();
  if (!c) notFound();
  const [deals, projects, meetings, leads, people, stages, lookups] = await Promise.all([
    supabase.from("deals").select("id, name, value, currency, stage_id, won_at, lost_at").eq("client_id", id).is("archived_at", null).order("created_at", { ascending: false }),
    supabase.from("projects").select("id, name, status, progress, deadline").eq("client_id", id).is("archived_at", null).order("created_at", { ascending: false }),
    supabase.from("meetings").select("id, title, starts_at, status").eq("client_id", id).order("starts_at", { ascending: false }).limit(10),
    supabase.from("leads").select("id, company_name, created_at").eq("client_id", id),
    getPeopleMap(), getDealStages(), getLookups(),
  ]);
  const won = (deals.data ?? []).filter((d) => d.won_at);
  const openDeals = (deals.data ?? []).filter((d) => !d.won_at && !d.lost_at);
  const canEdit = session.can("sales.manage") || (session.can("sales.view") && c.account_manager_id === session.userId);
  const country = lookups.countries.find((x) => x.code === c.country_code)?.name;
  const industry = lookups.industries.find((x) => x.id === c.industry_id)?.name;

  return (
    <>
      <Link href="/app/clients" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Clients</Link>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{c.company_name}</h1>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Badge color={c.status === "active" ? "emerald" : "zinc"}>{c.status === "active" ? "Active client" : "Inactive"}</Badge>
            {c.archived_at && <Badge color="zinc">Archived</Badge>}
          </div>
        </div>
        <div className="flex gap-2">
          {c.email && <a href={`mailto:${c.email}`} aria-label="Email contact" className="inline-flex size-10 items-center justify-center rounded-lg border border-border hover:bg-surface-2"><Mail className="size-4" /></a>}
          {c.phone && <a href={`tel:${c.phone.replace(/[^\d+]/g, "")}`} aria-label="Call contact" className="inline-flex size-10 items-center justify-center rounded-lg border border-border hover:bg-surface-2"><Phone className="size-4" /></a>}
          {canEdit && <ButtonLink href={`/app/clients/${c.id}/edit`} variant="secondary"><Pencil className="size-4" /> Edit</ButtonLink>}
        </div>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Revenue (won)" value={<MoneyList items={won.map((d) => ({ currency: d.currency, amount: d.value }))} />} hint={`${won.length} won deal${won.length === 1 ? "" : "s"}`} />
        <StatCard label="Open deals" value={openDeals.length} hint={<MoneyList items={openDeals.map((d) => ({ currency: d.currency, amount: d.value }))} empty="No open value" />} />
        <StatCard label="Projects" value={(projects.data ?? []).length} />
        <StatCard label="Account manager" value={<span className="text-base">{c.account_manager_id ? people.get(c.account_manager_id) ?? "—" : "Not set"}</span>} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <CardHeader
              title="Deals & orders"
              action={session.can("sales.view") ? <Link href={`/app/deals/new?client=${c.id}`} className="inline-flex items-center gap-1 text-xs text-accent hover:underline"><Handshake className="size-3.5" /> New deal</Link> : undefined}
            />
            {(deals.data ?? []).length === 0 ? <p className="px-5 py-4 text-sm text-text-3">No deals.</p> : (
              <ul className="divide-y divide-border">
                {(deals.data ?? []).map((d) => {
                  const st = stages.find((s) => s.id === d.stage_id);
                  return (
                    <li key={d.id}>
                      <Link href={`/app/deals/${d.id}`} className="flex items-center gap-3 px-5 py-2.5 hover:bg-surface-2/50">
                        <span className="flex-1 truncate text-sm">{d.name}</span>
                        <span className="text-sm tabular-nums">{formatMoney(d.value, d.currency)}</span>
                        {st && <Badge color={st.color}>{st.name}</Badge>}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>

          <Card>
            <CardHeader
              title="Projects"
              action={session.can("projects.manage") ? <Link href={`/app/projects/new?client=${c.id}`} className="inline-flex items-center gap-1 text-xs text-accent hover:underline"><FolderPlus className="size-3.5" /> New project</Link> : undefined}
            />
            {(projects.data ?? []).length === 0 ? <p className="px-5 py-4 text-sm text-text-3">No projects.</p> : (
              <ul className="divide-y divide-border">
                {(projects.data ?? []).map((p) => (
                  <li key={p.id}>
                    <Link href={`/app/projects/${p.id}`} className="flex items-center gap-3 px-5 py-2.5 hover:bg-surface-2/50">
                      <span className="flex-1 truncate text-sm">{p.name}</span>
                      <span className="text-xs text-text-3">{p.progress}%{p.deadline ? ` · due ${formatDate(p.deadline)}` : ""}</span>
                      <MapBadge map={PROJECT_STATUS} value={p.status} />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card>
            <CardHeader title="Communication" description="Meetings with this client" action={<Link href={`/app/meetings/new?client=${c.id}`} className="text-xs text-accent hover:underline">Schedule</Link>} />
            {(meetings.data ?? []).length === 0 ? <p className="px-5 py-4 text-sm text-text-3">No meetings recorded.</p> : (
              <ul className="divide-y divide-border">
                {(meetings.data ?? []).map((m) => (
                  <li key={m.id}>
                    <Link href={`/app/meetings/${m.id}`} className="flex items-center gap-3 px-5 py-2.5 hover:bg-surface-2/50">
                      <span className="flex-1 truncate text-sm">{m.title}</span>
                      <span className="text-xs text-text-3">{formatDateTime(m.starts_at)}</span>
                      <MapBadge map={MEETING_STATUS} value={m.status} />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <DocumentsCard entity="client" entityId={c.id} canUpload={canEdit} userId={session.userId} isAdmin={session.can("settings.manage")} />
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader title="Profile" />
            <dl className="divide-y divide-border px-5 py-2">
              <DescRow label="Contact">{c.contact_name}</DescRow>
              <DescRow label="Email">{c.email}</DescRow>
              <DescRow label="Phone">{c.phone}</DescRow>
              <DescRow label="Website">{c.website_domain ? <a className="inline-flex items-center gap-1 text-accent hover:underline" href={`https://${c.website_domain}`} target="_blank" rel="noopener noreferrer nofollow">{c.website_domain} <ExternalLink className="size-3" /></a> : c.website}</DescRow>
              <DescRow label="Industry">{industry}</DescRow>
              <DescRow label="Location">{[c.city, country].filter(Boolean).join(", ") || null}</DescRow>
              <DescRow label="Client since">{formatDate(c.created_at)}</DescRow>
              <DescRow label="Origin">{(leads.data ?? []).length ? (leads.data ?? []).map((l) => <Link key={l.id} href={`/app/leads/${l.id}`} className="block text-accent hover:underline">Lead from {formatDate(l.created_at)}</Link>) : "Added directly"}</DescRow>
              {c.notes && <DescRow label="Notes"><span className="whitespace-pre-wrap">{c.notes}</span></DescRow>}
            </dl>
          </Card>
          {session.can("sales.manage") && (
            <ActionButton action={setClientArchived.bind(null, c.id, !c.archived_at)} variant="ghost"
              confirm={c.archived_at ? "Restore this client?" : "Archive this client? Their deals, projects and history are kept."}>
              {c.archived_at ? "Restore client" : "Archive client"}
            </ActionButton>
          )}
        </div>
      </div>
    </>
  );
}
