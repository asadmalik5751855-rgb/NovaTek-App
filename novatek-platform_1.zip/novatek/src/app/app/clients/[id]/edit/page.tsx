import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { ClientForm } from "@/components/sales/client-form";
import { requirePermission } from "@/lib/auth/session";
import { canViewClients } from "@/lib/auth/permissions";
import { getPeople, opts } from "@/lib/data/lookups";
import { getLookups } from "@/lib/leads/queries";
import { createClient } from "@/lib/supabase/server";
import { validId } from "@/lib/actions";

export const metadata = { title: "Edit client" };

export default async function EditClientPage({ params }: PageProps<"/app/clients/[id]/edit">) {
  const session = await requirePermission(canViewClients);
  const { id } = await params;
  if (!validId(id)) notFound();
  const supabase = await createClient();
  const [{ data: c }, lookups, people] = await Promise.all([supabase.from("clients").select("*").eq("id", id).maybeSingle(), getLookups(), getPeople()]);
  if (!c) notFound();
  const canEdit = session.can("sales.manage") || (session.can("sales.view") && c.account_manager_id === session.userId);
  if (!canEdit) redirect(`/app/clients/${id}`);
  const s = (v: unknown) => (v === null || v === undefined ? "" : String(v));
  return (
    <>
      <Link href={`/app/clients/${id}`} className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> {c.company_name}</Link>
      <PageHeader title="Edit client" />
      <Card className="max-w-3xl p-5 sm:p-6">
        <ClientForm
          clientId={id}
          defaults={{ company_name: c.company_name, website: s(c.website), industry_id: s(c.industry_id), country_code: s(c.country_code), city: s(c.city),
            contact_name: s(c.contact_name), email: s(c.email), phone: s(c.phone), account_manager_id: s(c.account_manager_id), status: c.status, notes: s(c.notes) }}
          industries={opts(lookups.industries)}
          countries={lookups.countries.map((x) => ({ value: x.code, label: x.name }))}
          people={opts(people)}
          canAssign={session.can("sales.manage")}
        />
      </Card>
    </>
  );
}
