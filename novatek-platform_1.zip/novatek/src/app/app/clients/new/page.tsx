import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Card, PageHeader } from "@/components/ui/primitives";
import { ClientForm } from "@/components/sales/client-form";
import { requirePermission } from "@/lib/auth/session";
import { getPeople, opts } from "@/lib/data/lookups";
import { getLookups } from "@/lib/leads/queries";

export const metadata = { title: "New client" };

export default async function NewClientPage() {
  await requirePermission("sales.manage");
  const [lookups, people] = await Promise.all([getLookups(), getPeople()]);
  return (
    <>
      <Link href="/app/clients" className="mb-4 inline-flex items-center gap-1.5 text-sm text-text-3 hover:text-text"><ArrowLeft className="size-4" /> Clients</Link>
      <PageHeader title="New client" description="For clients that didn’t come through the lead pipeline. Won leads are converted automatically." />
      <Card className="max-w-3xl p-5 sm:p-6">
        <ClientForm
          defaults={{ company_name: "", website: "", industry_id: "", country_code: "", city: "", contact_name: "", email: "", phone: "", account_manager_id: "", status: "active", notes: "" }}
          industries={opts(lookups.industries)}
          countries={lookups.countries.map((c) => ({ value: c.code, label: c.name }))}
          people={opts(people)}
          canAssign
        />
      </Card>
    </>
  );
}
