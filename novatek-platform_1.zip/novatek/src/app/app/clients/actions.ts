"use server";

import { z } from "zod";
import { NOT_FOUND, ok, refresh, runAction, validId } from "@/lib/actions";
import { check, checkRow, type ActionResult } from "@/lib/errors";
import { createClient } from "@/lib/supabase/server";
import { clientSchema } from "@/lib/validation/sales";

export async function createClientRecord(input: unknown): Promise<ActionResult<{ id: string }>> {
  return runAction("createClient", "sales.manage", clientSchema, input, async (d) => {
    const supabase = await createClient();
    const row = checkRow(await supabase.from("clients").insert(d).select("id").single());
    refresh("/app/clients");
    return ok({ id: row.id as string });
  });
}

export async function updateClientRecord(id: string, input: unknown): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("updateClient", { anyOf: ["sales.manage", "sales.view"] }, clientSchema, input, async (d) => {
    const supabase = await createClient();
    const rows = check(await supabase.from("clients").update(d).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh("/app/clients", `/app/clients/${id}`);
    return ok();
  });
}

export async function setClientArchived(id: string, archived: boolean): Promise<ActionResult> {
  if (!validId(id)) return NOT_FOUND;
  return runAction("setClientArchived", "sales.manage", z.object({}), {}, async () => {
    const supabase = await createClient();
    const rows = check(await supabase.from("clients").update({ archived_at: archived ? new Date().toISOString() : null }).eq("id", id).select("id"));
    if (!rows?.length) return NOT_FOUND;
    refresh("/app/clients", `/app/clients/${id}`);
    return ok();
  });
}
