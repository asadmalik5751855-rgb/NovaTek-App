import Link from "next/link";
import { Building2, ChevronLeft, ChevronRight, Plus, Search } from "lucide-react";
import { Badge, ButtonLink, Card, EmptyState, Input, PageHeader, buttonClass } from "@/components/ui/primitives";
import { requirePermission } from "@/lib/auth/session";
import { canViewClients } from "@/lib/auth/permissions";
import { getPeopleMap } from "@/lib/data/lookups";
import { createClient } from "@/lib/supabase/server";
import { formatDate } from "@/lib/utils";

export const metadata = { title: "Clients" };
const PAGE = 30;

export default async function ClientsPage({ searchParams }: PageProps<"/app/clients">) {
  const session = await requirePermission(canViewClients);
  const sp = await searchParams;
  const term = typeof sp.q === "string" ? sp.q.replace(/[%,()*\\]/g, " ").trim().slice(0, 80) : "";
  const page = Math.max(1, Number(sp.page) || 1);
  const supabase = await createClient();
  let q = supabase.from("clients").select("id, company_name, contact_name, email, country_code, status, account_manager_id, created_at", { count: "exact" })
    .is("archived_at", null);
  if (term) q = q.or(`company_name.ilike.%${term}%,contact_name.ilike.%${term}%,email.ilike.%${term}%`);
  const [{ data, count, error }, people] = await Promise.all([
    q.order("company_name").range((page - 1) * PAGE, page * PAGE - 1), getPeopleMap(),
  ]);
  if (error) throw error;
  const rows = data ?? [];
  const pages = Math.max(1, Math.ceil((count ?? 0) / PAGE));

  return (
    <>
      <PageHeader
        title="Clients"
        description={`${(count ?? 0).toLocaleString()} client${count === 1 ? "" : "s"}. Won leads become clients automatically — never duplicated.`}
        actions={session.can("sales.manage") && <ButtonLink href="/app/clients/new" variant="brand"><Plus className="size-4" /> Add client</ButtonLink>}
      />
      <form className="mb-4 flex max-w-md gap-2" role="search">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-text-3" />
          <Input name="q" defaultValue={term} placeholder="Search company, contact, email" className="pl-9" aria-label="Search clients" />
        </div>
        <button className={buttonClass("secondary")} type="submit">Search</button>
      </form>
      <Card className="overflow-hidden">
        {rows.length === 0 ? (
          <EmptyState
            icon={<Building2 className="size-5" />}
            title={term ? "No clients match" : "No clients yet"}
            description={term ? "Try another search." : "When a deal is marked won, its lead becomes a client here automatically."}
            action={!term && session.can("sales.manage") ? <ButtonLink href="/app/clients/new" variant="brand">Add a client</ButtonLink> : undefined}
          />
        ) : (
          <ul className="divide-y divide-border">
            {rows.map((c) => (
              <li key={c.id}>
                <Link href={`/app/clients/${c.id}`} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-5 py-3 hover:bg-surface-2/50">
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-medium">{c.company_name}</span>
                    <span className="block truncate text-xs text-text-3">{[c.contact_name, c.email].filter(Boolean).join(" · ") || "No contact recorded"}</span>
                  </span>
                  <span className="text-xs text-text-3">{c.account_manager_id ? people.get(c.account_manager_id) ?? "—" : "No account manager"}</span>
                  {c.status === "inactive" && <Badge color="zinc">Inactive</Badge>}
                  <span className="hidden text-xs text-text-3 sm:inline">since {formatDate(c.created_at)}</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
        {pages > 1 && (
          <div className="flex items-center justify-between border-t border-border px-4 py-3 text-sm text-text-3">
            <span>Page {page} of {pages}</span>
            <div className="flex gap-2">
              {page > 1 && <Link className={buttonClass("secondary", "sm")} href={`/app/clients?q=${encodeURIComponent(term)}&page=${page - 1}`}><ChevronLeft className="size-4" /> Prev</Link>}
              {page < pages && <Link className={buttonClass("secondary", "sm")} href={`/app/clients?q=${encodeURIComponent(term)}&page=${page + 1}`}>Next <ChevronRight className="size-4" /></Link>}
            </div>
          </div>
        )}
      </Card>
    </>
  );
}
