import type { Metadata, Viewport } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import { brand } from "@/lib/config/brand";
import { publicEnv } from "@/lib/env";
import { RegisterServiceWorker } from "@/components/pwa/register-sw";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(publicEnv.siteUrl),
  title: { default: `${brand.companyName} — Digital Solutions & Software Services`, template: `%s · ${brand.companyName}` },
  description:
    "NovaTek builds websites, e-commerce stores, custom software, SaaS products and AI-powered automation for growing businesses.",
  applicationName: brand.companyName,
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/icons/icon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
    ],
    apple: "/icons/apple-touch-icon.png",
  },
  openGraph: { siteName: brand.companyName, images: [{ url: brand.logo.horizontal.src }] },
};

export const viewport: Viewport = {
  themeColor: brand.colors.base,
  width: "device-width",
  initialScale: 1,
};

// Applies the saved theme before paint (dark by default) to avoid a flash.
const themeScript = `(function(){try{var t=localStorage.getItem('nt-theme');var d=t?t==='dark':true;document.documentElement.classList.toggle('dark',d);}catch(e){document.documentElement.classList.add('dark');}})();`;

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable} dark`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="min-h-dvh">
        {children}
        <RegisterServiceWorker />
      </body>
    </html>
  );
}
