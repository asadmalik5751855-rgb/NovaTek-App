import Link from "next/link";
import { BrandMark } from "@/components/brand/brand-logo";

export default function NotFound() {
  return (
    <main className="dark grid min-h-dvh place-items-center bg-bg px-4 text-center text-text">
      <div>
        <BrandMark size={56} className="mx-auto" />
        <h1 className="mt-6 text-2xl font-semibold">Page not found</h1>
        <p className="mt-2 text-text-3">The page doesn’t exist, or you don’t have access to it.</p>
        <Link href="/" className="mt-6 inline-block text-sm text-accent hover:underline">Go to the homepage</Link>
      </div>
    </main>
  );
}
