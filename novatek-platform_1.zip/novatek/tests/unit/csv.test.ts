import { describe, expect, it } from "vitest";
import { csvCell, parseCsv, toCsv } from "@/lib/csv";

describe("CSV", () => {
  it("neutralises spreadsheet formula injection", () => {
    for (const bad of ["=HYPERLINK(\"x\")", "+1+1", "-2", "@SUM(A1)", "\tcmd"]) expect(csvCell(bad).replace(/^"/, "")[0]).toBe("'");
    expect(csvCell("Acme, Inc")).toBe('"Acme, Inc"');
    expect(csvCell('Say "hi"')).toBe('"Say ""hi"""');
  });
  it("round-trips quoted fields, commas, newlines and CRLF", () => {
    const csv = toCsv(["a", "b"], [["x, y", 'he said "ok"'], ["line1\nline2", 3]]);
    const rows = parseCsv(csv);
    expect(rows[0]).toEqual(["a", "b"]);
    expect(rows[1]).toEqual(["x, y", 'he said "ok"']);
    expect(rows[2]).toEqual(["line1\nline2", "3"]);
  });
  it("skips blank lines and strips the BOM", () => {
    expect(parseCsv("﻿company_name\r\n\r\nAcme\r\n")).toEqual([["company_name"], ["Acme"]]);
  });
});
