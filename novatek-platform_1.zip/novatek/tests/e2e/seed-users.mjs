// E2E ONLY: creates test accounts in a LOCAL test stack. Never run against production.
// Usage: SUPABASE_URL=http://localhost:54321 SERVICE_KEY=... node tests/e2e/seed-users.mjs
import { createClient } from "@supabase/supabase-js";

const url = process.env.SUPABASE_URL ?? "http://localhost:54321";
if (!/localhost|127\.0\.0\.1/.test(url)) throw new Error("Refusing to seed a non-local Supabase");
const admin = createClient(url, process.env.SERVICE_KEY, { auth: { persistSession: false } });
const PASSWORD = process.env.E2E_PASSWORD ?? "Test-Passw0rd-2026";

const USERS = [
  ["admin@novatek.test", "Nadia Admin", ["super_admin"], "Executive", "System Administrator"],
  ["ceo@novatek.test", "Imran Chaudhry", ["ceo"], "Executive", "Chief Executive Officer"],
  ["coo@novatek.test", "Omar Farooq", ["coo"], "Operations", "Chief Operating Officer"],
  ["cto@novatek.test", "Tariq Aziz", ["cto"], "Technology", "Chief Technology Officer"],
  ["cmo@novatek.test", "Mariam Siddiqui", ["cmo"], "Marketing", "Chief Marketing Officer"],
  ["salesmgr@novatek.test", "Bilal Ahmed", ["sales_manager"], "Sales", "Sales Manager"],
  ["rep@novatek.test", "Sana Rep", ["sales_rep"], "Sales", "Sales Representative"],
  ["dev@novatek.test", "Hamza Dev", ["developer"], "Technology", "Full-stack Developer"],
  ["designer@novatek.test", "Zara Design", ["designer"], "Design", "UI/UX Designer"],
];

const { data: roles } = await admin.from("roles").select("id, key");
const { data: depts } = await admin.from("departments").select("id, name");
for (const [email, name, roleKeys, dept, title] of USERS) {
  const res = await admin.auth.admin.createUser({ email, password: PASSWORD, email_confirm: true, user_metadata: { full_name: name } });
  if (res.error) throw new Error(`${email}: ${res.error.message}`);
  const id = res.data.user.id;
  await admin.from("profiles").update({ department_id: depts.find((d) => d.name === dept)?.id, designation: title }).eq("id", id);
  for (const k of roleKeys) {
    const { error } = await admin.from("user_roles").insert({ user_id: id, role_id: roles.find((r) => r.key === k).id });
    if (error) throw error;
  }
  console.log("seeded", email);
}
