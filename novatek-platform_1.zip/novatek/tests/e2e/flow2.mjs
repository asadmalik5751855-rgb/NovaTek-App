// End-to-end: sales → delivery → marketing → admin, against a running app + Supabase-compatible stack.
// Usage: BASE_URL=http://localhost:3000 SHOTS=./shots CRON_SECRET=... node tests/e2e/flow2.mjs
import { chromium } from "playwright";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const SHOTS = process.env.SHOTS ?? "./e2e-shots";
const PASSWORD = process.env.E2E_PASSWORD ?? "Test-Passw0rd-2026";
// Real browsers only: the proposal link deliberately ignores headless/bot user agents.
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36";
fs.mkdirSync(SHOTS, { recursive: true });

const browser = await chromium.launch();
const results = [];
let failedOnce = false;
async function step(name, fn) {
  if (failedOnce && process.env.STOP_ON_FAIL) return;
  try {
    await fn();
    results.push(["PASS", name]);
    console.log("PASS", name);
  } catch (e) {
    failedOnce = true;
    results.push(["FAIL", name, e.message]);
    console.log("FAIL", name, "-", e.message.split("\n")[0]);
  }
}
async function newPage(viewport = { width: 1366, height: 900 }, opts = {}) {
  const ctx = await browser.newContext({ viewport, userAgent: UA, acceptDownloads: true, ...opts });
  return ctx.newPage();
}
async function login(page, email) {
  await page.goto(`${BASE}/login`);
  await page.fill("#email", email);
  await page.fill("#password", PASSWORD);
  await Promise.all([page.waitForURL(/\/app/), page.click("button[type=submit]")]);
}
async function as(email, fn, viewport) {
  const page = await newPage(viewport);
  await login(page, email);
  try {
    return await fn(page);
  } catch (e) {
    await page.screenshot({ path: `${SHOTS}/fail-${email.split("@")[0]}-${Date.now()}.png`, fullPage: true }).catch(() => {});
    throw e;
  } finally {
    await page.context().close();
  }
}
const shot = (page, name) => page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: true });
const uniq = Date.now().toString(36);
const company = `Orchid Retail ${uniq}`;
const state = {};

// Confirms an ActionButton panel (optionally typing into its prompt).
async function confirmAction(page, buttonName, { input, confirm } = {}) {
  await page.getByRole("button", { name: buttonName }).first().click();
  if (input !== undefined) await page.locator("div.rounded-lg.border input, div.rounded-lg.border textarea").last().fill(input);
  await page.getByRole("button", { name: confirm ?? "Confirm", exact: true }).last().click();
}

await step("admin approves a 5% commission rule for sales reps", async () => {
  await as("cmo@novatek.test", async () => {}); // warm-up login path
  await as("admin@novatek.test", async (page) => {
    await page.goto(`${BASE}/app/commissions/rules`);
    await page.fill("#name", `Reps 5% ${uniq}`);
    await page.selectOption("#eligible_role_id", { label: "Sales Representative" });
    await page.fill("#percent", "5");
    await page.fill("#effective_from", "2026-01-01");
    await page.getByRole("button", { name: "Create rule (pending approval)" }).click();
    await page.getByText("Another manager must approve it").waitFor();
    await page.reload();
    const rule = page.locator("li", { hasText: `Reps 5% ${uniq}` });
    await rule.getByRole("button", { name: "Approve" }).click();
    await rule.getByRole("button", { name: "Confirm", exact: true }).click();
    await rule.getByText("Approved").first().waitFor();
    await shot(page, "20-commission-rules");
  });
});

await step("rep creates a lead and a deal from it", async () => {
  await as("rep@novatek.test", async (page) => {
    await page.goto(`${BASE}/app/leads/new`);
    await page.fill("#company_name", company);
    await page.fill("#website", `orchid-${uniq}.com`);
    await page.fill("#contact_name", "Hira Shah");
    await page.fill("#email", `hira@orchid-${uniq}.com`);
    await page.selectOption("#service_id", { label: "E-Commerce Development" });
    await page.fill("#estimated_value", "8000");
    await page.selectOption("#source_id", { label: "Referral" });
    await page.getByRole("button", { name: /Create lead|Save/ }).click();
    await page.waitForURL(/\/app\/leads\/[0-9a-f-]{36}$/);
    state.leadUrl = page.url();
    await page.getByRole("link", { name: "Create deal" }).click();
    await page.waitForURL(/\/app\/deals\/new\?lead=/);
    assert.match(await page.inputValue("#name"), new RegExp(company));
    await page.getByRole("button", { name: "Create deal" }).click();
    await page.waitForURL(/\/app\/deals\/[0-9a-f-]{36}$/);
    state.dealUrl = page.url();
    await page.getByText("projection, not revenue").waitFor();
    await shot(page, "21-deal");
  });
});

await step("rep drafts and sends a proposal; content locks", async () => {
  await as("rep@novatek.test", async (page) => {
    await page.goto(state.dealUrl);
    await page.getByText("New proposal").click();
    await page.fill("#scope", "Shopify store, 40 products, payments and shipping setup.");
    await page.fill("#timeline", "4 weeks");
    await page.fill("#expiry_date", "2099-12-31");
    await page.getByRole("button", { name: "Create draft proposal" }).click();
    await page.waitForURL(/\/app\/proposals\/[0-9a-f-]{36}$/);
    state.proposalUrl = page.url();
    await confirmAction(page, "Mark as sent", { confirm: "Mark as sent" });
    await page.getByText("Client link").waitFor();
    state.publicLink = (await page.locator("p.font-mono").first().innerText()).trim();
    assert.match(state.publicLink, /\/p\/[0-9a-f]{64}$/);
    assert.equal(await page.getByRole("link", { name: "Edit draft" }).count(), 0);
    await shot(page, "22-proposal-sent");
  });
});

await step("link-preview bots do not count as a view; the client's real view and acceptance are recorded", async () => {
  const path = new URL(state.publicLink).pathname;
  const bot = await browser.newContext({ userAgent: "WhatsApp/2.23.20 A" });
  const bp = await bot.newPage();
  await bp.goto(`${BASE}${path}`);
  await bp.getByText("Open the link in your browser").waitFor();
  await bot.close();

  const page = await newPage({ width: 390, height: 844 });
  await page.goto(`${BASE}${path}`);
  await page.getByText("Shopify store, 40 products").waitFor();
  await shot(page, "23-proposal-public-mobile");
  await page.fill("#respondent", "Hira Shah");
  await page.check('input[type="checkbox"]');
  await page.getByRole("button", { name: "Accept proposal" }).click();
  await page.getByText("Accepted by Hira Shah").waitFor();
  await page.context().close();

  await as("rep@novatek.test", async (rep) => {
    await rep.goto(state.proposalUrl);
    await rep.getByText("by Hira Shah on the link").waitFor();
    assert.ok(await rep.getByText("1×").isVisible(), "exactly one real view recorded");
    await rep.goto(`${BASE}/app/notifications`);
    await rep.getByText(/Proposal accepted/).first().waitFor();
  });
});

await step("rep marks the deal won: lead → Won, client created, 5% commission estimated", async () => {
  await as("rep@novatek.test", async (page) => {
    await page.goto(state.dealUrl);
    await confirmAction(page, "Mark won", { input: "9000", confirm: "Mark won" });
    await page.getByText(/Won on/).waitFor();
    await page.getByText("$450").waitFor(); // 5% of 9,000
    await page.getByText("Estimated").first().waitFor();
    await page.goto(state.leadUrl);
    await page.getByText("View client record").click();
    await page.waitForURL(/\/app\/clients\/[0-9a-f-]{36}$/);
    state.clientUrl = page.url();
    await page.getByRole("heading", { name: company }).waitFor();
    await shot(page, "24-client");
  });
});

await step("rep cannot approve commissions; admin approves and pays with a reference", async () => {
  await as("rep@novatek.test", async (page) => {
    await page.goto(`${BASE}/app/commissions`);
    await page.getByText("$450").first().waitFor();
    assert.equal(await page.getByRole("button", { name: "Approve" }).count(), 0);
  });
  await as("admin@novatek.test", async (page) => {
    await page.goto(`${BASE}/app/commissions?scope=all&status=estimated`);
    const row = page.locator("li", { hasText: company });
    await row.getByRole("button", { name: "Approve" }).click();
    await row.getByRole("button", { name: "Approve" }).last().click();
    await row.waitFor({ state: "detached" }); // leaves the "estimated" list once the server confirms
    await page.goto(`${BASE}/app/commissions?scope=all&status=approved`);
    const row2 = page.locator("li", { hasText: company });
    await row2.getByRole("button", { name: "Mark paid" }).click();
    await row2.locator("input").fill("HBL-TX-55821");
    await row2.getByRole("button", { name: "Mark paid" }).last().click();
    await row2.waitFor({ state: "detached" });
    await page.goto(`${BASE}/app/commissions?scope=all&status=paid`);
    await page.getByText("ref HBL-TX-55821").waitFor();
    await shot(page, "25-commissions");
  });
});

await step("CTO creates a project for the client, adds a developer and a task", async () => {
  await as("cto@novatek.test", async (page) => {
    await page.goto(`${BASE}/app/projects/new?client=${state.clientUrl.split("/").pop()}`);
    await page.fill("#name", `${company} store build`);
    await page.selectOption("#status", "active");
    await page.getByRole("button", { name: "Create project" }).click();
    await page.waitForURL(/\/app\/projects\/[0-9a-f-]{36}$/);
    state.projectUrl = page.url();
    await page.selectOption("#user_id", { label: "Hamza Dev" });
    await page.fill("#role", "Shopify developer");
    await page.getByRole("button", { name: "Add member" }).click();
    await page.getByText("Shopify developer").waitFor();
    await page.goto(`${BASE}/app/tasks/new?project=${state.projectUrl.split("/").pop()}`);
    await page.fill("#title", "Configure payment gateway");
    await page.selectOption("#kind", "technical");
    await page.selectOption("#assignee_id", { label: "Hamza Dev" });
    await page.getByRole("button", { name: "Create task" }).click();
    await page.waitForURL(/\/app\/tasks\/[0-9a-f-]{36}$/);
  });
});

await step("developer sees the task on their dashboard, completes it; project reaches 100%", async () => {
  await as("dev@novatek.test", async (page) => {
    await page.getByText("Configure payment gateway").first().waitFor();
    await shot(page, "26-dev-dashboard");
    await page.goto(`${BASE}/app/tasks`);
    const row = page.locator("li", { hasText: "Configure payment gateway" });
    await row.locator("select").selectOption("completed");
    await page.waitForTimeout(1200);
    await page.goto(state.projectUrl);
    await page.getByText("100%").first().waitFor();
    // developers can't see deals or commissions of others
    await page.goto(`${BASE}/app/deals`);
    await page.waitForURL(/\/app\/denied/);
  });
});

await step("rep schedules a meeting on the lead with the COO; COO is invited; lead timeline updated", async () => {
  await as("rep@novatek.test", async (page) => {
    await page.goto(`${BASE}/app/meetings/new?lead=${state.leadUrl.split("/").pop()}`);
    await page.fill("#starts_at", "2099-01-15T15:00");
    await page.fill("#meeting_link", "https://meet.google.com/abc-defg-hij");
    await page.locator("label", { hasText: "Omar Farooq" }).locator("input").check();
    await page.getByRole("button", { name: "Schedule meeting" }).click();
    await page.waitForURL(/\/app\/meetings\/[0-9a-f-]{36}$/);
    await page.getByText("15 Jan 2099").waitFor(); // shown in company time, as entered
    assert.equal(await page.getByRole("button", { name: "Mark completed" }).count(), 0, "can't complete before it starts");
    await page.goto(state.leadUrl);
    await page.getByText(/scheduled a meeting/).waitFor();
  });
  await as("coo@novatek.test", async (page) => {
    await page.goto(`${BASE}/app/notifications`);
    await page.getByText(/Meeting: Call with/).first().waitFor();
  });
});

await step("CMO creates a campaign and a published landing page", async () => {
  await as("cmo@novatek.test", async (page) => {
    await page.goto(`${BASE}/app/campaigns/new`);
    await page.fill("#name", `Schools ${uniq}`);
    await page.fill("#utm_campaign", `schools-${uniq}`);
    await page.selectOption("#status", "active");
    await page.fill("#spend", "200");
    await page.getByRole("button", { name: "Create campaign" }).click();
    await page.waitForURL(/\/app\/campaigns\/[0-9a-f-]{36}$/);
    state.campaignUrl = page.url();
    await page.goto(`${BASE}/app/landing-pages/new`);
    await page.fill("#slug", `schools-${uniq}`);
    await page.selectOption("#status", "published");
    await page.selectOption("#campaign_id", { label: `Schools ${uniq}` });
    await page.fill("#headline", "Online admissions for your school");
    await page.fill("#subheadline", "Accept applications and fees online.");
    await page.fill("#benefits", "Admission forms\nFee payments\nParent portal");
    await page.fill("#faq", "How long does it take? | Usually 4–6 weeks.");
    await page.getByRole("button", { name: "Create page" }).click();
    await page.waitForURL(/\/app\/landing-pages\/[0-9a-f-]{36}$/);
  });
});

await step("visitor submits the landing page form; lead is attributed to the campaign", async () => {
  const page = await newPage();
  await page.goto(`${BASE}/l/schools-${uniq}`);
  await page.getByText("Online admissions for your school").first().waitFor();
  await shot(page, "27-landing-page");
  await page.fill("#name", "Rabia Khan");
  await page.fill("#company", `Beacon School ${uniq}`);
  await page.fill("#email", `rabia.${uniq}@beacon.edu.pk`);
  await page.fill("#message", "We want online admissions for next term.");
  await page.check('input[name="consent"]');
  await page.waitForTimeout(3200);
  await page.getByRole("button", { name: "Get a free consultation" }).click();
  await page.getByText("Enquiry received").waitFor({ timeout: 15000 });
  await page.context().close();
  await as("cmo@novatek.test", async (p) => {
    await p.goto(state.campaignUrl);
    await p.getByText(`Beacon School ${uniq}`).waitFor();
    await p.getByText("$200", { exact: true }).first().waitFor(); // cost per lead = 200 / 1
    await shot(p, "28-campaign");
  });
});

await step("COO imports a CSV: invalid rows are shown and only skipped on request", async () => {
  await as("coo@novatek.test", async (page) => {
    await page.goto(`${BASE}/app/leads/import`);
    const csv = `company_name,email,country,service\nImport One ${uniq},one@imp-${uniq}.com,PK,Web Development\nImport Two ${uniq},two@imp-${uniq}.com,United Arab Emirates,\n,bad-email,Narnia,\n`;
    const file = `${SHOTS}/import-${uniq}.csv`;
    fs.writeFileSync(file, csv);
    await page.setInputFiles('input[type="file"]', file);
    await page.getByText("2 valid").waitFor();
    await page.getByText("1 with errors").waitFor();
    assert.ok(await page.getByRole("button", { name: "Import 2 leads" }).isDisabled());
    await shot(page, "29-import-preview");
    await page.getByLabel(/Skip the 1 row/).check();
    await page.getByRole("button", { name: "Import 2 leads" }).click();
    await page.getByText(/Imported 2 leads/).waitFor();
    await page.goto(`${BASE}/app/leads?q=${encodeURIComponent(`Import One ${uniq}`)}`);
    await page.getByText(`Import One ${uniq}`).first().waitFor();
  });
});

await step("exports need a password; CMO downloads a leads CSV; reps can't export", async () => {
  await as("cmo@novatek.test", async (page) => {
    const before = await page.request.get(`${BASE}/app/export/leads`);
    assert.equal(before.status(), 403);
    await page.goto(`${BASE}/app/export`);
    await page.getByRole("button", { name: "Unlock exports" }).click();
    await page.locator('input[type="password"]').fill("wrong-password");
    await page.getByRole("button", { name: "Confirm", exact: true }).click();
    await page.getByText("Password is incorrect.").waitFor();
    await page.locator('input[type="password"]').fill(PASSWORD);
    await page.getByRole("button", { name: "Confirm", exact: true }).click();
    await page.getByText("Downloads unlocked").waitFor();
    const res = await page.request.get(`${BASE}/app/export/leads`);
    assert.equal(res.status(), 200);
    const body = await res.text();
    assert.match(body, /company_name/);
    assert.match(body, new RegExp(`Beacon School ${uniq}`));
  });
  await as("rep@novatek.test", async (page) => {
    const res = await page.request.get(`${BASE}/app/export/leads`);
    assert.equal(res.status(), 403);
  });
});

await step("CEO portal, analytics and reports render from real data; CEO can't change settings", async () => {
  await as("ceo@novatek.test", async (page) => {
    await page.getByText("Department performance").waitFor();
    await shot(page, "30-ceo-dashboard");
    await page.goto(`${BASE}/app/analytics?range=90d`);
    await page.getByText("Conversion funnel").waitFor();
    await shot(page, "31-analytics");
    await page.goto(`${BASE}/app/reports/executive`);
    await page.getByText("Headline metrics").waitFor();
    const csv = await page.request.get(`${BASE}/app/reports/executive/csv?range=30d`);
    assert.equal(csv.status(), 200);
    await page.goto(`${BASE}/app/settings`);
    await page.waitForURL(/\/app\/denied/);
  });
});

await step("COO, CTO and CMO portals render", async () => {
  for (const [email, path, text] of [["coo@novatek.test", "/app/portals/coo", "Team workload"], ["cto@novatek.test", "/app/portals/cto", "Project progress"], ["cmo@novatek.test", "/app/portals/cmo", "Lead quality"]]) {
    await as(email, async (page) => {
      await page.goto(`${BASE}${path}`);
      await page.getByText(text).first().waitFor();
      await shot(page, `32-${path.split("/").pop()}-portal`);
    });
  }
});

await step("reps are denied analytics and other people's portals by URL", async () => {
  await as("rep@novatek.test", async (page) => {
    for (const p of ["/app/analytics", "/app/portals/ceo", "/app/settings/crm", "/app/admin/roles", "/app/reports"]) {
      await page.goto(`${BASE}${p}`);
      await page.waitForURL(/\/app\/denied/);
    }
  });
});

await step("global search finds the rep's own lead and nothing of others", async () => {
  await as("rep@novatek.test", async (page) => {
    await page.getByLabel("Search everything").fill(company.slice(0, 14));
    await page.getByRole("option", { name: new RegExp(company) }).first().waitFor();
    await page.getByLabel("Search everything").fill(`Beacon School ${uniq}`);
    await page.getByText("No results you have access to.").waitFor();
  });
});

await step("admin edits branding text; public site updates; logo file is untouched", async () => {
  await as("admin@novatek.test", async (page) => {
    await page.goto(`${BASE}/app/settings`);
    await page.fill("#tagline", `Software that moves business forward · ${uniq}`);
    await page.getByRole("button", { name: "Save branding" }).click();
    await page.getByText("Saved.").waitFor();
    await shot(page, "33-settings-branding");
    await page.goto(`${BASE}/app/admin/roles`);
    await page.getByText("Permission matrix").waitFor();
  });
  const page = await newPage();
  for (let i = 0; i < 20; i++) { // public branding is cached up to 5 minutes; revalidated on save
    await page.goto(`${BASE}/services`);
    if (await page.getByText(uniq).count()) break;
    await page.waitForTimeout(1000);
  }
  await page.getByText(`Software that moves business forward · ${uniq}`).waitFor();
  const logo = await page.request.get(`${BASE}/brand/novatek-logo-horizontal.png`);
  const hash = createHash("sha256").update(await logo.body()).digest("hex");
  assert.equal(hash, "8609697a910a37aeaf4466bce75c88fbcd431868843d2f1b7d2e59b1145e383b");
  await page.context().close();
});

await step("reminders endpoint requires the cron secret", async () => {
  const ctx = await browser.newContext();
  const bad = await ctx.request.get(`${BASE}/api/cron/notifications`);
  assert.equal(bad.status(), 401);
  if (process.env.CRON_SECRET) {
    const good = await ctx.request.get(`${BASE}/api/cron/notifications`, { headers: { Authorization: `Bearer ${process.env.CRON_SECRET}` } });
    assert.equal(good.status(), 200);
    assert.ok((await good.json()).ok);
  }
  await ctx.close();
});

await step("mobile: rep dashboard, leads and lead detail are usable", async () => {
  await as("rep@novatek.test", async (page) => {
    await shot(page, "34-mobile-rep-dashboard");
    await page.goto(state.leadUrl);
    await shot(page, "35-mobile-lead");
    await page.getByRole("button", { name: "More" }).click();
    await page.getByRole("dialog", { name: "All sections" }).getByRole("link", { name: "Deals" }).click();
    await page.waitForURL(/\/app\/deals/);
  }, { width: 390, height: 844 });
});

await browser.close();
const failed = results.filter((r) => r[0] === "FAIL");
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
