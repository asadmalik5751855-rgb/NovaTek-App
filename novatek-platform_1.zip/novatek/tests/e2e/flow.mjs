// End-to-end flow against a running app + Supabase-compatible backend.
// Usage: BASE_URL=http://localhost:3000 SHOTS=./shots node tests/e2e/flow.mjs
// Requires `playwright` and a Chromium build (PLAYWRIGHT_BROWSERS_PATH).
import { chromium } from "playwright";
import assert from "node:assert/strict";
import fs from "node:fs";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const SHOTS = process.env.SHOTS ?? "./e2e-shots";
const PASSWORD = process.env.E2E_PASSWORD ?? "Test-Passw0rd-2026";
fs.mkdirSync(SHOTS, { recursive: true });

const browser = await chromium.launch();
const results = [];
async function step(name, fn) {
  try {
    await fn();
    results.push(["PASS", name]);
    console.log("PASS", name);
  } catch (e) {
    results.push(["FAIL", name, e.message]);
    console.log("FAIL", name, "-", e.message.split("\n")[0]);
  }
}
async function newPage(viewport = { width: 1366, height: 900 }) {
  const ctx = await browser.newContext({ viewport });
  return ctx.newPage();
}
async function login(page, email) {
  await page.goto(`${BASE}/login`);
  await page.fill("#email", email);
  await page.fill("#password", PASSWORD);
  await Promise.all([page.waitForURL(/\/app/), page.click("button[type=submit]")]);
}

const company = `Crescent Academy ${Date.now().toString(36)}`;
let leadUrl;

await step("public homepage renders the official logo image (not text)", async () => {
  const page = await newPage();
  await page.goto(BASE);
  const logo = page.locator('header img[alt="NovaTek"]');
  await logo.waitFor();
  assert.match(await logo.getAttribute("src"), /novatek-logo-horizontal\.png/);
  await page.screenshot({ path: `${SHOTS}/01-home.png`, fullPage: true });
  await page.context().close();
});

await step("visitor submits an enquiry that becomes a real CRM lead (with UTM)", async () => {
  const page = await newPage();
  await page.goto(`${BASE}/contact?service=ecommerce&utm_source=linkedin&utm_campaign=launch`);
  await page.fill("#name", "Ayesha Malik");
  await page.fill("#company", company);
  await page.fill("#email", `ayesha.${Date.now()}@crescent.edu.pk`);
  await page.fill("#phone", "+92 321 5550101");
  await page.selectOption("#country", "PK");
  await page.selectOption("#budget", "5k_15k");
  await page.fill("#message", "We need an online admissions and fee payment portal for our school.");
  await page.check('input[name="consent"]');
  await page.screenshot({ path: `${SHOTS}/02-contact-filled.png`, fullPage: true });
  await page.waitForTimeout(3200); // human-speed submission
  await page.click("button[type=submit]");
  await page.getByText("Enquiry received").waitFor({ timeout: 10000 });
  await page.screenshot({ path: `${SHOTS}/03-contact-success.png` });
  await page.context().close();
});

await step("server rejects a bot-speed submission (no fake success)", async () => {
  const page = await newPage();
  await page.goto(`${BASE}/contact`);
  await page.fill("#name", "Bot");
  await page.fill("#company", "Spam Co");
  await page.fill("#email", `bot${Date.now()}@spam.io`);
  await page.fill("#message", "Buy cheap things now please");
  await page.check('input[name="consent"]');
  await page.click("button[type=submit]");
  await page.getByText("Please review your details and send again.").waitFor({ timeout: 10000 });
  assert.equal(await page.getByText("Enquiry received").count(), 0);
  await page.context().close();
});

await step("anonymous visitor is redirected from /app to login", async () => {
  const page = await newPage();
  await page.goto(`${BASE}/app/leads`);
  assert.match(page.url(), /\/login\?next=%2Fapp%2Fleads/);
  await page.screenshot({ path: `${SHOTS}/04-login.png` });
  await page.context().close();
});

await step("wrong password gives a generic error", async () => {
  const page = await newPage();
  await page.goto(`${BASE}/login`);
  await page.fill("#email", "coo@novatek.test");
  await page.fill("#password", "wrong-password");
  await page.click("button[type=submit]");
  await page.getByText("Incorrect email or password.").waitFor();
  await page.context().close();
});

await step("COO sees the inbound notification and the scored lead", async () => {
  const page = await newPage();
  await login(page, "coo@novatek.test");
  await page.screenshot({ path: `${SHOTS}/05-coo-dashboard.png`, fullPage: true });
  await page.goto(`${BASE}/app/notifications`);
  await page.getByText(`New website lead: ${company}`).click();
  await page.waitForURL(/\/app\/leads\/[0-9a-f-]{36}$/);
  leadUrl = page.url();
  await page.getByText("utm_campaign").waitFor();
  assert.ok(await page.getByText("launch", { exact: true }).isVisible());
  assert.ok(await page.getByText("Campaign", { exact: true }).first().isVisible(), "source should be Campaign");
  // PK target(15) + e-commerce service(10) + budget known(10) + budget >=5k(15) + complete contact(5) + no website(10) = 65
  assert.ok(await page.getByText("65/100").isVisible(), "score should be 65");
  await page.screenshot({ path: `${SHOTS}/06-lead-detail.png`, fullPage: true });
  await page.context().close();
});

await step("sales rep cannot see an unassigned lead, even by direct URL (IDOR)", async () => {
  const page = await newPage();
  await login(page, "rep@novatek.test");
  await page.goto(`${BASE}/app/leads`);
  assert.equal(await page.getByText(company).count(), 0);
  // Responses stream (loading UI), so assert on what is rendered, not the status code.
  await page.goto(leadUrl);
  await page.getByText("Page not found").waitFor();
  assert.equal(await page.getByText(company).count(), 0);
  await page.context().close();
});

await step("COO assigns the lead, changes status and logs a note — timeline records all", async () => {
  const page = await newPage();
  await login(page, "coo@novatek.test");
  await page.goto(leadUrl);
  await page.selectOption('select[aria-label="Assigned to"]', { label: "Sana Rep" });
  await page.getByText("assigned it to Sana Rep").waitFor({ timeout: 10000 });
  await page.selectOption('select[aria-label="Lead status"]', { label: "Qualified" });
  await page.getByText("moved it from New to Qualified").waitFor({ timeout: 10000 });
  await page.fill('textarea[aria-label="Activity details"]', "Budget confirmed on intro email. Wants portal before next admissions cycle.");
  await page.getByRole("button", { name: "Log note" }).click();
  await page.getByText("Budget confirmed on intro email.").waitFor({ timeout: 10000 });
  await page.screenshot({ path: `${SHOTS}/07-lead-timeline.png`, fullPage: true });
  await page.context().close();
});

await step("rep now sees the lead, gets notified, and moves it on the pipeline", async () => {
  const page = await newPage();
  await login(page, "rep@novatek.test");
  await page.goto(`${BASE}/app/notifications`);
  await page.getByText(`Lead assigned to you: ${company}`).waitFor();
  await page.goto(`${BASE}/app/pipeline`);
  const card = page.locator("li", { hasText: company }).first();
  await card.locator("select").selectOption({ label: "Move to: Contacted" });
  await page.waitForTimeout(1500);
  await page.reload();
  const contacted = page.locator('section[aria-label="Contacted"]');
  await contacted.getByText(company).waitFor();
  await page.screenshot({ path: `${SHOTS}/08-pipeline.png`, fullPage: true });
  await page.context().close();
});

await step("rep is denied admin pages and admin nav is hidden", async () => {
  const page = await newPage();
  await login(page, "rep@novatek.test");
  assert.equal(await page.getByRole("link", { name: "Users", exact: true }).count(), 0);
  await page.goto(`${BASE}/app/admin/users`);
  await page.waitForURL(/\/app\/denied/);
  await page.goto(`${BASE}/app/admin/audit`);
  await page.waitForURL(/\/app\/denied/);
  await page.getByText(/have access to that page/).waitFor();
  await page.context().close();
});

await step("duplicate enquiry is flagged, not merged", async () => {
  const page = await newPage();
  await page.goto(`${BASE}/contact`);
  await page.fill("#name", "Ayesha M.");
  await page.fill("#company", `The ${company} (Pvt) Ltd`);
  await page.fill("#email", `other.${Date.now()}@gmail.com`);
  await page.fill("#message", "Following up on the admissions portal enquiry.");
  await page.check('input[name="consent"]');
  await page.waitForTimeout(3200);
  await page.click("button[type=submit]");
  await page.getByText("Enquiry received").waitFor({ timeout: 10000 });
  await page.context().close();

  const coo = await newPage();
  await login(coo, "coo@novatek.test");
  await coo.goto(`${BASE}/app/leads?q=${encodeURIComponent("(Pvt)")}`);
  await coo.goto(`${BASE}/app/leads`);
  const row = coo.locator("tr", { hasText: `The ${company}` });
  await row.getByText("Possible duplicate").waitFor();
  await coo.screenshot({ path: `${SHOTS}/09-leads-list.png`, fullPage: true });
  await coo.context().close();
});

await step("super admin sees audit log with lead and auth events", async () => {
  const page = await newPage();
  await login(page, "admin@novatek.test");
  await page.goto(`${BASE}/app/admin/audit`);
  for (const a of ["lead.created", "lead.assigned", "lead.status_changed", "auth.login"]) {
    await page.locator("td", { hasText: a }).first().waitFor();
  }
  await page.screenshot({ path: `${SHOTS}/10-audit.png`, fullPage: true });
  await page.context().close();
});

await step("super admin creates a user with a role; they can sign in", async () => {
  const page = await newPage();
  await login(page, "admin@novatek.test");
  await page.goto(`${BASE}/app/admin/users/new`);
  const email = `dev${Date.now()}@novatek.test`;
  await page.fill("#full_name", "Hamza Developer");
  await page.fill("#email", email);
  await page.fill("#password", PASSWORD);
  await page.locator("label").filter({ has: page.getByText("Developer", { exact: true }) }).locator("input").check();
  await page.screenshot({ path: `${SHOTS}/11-create-user.png`, fullPage: true });
  await page.getByRole("button", { name: "Create account" }).click();
  await page.waitForURL(/\/app\/admin\/users\/[0-9a-f-]{36}$/);
  await page.getByRole("heading", { name: "Hamza Developer" }).waitFor();
  await page.context().close();

  const dev = await newPage();
  await login(dev, email);
  await dev.getByText("My open tasks").waitFor(); // developers land on their work dashboard
  assert.equal(await dev.getByRole("link", { name: "Leads" }).count(), 0);
  await dev.context().close();
});

await step("mobile layout: bottom navigation on dashboard", async () => {
  const page = await newPage({ width: 390, height: 844 });
  await login(page, "rep@novatek.test");
  await page.locator('nav[aria-label="Quick"]').waitFor();
  await page.screenshot({ path: `${SHOTS}/12-mobile-dashboard.png`, fullPage: true });
  await page.goto(BASE);
  await page.screenshot({ path: `${SHOTS}/13-mobile-home.png`, fullPage: true });
  await page.context().close();
});

await browser.close();
const failed = results.filter((r) => r[0] === "FAIL");
console.log(`\n${results.length - failed.length}/${results.length} passed`);
process.exit(failed.length ? 1 : 0);
