import { afterAll, describe, expect, it } from "vitest";
import { normalizeCompanyName, normalizeDomain, normalizeEmail, phoneKey, temperatureFor } from "@/lib/leads/normalize";
import { asOwner, pool } from "./helpers";

afterAll(() => pool.end());

const names = ["Zenith Traders (Pvt.) Ltd.", "The Acme Co.", "A&B Foods LLC", "  Nova   Systems  FZ-LLC ", "", "Company Name Inc"];
const domains = ["https://www.Example.com/path?q=1", "example.com.", "//cdn.site.io:8080", "localhost", "user@mail.org", "not a url", "", "HTTP://Sub.Domain.co.uk#x"];
const emails = ["  Foo@Bar.COM ", "", "a@b.c"];
const phones = ["+92 300 1234567", "0300-1234567", "123", "(050) 123 4567", ""];

describe("SQL ↔ TypeScript normalization parity", () => {
  it.each(names)("company name %j", async (n) => {
    const sql = await asOwner(async (c) => (await c.query("select normalize_company_name($1) v", [n])).rows[0].v);
    expect(normalizeCompanyName(n)).toBe(sql);
  });
  it.each(domains)("domain %j", async (d) => {
    const sql = await asOwner(async (c) => (await c.query("select normalize_domain($1) v", [d])).rows[0].v);
    expect(normalizeDomain(d)).toBe(sql);
  });
  it.each(emails)("email %j", async (e) => {
    const sql = await asOwner(async (c) => (await c.query("select normalize_email($1) v", [e])).rows[0].v);
    expect(normalizeEmail(e)).toBe(sql);
  });
  it.each(phones)("phone %j", async (p) => {
    const sql = await asOwner(async (c) => (await c.query("select phone_key($1) v", [p])).rows[0].v);
    expect(phoneKey(p)).toBe(sql);
  });
  it.each([0, 30, 31, 60, 61, 80, 81, 100])("temperature %i", async (s) => {
    const sql = await asOwner(async (c) => (await c.query("select temperature_for($1) v", [s])).rows[0].v);
    expect(temperatureFor(s)).toBe(sql);
  });
});
