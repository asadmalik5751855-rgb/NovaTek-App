import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { asOwner, asRole, asUser, createUser, ipHash, pool, sourceId, statusId, uniq } from "./helpers";

let admin: string, cmo: string, coo: string, repA: string, repB: string, salesMgr: string, dev: string;
let manual: string, newStatus: string, qualifiedStatus: string;

async function insert(uid: string, table: string, fields: Record<string, unknown>) {
  return asUser(uid, async (c) => {
    const keys = Object.keys(fields);
    const { rows } = await c.query(
      `insert into ${table}(${keys.join(",")}) values (${keys.map((_, i) => `$${i + 1}`).join(",")}) returning *`,
      Object.values(fields).map((v) => (v && typeof v === "object" ? JSON.stringify(v) : v)),
    );
    return rows[0];
  });
}
const owner = <T>(sql: string, params: unknown[] = []) => asOwner(async (c) => (await c.query(sql, params)).rows as T[]);

beforeAll(async () => {
  [admin, cmo, coo, repA, repB, salesMgr, dev] = await Promise.all([
    createUser(["super_admin"]), createUser(["cmo"]), createUser(["coo"]), createUser(["sales_rep"]),
    createUser(["sales_rep"]), createUser(["sales_manager"]), createUser(["developer"]),
  ]);
  manual = await sourceId("manual");
  newStatus = await statusId("new");
  qualifiedStatus = await statusId("qualified");
});
afterAll(() => pool.end());

describe("campaigns and landing pages", () => {
  it("leads with a campaign's utm are attributed automatically (any casing)", async () => {
    const slug = uniq("spring-").toLowerCase();
    const c = await insert(cmo, "campaigns", { name: "Spring launch", utm_campaign: slug, channel: "social", status: "active", spend: 300 });
    const l = await insert(coo, "leads", { company_name: uniq("Utm "), source_id: manual, status_id: newStatus, utm_campaign: slug.toUpperCase() });
    const rows = await owner("select 1 from campaign_leads where campaign_id=$1 and lead_id=$2", [c.id, l.id]);
    expect(rows).toHaveLength(1);
    await expect(insert(repA, "campaigns", { name: "x", utm_campaign: uniq("x-").toLowerCase() })).rejects.toThrow(/row-level security/);
  });

  it("published landing page form creates a landing-page lead linked to its campaign and service", async () => {
    const slug = uniq("lp-").toLowerCase();
    const camp = await insert(cmo, "campaigns", { name: "Schools Q4", utm_campaign: uniq("schools-").toLowerCase() });
    const [{ id: svc }] = await owner<{ id: string }>("select id from services where key='ecommerce'");
    const page = await insert(cmo, "landing_pages", {
      slug, campaign_id: camp.id, service_id: svc, headline: "Online admissions for schools", status: "published",
      benefits: ["Fast", "Secure"],
    });
    expect(page.published_at).toBeTruthy();

    // Anonymous visitors can read published pages only.
    const pub = await asRole("anon", null, async (c) => (await c.query("select slug from landing_pages where slug=$1", [slug])).rows);
    expect(pub).toHaveLength(1);
    const draft = await insert(cmo, "landing_pages", { slug: uniq("draft-").toLowerCase(), headline: "Not yet live" });
    const hidden = await asRole("anon", null, async (c) => (await c.query("select slug from landing_pages where id=$1", [draft.id])).rows);
    expect(hidden).toHaveLength(0);

    const r = await asRole("service_role", null, async (c) =>
      (await c.query("select submit_public_lead($1) r", [{
        name: "Hina", company: uniq("Bloom School "), email: `${uniq("h")}@bloom.edu`, ip_hash: ipHash(), landing_page: slug,
      }])).rows[0].r);
    expect(r.ok).toBe(true);
    const [lead] = await owner<{ key: string; service_id: string; utm_campaign: string; source_reference: string }>(
      "select s.key, l.service_id, l.utm_campaign, l.source_reference from leads l join lead_sources s on s.id=l.source_id where l.id=$1", [r.lead_id]);
    expect(lead).toMatchObject({ key: "landing_page", service_id: svc, utm_campaign: camp.utm_campaign, source_reference: `/l/${slug}` });
    const link = await owner("select 1 from campaign_leads where campaign_id=$1 and lead_id=$2", [camp.id, r.lead_id]);
    expect(link).toHaveLength(1);
  });

  it("case studies naming a client can't be published without recorded permission", async () => {
    await expect(insert(cmo, "site_entries", {
      kind: "case_study", slug: uniq("cs-").toLowerCase(), title: "Admissions portal", client_name: "Real School",
      summary: "We built an admissions portal.", status: "published",
    })).rejects.toThrow(/check constraint/);
    const ok = await insert(cmo, "site_entries", {
      kind: "case_study", slug: uniq("cs-").toLowerCase(), title: "Admissions portal", client_name: "Real School", client_permission: true,
      summary: "We built an admissions portal.", status: "published",
    });
    expect(ok.published_at).toBeTruthy();
    await expect(insert(repA, "site_entries", { kind: "portfolio", slug: uniq("p-").toLowerCase(), title: "Nope", summary: "Not allowed here" }))
      .rejects.toThrow(/row-level security/);
  });
});

describe("analytics respect RLS", () => {
  it("a rep's numbers only include their own leads; managers see the company", async () => {
    const from = new Date(Date.now() - 60e3).toISOString();
    for (let i = 0; i < 3; i++) await insert(repA, "leads", { company_name: uniq("A "), source_id: manual, status_id: newStatus, assigned_to: repA });
    await insert(repA, "leads", { company_name: uniq("AQ "), source_id: manual, status_id: qualifiedStatus, assigned_to: repA });
    for (let i = 0; i < 2; i++) await insert(salesMgr, "leads", { company_name: uniq("B "), source_id: manual, status_id: newStatus, assigned_to: repB });
    const to = new Date(Date.now() + 60e3).toISOString();
    const sum = (uid: string) => asUser(uid, async (c) => (await c.query("select analytics_summary($1,$2) s", [from, to])).rows[0].s);
    const a = await sum(repA);
    expect(a.leads).toBe(4);
    expect(a.qualified).toBe(1);
    const m = await sum(salesMgr);
    expect(m.leads).toBeGreaterThanOrEqual(6);
    const d = await sum(dev);
    expect(d.leads).toBe(0);
  });

  it("breakdown by owner and time series are consistent with the summary", async () => {
    const from = new Date(Date.now() - 864e5).toISOString();
    const to = new Date(Date.now() + 864e5).toISOString();
    const rows = await asUser(salesMgr, async (c) => (await c.query("select * from analytics_breakdown('owner',$1,$2)", [from, to])).rows);
    const total = rows.reduce((s: number, r: { leads: string }) => s + Number(r.leads), 0);
    const summary = await asUser(salesMgr, async (c) => (await c.query("select analytics_summary($1,$2) s", [from, to])).rows[0].s);
    expect(total).toBe(summary.leads);
    const series = await asUser(salesMgr, async (c) => (await c.query("select * from analytics_timeseries($1,$2,'day','Asia/Karachi')", [from, to])).rows);
    expect(series.reduce((s: number, r: { leads: string }) => s + Number(r.leads), 0)).toBe(summary.leads);
    await expect(asUser(salesMgr, (c) => c.query("select * from analytics_breakdown('salary',$1,$2)", [from, to]))).rejects.toThrow(/unknown dimension/);
  });

  it("won revenue is reported per currency (never silently converted)", async () => {
    const from = new Date(Date.now() - 60e3).toISOString();
    const to = new Date(Date.now() + 60e3).toISOString();
    const revenue = async () => {
      const s = await asUser(salesMgr, async (c) => (await c.query("select analytics_summary($1,$2) s", [from, to])).rows[0].s);
      return Object.fromEntries(s.revenue.map((r: { currency: string; amount: number }) => [r.currency, Number(r.amount)])) as Record<string, number>;
    };
    const before = await revenue();
    const [{ id: q }] = await owner<{ id: string }>("select id from deal_stages where key='qualification'");
    for (const [cur, val] of [["USD", 1000], ["PKR", 250000]] as const) {
      const l = await insert(salesMgr, "leads", { company_name: uniq("Rev "), source_id: manual, status_id: newStatus, assigned_to: salesMgr });
      const d = await insert(salesMgr, "deals", { name: uniq("D "), lead_id: l.id, stage_id: q, value: val, currency: cur });
      await asUser(salesMgr, (c) => c.query("select mark_deal_won($1)", [d.id]));
    }
    const after = await revenue();
    expect(after.USD - (before.USD ?? 0)).toBe(1000);
    expect(after.PKR - (before.PKR ?? 0)).toBe(250000);
  });
});

describe("targets", () => {
  it("progress is computed from real records and only visible to the right people", async () => {
    const today = new Date().toISOString().slice(0, 10);
    const t = await insert(salesMgr, "employee_targets", { user_id: repB, metric: "leads_created", period_start: today, period_end: today, target_value: 5 });
    await insert(repB, "leads", { company_name: uniq("T "), source_id: manual, status_id: newStatus });
    await insert(repB, "leads", { company_name: uniq("T "), source_id: manual, status_id: newStatus });
    const actual = (uid: string) => asUser(uid, async (c) => (await c.query("select target_actual($1) v", [t.id])).rows[0].v);
    expect(Number(await actual(repB))).toBe(2);
    expect(await actual(repA)).toBeNull();
    await expect(insert(repA, "employee_targets", { user_id: repA, metric: "deals_won", period_start: today, period_end: today, target_value: 99 }))
      .rejects.toThrow(/row-level security/);
  });
});

describe("integrations", () => {
  it("cannot be enabled without a successful server-side check; only settings managers see them", async () => {
    await expect(asUser(admin, (c) => c.query("update integrations set enabled=true where key='stripe'"))).rejects.toThrow(/connection check/);
    const visible = await asUser(coo, async (c) => (await c.query("select key from integrations")).rows);
    expect(visible).toHaveLength(0);
    await asRole("service_role", null, (c) => c.query("select record_integration_check('stripe','ok',null,$1)", [admin]));
    await asUser(admin, (c) => c.query("update integrations set enabled=true where key='stripe'"));
    // a failed re-check switches it off
    await asRole("service_role", null, (c) => c.query("select record_integration_check('stripe','error','401 Unauthorized',$1)", [admin]));
    const [row] = await owner<{ enabled: boolean }>("select enabled from integrations where key='stripe'");
    expect(row.enabled).toBe(false);
  });

  it("AI generations can only be written by the server", async () => {
    await expect(insert(repA, "ai_generations", { feature: "outreach_draft", model: "x", output: "fake" })).rejects.toThrow(/permission denied/);
  });
});

describe("CSV import and search", () => {
  it("imports atomically with source Import, flags duplicates, and rolls back entirely on a bad row", async () => {
    const domain = `${uniq("imp")}.com`;
    await insert(coo, "leads", { company_name: uniq("Existing "), source_id: manual, status_id: newStatus, website: domain });
    const rows = [
      { company_name: uniq("Fresh "), email: `a@${uniq("f")}.com` },
      { company_name: uniq("Dupe "), website: `https://${domain}` },
    ];
    const preview = await asUser(coo, async (c) => (await c.query("select preview_duplicates($1) p", [JSON.stringify(rows)])).rows[0].p);
    expect(preview).toEqual([{ row: 1 }]);
    const r = await asUser(coo, async (c) => (await c.query("select import_leads($1) r", [JSON.stringify(rows)])).rows[0].r);
    expect(r).toMatchObject({ inserted: 2, possible_duplicates: 1 });
    const [{ n }] = await owner<{ n: number }>(
      "select count(*)::int n from leads l join lead_sources s on s.id=l.source_id where s.key='import' and l.source_reference like 'CSV import%' and l.created_by=$1", [coo]);
    expect(n).toBeGreaterThanOrEqual(2);

    const bad = [{ company_name: uniq("Ok ") }, { company_name: "" }];
    const before = (await owner<{ n: number }>("select count(*)::int n from leads"))[0].n;
    await expect(asUser(coo, (c) => c.query("select import_leads($1)", [JSON.stringify(bad)]))).rejects.toThrow();
    const after = (await owner<{ n: number }>("select count(*)::int n from leads"))[0].n;
    expect(after).toBe(before);

    await expect(asUser(repA, (c) => c.query("select import_leads($1)", [JSON.stringify(rows)]))).rejects.toThrow(/Not allowed/);
    await expect(asUser(repA, (c) => c.query("select preview_duplicates($1)", [JSON.stringify(rows)]))).rejects.toThrow(/Not allowed/);
  });

  it("global search only returns what the caller may see, and treats wildcards literally", async () => {
    const name = uniq("Searchable Zephyr ");
    await insert(salesMgr, "leads", { company_name: name, source_id: manual, status_id: newStatus, assigned_to: repB });
    const search = (uid: string, q: string) => asUser(uid, async (c) => (await c.query("select * from global_search($1)", [q])).rows);
    expect((await search(repB, name)).map((r) => r.title)).toContain(name);
    expect((await search(repA, name)).map((r) => r.title)).not.toContain(name);
    expect(await search(repA, "%")).toEqual([]);
  });
});
