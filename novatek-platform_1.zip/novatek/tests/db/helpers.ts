import { Pool, type PoolClient } from "pg";

export const TEST_DB_URL =
  process.env.TEST_DATABASE_URL ?? "postgres://claude:claude@localhost:5432/novatek_test";

export const pool = new Pool({ connectionString: TEST_DB_URL, max: 4 });

/** Run as the database owner (bypasses RLS) — for test setup only. */
export async function asOwner<T>(fn: (c: PoolClient) => Promise<T>): Promise<T> {
  const c = await pool.connect();
  try {
    return await fn(c);
  } finally {
    c.release();
  }
}

type Role = "anon" | "authenticated" | "service_role";

/** Run inside a transaction as a PostgREST role with the given JWT subject (RLS applies). */
export async function asRole<T>(role: Role, sub: string | null, fn: (c: PoolClient) => Promise<T>): Promise<T> {
  const c = await pool.connect();
  try {
    await c.query("begin");
    await c.query(`set local role ${role}`);
    await c.query("select set_config('request.jwt.claims', $1, true)", [
      JSON.stringify(sub ? { sub, role } : { role }),
    ]);
    const result = await fn(c);
    await c.query("commit");
    return result;
  } catch (e) {
    await c.query("rollback").catch(() => undefined);
    throw e;
  } finally {
    c.release();
  }
}

export const asUser = <T>(uid: string, fn: (c: PoolClient) => Promise<T>) => asRole("authenticated", uid, fn);

let seq = 0;
/** Create an auth user + profile and grant roles. Returns the user id. */
export async function createUser(roles: string[], opts: { status?: "active" | "disabled"; name?: string } = {}) {
  seq += 1;
  const email = `user${Date.now()}_${seq}@novatek.test`;
  return asOwner(async (c) => {
    const { rows } = await c.query(
      "insert into auth.users(email, raw_user_meta_data) values ($1, $2) returning id",
      [email, { full_name: opts.name ?? `Test User ${seq}` }],
    );
    const id = rows[0].id as string;
    for (const r of roles) {
      await c.query(
        "insert into public.user_roles(user_id, role_id) select $1, id from public.roles where key = $2",
        [id, r],
      );
    }
    if (opts.status === "disabled") {
      await c.query("update public.profiles set status = 'disabled' where id = $1", [id]);
    }
    return id;
  });
}

export async function statusId(key: string): Promise<string> {
  return asOwner(async (c) => (await c.query("select id from lead_statuses where key = $1", [key])).rows[0].id);
}

export async function sourceId(key: string): Promise<string> {
  return asOwner(async (c) => (await c.query("select id from lead_sources where key = $1", [key])).rows[0].id);
}

export function uniq(prefix: string) {
  seq += 1;
  return `${prefix}${Date.now().toString(36)}${seq}`;
}

export function ipHash() {
  return "test-ip-" + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
}
