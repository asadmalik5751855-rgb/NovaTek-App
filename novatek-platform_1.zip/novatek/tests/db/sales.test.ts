import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { asOwner, asRole, asUser, createUser, pool, sourceId, statusId, uniq } from "./helpers";

let admin: string, salesMgr: string, repA: string, repB: string, dev: string, coo: string;
let manual: string, newStatus: string, qualification: string, wonStage: string, serviceWeb: string;

async function insert(uid: string, table: string, fields: Record<string, unknown>) {
  return asUser(uid, async (c) => {
    const keys = Object.keys(fields);
    const { rows } = await c.query(
      `insert into ${table}(${keys.join(",")}) values (${keys.map((_, i) => `$${i + 1}`).join(",")}) returning *`,
      Object.values(fields),
    );
    return rows[0];
  });
}
const lead = (uid: string, f: Record<string, unknown> = {}) =>
  insert(uid, "leads", { company_name: uniq("Deal Co "), source_id: manual, status_id: newStatus, ...f });
const deal = (uid: string, f: Record<string, unknown>) =>
  insert(uid, "deals", { name: uniq("Website build "), stage_id: qualification, value: 10000, currency: "USD", probability: 25, ...f });
const owner = <T>(sql: string, params: unknown[] = []) => asOwner(async (c) => (await c.query(sql, params)).rows as T[]);

beforeAll(async () => {
  [admin, salesMgr, repA, repB, dev, coo] = await Promise.all([
    createUser(["super_admin"]), createUser(["sales_manager"]), createUser(["sales_rep"]), createUser(["sales_rep"]),
    createUser(["developer"]), createUser(["coo"]),
  ]);
  manual = await sourceId("manual");
  newStatus = await statusId("new");
  [{ id: qualification }] = await owner<{ id: string }>("select id from deal_stages where key='qualification'");
  [{ id: wonStage }] = await owner<{ id: string }>("select id from deal_stages where key='won'");
  [{ id: serviceWeb }] = await owner<{ id: string }>("select id from services where key='web_development'");
});
afterAll(() => pool.end());

describe("deals", () => {
  it("rep creates a deal on own lead; it is recorded on the lead timeline; forecast = value × probability", async () => {
    const l = await lead(repA, { assigned_to: repA });
    const d = await deal(repA, { lead_id: l.id });
    expect(d.owner_id).toBe(repA);
    expect(Number(d.forecast_value)).toBe(2500);
    const acts = await owner<{ type: string }>("select type from lead_activities where lead_id=$1", [l.id]);
    expect(acts.map((a) => a.type)).toContain("deal");
  });

  it("rep cannot attach a deal to a lead they cannot see, or create deals for others", async () => {
    const hidden = await lead(salesMgr, { assigned_to: repB });
    await expect(deal(repA, { lead_id: hidden.id })).rejects.toThrow(/Lead not found/);
    const mine = await lead(repA, { assigned_to: repA });
    await expect(deal(repA, { lead_id: mine.id, owner_id: repB })).rejects.toThrow(/other people/);
  });

  it("reps see only their own deals; developers see none", async () => {
    const theirs = await deal(salesMgr, { lead_id: (await lead(salesMgr, { assigned_to: repB })).id, owner_id: repB });
    const visA = await asUser(repA, async (c) => (await c.query("select id from deals")).rows.map((r) => r.id));
    expect(visA).not.toContain(theirs.id);
    const visB = await asUser(repB, async (c) => (await c.query("select id from deals")).rows.map((r) => r.id));
    expect(visB).toContain(theirs.id);
    const visDev = await asUser(dev, async (c) => (await c.query("select count(*)::int n from deals")).rows[0].n);
    expect(visDev).toBe(0);
  });

  it("won/lost cannot be set by editing the stage directly", async () => {
    const d = await deal(repA, { lead_id: (await lead(repA, { assigned_to: repA })).id });
    await expect(asUser(repA, (c) => c.query("update deals set stage_id=$2 where id=$1", [d.id, wonStage]))).rejects.toThrow(
      /Mark won/,
    );
    await expect(deal(repA, { lead_id: d.lead_id, stage_id: wonStage })).rejects.toThrow(/cannot start as won/);
  });
});

describe("closing a deal (atomic conversion)", () => {
  it("mark won: lead → Won, client created once, deal linked, timeline + audit + notifications", async () => {
    const domain = `${uniq("won")}.com`;
    const l = await lead(repA, { assigned_to: repA, website: domain, email: `ceo@${domain}`, contact_name: "Ali" });
    const d = await deal(repA, { lead_id: l.id, service_id: serviceWeb });
    const r = await asUser(repA, async (c) => (await c.query("select mark_deal_won($1, 12500) r", [d.id])).rows[0].r);
    expect(r.client_id).toBeTruthy();

    const [after] = await owner<{ won_at: string; value: string; probability: number; client_id: string }>(
      "select won_at, value, probability, client_id from deals where id=$1", [d.id]);
    expect(after.won_at).toBeTruthy();
    expect(Number(after.value)).toBe(12500);
    expect(after.probability).toBe(100);
    expect(after.client_id).toBe(r.client_id);

    const [ld] = await owner<{ key: string; client_id: string }>(
      "select s.key, l.client_id from leads l join lead_statuses s on s.id=l.status_id where l.id=$1", [l.id]);
    expect(ld.key).toBe("won");
    expect(ld.client_id).toBe(r.client_id);

    const [cl] = await owner<{ company_name: string; account_manager_id: string; source_lead_id: string }>(
      "select company_name, account_manager_id, source_lead_id from clients where id=$1", [r.client_id]);
    expect(cl.company_name).toBe(l.company_name);
    expect(cl.account_manager_id).toBe(repA);
    expect(cl.source_lead_id).toBe(l.id);

    const types = (await owner<{ type: string }>("select type from lead_activities where lead_id=$1", [l.id])).map((a) => a.type);
    expect(types).toEqual(expect.arrayContaining(["deal_won", "converted", "status_change"]));
    const audits = (await owner<{ action: string }>("select action from audit_logs where entity_id=$1", [d.id])).map((a) => a.action);
    expect(audits).toContain("deal.won");
    const notes = await owner<{ user_id: string }>("select user_id from notifications where link=$1 and type='deal.won'", [`/app/deals/${d.id}`]);
    expect(notes.map((n) => n.user_id)).toContain(salesMgr);

    // Second won deal for another lead from the same company domain reuses the client.
    const l2 = await lead(salesMgr, { assigned_to: repA, website: `https://www.${domain}/shop` });
    const d2 = await deal(repA, { lead_id: l2.id });
    const r2 = await asUser(repA, async (c) => (await c.query("select mark_deal_won($1) r", [d2.id])).rows[0].r);
    expect(r2.client_id).toBe(r.client_id);
    const [{ n }] = await owner<{ n: number }>("select count(*)::int n from clients where website_domain=$1", [domain]);
    expect(n).toBe(1);

    // Won deals are closed.
    await expect(asUser(repA, (c) => c.query("select mark_deal_won($1)", [d.id]))).rejects.toThrow(/already won/);
    await expect(asUser(repA, (c) => c.query("update deals set value=1 where id=$1", [d.id]))).rejects.toThrow(/closed/);
  });

  it("another rep cannot close someone else's deal", async () => {
    const d = await deal(repA, { lead_id: (await lead(repA, { assigned_to: repA })).id });
    await expect(asUser(repB, (c) => c.query("select mark_deal_won($1)", [d.id]))).rejects.toThrow(/not found/);
  });

  it("mark lost requires a reason and moves the lead to Lost", async () => {
    const l = await lead(repA, { assigned_to: repA });
    const d = await deal(repA, { lead_id: l.id });
    await expect(asUser(repA, (c) => c.query("select mark_deal_lost($1, '')", [d.id]))).rejects.toThrow(/reason/);
    await asUser(repA, (c) => c.query("select mark_deal_lost($1, 'Chose a cheaper vendor')", [d.id]));
    const [ld] = await owner<{ key: string }>("select s.key from leads l join lead_statuses s on s.id=l.status_id where l.id=$1", [l.id]);
    expect(ld.key).toBe("lost");
  });

  it("manual conversion only for won leads, and only by sales managers", async () => {
    const l = await lead(salesMgr, { assigned_to: repA });
    await expect(asUser(salesMgr, (c) => c.query("select convert_lead_to_client($1)", [l.id]))).rejects.toThrow(/Only won/);
    await asOwner((c) => c.query("update leads set status_id=(select id from lead_statuses where key='won') where id=$1", [l.id]));
    await expect(asUser(repA, (c) => c.query("select convert_lead_to_client($1)", [l.id]))).rejects.toThrow(/Not allowed/);
    const id = await asUser(salesMgr, async (c) => (await c.query("select convert_lead_to_client($1) id", [l.id])).rows[0].id);
    const again = await asUser(salesMgr, async (c) => (await c.query("select convert_lead_to_client($1) id", [l.id])).rows[0].id);
    expect(again).toBe(id);
  });

  it("client conversion links can't be forged through the API", async () => {
    const l = await lead(repA, { assigned_to: repA });
    const [{ id: someClient }] = await owner<{ id: string }>("select id from clients limit 1");
    await asUser(repA, (c) => c.query("update leads set client_id=$2, max_funnel_rank=7 where id=$1", [l.id, someClient]));
    const [row] = await owner<{ client_id: string | null; max_funnel_rank: number }>(
      "select client_id, max_funnel_rank from leads where id=$1", [l.id]);
    expect(row.client_id).toBeNull();
    expect(row.max_funnel_rank).toBe(0);
  });
});

describe("funnel tracking", () => {
  it("records the furthest stage a lead ever reached", async () => {
    const l = await lead(repA, { assigned_to: repA });
    await asUser(repA, (c) => c.query("update leads set status_id=(select id from lead_statuses where key='meeting_scheduled') where id=$1", [l.id]));
    await asUser(repA, (c) => c.query("update leads set status_id=(select id from lead_statuses where key='follow_up_later') where id=$1", [l.id]));
    const [row] = await owner<{ max_funnel_rank: number }>("select max_funnel_rank from leads where id=$1", [l.id]);
    expect(row.max_funnel_rank).toBe(4);
  });
});

describe("proposals (evidence-based statuses)", () => {
  async function newProposal(uid = repA) {
    const d = await deal(uid, { lead_id: (await lead(uid, { assigned_to: uid })).id });
    return insert(uid, "proposals", { deal_id: d.id, title: "Website proposal", price: 9000, scope: "5 pages", expiry_date: "2099-01-01" });
  }

  it("is created as a draft; viewed/accepted can't be faked by staff", async () => {
    const p = await newProposal();
    expect(p.status).toBe("draft");
    await expect(asUser(repA, (c) => c.query("update proposals set status='viewed' where id=$1", [p.id]))).rejects.toThrow(/automatically/);
    await expect(asUser(repA, (c) => c.query("update proposals set status='accepted' where id=$1", [p.id]))).rejects.toThrow(/Only sent/);
    await asUser(repA, (c) => c.query("update proposals set status='sent' where id=$1", [p.id]));
    await expect(asUser(repA, (c) => c.query("update proposals set status='accepted' where id=$1", [p.id]))).rejects.toThrow(/evidence/);
    await expect(asUser(repA, (c) => c.query("update proposals set price=1 where id=$1", [p.id]))).rejects.toThrow(/cannot be edited/);
    await asUser(repA, (c) =>
      c.query("update proposals set status='accepted', response_evidence='Signed PDF received by email 14 Oct' where id=$1", [p.id]));
    const [row] = await owner<{ status: string; response_source: string; responded_at: string }>(
      "select status, response_source, responded_at from proposals where id=$1", [p.id]);
    expect(row).toMatchObject({ status: "accepted", response_source: "staff_recorded" });
    expect(row.responded_at).toBeTruthy();
  });

  it("client link records real views and the client's own response", async () => {
    const p = await newProposal();
    const view = (token: string) =>
      asRole("service_role", null, async (c) => (await c.query("select view_public_proposal($1) v", [token])).rows[0].v);
    expect(await view(p.public_token)).toBeNull(); // drafts are not public
    await asUser(repA, (c) => c.query("update proposals set status='sent' where id=$1", [p.id]));
    const v = await view(p.public_token);
    expect(v.status).toBe("viewed");
    expect(v.price).toBe(9000);
    await view(p.public_token);
    const [row] = await owner<{ view_count: number; first_viewed_at: string }>(
      "select view_count, first_viewed_at from proposals where id=$1", [p.id]);
    expect(row.view_count).toBe(2);
    expect(row.first_viewed_at).toBeTruthy();

    const respond = (accept: boolean, name: string) =>
      asRole("service_role", null, async (c) =>
        (await c.query("select respond_public_proposal($1,$2,$3,$4) r", [p.public_token, accept, name, "iphash-test-123456"])).rows[0].r);
    expect(await respond(true, "")).toEqual({ ok: false, error: "name_required" });
    expect(await respond(true, "Ayesha Malik")).toEqual({ ok: true });
    expect(await respond(false, "Ayesha Malik")).toEqual({ ok: false, error: "closed" });
    const [done] = await owner<{ status: string; response_source: string; response_name: string }>(
      "select status, response_source, response_name from proposals where id=$1", [p.id]);
    expect(done).toEqual({ status: "accepted", response_source: "client_link", response_name: "Ayesha Malik" });
    const notes = await owner<{ type: string }>("select type from notifications where user_id=$1 and type like 'proposal.%'", [repA]);
    expect(notes.map((n) => n.type)).toEqual(expect.arrayContaining(["proposal.viewed", "proposal.accepted"]));
  });

  it("random or malformed tokens reveal nothing; anon and staff can't call the public functions", async () => {
    const r = await asRole("service_role", null, async (c) =>
      (await c.query("select view_public_proposal($1) v", ["f".repeat(64)])).rows[0].v);
    expect(r).toBeNull();
    await expect(asRole("anon", null, (c) => c.query("select view_public_proposal($1)", ["a".repeat(64)]))).rejects.toThrow(/permission denied/);
    await expect(asUser(repA, (c) => c.query("select respond_public_proposal($1,true,'x','y')", ["a".repeat(64)]))).rejects.toThrow(/permission denied/);
  });

  it("expired proposals cannot be accepted", async () => {
    const p = await newProposal();
    await asUser(repA, (c) => c.query("update proposals set expiry_date='2020-01-01' where id=$1", [p.id]));
    await asUser(repA, (c) => c.query("update proposals set status='sent' where id=$1", [p.id]));
    const r = await asRole("service_role", null, async (c) =>
      (await c.query("select respond_public_proposal($1,true,'Client Name','h') r", [p.public_token])).rows[0].r);
    expect(r.error).toBe("expired");
  });
});

describe("commissions", () => {
  it("only approved rules apply; approval needs a second person; payment needs a reference", async () => {
    // A rule is created by one manager...
    const commissionsMgr = await createUser(["employee"]);
    await asOwner((c) => c.query(
      `insert into roles(key, name) values ($1, 'Finance') returning id`, [uniq("finance_").toLowerCase().replace(/[^a-z0-9_]/g, "")],
    ).then(async ({ rows }) => {
      await c.query("insert into role_permissions values ($1, 'commissions.manage'), ($1, 'reports.view')", [rows[0].id]);
      await c.query("insert into user_roles(user_id, role_id) values ($1, $2)", [commissionsMgr, rows[0].id]);
    }));
    const rule = await insert(commissionsMgr, "commission_rules", {
      name: "Web dev 5% for reps", service_id: serviceWeb, percent: 5, eligible_user_id: repB, effective_from: "2020-01-01",
    });
    expect(rule.status).toBe("pending");
    await expect(asUser(commissionsMgr, (c) => c.query("update commission_rules set status='approved' where id=$1", [rule.id])))
      .rejects.toThrow(/someone other/);

    // Deal won before approval → no commission.
    const l1 = await lead(repB, { assigned_to: repB });
    const d1 = await deal(repB, { lead_id: l1.id, service_id: serviceWeb, value: 20000 });
    const r1 = await asUser(repB, async (c) => (await c.query("select mark_deal_won($1) r", [d1.id])).rows[0].r);
    expect(r1.commission_id).toBeNull();

    // Super admin approves; rules are then immutable.
    await asUser(admin, (c) => c.query("update commission_rules set status='approved' where id=$1", [rule.id]));
    await expect(asUser(commissionsMgr, (c) => c.query("update commission_rules set percent=50 where id=$1", [rule.id])))
      .rejects.toThrow(/cannot be changed/);

    const l2 = await lead(repB, { assigned_to: repB });
    const d2 = await deal(repB, { lead_id: l2.id, service_id: serviceWeb, value: 20000 });
    const r2 = await asUser(repB, async (c) => (await c.query("select mark_deal_won($1) r", [d2.id])).rows[0].r);
    const [cm] = await owner<{ id: string; amount: string; status: string; user_id: string }>(
      "select id, amount, status, user_id from commissions where id=$1", [r2.commission_id]);
    expect(Number(cm.amount)).toBe(1000);
    expect(cm).toMatchObject({ status: "estimated", user_id: repB });

    // Rep sees own commission, not others; can't write commissions.
    const mine = await asUser(repB, async (c) => (await c.query("select id from commissions")).rows.map((r) => r.id));
    expect(mine).toContain(cm.id);
    const other = await asUser(repA, async (c) => (await c.query("select id from commissions")).rows.map((r) => r.id));
    expect(other).not.toContain(cm.id);
    await expect(asUser(repB, (c) => c.query("update commissions set amount=99999 where id=$1", [cm.id]))).rejects.toThrow(/permission denied/);
    await expect(asUser(repB, (c) => c.query("select set_commission_status($1,'approved')", [cm.id]))).rejects.toThrow(/Not allowed/);

    // Must be approved before paid; paid needs a reference.
    await expect(asUser(commissionsMgr, (c) => c.query("select set_commission_status($1,'paid','TX-1')", [cm.id]))).rejects.toThrow(/cannot move/);
    await asUser(commissionsMgr, (c) => c.query("select set_commission_status($1,'approved')", [cm.id]));
    await expect(asUser(commissionsMgr, (c) => c.query("select set_commission_status($1,'paid','')", [cm.id]))).rejects.toThrow(/reference/);
    await asUser(commissionsMgr, (c) => c.query("select set_commission_status($1,'paid','BANK-TX-8812')", [cm.id]));
    const [paid] = await owner<{ status: string; paid_reference: string }>("select status, paid_reference from commissions where id=$1", [cm.id]);
    expect(paid).toEqual({ status: "paid", paid_reference: "BANK-TX-8812" });
  });

  it("nobody can approve their own commission", async () => {
    const rule = await insert(admin, "commission_rules", { name: "Mgr 3%", percent: 3, eligible_user_id: salesMgr, effective_from: "2020-01-01" });
    await asUser(admin, (c) => c.query("update commission_rules set status='approved' where id=$1", [rule.id]));
    const d = await deal(salesMgr, { lead_id: (await lead(salesMgr, { assigned_to: salesMgr })).id, value: 1000 });
    const r = await asUser(salesMgr, async (c) => (await c.query("select mark_deal_won($1) r", [d.id])).rows[0].r);
    expect(r.commission_id).toBeTruthy();
    await asOwner((c) => c.query(
      "insert into user_roles(user_id, role_id) select $1, id from roles where key='super_admin'", [salesMgr]));
    await expect(asUser(salesMgr, (c) => c.query("select set_commission_status($1,'approved')", [r.commission_id]))).rejects.toThrow(/your own/);
    await asOwner((c) => c.query("delete from user_roles where user_id=$1 and role_id=(select id from roles where key='super_admin')", [salesMgr]));
  });
});

describe("lead merge", () => {
  it("moves history, fills gaps, archives the duplicate and keeps an audit trail", async () => {
    const a = await lead(coo, { assigned_to: repA, email: `${uniq("m")}@merge.io` });
    const b = await lead(coo, { phone: "+1 555 0100", website: `${uniq("merge")}.io` });
    await asUser(coo, (c) => c.query("insert into lead_activities(lead_id, type, body) values ($1,'note','Note on duplicate')", [b.id]));
    await expect(asUser(repA, (c) => c.query("select merge_leads($1,$2)", [a.id, b.id]))).rejects.toThrow(/Not allowed/);
    await asUser(coo, (c) => c.query("select merge_leads($1,$2)", [a.id, b.id]));
    const [s] = await owner<{ phone: string; website: string; assigned_to: string }>("select phone, website, assigned_to from leads where id=$1", [a.id]);
    expect(s.phone).toBe("+1 555 0100");
    expect(s.website).toBe(b.website);
    expect(s.assigned_to).toBe(repA);
    const [d] = await owner<{ archived_at: string; merged_into: string }>("select archived_at, merged_into from leads where id=$1", [b.id]);
    expect(d.archived_at).toBeTruthy();
    expect(d.merged_into).toBe(a.id);
    const notes = await owner<{ body: string }>("select body from lead_activities where lead_id=$1 and type='note'", [a.id]);
    expect(notes.map((n) => n.body)).toContain("Note on duplicate");
    const audits = await owner<{ action: string }>("select action from audit_logs where entity_id=$1 and action='lead.merged'", [a.id]);
    expect(audits).toHaveLength(1);
  });
});
