import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { asOwner, asRole, asUser, createUser, ipHash, pool, sourceId, statusId, uniq } from "./helpers";

let superAdmin: string, ceo: string, coo: string, salesMgr: string, repA: string, repB: string, disabledRep: string;
let manualSource: string, newStatus: string;

async function insertLeadAs(uid: string, fields: Record<string, unknown> = {}) {
  return asUser(uid, async (c) => {
    const base = { company_name: uniq("Acme "), source_id: manualSource, status_id: newStatus, ...fields };
    const keys = Object.keys(base);
    const { rows } = await c.query(
      `insert into leads(${keys.join(",")}) values (${keys.map((_, i) => `$${i + 1}`).join(",")}) returning *`,
      Object.values(base),
    );
    return rows[0];
  });
}

beforeAll(async () => {
  [superAdmin, ceo, coo, salesMgr, repA, repB] = await Promise.all([
    createUser(["super_admin"]),
    createUser(["ceo"]),
    createUser(["coo"]),
    createUser(["sales_manager"]),
    createUser(["sales_rep"]),
    createUser(["sales_rep"]),
  ]);
  disabledRep = await createUser(["sales_rep"], { status: "disabled" });
  manualSource = await sourceId("manual");
  newStatus = await statusId("new");
});

afterAll(async () => {
  await pool.end();
});

describe("anonymous visitors", () => {
  it("cannot read leads, profiles, audit logs or settings", async () => {
    for (const table of ["leads", "profiles", "audit_logs", "settings", "lead_submissions", "user_roles"]) {
      await expect(asRole("anon", null, (c) => c.query(`select * from ${table} limit 1`))).rejects.toThrow(
        /permission denied/,
      );
    }
  });

  it("can read the public service and country catalogue", async () => {
    const { rows } = await asRole("anon", null, (c) => c.query("select key from services where active"));
    expect(rows.length).toBeGreaterThan(0);
  });

  it("cannot call the lead intake function or write leads directly", async () => {
    await expect(
      asRole("anon", null, (c) => c.query("select submit_public_lead($1)", [{ email: "x@y.com" }])),
    ).rejects.toThrow(/permission denied/);
    await expect(
      asRole("anon", null, (c) =>
        c.query("insert into leads(company_name, source_id, status_id) values ('x', $1, $2)", [manualSource, newStatus]),
      ),
    ).rejects.toThrow(/permission denied/);
  });
});

describe("public lead intake (server, service role)", () => {
  it("creates a real lead with source, score, timeline and notifications", async () => {
    const company = uniq("Bright School ");
    const res = await asRole("service_role", null, (c) =>
      c.query("select submit_public_lead($1) as r", [
        {
          name: "Sara Khan", company, email: `${uniq("sara")}@brightschool.pk`, phone: "+92 300 1234567",
          country: "PK", service: "web_development", budget: "5k_15k", message: "We need a new site",
          ip_hash: ipHash(), page_path: "/contact", utm_source: "google",
        },
      ]),
    );
    const r = res.rows[0].r;
    expect(r.ok).toBe(true);

    const lead = await asOwner(async (c) =>
      (await c.query(
        "select l.*, s.key as source_key from leads l join lead_sources s on s.id = l.source_id where l.id = $1",
        [r.lead_id],
      )).rows[0],
    );
    expect(lead.source_key).toBe("website");
    expect(lead.utm_source).toBe("google");
    // target_country(15)+service(10)+no_website(10)+budget_known(10)+budget_high(15)+contact_complete(5) = 65
    expect(lead.score).toBe(65);
    expect(lead.temperature).toBe("hot");

    const acts = await asOwner(async (c) =>
      (await c.query("select type from lead_activities where lead_id = $1", [r.lead_id])).rows,
    );
    expect(acts.map((a) => a.type)).toContain("created");

    const notes = await asOwner(async (c) =>
      (await c.query("select user_id from notifications where link = $1", [`/app/leads/${r.lead_id}`])).rows,
    );
    const recipients = notes.map((n) => n.user_id);
    expect(recipients).toContain(coo); // has leads.assign
    expect(recipients).not.toContain(repA); // does not
  });

  it("uses campaign source when utm_campaign is present", async () => {
    const res = await asRole("service_role", null, (c) =>
      c.query("select submit_public_lead($1) as r", [
        { name: "A", company: uniq("Camp "), email: `${uniq("c")}@x.io`, ip_hash: ipHash(), utm_campaign: "q4" },
      ]),
    );
    const key = await asOwner(async (c) =>
      (await c.query("select s.key from leads l join lead_sources s on s.id = l.source_id where l.id = $1", [
        res.rows[0].r.lead_id,
      ])).rows[0].key,
    );
    expect(key).toBe("campaign");
  });

  it("rate-limits by IP and blocks rapid duplicate submissions", async () => {
    const ip = ipHash();
    const submit = (email: string) =>
      asRole("service_role", null, async (c) =>
        (await c.query("select submit_public_lead($1) as r", [{ name: "N", company: uniq("Co "), email, ip_hash: ip }]))
          .rows[0].r,
      );
    const email = `${uniq("dup")}@corp.com`;
    expect((await submit(email)).ok).toBe(true);
    expect((await submit(email)).error).toBe("duplicate_submission");
    for (let i = 0; i < 4; i++) expect((await submit(`${uniq("r")}@corp.com`)).ok).toBe(true);
    expect((await submit(`${uniq("r")}@corp.com`)).error).toBe("rate_limited");
  });

  it("rejects invalid email without inserting", async () => {
    const r = await asRole("service_role", null, async (c) =>
      (await c.query("select submit_public_lead($1) as r", [{ name: "N", company: "C", email: "nope", ip_hash: ipHash() }]))
        .rows[0].r,
    );
    expect(r).toEqual({ ok: false, error: "invalid_email" });
  });
});

describe("deduplication", () => {
  it("flags a possible duplicate by website domain without touching the original", async () => {
    const domain = `${uniq("dupe")}.com`;
    const a = await insertLeadAs(coo, { website: `https://www.${domain}/about` });
    const b = await insertLeadAs(coo, { website: `http://${domain}` });
    expect(a.website_domain).toBe(domain);
    expect(a.possible_duplicate_of).toBeNull();
    expect(b.possible_duplicate_of).toBe(a.id);
  });

  it("flags by phone across formats and by normalized company name", async () => {
    // unique 7-digit subscriber number per run so re-runs don't match earlier runs' leads
    const n = String(Date.now() % 10_000_000).padStart(7, "0");
    const a = await insertLeadAs(coo, { phone: `0300-${n.slice(0, 3)}-${n.slice(3)}` });
    const b = await insertLeadAs(coo, { phone: `+92 300 ${n}` });
    expect(b.possible_duplicate_of).toBe(a.id);

    const base = uniq("Zenith Traders");
    const c1 = await insertLeadAs(coo, { company_name: `${base} (Pvt) Ltd.` });
    const c2 = await insertLeadAs(coo, { company_name: `The ${base} LLC` });
    expect(c2.possible_duplicate_of).toBe(c1.id);
  });

  it("only mergers can dismiss a duplicate flag, and nobody can forge one", async () => {
    const domain = `${uniq("dd")}.com`;
    const a = await insertLeadAs(repA, { website: domain, assigned_to: repA });
    const b = await insertLeadAs(repA, { website: domain, assigned_to: repA });
    await asUser(repA, (c) => c.query("update leads set possible_duplicate_of = null where id = $1", [b.id]));
    const still = await asOwner(async (c) => (await c.query("select possible_duplicate_of from leads where id=$1", [b.id])).rows[0]);
    expect(still.possible_duplicate_of).toBe(a.id);

    await asUser(salesMgr, (c) => c.query("update leads set possible_duplicate_of = null where id = $1", [b.id]));
    const cleared = await asOwner(async (c) => (await c.query("select possible_duplicate_of from leads where id=$1", [b.id])).rows[0]);
    expect(cleared.possible_duplicate_of).toBeNull();
  });
});

describe("sales representative isolation", () => {
  it("sees own leads only", async () => {
    const mine = await insertLeadAs(repA, { assigned_to: repA });
    const theirs = await insertLeadAs(salesMgr, { assigned_to: repB });
    const visible = await asUser(repA, async (c) => (await c.query("select id from leads")).rows.map((r) => r.id));
    expect(visible).toContain(mine.id);
    expect(visible).not.toContain(theirs.id);
  });

  it("cannot update another rep's lead (IDOR)", async () => {
    const theirs = await insertLeadAs(salesMgr, { assigned_to: repB });
    const res = await asUser(repA, (c) => c.query("update leads set company_name='hijack' where id=$1", [theirs.id]));
    expect(res.rowCount).toBe(0);
  });

  it("cannot assign leads to others, reassign, or archive", async () => {
    await expect(insertLeadAs(repA, { assigned_to: repB })).rejects.toThrow(/Not allowed to assign/);
    const mine = await insertLeadAs(repA, { assigned_to: repA });
    await expect(
      asUser(repA, (c) => c.query("update leads set assigned_to=$2 where id=$1", [mine.id, repB])),
    ).rejects.toThrow(/Not allowed to reassign/);
    await expect(
      asUser(repA, (c) => c.query("update leads set archived_at=now() where id=$1", [mine.id])),
    ).rejects.toThrow(/Not allowed to archive/);
  });

  it("cannot forge created_by or score", async () => {
    const mine = await insertLeadAs(repA, { assigned_to: repA, created_by: repB, score: 99 } as never);
    expect(mine.created_by).toBe(repA);
    expect(mine.score).not.toBe(99);
  });

  it("cannot delete leads at all", async () => {
    const mine = await insertLeadAs(repA, { assigned_to: repA });
    const res = await asUser(repA, (c) => c.query("delete from leads where id=$1", [mine.id]));
    expect(res.rowCount).toBe(0);
  });

  it("cannot read the audit log or other people's profiles", async () => {
    const audit = await asUser(repA, async (c) => (await c.query("select * from audit_logs")).rows);
    expect(audit).toHaveLength(0);
    const profiles = await asUser(repA, async (c) => (await c.query("select id from profiles")).rows.map((r) => r.id));
    expect(profiles).toEqual([repA]);
    const dir = await asUser(repA, async (c) => (await c.query("select * from directory where id=$1", [repB])).rows);
    expect(dir).toHaveLength(1);
    expect(Object.keys(dir[0])).not.toContain("email");
  });
});

describe("timeline integrity", () => {
  it("records status changes and assignment automatically, with actor", async () => {
    const lead = await insertLeadAs(coo);
    const qualified = await statusId("qualified");
    await asUser(coo, (c) => c.query("update leads set status_id=$2, assigned_to=$3 where id=$1", [lead.id, qualified, repA]));
    const acts = await asOwner(async (c) =>
      (await c.query("select type, actor_id, metadata from lead_activities where lead_id=$1 order by created_at", [lead.id])).rows,
    );
    const status = acts.find((a) => a.type === "status_change");
    expect(status?.actor_id).toBe(coo);
    expect(status?.metadata.to).toBe("Qualified");
    expect(acts.find((a) => a.type === "assigned")?.metadata.to).toBe(repA);

    const notif = await asUser(repA, async (c) =>
      (await c.query("select type from notifications where link=$1", [`/app/leads/${lead.id}`])).rows,
    );
    expect(notif.map((n) => n.type)).toContain("lead.assigned");
  });

  it("only allows manual activity types and forces the actor", async () => {
    const mine = await insertLeadAs(repA, { assigned_to: repA });
    await expect(
      asUser(repA, (c) =>
        c.query("insert into lead_activities(lead_id, type) values ($1, 'status_change')", [mine.id]),
      ),
    ).rejects.toThrow(/system-managed/);

    const note = await asUser(repA, async (c) =>
      (await c.query(
        "insert into lead_activities(lead_id, type, body, actor_id) values ($1,'note','hello',$2) returning actor_id",
        [mine.id, repB],
      )).rows[0],
    );
    expect(note.actor_id).toBe(repA);
  });

  it("logging a call updates last_contacted_at", async () => {
    const mine = await insertLeadAs(repA, { assigned_to: repA });
    await asUser(repA, (c) => c.query("insert into lead_activities(lead_id, type, body) values ($1,'call','Intro call')", [mine.id]));
    const l = await asOwner(async (c) => (await c.query("select last_contacted_at from leads where id=$1", [mine.id])).rows[0]);
    expect(l.last_contacted_at).not.toBeNull();
  });

  it("cannot add notes to leads the user cannot edit", async () => {
    const theirs = await insertLeadAs(salesMgr, { assigned_to: repB });
    await expect(
      asUser(repA, (c) => c.query("insert into lead_activities(lead_id, type, body) values ($1,'note','x')", [theirs.id])),
    ).rejects.toThrow(/row-level security/);
  });

  it("history is append-only", async () => {
    const mine = await insertLeadAs(repA, { assigned_to: repA });
    await expect(asUser(repA, (c) => c.query("update lead_activities set body='x' where lead_id=$1", [mine.id]))).rejects.toThrow(
      /permission denied/,
    );
    await expect(asUser(superAdmin, (c) => c.query("delete from audit_logs"))).rejects.toThrow(/permission denied/);
  });

  it("engagement signals raise the score and persist through history", async () => {
    const lead = await insertLeadAs(coo);
    const meeting = await statusId("meeting_scheduled");
    const negotiation = await statusId("negotiation");
    await asUser(coo, (c) => c.query("update leads set status_id=$2 where id=$1", [lead.id, meeting]));
    await asUser(coo, (c) => c.query("update leads set status_id=$2 where id=$1", [lead.id, negotiation]));
    const l = await asOwner(async (c) => (await c.query("select score, score_breakdown from leads where id=$1", [lead.id])).rows[0]);
    expect(l.score_breakdown.map((b: { signal: string }) => b.signal)).toContain("meeting_booked");
    expect(l.score).toBeGreaterThan(lead.score);
  });
});

describe("privilege escalation", () => {
  it("users cannot grant themselves roles", async () => {
    await expect(
      asUser(repA, (c) =>
        c.query("insert into user_roles(user_id, role_id) select $1, id from roles where key='super_admin'", [repA]),
      ),
    ).rejects.toThrow(/row-level security|own roles/);
  });

  it("role managers cannot change their own roles or grant Super Admin", async () => {
    const roleAdmin = await createUser([]);
    await asOwner(async (c) => {
      const { rows } = await c.query("insert into roles(key, name) values ($1, 'Role Admin') returning id", [uniq("roleadmin_")]);
      await c.query("insert into role_permissions(role_id, permission_key) values ($1, 'users.manage_roles')", [rows[0].id]);
      await c.query("insert into user_roles(user_id, role_id) values ($1, $2)", [roleAdmin, rows[0].id]);
    });
    await expect(
      asUser(roleAdmin, (c) =>
        c.query("insert into user_roles(user_id, role_id) select $1, id from roles where key='ceo'", [roleAdmin]),
      ),
    ).rejects.toThrow(/own roles/);
    await expect(
      asUser(roleAdmin, (c) =>
        c.query("insert into user_roles(user_id, role_id) select $1, id from roles where key='super_admin'", [repB]),
      ),
    ).rejects.toThrow(/Only a Super Admin/);
    // Allowed: grant a normal role to someone else, recorded with assigned_by
    const ok = await asUser(roleAdmin, async (c) =>
      (await c.query(
        "insert into user_roles(user_id, role_id) select $1, id from roles where key='marketing' returning assigned_by",
        [repB],
      )).rows[0],
    );
    expect(ok.assigned_by).toBe(roleAdmin);
  });

  it("only Super Admin can change what a role is allowed to do", async () => {
    const salesRepRole = await asOwner(async (c) => (await c.query("select id from roles where key='sales_rep'")).rows[0].id);
    await expect(
      asUser(coo, (c) =>
        c.query("insert into role_permissions(role_id, permission_key) values ($1, 'leads.view_all')", [salesRepRole]),
      ),
    ).rejects.toThrow(/row-level security/);
  });

  it("employees cannot change their own status, department or designation", async () => {
    await asUser(repA, (c) => c.query("update profiles set designation='CEO', status='active', full_name='Rep A' where id=$1", [repA]));
    const p = await asOwner(async (c) => (await c.query("select designation, full_name from profiles where id=$1", [repA])).rows[0]);
    expect(p.designation).toBeNull();
    expect(p.full_name).toBe("Rep A");
  });

  it("disabled accounts have no permissions", async () => {
    const perms = await asUser(disabledRep, async (c) => (await c.query("select * from my_permissions()")).rows);
    expect(perms).toHaveLength(0);
    const leads = await asUser(disabledRep, async (c) => (await c.query("select id from leads")).rows);
    expect(leads).toHaveLength(0);
  });

  it("CEO can view everything but cannot change system settings", async () => {
    const res = await asUser(ceo, (c) => c.query("update settings set value='{}' where key='branding'"));
    expect(res.rowCount).toBe(0);
    const ok = await asUser(superAdmin, (c) => c.query("update settings set value = value where key='branding'"));
    expect(ok.rowCount).toBe(1);
  });

  it("users can only mark their own notifications read, nothing else", async () => {
    await expect(
      asUser(repA, (c) => c.query("update notifications set title='x' where user_id=$1", [repA])),
    ).rejects.toThrow(/permission denied/);
    const lead = await insertLeadAs(coo, { assigned_to: repB });
    const res = await asUser(repA, (c) =>
      c.query("update notifications set read_at=now() where link=$1", [`/app/leads/${lead.id}`]),
    );
    expect(res.rowCount).toBe(0);
  });

  it("role changes are audited", async () => {
    const target = await createUser([]);
    await asUser(superAdmin, (c) =>
      c.query("insert into user_roles(user_id, role_id) select $1, id from roles where key='developer'", [target]),
    );
    const a = await asOwner(async (c) =>
      (await c.query("select actor_id, metadata from audit_logs where action='role.granted' and entity_id=$1", [target])).rows,
    );
    expect(a.find((x) => x.actor_id === superAdmin)?.metadata.role).toBe("developer");
  });
});
