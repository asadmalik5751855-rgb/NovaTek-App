import { afterAll, describe, expect, it } from "vitest";
import { PERMISSIONS } from "@/lib/auth/permissions";
import { asOwner, pool } from "./helpers";

afterAll(() => pool.end());

describe("app ↔ database parity", () => {
  it("the app knows exactly the permissions the database defines", async () => {
    const rows = await asOwner(async (c) => (await c.query("select key from permissions order by key")).rows.map((r) => r.key));
    expect([...PERMISSIONS].sort()).toEqual(rows);
  });

  it("every table in public has row level security enabled and forced", async () => {
    const rows = await asOwner(async (c) => (await c.query(
      "select relname from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r' and not (c.relrowsecurity and c.relforcerowsecurity)",
    )).rows);
    expect(rows).toEqual([]);
  });

  it("anonymous visitors can execute only the functions meant for them", async () => {
    const rows = await asOwner(async (c) => (await c.query(
      "select p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and has_function_privilege('anon', p.oid, 'execute') order by 1",
    )).rows.map((r) => r.proname));
    expect(rows).toEqual(["public_branding"]);
  });
});
