import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { asOwner, asRole, asUser, createUser, pool, sourceId, statusId, uniq } from "./helpers";

let admin: string, cto: string, devA: string, devB: string, repA: string, repB: string, coo: string, designer: string;
let manual: string, newStatus: string;

async function insert(uid: string, table: string, fields: Record<string, unknown>) {
  return asUser(uid, async (c) => {
    const keys = Object.keys(fields);
    const { rows } = await c.query(
      `insert into ${table}(${keys.join(",")}) values (${keys.map((_, i) => `$${i + 1}`).join(",")}) returning *`,
      Object.values(fields),
    );
    return rows[0];
  });
}
const owner = <T>(sql: string, params: unknown[] = []) => asOwner(async (c) => (await c.query(sql, params)).rows as T[]);
const ids = (uid: string, table: string) => asUser(uid, async (c) => (await c.query(`select id from ${table}`)).rows.map((r) => r.id));

beforeAll(async () => {
  [admin, cto, devA, devB, repA, repB, coo, designer] = await Promise.all([
    createUser(["super_admin"]), createUser(["cto"]), createUser(["developer"]), createUser(["developer"]),
    createUser(["sales_rep"]), createUser(["sales_rep"]), createUser(["coo"]), createUser(["designer"]),
  ]);
  manual = await sourceId("manual");
  newStatus = await statusId("new");
});
afterAll(() => pool.end());

describe("projects", () => {
  it("only project managers create projects; members are notified; progress follows tasks", async () => {
    await expect(insert(devA, "projects", { name: "Nope" })).rejects.toThrow(/row-level security/);
    const p = await insert(cto, "projects", { name: uniq("Portal "), manager_id: cto, status: "active" });
    await insert(cto, "project_members", { project_id: p.id, user_id: devA, role: "Backend" });
    const notes = await owner<{ type: string }>("select type from notifications where user_id=$1 and link=$2", [devA, `/app/projects/${p.id}`]);
    expect(notes.map((n) => n.type)).toContain("project.member");

    const t1 = await insert(cto, "tasks", { title: "API", project_id: p.id, assignee_id: devA, kind: "technical" });
    await insert(cto, "tasks", { title: "UI", project_id: p.id, assignee_id: devA });
    await asUser(devA, (c) => c.query("update tasks set status='completed' where id=$1", [t1.id]));
    const [row] = await owner<{ progress: number }>("select progress from projects where id=$1", [p.id]);
    expect(row.progress).toBe(50);
  });

  it("a member who is not a manager cannot change budget or manager", async () => {
    const p = await insert(cto, "projects", { name: uniq("Budgeted "), manager_id: devB, budget: 5000 });
    await asUser(devB, (c) => c.query("update projects set budget=999999, manager_id=$2, status='review' where id=$1", [p.id, devA]));
    const [row] = await owner<{ budget: string; manager_id: string; status: string }>("select budget, manager_id, status from projects where id=$1", [p.id]);
    expect(Number(row.budget)).toBe(5000);
    expect(row.manager_id).toBe(devB);
    expect(row.status).toBe("review");
  });
});

describe("tasks", () => {
  it("anyone can create a task for themselves; only assigners can assign others", async () => {
    const mine = await insert(repA, "tasks", { title: "Prepare call notes" });
    expect(mine.assignee_id).toBe(repA);
    await expect(insert(repA, "tasks", { title: "Do my work", assignee_id: repB })).rejects.toThrow(/assign tasks to other/);
    const forDev = await insert(coo, "tasks", { title: "Fix checkout", assignee_id: devA, kind: "bug", priority: "urgent" });
    const n = await owner<{ priority: string }>("select priority from notifications where user_id=$1 and link=$2", [devA, `/app/tasks/${forDev.id}`]);
    expect(n[0].priority).toBe("high");
  });

  it("people see their own tasks, not a colleague's private ones (unless they have project visibility)", async () => {
    const t = await insert(repA, "tasks", { title: uniq("Private follow-up ") });
    expect(await ids(repB, "tasks")).not.toContain(t.id);
    expect(await ids(repA, "tasks")).toContain(t.id);
    expect(await ids(coo, "tasks")).toContain(t.id); // tasks.assign → oversight
    const r = await asUser(repB, (c) => c.query("update tasks set title='hijack' where id=$1", [t.id]));
    expect(r.rowCount).toBe(0);
  });

  it("assignee can complete; completion stamps time and notifies the creator", async () => {
    const t = await insert(coo, "tasks", { title: uniq("Review copy "), assignee_id: designer, kind: "design" });
    await asUser(designer, (c) => c.query("update tasks set status='completed' where id=$1", [t.id]));
    const [row] = await owner<{ completed_at: string }>("select completed_at from tasks where id=$1", [t.id]);
    expect(row.completed_at).toBeTruthy();
    const notes = await owner<{ type: string }>("select type from notifications where user_id=$1 and link=$2", [coo, `/app/tasks/${t.id}`]);
    expect(notes.map((x) => x.type)).toContain("task.completed");
    await expect(asUser(designer, (c) => c.query("update tasks set assignee_id=$2 where id=$1", [t.id, devA]))).rejects.toThrow(/reassign/);
  });

  it("cannot link a task to a lead the user cannot see", async () => {
    const hidden = await insert(coo, "leads", { company_name: uniq("Hidden "), source_id: manual, status_id: newStatus, assigned_to: repB });
    await expect(insert(repA, "tasks", { title: "Snoop", lead_id: hidden.id })).rejects.toThrow(/Lead not found/);
    const own = await insert(repA, "leads", { company_name: uniq("Own "), source_id: manual, status_id: newStatus, assigned_to: repA });
    await insert(repA, "tasks", { title: "Send brochure", lead_id: own.id });
    const acts = await owner<{ type: string }>("select type from lead_activities where lead_id=$1", [own.id]);
    expect(acts.map((a) => a.type)).toContain("task");
  });
});

describe("meetings", () => {
  it("scheduling with a lead: timeline entry, meeting-booked score, participant invite", async () => {
    const l = await insert(repA, "leads", { company_name: uniq("Meet Co "), source_id: manual, status_id: newStatus, assigned_to: repA });
    const before = l.score;
    const start = new Date(Date.now() + 3 * 864e5).toISOString();
    const m = await insert(repA, "meetings", { title: "Discovery call", lead_id: l.id, starts_at: start, meeting_link: "https://meet.example.com/abc" });
    await insert(repA, "meeting_participants", { meeting_id: m.id, user_id: coo });
    const [after] = await owner<{ score: number; breakdown: { signal: string }[] }>(
      "select score, score_breakdown breakdown from leads where id=$1", [l.id]);
    expect(after.score).toBe(before + 20);
    expect(after.breakdown.map((b) => b.signal)).toContain("meeting_booked");
    const acts = await owner<{ type: string }>("select type from lead_activities where lead_id=$1", [l.id]);
    expect(acts.map((a) => a.type)).toContain("meeting_scheduled");
    expect(await ids(coo, "meetings")).toContain(m.id);
    expect(await ids(repB, "meetings")).not.toContain(m.id);

    // Can't claim a future meeting happened.
    await expect(asUser(repA, (c) => c.query("update meetings set status='completed' where id=$1", [m.id]))).rejects.toThrow(/before it starts/);
    await expect(asUser(repA, (c) => c.query("update meetings set status='no_show' where id=$1", [m.id]))).rejects.toThrow(/after the start/);
    // Non-https links are refused.
    await expect(insert(repA, "meetings", { title: "x", starts_at: start, meeting_link: "javascript:alert(1)" })).rejects.toThrow(/check constraint/);
  });

  it("completing a past meeting records contact on the lead", async () => {
    const l = await insert(repA, "leads", { company_name: uniq("Past "), source_id: manual, status_id: newStatus, assigned_to: repA });
    const m = await insert(repA, "meetings", { title: "Intro", lead_id: l.id, starts_at: new Date(Date.now() - 3600e3).toISOString() });
    await asUser(repA, (c) => c.query("update meetings set status='completed', outcome='Agreed on scope' where id=$1", [m.id]));
    const [row] = await owner<{ last_contacted_at: string }>("select last_contacted_at from leads where id=$1", [l.id]);
    expect(row.last_contacted_at).toBeTruthy();
    await expect(asUser(repA, (c) => c.query("update meetings set status='cancelled' where id=$1", [m.id]))).rejects.toThrow(/already closed/);
  });

  it("cannot book a meeting on someone else's lead", async () => {
    const hidden = await insert(coo, "leads", { company_name: uniq("NotYours "), source_id: manual, status_id: newStatus, assigned_to: repB });
    await expect(insert(repA, "meetings", { title: "x", lead_id: hidden.id, starts_at: new Date().toISOString() })).rejects.toThrow(/Lead not found/);
  });
});

describe("scheduled notifications", () => {
  it("sends due/overdue/meeting/follow-up reminders exactly once", async () => {
    const t = await insert(coo, "tasks", { title: uniq("Overdue "), assignee_id: devB, due_at: new Date(Date.now() - 3600e3).toISOString() });
    const l = await insert(repA, "leads", {
      company_name: uniq("Late "), source_id: manual, status_id: newStatus, assigned_to: repA,
      next_follow_up_at: new Date(Date.now() - 7200e3).toISOString(),
    });
    const m = await insert(repA, "meetings", { title: "Soon", starts_at: new Date(Date.now() + 20 * 60e3).toISOString() });
    const run = () => asRole("service_role", null, async (c) => (await c.query("select run_scheduled_notifications() r")).rows[0].r);
    const first = await run();
    expect(first.tasks_overdue).toBeGreaterThanOrEqual(1);
    await run();
    const count = async (uid: string, link: string, type: string) =>
      (await owner<{ n: number }>("select count(*)::int n from notifications where user_id=$1 and link=$2 and type=$3", [uid, link, type]))[0].n;
    expect(await count(devB, `/app/tasks/${t.id}`, "task.overdue")).toBe(1);
    expect(await count(repA, `/app/leads/${l.id}`, "followup.overdue")).toBe(1);
    expect(await count(repA, `/app/meetings/${m.id}`, "meeting.approaching")).toBe(1);
    await expect(asUser(admin, (c) => c.query("select run_scheduled_notifications()"))).rejects.toThrow(/permission denied/);
  });

  it("announcements reach every active user and require settings.manage", async () => {
    await expect(asUser(coo, (c) => c.query("select send_announcement('Office closed Friday','',null)"))).rejects.toThrow(/Not allowed/);
    const id = await asUser(admin, async (c) => (await c.query("select send_announcement('Office closed Friday','Eid holiday','high') id")).rows[0].id);
    const n = await owner<{ n: number }>("select count(*)::int n from notifications where dedupe_key=$1", [`announcement:${id}`]);
    const active = await owner<{ n: number }>("select count(*)::int n from profiles where status='active'");
    expect(n[0].n).toBe(active[0].n);
  });
});

describe("documents", () => {
  it("document rows follow the parent's access", async () => {
    const own = await insert(repA, "leads", { company_name: uniq("Doc "), source_id: manual, status_id: newStatus, assigned_to: repA });
    const d = await insert(repA, "documents", {
      entity: "lead", entity_id: own.id, name: "brief.pdf", storage_path: `lead/${own.id}/${uniq("f")}-brief.pdf`, size_bytes: 1000, mime_type: "application/pdf",
    });
    expect(await ids(repB, "documents")).not.toContain(d.id);
    expect(await ids(repA, "documents")).toContain(d.id);
    const hidden = await insert(coo, "leads", { company_name: uniq("HiddenDoc "), source_id: manual, status_id: newStatus, assigned_to: repB });
    await expect(insert(repA, "documents", {
      entity: "lead", entity_id: hidden.id, name: "x.pdf", storage_path: `lead/${hidden.id}/x.pdf`, size_bytes: 10, mime_type: "application/pdf",
    })).rejects.toThrow(/row-level security/);
  });
});
