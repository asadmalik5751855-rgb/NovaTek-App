/**
 * BRAND LOCK — the NovaTek logo and the "NovaTek" wordmark (its custom font) must never change on the website.
 *
 * These tests fail the build if:
 *  - the supplied logo / app-icon files are modified or replaced (byte-exact SHA-256 pin);
 *  - brand config dimensions drift from the real files (would distort the logo);
 *  - any file other than the BrandLogo component references the logo files directly;
 *  - the BrandLogo component applies filters, blend modes, rotation, opacity or non-proportional sizing;
 *  - "NovaTek" is typed out as a standalone text element anywhere (i.e. a web-font imitation of the wordmark).
 *
 * If the owner ever supplies a NEW official logo, replace the files AND update the pinned hashes in one reviewed change.
 */
import { createHash } from "node:crypto";
import { readFileSync, readdirSync, statSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { brand } from "@/lib/config/brand";

const ROOT = path.resolve(__dirname, "../..");
const PUBLIC = path.join(ROOT, "public");
const SRC = path.join(ROOT, "src");

const PINNED = {
  "/brand/novatek-logo-horizontal.png": "8609697a910a37aeaf4466bce75c88fbcd431868843d2f1b7d2e59b1145e383b",
  "/brand/novatek-app-icon.png": "2efe84ea1016e4f3cb1fda5f2baeb9aa0e90e3ff9015c8af0fc9d2d885f26b7e",
} as const;

const sha256 = (p: string) => createHash("sha256").update(readFileSync(p)).digest("hex");

function pngSize(p: string) {
  const b = readFileSync(p);
  expect(b.subarray(1, 4).toString()).toBe("PNG");
  return { width: b.readUInt32BE(16), height: b.readUInt32BE(20) };
}

function walk(dir: string): string[] {
  return readdirSync(dir).flatMap((n) => {
    const p = path.join(dir, n);
    return statSync(p).isDirectory() ? walk(p) : [p];
  });
}
const sourceFiles = walk(SRC).filter((f) => /\.(tsx?|css)$/.test(f));
const rel = (f: string) => path.relative(ROOT, f);

describe("brand lock: logo files", () => {
  it.each(Object.entries(PINNED))("%s is byte-identical to the supplied original", (src, hash) => {
    expect(sha256(path.join(PUBLIC, src))).toBe(hash);
  });

  it("brand config points at the pinned files", () => {
    expect(brand.logo.horizontal.src).toBe("/brand/novatek-logo-horizontal.png");
    expect(brand.logo.icon.src).toBe("/brand/novatek-app-icon.png");
  });

  it("brand config dimensions match the real files (no distortion)", () => {
    for (const l of [brand.logo.horizontal, brand.logo.icon]) {
      const real = pngSize(path.join(PUBLIC, l.src));
      expect({ width: l.width, height: l.height }).toEqual(real);
    }
  });

  it("company name is exactly NovaTek", () => {
    expect(brand.companyName).toBe("NovaTek");
  });
});

describe("brand lock: how the logo is rendered", () => {
  const LOGO_COMPONENT = "src/components/brand/brand-logo.tsx";
  const BRAND_CONFIG = "src/lib/config/brand.ts";

  it("only the BrandLogo component and brand config reference logo files", () => {
    const offenders = sourceFiles
      .filter((f) => ![LOGO_COMPONENT, BRAND_CONFIG].includes(rel(f)))
      .filter((f) => /novatek-(logo-horizontal|app-icon)/.test(readFileSync(f, "utf8")))
      .map(rel);
    expect(offenders).toEqual([]);
  });

  it("BrandLogo applies no filters, blends, transforms, opacity or object-fit tricks", () => {
    // strip comments so the documentation of the rule doesn't trip the check
    const code = readFileSync(path.join(ROOT, LOGO_COMPONENT), "utf8")
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/\/\/.*$/gm, "");
    expect(code).not.toMatch(
      /\b(filter|invert|grayscale|sepia|saturate|hue-rotate|brightness|contrast|mix-blend|blend|rotate|skew|scale-|opacity|object-cover|object-fill|clip-path|mask)\b/,
    );
  });

  it("BrandLogo serves the original files untouched and keeps the exact aspect ratio", () => {
    const code = readFileSync(path.join(ROOT, LOGO_COMPONENT), "utf8");
    expect(code.match(/^\s*unoptimized$/gm)?.length).toBe(2); // both logo and icon: original bytes, no re-encoding
    expect(code).toMatch(/width: "auto"/); // scale by height only — never two independent dimensions
    expect(code).not.toMatch(/Math\.round/);
  });

  it("no global CSS targets the logo images", () => {
    const css = sourceFiles.filter((f) => f.endsWith(".css")).map((f) => readFileSync(f, "utf8")).join("\n");
    // colour tokens like --brand-blue are fine; selectors that could restyle the logo image are not
    const selectors = css.replace(/\/\*[\s\S]*?\*\//g, "").match(/[^{}]+(?=\{)/g) ?? [];
    expect(selectors.filter((s) => /\bimg\b|logo|novatek-|\/brand\//i.test(s))).toEqual([]);
  });

  it('"NovaTek" is never typed out as a standalone text element (no web-font imitation of the wordmark)', () => {
    const offenders = sourceFiles
      .filter((f) => f.endsWith(".tsx"))
      .filter((f) => {
        const code = readFileSync(f, "utf8");
        return (
          />\s*NovaTek\s*</.test(code) || // <span>NovaTek</span>
          />\s*\{\s*brand\.companyName\s*\}\s*</.test(code) // <span>{brand.companyName}</span>
        );
      })
      .map(rel);
    expect(offenders).toEqual([]);
  });
});
